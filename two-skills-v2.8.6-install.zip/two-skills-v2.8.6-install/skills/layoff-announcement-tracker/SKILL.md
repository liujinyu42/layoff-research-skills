---
name: layoff-announcement-tracker
description: Collect layoff table rows from Layoffs.fyi company pages, then confirm distinct events using Google Search and one publisher page per event.
---
# Layoff announcement tracker — v2.8.6

Use this workflow for new runs. The older bulk seed, RSS, per-alias/per-year discovery and automatic follow-up collectors are not steps in this workflow. Do not run run_collection.py or delegate discovery to the legacy workflow. Use the bundled coding definitions and Excel column template for delivery.

1. Verify the requested company identities, CIDs and observation window. Create a fresh work directory. For each company, run the command below serially using the public brand (not its CID). The script archives the company page, extracts Date, Employees, %, and Source, and does not visit Source links. It needs Python with beautifulsoup4. Use --slug only for a verified listing slug. Check the archived page heading against the target before attributing rows. Preserve the raw table; apply window filters and distinguish publication from event dates during review.

    python scripts/company_table.py --work WORK --cid CID --company "Company name"

2. If the table is rendered dynamically, open the company URL once in the browser, save its rendered HTML and use --html FILE with the same command. If access is restricted, stop that channel, record the blocker and continue with Google. Never equate a missing table with no events. Honor site throttling, including Retry-After. Do not start concurrent tracker requests.

3. Once the tracker pass is finished, use the host browser to execute the Google query in each company's JSON receipt (default: COMPANY layoffs details from 2019 to 2026; override --start and --end for other years). Inspect result titles, dates and publishers for new events as well as matches. Maintain a shared URL ledger; strip fragments and tracking parameters, reuse stored pages across companies and events. Group leads by employer, announcement timing, affected unit and plan before opening articles. Select one credible, accessible page per distinct event. Stop fetching corroboration once that page confirms the event. Try a different result only if the first cannot confirm it. Record the selected URL, excerpt and date; keep unsupported quantities null. Do not merge independent rounds merely because their dates are close. Mark blocked searches and unconfirmed leads PARTIAL.

4. Export one row per verified event using the bundled output columns and one Results sheet. Deliver the raw tracker receipts, search and URL ledger, event-to-source map and unresolved leads alongside it. Validate CID, window, source, duplicate plan identity and count qualifiers. Legacy audit requirements for superseded search channels must not be marked passed or populated with synthetic receipts.
