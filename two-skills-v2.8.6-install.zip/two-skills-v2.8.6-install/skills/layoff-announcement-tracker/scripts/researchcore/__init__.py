VERSION = "2.8.4"

# The runtime version a workspace must report. It is the version of
# the code that reads the workspace, and it is checked so that a workspace
# written by one runtime is not read by another without being noticed.
RUNTIME_VERSION = VERSION
