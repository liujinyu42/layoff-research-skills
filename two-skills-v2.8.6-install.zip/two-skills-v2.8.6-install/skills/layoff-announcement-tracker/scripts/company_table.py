"""Collect one company's raw tracker rows, without following article links."""
import argparse, hashlib, json, re, time
from pathlib import Path
from urllib.parse import quote, urljoin
from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

def parse(html, url):
    soup = BeautifulSoup(html, 'html.parser')
    rows = []
    found = False
    for table in soup.select('table'):
        idx = None
        for tr in table.select('tr'):
            cells = tr.find_all(['th','td'], recursive=False)
            vals = [c.get_text(' ', strip=True) for c in cells]
            keys = [v.lower() for v in vals]
            fields = ['date','employees','%','source']
            if all(k in keys for k in fields):
                idx = [keys.index(k) for k in fields]
                found = True
            elif idx and len(cells)>max(idx):
                row = dict(zip(fields,[vals[i] for i in idx]))
                a = cells[idx[-1]].find('a',href=True)
                row['source_url'] = urljoin(url,a['href']) if a else None
                rows.append(row)
    return found,rows

def main():
    p=argparse.ArgumentParser()
    for k in ('company','cid','work'): p.add_argument('--'+k,required=True)
    for k in ('slug','html'): p.add_argument('--'+k)
    p.add_argument('--start',type=int,default=2019);p.add_argument('--end',type=int,default=2026)
    a=p.parse_args(); d=Path(a.work)/'company-tables';d.mkdir(parents=True,exist_ok=True)
    slug=a.slug or re.sub(r'[^\w-]+','-',a.company.casefold()).strip('-')
    url='https://layoffs.fyi/company/'+quote(slug,safe='')+'/'
    key=hashlib.sha256(url.encode()).hexdigest()[:20]; raw=d/(key+'.html')
    result=dict(cid=a.cid,company=a.company,url=url,query=f'{a.company} layoffs details from {a.start} to {a.end}',rows=[])
    try:
        if a.html: raw.write_bytes(Path(a.html).read_bytes())
        if not raw.exists():
            stamp=d/'last-request';time.sleep(max(0,12-(time.time()-stamp.stat().st_mtime)) if stamp.exists() else 0);stamp.touch()
            with urlopen(Request(url,headers={'User-Agent':'Layoff research collector/2.8.6'}),timeout=30) as r: data=r.read()
            raw.write_bytes(data)
        found,result['rows']=parse(raw.read_bytes(),url)
        result['status']='rows_collected' if result['rows'] else ('empty_table_review' if found else 'table_not_found')
    except Exception as e:
        result.update(status='blocked_or_failed',error=str(e))
        headers=getattr(e,'headers',None)
        if headers: result['retry_after']=headers.get('Retry-After')
    out=d/(key+'-'+quote(a.cid,safe='')+'.json');out.write_text(json.dumps(result,ensure_ascii=False,indent=2));print(out,result['status'])
if __name__=='__main__':main()
