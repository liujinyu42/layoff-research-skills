# Changelog — v2.8.7

## Tracker channel: two-pass field history and the adopted pattern

**Pass 1 (v2.8.6 as shipped — failed in the field, 2026-11-18 run).**
- `company_table.py` fetched `https://layoffs.fyi/company/<slug>/` and parsed HTML `<table>` rows.
- Result: correct page titles, zero rows — company pages are client-side rendered shells (~50 KB, no table markup) → `empty_table_review` for Salesforce/Samsara/SAP, `blocked_or_failed` for SAP Labs (connection reset).
- Browser rendering of the pages failed (navigation never reached load-complete; 30 s readiness timeouts).
- Under load the site tarpitted plain HTTP clients (urllib/curl read timeouts), including after a 50-minute cooldown. The tracker channel collapsed to SERP-snippet partial evidence.

**Pass 2 (working pattern — adopted as the primary channel).**
- Page-shell inspection found the data-loader script `https://layoffsfyi.netlify.app/charts/company.js`, which fetches JSON from `https://layoffs-fyi.onrender.com/api/company/<slug>`.
- Response: `{"company", "slug", "events": [{"date", "count", "percent", "industry", "source", "country"}...], "wiki": {"extract"}}` — the full Date/Employees/%/Source table in one request, immune to the HTML tarpit.
- Field result: every event enumerated for all requested companies with 12 s serial spacing (Salesforce 15, Samsara 1, SAP 2, SAP Labs 1); enabled correcting an SF-only row to the full 133 WA+CA total and adding 8 missed events.

## Changes

1. `scripts/company_table.py` — backend API is now the primary channel (raw JSON archived as `<key>-api.json`); HTML parse and `--html` kept as fallbacks; serial >=12 s throttle applies to every network request; receipts record which channel produced the rows.
2. `SKILL.md` — workflow rewritten around: company name + CID input → API-first tracker pass → Google pass (`<Company> layoffs details from 2019 to 2026`, one page per distinct event, no site re-crawling) → mandatory cross-check of each tracker row against its source page with credibility arbitration (original-source wording beats tracker rounding: "fewer than 1,000" vs 1000; "at least 90" vs 90; "up to 3,000 / about 2.5%" vs 3000/3%) → independent verification of tracker-omitted events → export with receipts/ledgers and PARTIAL labeling.
3. Field-proven arbitration examples recorded: tracker `1000` → CNBC "fewer than 1,000" (upper bound); tracker `90` → Protocol "at least 90" (lower bound); tracker `3000/3%` → CNBC "up to 3,000 / about 2.5%"; tracker percent 1.85% with no accessible page → percentage blank; tracker-omitted real event: SAP America 2025-10-06 Palo Alto WARN (82 positions).

## Performance update (same version, same run)

Speed and anti-detection changes to `scripts/company_table.py`:

1. **Two-tier pacing.** The old single 12 s gap applied to every request was designed for the HTML site and made the API channel ~4× slower than needed. Now: 3–5 s (jittered) between backend-API calls, 12–18 s (jittered) for public-site HTML fetches. Four companies drop from ~48 s of spacing to ~15 s.
2. **Jitter everywhere.** Randomized delays replace fixed intervals; a fixed cadence is a bot fingerprint.
3. **Exponential backoff with Retry-After** on 429/503/timeout (10→20→40 s, max 2 retries), then file the blocker — no hammering.
4. **Browser-like headers** (Chrome UA + Accept + Accept-Language) replace the collector-identifying UA.
5. **Receipt caching.** Re-runs reuse saved API JSON at zero network cost (`--refresh` forces). Combined with the shared URL ledger, a second pass never repeats a request.
6. **Per-host serialisation documented** — including never running discovery and source fetches against the same host simultaneously.
