# CHANGELOG v2.8.8 — resumability update

Long-run durability rules for batched/agent-driven execution, added after a field run where three
batch agents stalled mid-write and their unwritten output was lost with the agent session.

## Added

- `references/resumable-batching.md` — mandatory durability rules:
  1. **Persist per company, immediately.** Save intermediate results as soon as usable data
     exists; official result file only after verification completes. Large JSONs written minified
     and in chunks (marker-append pattern). Every write mechanically verified afterwards: file
     exists, JSON parses, company ID/CID correct — announcing a write is not a write.
  2. **Blocked pages end the step, not the run.** Per-fetch timeout and retry cap (2 retries,
     exponential backoff, honor Retry-After). On failure: try another credible result → cached
     receipt snippet → Wayback capture. If none works, keep acquired data, mark verification
     status `blocked`/`pending_verification`, log the blocker, move on. Never fabricate; unverified
     data is never counted as a confirmed event.
  3. **Disk checkpoints, not agent handles.** Per-company checkpoint record (collection /
     verification / written / failure reason). Resume fills only missing or incomplete companies;
     recovery never depends on a dead agent's in-memory state and never re-runs completed
     companies.
  4. **Append the search log per query.** One JSONL line per executed search immediately after the
     query completes; never buffered until batch end.
- `SKILL.md` workflow step 6 (Durability) summarizing the above; export renumbered to step 7.
- Batch protocol template gains a matching "Durability rules" hard-rules section.

## Compatibility

No changes to output columns, coding enums, pacing rules, or receipt cache format.
