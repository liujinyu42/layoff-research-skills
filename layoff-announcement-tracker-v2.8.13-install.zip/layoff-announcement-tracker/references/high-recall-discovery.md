# High-recall discovery accelerator

Optional, additive tooling for Stage 2 Google/web gap discovery only. Complete the Stage 1 tracker/report seed sweep first. It changes no definition, field, contract or export rule. Use it when the standard search channel returns too few pages per company.

## Channel

`scripts/bing_discovery.py` queries Bing News RSS, which returns historical
items with **direct article URLs** (no Google News signature decoding) plus a
publication date:

```bash
python3 scripts/bing_discovery.py --roster roster.csv --out discovery_bing \
    --start 2019-01-01 --end 2026-11-08 --workers 6 --broad --by-year
```

Outputs, under `--out`:

- `candidates_<company_id>.json` — company status, candidate list and one receipt per attempted query; each receipt records status, HTTP code, result count, error and execution timestamp
- `candidates.csv` — one row per candidate across the roster, compatible with the earlier candidate index

Every query template runs for the roster company name and every semicolon-separated alias. Queries per name: `"Company" layoffs`, `"Company" "job cuts"`,
`"Company" "lays off"`, `"Company" "workforce reduction"`. `--broad` adds
alternate phrasings plus Reuters, TechCrunch and Bloomberg site queries;
`--by-year` adds explicit calendar-year queries for historical coverage. Only a per-company payload whose status is `completed` is resumed; empty completed results and failed/partial requests remain distinct, and `--force` refreshes. Publication dates use a default 45-day boundary buffer (`--boundary-days`) so a later report about an in-window announcement is not discarded; final event-date review still applies. Non-http links are dropped, and a duplicate URL OR normalized title removes the repeated lead.

## Registering candidates as sources

Register each retained URL through the normal source manifest
(`sync --manifest`), with `source_type=news`, the real publication date, and a
plan binding. Candidate discovery never becomes evidence by itself: a candidate
that cannot be fetched, or whose text does not name the employer and state the
action, stays unresolved.

## Evidence rules confirmed by production runs

These are refinements of the existing coding rules, applied when anchoring
quotes:

1. The evidence quote must name the employer (roster name, legal-entity first
   token, or a recorded alias). If the sentence names no employer, widen the
   verbatim span backwards to the nearest employer mention in the same article,
   or leave the field unresolved.
2. A numeric claim must be cited from the span that states the number. When a
   count and a percentage come from different sentences or different articles,
   give the count fields and the percentage fields their own evidence bindings;
   never cite a percentage sentence for a headcount.
3. Same-day duplicates: one row with a headcount and another with only a
   percentage describe the same announcement. Keep the headcount row; do not
   copy the percentage across unless the percentage sentence is captured as
   evidence.
4. Reject cumulative tallies: `laid off … since 2019 / since November / in
   total / cumulatively`. These describe multi-round totals, not one plan.
5. Reject articles published outside the run window, and sentences about other
   companies in round-up articles (employer must be the sentence subject within
   its first clause).
6. Round-up and "tech layoffs tracker" pages are legitimate verification
   sources only when the employer is the grammatical subject of the sentence
   that states the action and the count.

## Known blocked or degraded channels

- Layoffs.fyi: Airtable view rendered client-side; no static per-company records.
- TrueUp: HTTP 403 to scripted requests.
- WARN consolidated index: not retrievable as a bulk index; state portals must be
  queried individually.
- GDELT DOC API: HTTP 429 under a one-request-per-five-seconds cap.
- Google News RSS: usable for discovery, but links require signature decoding
  before the publisher page can be fetched.
