# Resumable batching & durability rules (v2.8.8)

Long runs (hundreds of companies, batched agents) must survive interruption at any point.
These rules are mandatory whenever a run is executed in batches or delegated to sub-agents.

## 1. Persist per company, immediately

- Save each company's intermediate result the moment usable data exists (tracker receipt parsed,
  candidate list, partial verification), before verification completes.
- Update the company's official result file only when verification for that company is done.
- Large result JSONs: write in chunks. Use the marker-append pattern — Write part 1 ending with a
  unique placeholder (e.g. `"__APPEND1__"`), then Edit replacing the placeholder with the next chunk
  ending in `"__APPEND2__"`, repeat, then remove the final marker. Write minified JSON
  (`json.dump(..., separators=(',',':'))`, no indentation) to keep single writes small.
- After every write, mechanically verify — never just announce "writing now":
  1. the file exists (`test -f`),
  2. it parses (`python3 -c "import json;json.load(open('<file>'))"`),
  3. the company ID / CID inside matches the roster row.
  If any check fails, repair before moving to the next company.

## 2. Blocked pages end the step, not the run

- Set an explicit per-fetch timeout and a retry cap (default: 2 retries with exponential backoff,
  honoring `Retry-After`; then stop touching that page).
- On failure, try alternative sources in order: another credible search result, the tracker
  receipt's cached snippet, a Wayback Machine capture of the blocked URL.
- If no accessible source remains, keep the data already acquired plus the attempted source URL,
  record the verification status as `blocked` (or `pending_verification`), log the blocker, and
  move to the next company. Never fabricate; never promote unverified data to a confirmed event;
  a blocked step must not stall the batch.

## 3. Disk checkpoints, not agent handles

- Maintain a per-company checkpoint record: collection status, verification status, result-file
  written (yes/no), failure reason, timestamps.
- On resume, read the checkpoint and only fill in missing or incomplete companies/files.
- Recovery must not depend on a previous sub-agent's in-memory state or "handle" — if a prior
  agent died mid-step, treat its unwritten output as lost and rebuild that company from the
  persisted receipts and any intermediate files it did save.
- Never re-run a company that is already checkpointed as verified-and-written.

## 4. Append the search log per query

- Append one line per executed search/fetch to the run's search log immediately after the query
  completes (JSONL: timestamp, company, query, pages reviewed, outcome, candidates found).
- Never buffer the log until a batch finishes — an interrupted batch must still leave a
  reconstructable trace of which queries ran and what they produced.
