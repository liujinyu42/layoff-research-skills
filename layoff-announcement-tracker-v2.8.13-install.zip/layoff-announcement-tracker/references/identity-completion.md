# Identity completion

A delivery audit of the previous collection round reported that every exported
row had an empty country, listing venue and ticker, and that no row carried an
event-time firm size. The finding was read as a coding omission. It was
actually a data omission: the company identity records never held those
attributes, so there was nothing to backfill from, and the coding step could
only write what it was given.

The registrant filings were already in the workspace. This module reads them
and recovers, for each company:

* the jurisdiction, from the incorporation statement or the address of the
  principal office;
* the exchange and the trading symbol, from the securities table that
  Section 12(b) of the Exchange Act requires;
* the number of employees, from the human-capital discussion, together with
  the date that figure refers to.

```bash
python "$S/scripts/complete_identity.py" --work "$W" --out "$W/qa/identity-completion.json"
```

It writes the recovered attributes back into `registry/entities.json` and
reports how many it filled.

## Reading the securities table

The securities table is the only reliable source for the exchange and the
symbol, and its layout varies between filings:

```
Class A Common Stock, $0.001 par value GOOGL Nasdaq Stock Market LLC
Common Stock, par value $0.10 per share
MU Nasdaq Global Select Market
Common stock
TSLA
The Nasdaq Global Select Market
```

Three readings are tried, in order:

1. **Same row.** The security description, the symbol and the exchange on one
   line. The symbol must follow a description that names an equity, which is
   what keeps the table's own heading row and the narrative around it out of
   the reading.
2. **Wrapped row.** The description on one line and the symbol and exchange on
   the lines that follow. This is the common case in modern filings.
3. **Exchange only.** A filing that names the venue without a symbol yields an
   exchange and no symbol, which is better than an invented symbol.

The scan is bounded to the text between the Section 12(b) heading and the
Section 12(g) heading, because that is where the table is and because the
surrounding narrative mentions many capitalised words.

A symbol that is also an ordinary English word is only accepted through the
first two readings, which anchor it to an equity description. Without that
anchor, "by" in "registered by" and "on" in "listed on" are picked up as
symbols.

## Why the workforce figure matters

The event-time firm size is not a decorative field. It is the denominator for
the plausibility gate in `researchcore/delivery_review.py`, which rejects a
count that would remove more than 45% of the workforce or that exceeds it.
Without a firm size that gate cannot run, and a figure like "100,000
positions eliminated across major companies" reaches the workbook unchecked.

The figure is taken with its date. A workforce number without a date cannot
describe the employer at the time of an event, and a later figure must not
replace an earlier one.

## What it does not do

It does not infer a jurisdiction from a company's name or its listing venue. A
company listed in New York may be incorporated in Delaware, and the audit
requires a country or jurisdiction rather than an address or a description.

It does not read a firm size from a press article. The workforce figure comes
from the registrant's own human-capital disclosure.
