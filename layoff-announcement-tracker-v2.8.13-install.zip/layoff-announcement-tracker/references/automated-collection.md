# Automated collection

This reference describes the receipt-backed sweep and subsequent candidate review. It exists because the previous round was driven by
throwaway scripts outside the skill: after every interruption someone had to
swap the exit address by hand, watch the throttle, work out which tail was
missing, and patch the failures by hand. Nothing about that procedure was
reviewable, and nothing about it was repeatable.

Initialize the workspace and verify the registry first. Run the bundled sweep and review preparation:

```bash
python "$S/scripts/run_collection.py" --work "$W" --candidates-only
```

The driver is resumable. Re-running it after an interruption continues from
the last completed unit; it does not repeat finished searches, and it does not
discard receipts.

## The order of operations

| Stage | Command | What it produces |
|---|---|---|
| 1 | `seed-plan` → `collect_seeds.py` → `seed-import` → `seed-status` | one receipt per roster company × channel (trackers and the issuer filing) |
| 2 | `discovery-plan` → `collect_discovery.py` → `discovery-import` | one receipt per planned company/year query, each with a saved capture |
| 3 | `register_candidates.py` | registered publisher snapshots and access gaps |
| 4 | `event_plans.build_plans` | one plan per announcement, with the pages that belong to it |
| 5 | `coding.build_plan_decisions` | source-bound field decisions and second reviews |
| 6 | `audit` → `export` | `1_layoff_announcements.xlsx` and its sidecars |

The driver runs the first four stages with `--candidates-only`. Complete the substantive candidate reviews and remaining field decisions before audit and export. See [candidate reconciliation](discovery-reconciliation.md).

## Stage 1: the source-first sweep

Before any web search, every roster company is checked against each channel:

| Channel | Where the rows come from |
|---|---|
| `layoffs_fyi` | the tracker's Airtable table, rendered in a browser |
| `trueup` | the per-company tracker page |
| `thelayoff` | the per-company board |
| `issuer_report` | the registrant annual report already registered for the company |

`collect_seeds.py` records what actually happened to each channel:

* **completed** — the channel answered and its rows were read. An empty hit
  list on a live channel means the channel carries nothing for that employer
  inside the window.
* **blocked** — the channel refused, kept refusing after an exit change, and a
  browser render also returned nothing. The receipt names the reason.
* **not_applicable** — only for `issuer_report`, when the company has no
  registered filing. It requires an applicability basis.

A `404` is `completed` with no rows, because "this tracker has no board for
this employer" is an inspected answer, not a refusal.

### Rendering a client-side table

Several trackers publish their data only through a JavaScript grid or an
embedded view. An unauthenticated fetch receives the page shell and no rows.
`render_table.py` reads those pages through headless Chrome over the DevTools
protocol and scrolls the grid to the end, so the sweep can read them without a
human opening a browser:

```bash
python "$S/scripts/render_table.py" --preset layoffs_fyi --out "$W/discovery/captures/seed/layoffs_fyi/_table.json"
```

The output records the row count the page itself reports, so a partial read is
visible rather than silently truncated. `collect_seeds.py` escalates to this
renderer on its own when a fetch is refused or returns a shell, and it stops
escalating after six consecutive empty renders on one channel: a site that
refuses the browser refuses it for every board, and continuing would spend the
round proving the same point.

### What a blocked channel does and does not do

A blocked channel is a **coverage gap**, not an integrity failure. The receipt
exists, its capture is intact and the refusal is named, so `discovery-plan`
proceeds and the gap is reported in the audit. A **missing, partial or altered**
receipt is different: that is an unexecuted step and it stops the run. The
distinction matters because one permanently unreachable tracker would otherwise
block every later round, while a fabricated success would silently shrink the
dataset.

## Exit address and throttling

The search endpoints refuse an address that issues too many requests. When
that happens the operator used to change the exit address manually. That step
is now part of the collection, not a separate action.

`researchcore/egress.py` provides the transport:

* every request across all workers passes through one pacer, so concurrency
  never multiplies the request rate;
* the interval starts small and grows when the endpoint refuses, then decays
  back toward the floor once requests succeed again;
* a refusal is detected from the response body as well as the status code,
  because a blocked page often returns HTTP 200 with an "automated queries"
  body;
* after repeated refusals the driver moves to a different exit node through
  the local sing-box control API, verifies the new address, and continues.

The node history is written to `discovery/captures/access/vpn-nodes.json`, so
a reader can see exactly which address served which part of the run.

Set `LAYOFF_EGRESS_API` to point the controller at a different address. When
no controller is reachable the driver keeps running on the current address and
records the refusals instead; it never silently pretends a blocked query
returned no results.

**A blocked query is a `blocked` receipt, not a zero-result query.** The
distinction matters: a zero-result query is a completed search, while a
blocked query is a named coverage gap.

### The request must actually travel through the rotated node

Rotation only changes the exit address if the request leaves through
sing-box. A request that only inherits the ambient `HTTP_PROXY` never leaves
that proxy, so changing the node changes nothing and the same refused address
is retried indefinitely. Set `LAYOFF_EGRESS_PROXY` (default
`socks5h://127.0.0.1:2334`, the sing-box SOCKS5 inbound) so the transport
routes through the node it rotates.

The rotation result records whether the address actually changed. A node group
can expose several entries that share one egress address, so a rotation that
returns the same IP is reported as `changed: false` and is not counted as a
rotation. The skill never claims to have moved to a new address when it did
not.

### A rotation is only an escape when the new address can actually answer

Changing the node is not the same as escaping a refusal. The new node may
present the same egress address, or a different address that the endpoint
refuses as well. A rotation therefore **verifies the new address with a real
request** before it is accepted: the address must return a document, not a
refusal. An address that is refused is remembered, and the rotation continues
past it rather than returning to it. The rotation is also bounded in time, so
a run that must try many candidates still finishes.

Two facts about the exit are worth recording, because both were observed and
both change what an operator should expect:

* **The node names do not determine the address.** A single group can expose
  dozens of named nodes across many regions that all resolve to one egress
  address, and at another moment the same group's nodes can resolve to a
  different address. The address is therefore always read from the running
  system, never inferred from the node name.
* **The group may change the address on its own.** An automatic-selection
  entry inside the group can move the address by itself. A run that reads the
  address once and keeps it for the whole sweep will hold a stale address
  long after the group has moved. Read the address when the run starts and
  again whenever a refusal suggests the address has changed.

A refused address is a shared, finite resource: the endpoint's quota belongs
to the address, not to the node that produced it. Rotation can move the run
off an exhausted address, but it cannot raise the quota, and a run that is
itself consuming the quota will exhaust the address it is on. Discovery and
source registration therefore do not run at the same time; they take turns.

### The group that measures its own entries is what actually moves the address

A group of named nodes can present dozens of entries across many regions
that all resolve to one refused address, and moving the selection between
them changes nothing: the run keeps hammering the same address while
believing it has moved. A group that measures its entries and picks the
fastest is not locked to one upstream. Moving the selection to such a group
and letting it settle is what changes the address, and it must be given a
few seconds to settle before the first request: a request sent too early
meets the address that is being replaced and reads as a refusal.

The rotation therefore tries that group first, and only then the named
entries. A new address is accepted only after **two** probes several seconds
apart both return a document: a node that has just been selected may still
be finishing its handshake, and one successful request through it does not
mean the address can be used for the next one.

### A refused request and an empty result are different facts

A feed that answered with a well-formed document containing no items is a
**completed search that found nothing**. A refusal — a non-200 status, a
refusal body, or an unreachable endpoint — is a **blocked query**.

Conflating the two is expensive. In the previous round 2,715 planned queries
returned zero items, and the executor recorded every one of them as `blocked`
with the wording "the search endpoint refused the request on every attempted
engine". Nothing had refused anything. The queries were answered normally and
the answer was empty, because of the query syntax described below. The
coverage gap was therefore invisible: the audit reported a network problem
where a syntax problem was, and the affected companies never got a real
sweep.

The executor now returns the raw document for any answered feed, and the
receipt states which engine answered and how many results it returned. Only a
request that produced no document at all is recorded as `blocked`.

## Query syntax: no boolean operators

**Google News RSS does not support the `OR` operator.** A query of the form
`("Acme") (layoffs OR "job cuts") 2024` returns zero results unless a single
article satisfies the whole parenthesised group. The group is treated as one
required condition, so an article that says only "layoffs" is not returned.

This is silent. The response is a well-formed feed with no items, which is
indistinguishable from a genuinely empty result set unless the query is
checked against a control.

| Query | Result |
|---|---|
| `("HubSpot") (WARN OR "layoff notice" OR "team cuts" OR "local layoffs") 2024` | 0 items |
| `("HubSpot") WARN 2024` | 4 items |
| `("HubSpot") (layoffs OR "job cuts") 2024` | 10 items |
| `("Microsoft") (WARN OR "layoff notice") 2023` | 14 items |
| `("Microsoft") WARN 2023` | 19 items |
| `("Zuora") (layoffs OR "job cuts") 2023` | 0 items |
| `("Zuora") layoffs 2023` | 1 item |

The planned sweep therefore asks **one query per term**, never a group:

```
"HubSpot" WARN 2024
"HubSpot" "layoff notice" 2024
"HubSpot" layoffs 2024
```

Each term is quoted separately, the company name is quoted, and no boolean
operator appears anywhere in a planned query. The hits from the terms of one
family are unioned downstream, so the family's coverage is the union of its
terms rather than their intersection.

Two rules follow from the same behaviour:

* **A multi-word term is quoted.** `"job cuts"` matches the phrase; `job cuts`
  unquoted matches both words independently and returns nothing when no single
  article contains both.
* **Adding more terms narrows, not widens.** `"Zuora" layoffs job cuts 2023`
  returns 0 items where `"Zuora" layoffs 2023` returns 1, because the extra
  term becomes another required condition.

The seed-verification queries follow the same rule: the company phrase and the
title phrase are quoted separately with no operator between them.

### Choosing the year filter

The bare year token (`2023`) is a search term, not a date filter: it matches
articles that mention the year. Google News RSS accepts `after:` and `before:`
bounds, which bound the window properly.

Bing News RSS is a different animal and is not a substitute. It ignores the
boolean syntax in the same way, it is biased to the last few weeks, and it
answers a 2021 query with 2026 articles. It is useful for the recent past
only. The historical sweep stays on Google News RSS.

## Query coverage

The planned Stage-2 sweep asks one question per company per year per query
family. That is the coverage floor, not the ceiling. Companies that the
sweep did not cover, and years that came back thin, are handled by
`close_gaps.py`, which asks the same questions differently:

* several engines, because their archives differ;
* twelve verb and noun phrasings, plus subject-position phrasings that ask for
  the employer as the actor ("will cut", "said it would", "announced");
* a year-scoped sweep, because a general feed is biased toward recent items;
* the employer name and every declared alias.

Run it against the gap list produced by the delivery audit:

```bash
python "$S/scripts/close_gaps.py" --work "$W" \
    --out "$W/discovery/gapsearch.json" --targets "$W/qa/gap-targets.json"
```

## Entity binding

A retrieved page is bound to a company only when a sentence names that
company **as the party performing the reduction**. Two rules enforce this:

* a company whose name is an ordinary English word (`ON`, `Here`, `Sea`)
  additionally needs a corporate marker or a possessive construction, so
  "here are the layoffs" and "North Sea" do not become events;
* a sentence that lists several employers inside an industry roundup does not
  attribute the reduction to any of them, so a figure from that sentence is
  not any one company's event.

A page that fails the binding test stays a candidate with an exclusion reason.
It never becomes a plan.

## Number scope

A number becomes a claim only after it means what the sentence says:

| Wording | Recorded as |
|---|---|
| "will cut about 500 employees" | 500, qualifier `approximately` |
| "over 61,000 jobs" | lower bound only, qualifier `more_than` |
| "cut its support team from 9,000 to 5,000" | 4,000, basis states the difference |
| "100,000 positions eliminated across major companies like …" | not recorded |
| "now employs 180,000 people after the cuts" | not recorded |
| "furloughed 2,000 employees" | not recorded |
| a figure tied to a different year | not recorded |

The extraction rules live in `researchcore/extraction.py` and are covered by
`scripts/test_extraction_rules.py`. The audit enforces the magnitude rule
independently, in `researchcore/delivery_review.py`: a count that would remove
more than 45% of the event-time workforce, or that exceeds it, is a measure
error and blocks export.

## Page retrieval

A plain HTTP fetch covers most publishers. Three cases need more:

* a page that serves only a script shell is rendered through a browser;
* a publisher that refuses a bare client is retried through the browser path;
* a page that still cannot be read is recorded as unreadable, and its
  candidate stays `unresolved` with the access failure as the reason.

An unreadable page is never treated as evidence that no layoff occurred.

### From a hit to an event

A search hit is a pointer, not evidence. The runtime only accepts a decision
whose evidence span is bound to a registered source with a matching
`row_sha256` and `text_sha256`, so a page that was found but never registered
can support no claim and its candidate can never leave the ledger. Three
scripts close that loop, in this order:

```bash
# 1. Register every readable hit as a source (publisher articles and issuer
#    filings). Hits that only point at an aggregator redirect are recorded as
#    unreadable instead of being given the aggregator shell's text.
python "$S/scripts/register_candidates.py" --work "$W"

# 2. Cluster the registered pages into events, write each plan id back onto its
#    sources, and give every relevant hit a ledger disposition.
python "$S/scripts/close_candidate_gaps.py" --work "$W"
```

`register_candidates.py` distinguishes two kinds of hit because they need
different honesty:

* a **direct page** is fetched and registered; an SEC filing is registered as
  `sec_filing` / `event_filing`, which is the strongest evidence tier because
  the registrant is speaking, not a reporter describing it;
* an **aggregator redirect** (`news.google.com/rss/articles/CBMi...`) returns a
  script shell whose body does not contain the publisher address, so the page
  is recorded as unreadable. Registering the shell would attribute its text to
  the employer, which is the exact failure that produces a wrong count.

`close_candidate_gaps.py` then accounts for every relevant hit exactly once:

| Situation | Disposition | What it claims |
|---|---|---|
| source bound to an announcement of the same employer | `included` or `merged` | review the source and plan link |
| original source supports exclusion | `excluded` after substantive review | record the reason and exact quote |
| original inaccessible or event rule inconclusive | `unresolved` | route to source recovery or substantive review |

### Keeping event identity stable

Clustering is not idempotent in the way it first appears. A plan's id is
derived from its strongest page, so when a newly retrieved page becomes that
page the event is *renamed*. Every decision is keyed by `plan_id`, so a rename
silently drops the decisions bound to the old id and reports one announcement
twice: once as a lost event, once as a new one.

`reconcile_plans.py` prevents that. A fresh cluster covering an event the
runtime already knows adopts that event's id and date; a cluster with no
counterpart becomes a new plan; an event with no fresh page keeps its place,
because losing it would be a coverage regression rather than a finding.

One measured round, before and after the reconciliation step:

| Measure | Without it | With it |
|---|---|---|
| plans | 835 | 1113 |
| existing events renamed away | 327 | 0 |
| events with no readable page kept | — | 0 (dropped) |

A plan whose pages are all unregistered is dropped rather than kept: the
runtime builds its entity list from the `plan_id` on registered sources, so
such a plan could carry no decision and no evidence.

### Resolving a source by address and company

One article can cover several employers, and the same address may be
registered once per employer it discusses. Resolving a plan's source by
address alone binds the plan to another company's snapshot — a Lyft
registration became the primary source of a Tesla event. Match on both the
address and the company id.

## What the driver does not do

It does not replace any bundled runtime command. `runtime-check`, the registry
checks, seed and discovery receipts, candidate reconciliation, source-bound
decisions, second review, the final audit and the export all stay with the
runtime. The driver only executes the searches, retrieves the pages, and
applies the extraction and clustering rules.

It does not invent a roster, a company identity or a CIK. Those come from the
roster file and the verified identity records.

It does not claim coverage it does not have. A company with no readable
public announcement stays a named gap in the audit.

## Restoring a partially cleaned workspace

The runtime verifies each source twice: once against the raw snapshot and once
against the normalized text. When a workspace is archived, copied or partly
cleaned, the raw copies can disappear while the normalized text remains, and
the audit then reports every source as changed.

`scripts/restore_raw_snapshots.py` restores the raw copies from the text
archive, but only for the sources whose recorded raw and text hashes are
identical. That condition means the two were the same bytes, so the text
archive is an exact copy of what the raw path held. A source whose hashes
differ is left alone, because in that case the raw snapshot held content the
normalized text does not and it cannot be reconstructed.

```bash
python "$S/scripts/restore_raw_snapshots.py" --work "$W"
```

When the raw snapshot is genuinely gone and cannot be restored, the runtime
delivers the normalized text, whose hash still matches, and marks the source
as snapshot-missing instead of failing every read. The evidence remains
verifiable because every quotation is bound to the normalized text.

## Registering new pages without retiring the corpus

`ingest()` treats the manifest as the complete list of live sources. Every
source the manifest does not carry is written back as `active: false`. That is
correct for a full round and destructive for an incremental one: registering
thirty newly resolved publisher addresses through a manifest that lists only
those thirty silently retires the whole existing corpus, and because the
entity list is derived from the active sources, every event entity
disappears with it. The audit then reports the workspace as empty rather
than as damaged, which is the expensive kind of failure to diagnose.

The repair keeps the evidence and rebuilds the bindings:

```bash
python "$S/scripts/repair_source_ledger.py" --work "$W"
```

It recovers the sources the manifest lost, restores the snapshot address the
manifest dropped, and retires the plan binding of a plan the runtime has
already retired — a retired plan keeps its documents, but it must not
produce an entity. It writes `qa/full_manifest_repaired.csv` and re-ingests
it offline, so every snapshot that was already fetched is reused verbatim.

Two details matter more than they look:

* **A row's plan binding stays as the manifest had it.** The manifest is the
  authority on which plan a source serves. Only the snapshot address was
  lost from it.
* **A source row that gains its plan binding after its row hash was
  computed keeps the old hash.** The stored hash no longer describes the row
  the manifest now holds, so every decision bound to that source is reported
  as stale even though the document never changed.

## When a decision is reported as stale

A decision records the fingerprint of the source set that applied when it was
made, and the runtime recomputes that fingerprint from the current ledger on
every read. When the two disagree, the field is requeued. That is the
correct default, because a source that entered or left the applicable set
can change what the right answer is.

Some drift is mechanical rather than editorial. The document text is
identical, the quoted evidence is identical, the reviewed scopes still
cover the same ready sources, and only the row hash moved. Those decisions
are sound and only need a signature that matches the ledger they live in:

```bash
python "$S/scripts/reseal_decisions.py" --work "$W"
python "$S/scripts/research.py" apply --work "$W" --decisions "$W/qa/reseal-decisions.jsonl"
```

`apply` recomputes the fingerprint and the signature from the current ledger.
No judgment is rewritten by this path, and it does not touch a decision
whose document text changed or whose applicable set changed — those must be
re-read and re-judged.

## Reading the egress status correctly

The probe reports health, not reachability of the endpoint. A `200` with a
"Sorry..." body is a refusal, and the exit address that produced it must be
rotated away before the next query.

The runtime needs `requests` with SOCKS support (`PySocks`) to talk to the
proxy at all. Without it every proxied request fails with
`InvalidSchema: Missing dependencies for SOCKS support`, and the failure
looks like a blocked endpoint rather than a missing dependency. Check the
interpreter, not the endpoint:

```bash
python3 -c "import socks; print('socks ok')"
```

When the group that measures its own entries is selected — `自动选择` in a
sing-box installation — the address actually moves between nodes, and the
rotation becomes observable. Switching the top-level selector does not
switch the group the traffic actually uses; the group has to be the one that
is selected.

### A rotation has to leave the region, not the node

Nodes of one region share one egress address, so moving the selection
between the named nodes of the selected group keeps hitting the same
refused address. The rotation has to reach past the region that produced the
refusal, and it has to remember two things: which addresses were refused and
which regions produced them.

Two defects made that impossible. The candidate filter rejected every
candidate as soon as any address was known to be refused, so the loop always
returned nothing and the rotation fell back to the first candidate — the
region it was already in. And nothing recorded which region had produced a
refusal, so the region could not be excluded from the next candidate pool.

A third defect sat in the automatic group. The group that measures its own
entries settles on the lowest-latency node, which is usually the node
closest to the client, and the whole provider range then shares one address
block. When that block is refused, every rotation lands back inside it. The
node the automatic group actually settled on is the one that has to be
recorded as refused, not the name of the group.

The exit map is worth keeping: a survey of one node per region shows which
regions share an address block and which stand alone, and a standalone
region is the one that survives a block-level refusal.

### An address that was resolved on one side has to be resolved on the other

The candidate ledger holds the publisher's own address once an aggregate
link has been resolved. A receipt that still carries the aggregate address
and a ledger row that carries the publisher address are the same document,
and the runtime compares the two when it checks candidate identity. The
comparison fails on the address, so the receipt has to be told where the
document really lives:

```bash
python "$S/scripts/apply_publisher_addresses.py" --work "$W"
```

Only the address moves. The candidate identity stays as it was, because a
document does not become a different document when its address is resolved.
The receipt signature covers the receipt content, so it is recomputed.

The receipt also has to carry the publisher name and domain. The feed
records both, but the imported receipt keeps only the fields the runtime
reads, and the publisher domain is exactly what the resolver needs to start.
Without it the resolver reports "the feed recorded no publisher domain" and
resolves nothing, which reads as a broken resolver rather than a missing
field. The batch files still hold the publisher; the repair copies it back
into the receipt before the resolver runs.

Resolving a chosen set of hits, rather than every aggregate hit in the
workspace, is worth its own script when the workspace holds thousands:

```bash
python "$S/scripts/resolve_selected.py" --work "$W" --hits /tmp/hits.json --out /tmp/resolved.json
```

A publisher that does not expose a search endpoint, or that answers only
behind a paywall, cannot be resolved by any strategy. Those hits stay
unresolved and remain a named gap. They are not failures to be retried
forever, and they are not to be reported as a resolved document.

### The registry of executed searches, and the channels it names

A table of events proves that events were found. It does not prove that the
other events of a company were looked for, and a company with no row can
mean either "nothing happened" or "nobody looked". The search-coverage
contract keeps the two apart: it asks for a registry of what was actually
searched, at the grain of company x window x channel x query.

The receipts hold that registry already, and three things have to be right
before it can be built:

* **A hit is not an event.** A search that returned documents and whose
  relevance rule rejected all of them searched the window and found no
  qualifying event. Only a search that produced a registered plan counts as
  having found events. Counting the hits instead overstates coverage and
  makes a noisy search look like a productive one.
* **The channel comes from the kind of search, not from the engine.** The
  contract speaks in channels — the issuer's own newsroom, the regulator's
  notices, the news index, the layoff trackers. The collector knows which
  kind of query it ran, and the registry has to be stated in the contract's
  vocabulary. A statutory-notice query is the regulator's channel; it is not
  the issuer's.
* **The first stage is the tracker channel.** The layoff trackers are read
  in the first stage, so their receipts are the executed-search records of
  the tracker channel. A tracker that could not be read is blocked, which is
  a named limitation rather than a search that found nothing.

The registry is built from the receipts and imported:

```bash
python "$S/scripts/build_search_log.py" --work "$W"
python "$S/scripts/research.py" search-log-import --work "$W" --file "$W/qa/search_log.csv"
```

### Coding a reason the decisions already state

The reason codebook asks for the stated reason in a structured form: which
categories apply, each with its own quotation from the bound source. The
stated-reason decision already holds the sentence, and the attribution
decision already holds who said it. The coding follows from those two.

The attribution decides whether a label is allowed at all. A reporter's
reading of an event is not the issuer's stated reason, so it carries no
label; the plan still carries a coding record, and the record says that the
basis was the reporter's reading.

The categories carry positive cues, and a cue has to be found in the quoted
span. A reason that names no category is recorded with a proposed category
for review rather than forced into a label: a category that fits only loosely
would turn a researcher's reading of a sentence into the company's stated
reason.

```bash
python "$S/scripts/build_reason_codes.py" --work "$W"
python "$S/scripts/research.py" reason-apply --work "$W" --file "$W/qa/reason_codes.jsonl"
```

The submission is written as JSON rather than CSV. A label carries a nested
list, and a CSV cell carries it as a string that the runtime reads as a flat
code list instead, which loses every label.

### Company context read from the identity record

Seven fields describe the company rather than the event: its listing
exchange, its ticker, its CIK, its history, its founding year, what it
sells, and how it makes money. Every registered plan needs them, and the
identity record already holds them together with the registrant filing that
verified them.

The value is not copied on trust. Each one becomes a decision whose evidence
quotes the filing, and the runtime re-reads that quote from the bound source
bytes. Three things have to be right:

* **The identity record names things the way a data feed does.** It writes
  "NYSE" where the filing writes "New York Stock Exchange", and it writes a
  CIK with leading zeros where the filing writes the number. Both forms are
  looked for.
* **The context has to hold at the event.** A context field carries the
  date the information is stated as of, and it may not be later than the
  event. An annual report describes a fiscal year; when that year ends
  after the event, the context is stated as of the start of the period the
  filing covers, which is the last point the filing describes that precedes
  the event.
* **A negative finding has to show the source was read.** A field the
  record does not hold is recorded as reviewed-absent with the scope of
  every applicable source, from the first character to the last, and the
  runtime refuses a snippet.

```bash
python "$S/scripts/fill_profile_fields.py" --work "$W"
python "$S/scripts/research.py" apply --work "$W" --decisions "$W/qa/profile-decisions.jsonl"
```
