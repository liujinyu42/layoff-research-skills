---
name: layoff-announcement-tracker
description: Collect and verify public layoff events from trackers, company disclosures and reliable reporting. Find omissions, review unresolved candidates and export an English Excel file with evidence. Accepts optional reference URLs for coverage reconciliation.
---

# Layoff announcements and proposal-required company context

Discovery patch v2.8.5 uses the bundled runtime and schema 1.6.0. On resume, run `candidate-review-prepare` to reopen legacy automated exclusions caused by a missing plan or an inconclusive text rule. Back up the workspace or work on a copy before the first migration.

Implement proposal Part 1 for any company: listed, private, delisted, US or elsewhere. No historical dataset, original template, fixed company list or CIK is required. The proposal's existing 5,000+/2,952/610 counts are background, not a new collection obligation. Default event window 2020-01-01 through 2026-09-30 is user-overridable.

Read [workflow.md](references/workflow.md), [announcement-coding.md](references/announcement-coding.md) and the optional [first-use prompt](references/first-run.md). Templates, definitions and runtime are inside this skill.

## Automated collection

After initializing the workspace and verifying the registry, run the discovery sweep and prepare review tasks:

```bash
python "$S/scripts/run_collection.py" --work "$W" --candidates-only
```

The driver reuses completed search receipts, registers accessible publisher pages and prepares event and candidate review tasks. Continue with substantive review, field decisions, audit and export. See [candidate reconciliation](references/discovery-reconciliation.md) for optional baseline leads and evidence-backed event admission.

The procedure that a human used to perform by hand is now inside it. Search throttling is detected from the response body as well as the status code; the request rate backs off and recovers on its own; after repeated refusals the driver moves to a different exit address through the local sing-box control API, verifies the new address and continues, recording the node history in `discovery/captures/access/vpn-nodes.json`. **No manual address change is required at any point.** A blocked query is filed as a `blocked` receipt, never as a zero-result query.

Read [automated collection](references/automated-collection.md) before running a round.

## Scope-safe reading

Use the following rules for automated screening and evidence review:

* **Entity binding.** The automated screen looks for a sentence that attributes a reduction to the named employer. Generic names require additional disambiguation. The publisher byline alone supplies no employer evidence. A missed pattern creates a review task. A reviewer can establish the employer and action across adjacent passages, verified business-unit identities or local-language reporting, with source quotations and an explicit date basis.
* **Number scope.** A threshold keeps its bound, a before/after construction yields the difference and says so, and a figure that describes a workforce total, an industry aggregate, a year-to-date tally, a furlough or another employer's action is not recorded. When the event-time firm size is known, the audit rejects a count that would remove more than 45% of the workforce or that exceeds it; that check blocks export even under `--allow-partial`.

The rules live in `researchcore/extraction.py` and `researchcore/delivery_review.py`, and `scripts/test_extraction_rules.py` plus `scripts/test_magnitude_gate.py` lock them in.

Runtime 2.8.3 uses a mandatory source-first order. Run `runtime-check` before initialization and require `runtime_version=2.8.3`, `schema_version=1.6.0` and `pass=true`; an old installed release that does not recognize this command fails installation preflight. Verify every roster entity, then execute Stage 1 `seed-plan/import/status` for Layoffs.fyi, TrueUp Tech Layoffs Tracker, TheLayoff.com and applicable 10-K/20-F/annual reports. Once Stage 1 has intact receipts for every task, execute Stage 2. A documented channel refusal remains a coverage gap and permits the next stage. Use `discovery-plan/import/status`. News search verifies every seed by exact title and independently searches every company/year for omissions. Stage 3 reconciles both candidate streams, completes source reading and substantive second review, then runs final audit. Custom runner scripts never replace these stage commands or their receipts. Read [source-first discovery and candidate reconciliation](references/discovery-reconciliation.md). Tracker/report hits remain candidates until verified; inaccessible sources stay visible. Preserve uncertain plan relationships and counts, and cite a primary verification source where available.

**No planned query contains a boolean operator.** Google News RSS does not implement `OR`: it treats a parenthesised group as one required condition, so `("Acme") (layoffs OR "job cuts") 2024` returns nothing unless one article satisfies the whole group. The sweep therefore plans one query per term, with the company phrase and the term phrase quoted separately, and unions the family's terms downstream. **A zero-result feed is a completed search, not a blocked one:** only a request that produced no document at all is filed as `blocked`. Recording an empty answer as a refusal hides a syntax fault behind a network excuse and leaves the affected companies unswept. Read [automated collection](references/automated-collection.md) for the measured behaviour, the query rules and the exit-address handling.

**A rotation only counts when the new address can answer.** Changing the exit node is not the same as escaping a refusal: the new node may present the same egress address, or a different address the endpoint refuses as well. The rotation therefore verifies the new address with a real request and requires a document back, remembers a refused address and continues past it, and is bounded in time. Measured on one plan: rotating between two exhausted addresses ran at 2.4 queries per minute; verifying the new address and moving past the exhausted one ran at 132 — a 55-fold difference. Node names do not determine the address, and the group may change the address on its own, so the address is always read from the running system. The endpoint's quota belongs to the address, not the node, so discovery and source registration take turns rather than run at once.

**An aggregator address is not an article.** A feed points at the publisher's article through an encoded pointer that no client resolves. Every hit records the publisher's own domain, and the address is resolved to the publisher's page before it is registered as a source: the publisher's WordPress search (under both `/wp-json/wp/v2/search` and `/?rest_route=/wp/v2/search`, which are not interchangeable), then the slice of its site map that covers the month the article was reported in, then a site-scoped engine query. The title is matched against the address by its distinctive words, and the reported date is cross-checked against the site map's modification date. **A publisher's home page is not a source:** an address with no article path is recorded as unresolved rather than registered, because returning the front door for every candidate makes resolution look successful while producing nothing that can carry a quotation. An unresolved candidate is an honest gap; a fabricated address is not.

**A site map that splits by month is read by its own name.** A publisher that files thousands of articles a month publishes its site map in dated slices, and the slice that covers the reported month is the one that holds the article. The year and the month are read as a pair from the slice's name, never as loose text: the text `02` also appears inside the name of the December slice, so a loose match reads the wrong month of the right year. The publisher names its own maps in its robots file, and the index that lists its slices is often at an address the publisher chose itself, so every map the robots file names is read rather than only the conventional ones. The title must match on **every** distinguishing word: a search endpoint returns whatever it thinks is close, and a page that shares two words with the title is often a different article about a different subject. The rules are locked in by `scripts/test_publisher_resolution.py`.

**A request that never arrived is not a refusal.** The transport tries every address it can and reports a refusal only when an endpoint answers with a refusal status or a refusal body. A request that raised on every attempt has no status and no body, so it is reported as a request that never reached the endpoint. Treating it as a refusal would make an unreachable publisher look like a publisher that refused, and a run that keeps hammering an unreachable address would never finish.

## Fixed output

Google-discoverable pages are eligible discovery leads. Apply the final source credibility review in the workflow before using a page to support a published event. A verified secondary report can support inclusion without an issuer-hosted URL. Reconcile individual regulatory notices and keep inaccessible leads visible as coverage gaps.

Before registering plans, reconcile every supplied reference lead and every discovered candidate in an English `event_candidate_review.csv` sidecar. Use columns `candidate_id,company,reported_date,source_url,affected_scope,disposition,plan_id,evidence_url,reason`. Use dispositions `included,merged,excluded,unresolved`. Verify announcement date, affected entity and qualifying workforce action from the source. Record the surviving plan ID and positive linkage evidence for each merge. A dead link requires alternate-source discovery or an unresolved disposition. Search each company and calendar year, including local-language sources and operating units when relevant. An unresolved material candidate requires PARTIAL.

Require evidence of an announced or implemented involuntary workforce reduction for admission to the layoff workbook. Keep hiring pauses, automation forecasts, generic restructuring, and stand-alone voluntary offers in the candidate sidecar. A mixed program may qualify when involuntary cuts are supported, but its voluntary or projected counts must not become layoff counts. Keep parent-wide counts at parent scope and preserve source-supported qualifiers and bounds. Before delivery, reconcile every exported plan to the candidate ledger and ensure all supplied leads have dispositions.

Delivery enforces semantic gates in addition to source binding. An observed `announcement_date` needs `date_basis` identifying an actual announcement/notice; publication and implementation dates are not substitutes. Count and percentage evidence must name the target employer or registered alias and describe the current event, not another employer, an earlier year, a previous round or a cumulative tally. Remaining post-reduction headcount, furloughs and open/vacant positions are not layoff counts. When evidence states separate US and international components, review every component and attach `geographic_component_review={status:complete,components:[...],basis:...}` before using one component. Exact/approximate points, one-sided thresholds and explicit ranges require structurally consistent point/bound fields; `more_than`/`at_least` use only a lower bound, while `up_to`/`less_than` use only an upper bound. Percentage bounds such as 0/0 with an exact point are invalid. `country` accepts a controlled country/jurisdiction name, not an address or profile paragraph. Event context requires both `information_as_of` and `identity_match_basis`. These errors block export even with `--allow-partial`. See [announcement coding](references/announcement-coding.md).

Preserve the nine substantive Part 1 fields: stated layoff reason, M&A activity, leadership transition, company history, event-time firm size, founding year, product/service, business model, known affected parties. Essential event identity, dates, counts/percentages and their qualifiers, listing identifiers, source/attribution and plan links make 43 business fields, plus three row identifiers and four provenance/status fields (50 base columns).

Fixed eight reason-category codes, industry/sector, duplicate other-reason and generic event-note columns are omitted. Do not restore them through full; both profile names select the same closed set. Present the company-stated reason in English with exact English source evidence or a reviewed English translation linked to the unchanged native original. Preserve attribution; do not decide that AI is an excuse or true driver.

Start with receipt-bound Stage 1 collection from all four channels, then run Google seed verification and independent company/year omission searches as specified in [workflow.md](references/workflow.md). Keep executed searches in the bundled search log and candidate decisions in the workspace-root ledger. Use a header-only ledger when there were no candidates. For included or merged rows, cite the exact ready manifest URL assigned to the surviving plan. Keep failed or inaccessible channels visible in the coverage log. Batch repeated coverage around the same plan and reuse the existing source cache.

When the standard channel yields too few pages per company, use the optional [high-recall discovery accelerator](references/high-recall-discovery.md): `scripts/bing_discovery.py` collects historical, direct-URL candidates from Bing News RSS, and the reference restates the quote-anchoring rules (employer named in the span, numeric claim cited from the sentence that states it, same-day count/percentage deduplication, cumulative-tally rejection). It adds candidates only; every admission still runs through the normal evidence and audit path.

## Measurement contracts

Seven versioned contracts decide what may be *claimed* from those same 50 columns, without adding one. `strict` (default) enforces them; `baseline` preserves pre-1.5 behaviour for historical workspaces.

- [Reason coding](references/reason-coding.md): nine categories, four attribution levels, one evidence span per label. AI, cost and restructuring in one statement are three labels, not a choice.
- [Search coverage](references/search-coverage.md): executed searches are recorded separately from discovered events, so a zero-row table cannot be read as "no layoffs".
- [Pre-event linkage](references/pre-event-linkage.md): a fiscal year earlier than an event is not evidence that was public before it.
- [Human validation](references/human-validation.md): blind annotation of a held-out split is the only route to a reliability claim.
- [Market routes and registry](references/market-routes-and-registry.md): which documents a market publishes, which legal entity a row is, and whether two years may be divided.

```bash
python "$S/scripts/research.py" contracts-status    --work "$W"
python "$S/scripts/research.py" contracts-scorecard --work "$W"
python "$S/scripts/research.py" readiness           --work "$W"
python "$S/scripts/research.py" next-actions        --work "$W"
```

`readiness` answers five named comparisons rather than one composite score: `reason_description`, `financial_contrast`, `pre_event_capability`, `longitudinal_performance` and `job_skill_pairing`. Each is `measurable`, `partially_measurable` or `not_measurable` with its own sample size and blockers; a contract that is present but has no usable units cannot make a comparison measurable.

`next-actions` turns every open gap into an ordered work list: deterministic repairs first (they settle what is missing, never what a value is), then the semantic comparisons that need reading and judgment. Use it instead of deciding by hand which of seven contracts to run next.

`audit` reports `measurement_contracts_pass`, `contract_gaps`, `research_readiness` (RQ1–RQ3), `comparisons` and `weakest_link` separately from evidence integrity, and COMPLETE now requires no contract gap. Sidecars are content-addressed against the contract asset, the schema version and the upstream files they were derived from, so editing a contract — or a decision the codes were read from — invalidates existing records with a named `stale_record` instead of leaving a stale claim.

## Discovery and extraction

Build a roster from names or use the supplied CSV template; verify brands, subsidiaries and legal companies. Discover candidates from an authorized existing event list, trackers, company announcements, regulatory filings and reliable news. Trace originals where available and record unsuccessful searches/access limits. A news story is not automatically a new plan. No SEC filing does not mean no layoff. The tool snapshots explicit URLs/files; host discovery is needed for dynamic trackers and local sources.

```bash
python "$S/scripts/research.py" runtime-check
python "$S/scripts/research.py" init --work "$W" --company "Company name"
python "$S/scripts/research.py" source-plan --work "$W"
python "$S/scripts/research.py" registry-init --work "$W"
# After syncing a ready identity source and preparing entity_registry.csv:
python "$S/scripts/research.py" registry-verify --work "$W" --file /input/entity_registry.csv
python "$S/scripts/research.py" registry-check --work "$W"
python "$S/scripts/research.py" seed-plan --work "$W"
# After executing every stage-1 task and preparing discovery/seed-batch.json:
python "$S/scripts/research.py" seed-import --work "$W" --file "$W/discovery/seed-batch.json"
python "$S/scripts/research.py" seed-status --work "$W"
python "$S/scripts/research.py" discovery-plan --work "$W"
# After executing every Stage 2 task and preserving each raw result capture:
python "$S/scripts/research.py" discovery-import --work "$W" --file "$W/discovery/google-batch.json"
python "$S/scripts/research.py" discovery-status --work "$W"
python "$S/scripts/research.py" candidate-review-prepare --work "$W"
# Reconcile candidates, sync sources, finish first/second source-bound decisions and contracts.
python "$S/scripts/research.py" audit --work "$W"
python "$S/scripts/research.py" export --work "$W" --output /outputs/1_layoff_announcements.xlsx
```

## Collection scripts

These run the collection itself. They sit beside the runtime commands and do not replace them.

```bash
# Execute the planned Stage-1 channel sweep (trackers and the issuer filing)
# and emit one receipt per roster company x channel.
python "$S/scripts/collect_seeds.py" --work "$W" --out "$W/discovery/seed-batch.json"

# Read a tracker that publishes its table only through a client-side grid.
# collect_seeds.py escalates to this renderer on its own when a fetch is
# refused or returns a page shell.
python "$S/scripts/render_table.py" --preset layoffs_fyi \
    --out "$W/discovery/captures/seed/layoffs_fyi/_table.json"

# Execute the planned Stage-2 searches and emit runtime-compliant receipts.
python "$S/scripts/collect_discovery.py" --work "$W" --out "$W/discovery/google-batch.json"

# Prepare the ledger and reopen legacy automated exclusions.
python "$S/scripts/research.py" candidate-review-prepare --work "$W"

# Register direct links and resolved publisher URLs. Ingest is an incremental
# upsert: a manifest retires nothing it does not list, each committed source is
# journaled before the ledger snapshot, and an interrupted round resumes
# instead of downloading again. Retiring sources requires an explicit full
# replacement, never a partial manifest.
python "$S/scripts/register_candidates.py" --work "$W"

# Cluster the registered pages into events, bind each plan id onto its sources,
# and give every relevant hit a ledger disposition.
python "$S/scripts/close_candidate_gaps.py" --work "$W"

# Keep event identity stable across rounds. A fresh cluster that covers an
# event the runtime already knows adopts that event's id, so a newly retrieved
# page cannot rename an announcement and orphan its decisions.
python "$S/scripts/reconcile_plans.py" --work "$W"

# Search the companies and years the sweep did not cover, with several engines
# and several phrasings.
python "$S/scripts/build_gap_targets.py" --work "$W" --out "$W/qa/gap-targets.json"
python "$S/scripts/close_gaps.py" --work "$W" --out "$W/discovery/gapsearch.json" \
    --targets "$W/qa/gap-targets.json"

# Recover country, venue, ticker and event-time firm size from the filings.
python "$S/scripts/complete_identity.py" --work "$W" --out "$W/qa/identity-completion.json"

# Register direct links and resolved publisher URLs. Ingest is an incremental
# upsert: a manifest retires nothing it does not list, each committed source is
# journaled before the ledger snapshot, and an interrupted round resumes
# instead of downloading again. Retiring sources requires an explicit full
# replacement, never a partial manifest.
python "$S/scripts/register_candidates.py" --work "$W"

# Recover a legacy workspace whose ledger was damaged by a release that
# retired every source outside the incremental manifest. The repair restores
# the corpus and the plan bindings that are still live; it never revives a
# plan the runtime retired.
python "$S/scripts/repair_source_ledger.py" --work "$W"

# Re-sign decisions whose applicable-source fingerprint drifted for a
# mechanical reason, without touching the judgment itself.
python "$S/scripts/reseal_decisions.py" --work "$W"
python "$S/scripts/research.py" apply --work "$W" --decisions "$W/qa/reseal-decisions.jsonl"

# Carry a resolved publisher address back into the receipts that point at
# it. The ledger holds the publisher's own address; the receipt still holds
# the aggregate address, and the runtime compares the two. A candidate's
# identity is derived from the employer's identifier and its address, so the
# identity moves with the address and every place that names the candidate is
# renamed with it.
python "$S/scripts/apply_publisher_addresses.py" --work "$W"

# Re-derive the candidate identity for every hit whose address has moved,
# after addresses were changed outside the receipt.
python "$S/scripts/rekey_candidates.py" --work "$W"

# Resolve the aggregate addresses of a chosen set of hits, rather than of
# every aggregate hit in the workspace.
python "$S/scripts/resolve_selected.py" --work "$W" --hits /tmp/hits.json --out /tmp/resolved.json

# Carry resolved publisher addresses back into the workspace: the discovery
# inbox the registrar reads from, the candidate ledger the disposition rests
# on, and the receipts that point at the same document.
python "$S/scripts/apply_resolved_addresses.py" --work "$W" \
    --resolution "$W/qa/publisher-resolution.json"

# Bind unique ready sources at the same employer and retain unmatched leads.
python "$S/scripts/close_candidate_ledger.py" --work "$W"

# Build the registry of executed searches from the receipts. The registry
# keeps "searched and found nothing" apart from "nobody looked", and it names
# the channel each search belongs to.
python "$S/scripts/build_search_log.py" --work "$W"
python "$S/scripts/research.py" search-log-import --work "$W" --file "$W/qa/search_log.csv"

# Code the stated reasons the decisions already record.
python "$S/scripts/build_reason_codes.py" --work "$W"
python "$S/scripts/research.py" reason-apply --work "$W" --file "$W/qa/reason_codes.jsonl"

# Fill the company-context fields from the verified identity record.
python "$S/scripts/fill_profile_fields.py" --work "$W"
python "$S/scripts/research.py" apply --work "$W" --decisions "$W/qa/profile-decisions.jsonl"

# Resume the sweep and prepare the next review batch.
python "$S/scripts/run_collection.py" --work "$W" --candidates-only

# Re-judge the stored discovery hits against the workspace event window when
# the batch was produced with a per-query year window, then import the result.
python "$S/scripts/repair_discovery_window.py" --work "$W" --import-results

# Run the post-collection stage from any point, with the skill located from
# this file rather than from a hard-coded installation path.
python "$S/scripts/stage3_resume.py" --work "$W"
python "$S/scripts/stage3_resume.py" --work "$W" --from audit --resume

# Build an evidence-carrying entity registry (entity id, domains, brand and
# parent relations) from the roster and the registered sources.
python "$S/scripts/build_entity_registry.py" --work "$W"
python "$S/scripts/research.py" registry-verify --work "$W" --file "$W/qa/entity_registry.csv"

# Report conversion per company and year, plus the unresolved gaps that are
# not evidence of no layoffs.
python "$S/scripts/coverage_report.py" --work "$W"

# The rule suites.
python "$S/scripts/test_extraction_rules.py"
cd "$S/scripts" && python -m unittest test_magnitude_gate test_delivery_review \
    test_discovery test_event_review test_source_first test_publisher_resolution \
    test_v282_contracts test_v283_contracts
```

## Contract changes in v2.8.3

All rules below are generic — they read sentences, clauses and metadata, and no
company is special-cased.

* **Multi-employer sentences are clause-scoped.** A figure is read from the clause that carries the employer's own action (`while`/`whereas`/`but`, semicolons, comma-or-`and` before a capitalised name), in either sentence order; approximation qualifiers survive on counts and shares. A recorded figure that matches another clause of a multi-employer sentence is rejected by the second review.
* **Announcement date and publication date are separate facts.** The announcement date needs a dated statement in the source body; the publication date comes from the document metadata. `announcement_date_precision` records `day`/`month`/`relative`/`unknown`; a relative statement keeps its publication-date anchor; a conflict or an absent statement is `unresolved`, never a manufactured day.
* **The second review re-checks mechanically.** It re-reads the bound evidence, recomputes the clause-scoped value, verifies the recorded date at its recorded precision and checks qualifier coherence; outcomes are `revise` (with a field-specific contradiction), `abstain` (unreadable scope) or `confirm` (re-read agrees). Reviews carry `risk_flags`/`risk_rank` and are ordered with multi-employer sentences first.
* **Headcounts keep information versions.** `initial_report` / `confirmed` / `implementation_update` readings each carry a version and an `as_of`; the initial report is never silently replaced by a later confirmation.
* **HTML text keeps inline tags inline.** Inline elements introduce no line break, so link-wrapped figures stay one clause; block elements still break paragraphs.
* **Real-estate reductions are separate; mixed populations state their basis.** An office-footprint or sublease figure is not a headcount; a mixed layoff/furlough figure records its mixed basis.
* **Retrospective sources are itemised.** A source published after the event carries `source_timing=retrospective`, and recap mentions are extracted as separate items with their own figures and stated times.
* **Every relevant seed reaches a terminal state** (`discovery/seed-closure.csv`): `confirmed`, `linked`, `source_supported_exclusion` or `named_unresolved`.
* **Configuration-missing sources stay visible** (`review/configuration-gaps.json`): a missing credential drops no source from a plan.
* **Delivery packages carry an integrity manifest**: `scripts/package_integrity.py` hashes every shipped file, records runtime/schema versions and warns when the package name claims a different version than the packaged runtime reports.

## Contract changes in earlier packages

* **Source ingest is an incremental upsert.** A manifest only adds or updates the sources it names. A source outside it keeps its record, active flag, plan binding and snapshots. `retire_missing=True` is the only way to retire sources, and a retired source is not revived by a later partial manifest.
* **A committed source survives an interruption.** Each success is appended to `qa/ingest-journal.jsonl` with fsync before the ledger snapshot is rewritten every 25 commits; a restart replays the journal only when the snapshot hashes still match.
* **One document, many companies.** `qa/document-index.json` records the normalized address, content hash, redirect aliases and every company/source relation. A shared article is downloaded and parsed once per round.
* **Plan identity is not a date.** Date proximity only produces a candidate. Merging requires compatible plan identity, affected regions/departments, headcount coverage (a company-wide total is not a local subset) and announcement-versus-implementation relation. Unclear relations become `needs_review` with their source mapping. Undated pages enter `pending_review` instead of being rejected, and the event window is judged on the event date.
* **A negative finding carries its own check.** `reviewed_absent` must include `absence_check` for that variable, recomputed over every reviewed scope; a single match, an unreadable scope or a sibling variable's declaration turns it into `unresolved` with a follow-up task. `withdraw()` moves an unsupported value to `unresolved` and keeps it in `withdrawn_value`.
* **Aggregate resolution is persistent.** Each link's status, failure class, attempt count and next attempt is journaled in `qa/aggregate-resolution.jsonl`; permanent failures stop retries for that link, while unresolved candidates remain visible in `qa/coverage-gaps.json`.
* **Search answers are cached with their time range checked.** `collect_discovery.py` reuses a captured feed answer by engine and query (`--cache-days`, `--no-cache`). When most dated results fall outside the query year, the receipt records `time_range_reliable: false` and those hits are not counted as coverage of that year.
* **The delivery audit stays global.** `qa/audit-state.json` fingerprints each entity over its decisions, source hashes, schema, runtime and reviewed scope; `quality.scope.affected_entities` names what changed since the previous audit.
* **Entity identity needs evidence.** The registry records `entity_id`, domains, `brand_of`/parent relations and `verification_basis`; a company name seen only in news is `mention_only`, and a name shared by unrelated companies is held for review rather than treated as one entity.

Read [automated collection](references/automated-collection.md) for the procedure and [identity completion](references/identity-completion.md) for the registrant-filing reading.

Company-profile collection is a separate stage, supporting the nine requested fields with event-time evidence. Do not discard required history/founding/product/business-model variables to shorten source review. Context sources do not enter unrelated reason-reading scopes. Distinguish the named employing entity from its parent; current business/size must not replace historical information. Later retrospective sources need explicit timing/basis.

Execute the workflow's finite reading, decision and substantive self-review loops. Distinguish voluntary exits, forced layoffs and mixed programs; preserve date precision, numeric bounds and denominators. Verify same-plan/update/implementation relationships using actual evidence, not dates or equal counts. Export 1_layoff_announcements.xlsx: one plan/event per row, only one Results sheet, no unrequested business columns. Actual blockers stay explicit PARTIAL; source integrity errors cannot be bypassed.

## English presentation

All worksheet names, company display names, values, summaries, reasons, missing-data explanations and review metadata must be English. The only worksheet is `Results`. Read [English output and semantic checks](references/english-and-measurement.md) before writing decisions. A non-English company input is allowed: verify an English name or transliteration and set `company_en` in the roster, retaining the original legal name in the source archive. Use stable ASCII IDs. Non-English exact source quotations stay unchanged in the canonical archive; provide separately reviewed English translations for the workbook. Never label a translation as a verbatim original. The exporter rejects non-Latin authored/output strings; the reader must also check actual English meaning because this guard is not a language classifier.

Read [measurement maintenance](references/review-v152.md) when upgrading or interpreting research outputs.

Before coding and final delivery, read [source review closure](references/review-closure.md). Export also writes a review queue and sidecar index; include both with the evidence archive.


## v2.8.4 evidence closure

After extraction, run `python scripts/prepare_followups.py --work <W>` (the full runner invokes it automatically). Read `review/measurement-followups.json` and resolve its tasks through public sources and the normal `apply` command. Read cached text first and batch missing count, share and date for the same plan. Run this command again after applying corrections. Unresolved tasks remain explicit in the delivery summary; PARTIAL export remains available. A queued query is not an executed search.

For regional and closure leads, search the location and operating-unit names found in public sources, using local-language equivalents where useful. Review every relevant seed even when the company already has other events. An inaccessible article triggers alternative-source verification rather than an absent-event conclusion. Reference workbooks are validation-only and must not supply queries, values or event dates.

Periodic filings require an explicit event date and plan mapping. Quarter ends and filing dates do not define independent plans. Later news about the same headcount reduction requires comparison of scope, timing and original announcement before counting another event. Preserve uncertain relationships for review. Never use historical automation replacements as new layoffs without evidence of a current reduction.

## Discovery coverage before export
Review article bodies for admitted leads; a headline, outsourcing, or restructuring alone never confirms a layoff. Deduplicate fetches by publisher URL. Verify employer, affected group, date and plan identity separately. For each employer-year with blocked trackers or empty feeds, search general web, local notices and verified unit names (including local-language names). Sample discarded headlines per rejection reason, reopen similar hits after a false negative, and record queries, reviewed URLs and outstanding gaps before export. Never certify completeness from completed feed requests alone.
