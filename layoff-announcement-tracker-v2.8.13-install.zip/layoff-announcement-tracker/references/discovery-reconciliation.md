# Source-first discovery, Google verification and final audit

Use three ordered stages before company-profile enrichment and per-field coding. Verify roster identities first with `registry-init`, `registry-verify` and `registry-check`; add verified historical/common names to semicolon-separated `aliases`. An unverified roster identity blocks final export.

## Stage 1 — collect tracker and report seeds first

Run `seed-plan --work W`. It creates one task per roster company for each channel:

- `layoffs_fyi`: inspect the accessible Layoffs.fyi table/export or company records for the full requested window.
- `trueup`: inspect TrueUp Tech Layoffs Tracker, including available historical records.
- `thelayoff`: inspect the relevant TheLayoff.com company board and dated posts; anonymous claims remain unverified leads.
- `issuer_report`: for an applicable issuer, inspect 10-K, 20-F, annual/interim reports and related official disclosures covering the requested window for announced or implemented reductions. A private/non-reporting company needs a specific `not_applicable` basis; no filing or no mention never proves no layoff.

Use the host browser/fetch tools or authorized exports. Download a shared tracker table once and filter it locally by company, aliases and full date window where possible. Preserve the actual page/export/PDF/text capture inside the workspace before filtering. Record every inspected hit, including repeats and rejected hits with reasons. Tracker rows and report mentions are candidates, not accepted facts.

```bash
python "$S/scripts/research.py" seed-plan --work "$W"
python "$S/scripts/research.py" seed-import --work "$W" --file "$W/discovery/seed-batch.json"
python "$S/scripts/research.py" seed-status --work "$W"
```

Each seed receipt has this shape; replace examples with actual task and capture data:

```json
[
  {
    "task_id": "task ID from discovery/seed-plan.json",
    "executed_at": "2026-11-09",
    "outcome": "completed",
    "stop_basis": "Actual channel, page depth, date coverage and stopping explanation",
    "result_path": "discovery/captures/seed-result.json",
    "hits": [
      {"url": "https://example.org/lead", "title": "Actual lead title", "reported_date": "2025-01-10", "relevant": true}
    ]
  }
]
```

Use `blocked` for a named access limitation and `partial` for unfinished/truncated collection. `not_applicable` is allowed only for `issuer_report` and also needs `applicability_basis`. Missing, partial, edited or stale-capture seed tasks block Google planning; a genuine blocked channel remains visible to final audit and PARTIAL reporting.

`discovery/seed-inbox.csv` contains stable company-and-URL candidate IDs. Every relevant seed must later appear in `event_candidate_review.csv`; a seed cannot bypass reconciliation merely because it arrived before Google.

## Stage 2 — Google verifies every seed and searches for omissions

Only after `seed-status` passes, run:

```bash
python "$S/scripts/research.py" discovery-plan --work "$W"
```

The stage-2 plan contains two complementary task types:

1. `seed_verification`: one exact-title Google query per relevant stage-1 seed, using the company and all verified aliases. Search the title, employer, unit, month/year and stated number as needed to locate the original issuer statement, regulatory notice, filing or reliable independent report. Seek contradictory as well as confirming evidence. A matching repost is not independent corroboration.
2. Company/year gap discovery: `broad_news`, `unit_notice`, `alternative_news` and `official_notice` for every company and calendar year. These searches detect events absent from the initial trackers/reports. Finding one known event does not complete an annual sweep. Add local-language, subsidiary, geography and operating-unit queries when relevant.

Save every actual Google result capture. Record all inspected hits with boolean relevance and rejection reasons. Import the exact planned query, not a narrower known-event substitute:

```json
[
  {
    "task_id": "task ID from discovery/plan.json",
    "query": "exact planned query",
    "executed_at": "2026-11-09",
    "outcome": "completed",
    "stop_basis": "Actual bounded search coverage and stopping explanation",
    "result_path": "discovery/captures/google-result.json",
    "hits": [
      {"url": "https://example.org/article", "title": "Article title", "relevant": true}
    ]
  }
]
```

```bash
python "$S/scripts/research.py" discovery-import --work "$W" --file "$W/discovery/google-batch.json"
python "$S/scripts/research.py" discovery-status --work "$W"
```

`discovery/inbox.csv` preserves Google candidates; the seed inbox remains separate. Transfer both to the same candidate ledger. Distinct URLs stay distinct candidates until affirmative evidence supports a plan merge. For inaccessible leads, try at least two distinct fallback queries using exact headline, company/unit and month. Access failure, unknown count or absence of an issuer-hosted URL requires follow-up/unresolved status, not factual exclusion.

Verified regulatory notices may support local event rows without a second issuer announcement. Use actual employer, notice date, effective date and population. Keep local counts non-additive to possible parent-wide counts until overlap is resolved.

Existing search-log imports take `search_scope=event_lookup` or `window_sweep`. An event lookup cannot certify a whole-year search. A `window_sweep` needs a non-negative integer `pages_reviewed` and a specific stop condition. The snapshot-backed seed/Google gates and search-coverage contract are complementary.

## Stage 3 — reconcile, reread and audit only after both discovery stages

Run `candidate-review-prepare --work W`. Write `candidate_reviews.json` as a map from candidate ID to a source-bound review. Preserve candidate row hash, text hash, source metadata hash and exact span. Record substantive entity, date-basis, action, credibility and count-scope checks; merged candidates also need plan-link evidence.

### Recover and verify open leads

- `candidate-review-prepare` reopens legacy automated exclusions caused by a missing plan or inconclusive text rules. `register_candidates.py` considers unresolved rows even if they are already in the ledger. It prioritizes direct links and uses known publisher resolutions. Use `--resolve` on a selected batch of unresolved redirects or record an alternative public source in the candidate's `evidence_url`. Use `--retry-failed --limit N` to retry selected failed downloads. Keep forum rumors and tracker entries as leads until corroborated.
- For optional known leads, write `discovery/reference-leads.csv` with `company_id,source_url,lead_date,title`. The first two columns are required. Use verified roster IDs and article URLs. `lead_date` is a search hint. The runtime does not copy it into source publication metadata or accept it as an announcement date. Keep a separate crosswalk to benchmark row IDs when a link supplies several leads or when a row has no URL.
- `close_candidate_gaps.py` keeps readable pages that fail the text rule open. For a positive review, read the registered source and verify the employing entity, involuntary reduction and actual public announcement/notice date. Add an entry to `qa/reviewed-event-sources.json` keyed by its registered `source_id`:

```json
{
  "registered-source-id": {
    "company_id": "verified-roster-id",
    "event_date": "2024-06-20",
    "text_sha256": "current registered text hash",
    "char_start": 123,
    "quote": "Exact contiguous excerpt covering the event and its attribution.",
    "reviewer_id": "actual reviewer identifier",
    "entity_basis": "Explain the employer or verified business unit and its scope.",
    "action_basis": "Explain how the original text establishes an involuntary reduction.",
    "date_basis": "Explain how the original source establishes the announcement or notice date."
  }
}
```

Re-run `close_candidate_gaps.py` to validate the text hash, quote offset, company and window and bind the approved source. Complete the existing candidate receipt and field decisions using the cited evidence. A confirmed event can have an unknown count. Remove a stale positive review from the file or refresh it against the current text before re-running. When coverage is audited against known leads, retain original row references and record the evidence or blocker for each lead.

```json
{
  "candidate ID": {
    "candidate_sha256": "hash supplied by candidate-review-prepare",
    "reviewer_id": "actual reviewer identifier",
    "criterion_application": "Explain how the cited source supports the disposition",
    "checks": {
      "entity": "Entity and employment scope established from the source",
      "date_basis": "Announcement, notice, publication or effective date and evidence",
      "action": "Confirmed workforce reduction or evidence-supported exclusion",
      "credibility": "Publisher, attribution and provenance assessment",
      "count_scope": "Population, qualifier, component/total and numerical limitations",
      "plan_link": "Evidence of the link when merged"
    },
    "evidence": [
      {
        "source_id": "registered source ID",
        "text_sha256": "current text hash",
        "row_sha256": "current source metadata hash",
        "char_start": 0,
        "quote": "Exact normalized source quotation at this offset"
      }
    ]
  }
}
```

Excluded candidates need `exclusion_code`: `outside_window`, `wrong_entity`, `duplicate_candidate`, `no_workforce_reduction`, `voluntary_only`, `contractor_only`, `speculation_only` or `context_document`.

Complete field decisions and substantive second review, then run final `audit`. It jointly checks initial seed receipts, per-seed Google verification tasks, annual gap searches, candidate dispositions, source integrity, event semantics, plan links and measurement contracts. Do not audit only the final workbook while ignoring unprocessed seed/Google inboxes. `qa/candidate-review.json`, `review/fallback-tasks.json`, `review/seed-next.json` and `review/discovery-next.json` expose remaining work.

Batch independent searches, cache actual captures and source bodies, and read one source once for event/date/count/attribution plus its candidate receipt. Report unique seeds, Google-only candidates, corrected seeds, newly discovered events, unresolved candidates, resulting plans and access failures separately. Receipts document process; they never prove exhaustive worldwide recall.
