# layoff-announcement-tracker v2.8.3

Collect layoff announcements source-first, from Layoffs.fyi, TrueUp,
TheLayoff.com and applicable registrant filings, then verify every seed and
search every company/year for omissions. Reconcile all candidates, cluster
them into event plans, code every field with exact source evidence, audit the
result and export an English source-linked workbook.

The discovery sweep is resumable. See `references/automated-collection.md`.

## What is new in v2.8.3

All changes are generic: every rule reads sentences, clauses and metadata, and
no company is special-cased anywhere.

**Multi-employer sentences are clause-scoped.** A comparison sentence states
one figure per employer ("A said it would lay off 14% of its workforce, about
1,000 people, while B will cut nearly 700 employees, or 13% of its staff").
The count and the share are now read from the clause that carries the
employer's own action — under `while`, `whereas`, `but`, semicolons and
comma/`and` boundaries between capitalised names — in either order.
Approximation qualifiers (`nearly`, `about`) survive on counts and shares
alike. This removes the cross-employer misattribution the delivery audit
found.

**Announcement date and publication date are separate facts.** The
announcement date must be supported by a dated statement in the source body;
the publication date comes from the document metadata. A follow-up report
that says "in mid-April" supports month precision only — `announcement_date_precision`
records `day` / `month` / `relative` / `unknown`, a relative statement keeps
its publication-date anchor, a conflicting statement is `unresolved`, and no
day is manufactured from page chrome.

**The second review actually re-checks.** `build_second_reviews` re-reads the
bound evidence from the registered source, recomputes the clause-scoped value
with the current scope rules, verifies the recorded date at its recorded
precision, and checks qualifier coherence. A contradiction produces `revise`
with a field-specific reason naming both values; an unreadable scope produces
`abstain`; only a re-read that agrees produces `confirm`. Reviews are returned
in risk order (`multi_employer_sentence` first) with `risk_flags`/`risk_rank`.

**Headcounts keep information versions.** The initial report, the confirmed
figure and the implementation update each carry a version and an as-of, so a
later confirmation can neither silently replace the initial report nor be
back-filled onto it.

**HTML text keeps inline tags inline.** Inline elements no longer introduce
line breaks, so a link-wrapped figure ("will lay off <a>2,800</a> people")
stays one clause and evidence offsets map back to readable sentences; block
elements still produce paragraph breaks.

**Real-estate reductions are separate events.** An office-footprint or
sublease figure is not a headcount, and a genuine headcount survives a
sublease mention in the same article. A mixed layoff/furlough population
records its mixed basis instead of masquerading as permanent layoffs.

**Retrospective sources are itemised.** A source published after the event is
marked `source_timing=retrospective`, and each recap mention ("had cut 700
people in the first quarter") is extracted as a separate item with its own
figures and stated time.

**Every relevant seed reaches a terminal state.** `seed_closure` writes
`discovery/seed-closure.csv`: `confirmed`, `linked`,
`source_supported_exclusion` or `named_unresolved`, so a relevant seed that
closed no event stays visible instead of disappearing.

**Configuration-missing sources stay visible.** A source blocked by operator
configuration (the missing `SEC_USER_AGENT` being the recurring case) is
reported in `review/configuration-gaps.json` and never silently dropped from
a plan.

**Delivery packages carry an integrity manifest.** `scripts/package_integrity.py`
computes the SHA256 of every shipped file, records the runtime and schema
versions, and warns when the package name claims a different version than the
packaged runtime reports.

**Runtime is 2.8.3**; schema stays 1.6.0. New contract regressions live in
`scripts/test_v283_contracts.py` (35 cases, fictional employers throughout).

## What is in this release

**Ingest is incremental and resumable.** A manifest no longer retires the
sources it does not name; `retire_missing=True` is the only way to retire.
Every committed source is appended to `qa/ingest-journal.jsonl` before the
ledger snapshot, so an interrupted round resumes from the journal and verifies
the snapshot hashes instead of downloading again. Fetching is bounded
(4 workers, one request per host) with a DNS guard at the normal fetch entry.
`qa/document-index.json` stores one copy per normalized address and relates it
to every company that registers it.

**Plans are identified by evidence, not by dates.** Two pages merge only when
identity, affected regions/departments, headcount coverage and the
announcement-versus-implementation relation are compatible. Same-day regional
plans, global totals next to local subsets and consecutive coverage chains stay
apart. Undated pages go to `qa/plan-review-queue.json` as `pending_review`
rather than being discarded, and the event window is judged on the event date
with its own `date_basis`. Reconciliation matches on a shared address or the
same date plus a similar headline and never copies an old date onto a new plan.

**Negative findings are checkable.** A `reviewed_absent` decision must carry
`absence_check` for its own variable over every reviewed source. A criterion
match, an unreadable scope or a sibling variable's reading declaration turns it
into `unresolved` with a follow-up task; `withdraw()` keeps the rejected value
in `withdrawn_value`. The audit reports structure, evidence, semantic review
and coverage separately.

**Aggregate resolution and coverage gaps are persistent.** Each aggregate link
records status, failure class, attempts and next attempt in
`qa/aggregate-resolution.jsonl`. A paywall stops retries for that link but not
the search for the same report elsewhere. Unresolved candidates are written to
`qa/coverage-gaps.json` and remain coverage gaps, never "no layoffs".

**Identity is stronger.** The entity registry carries `entity_id`, domains,
`brand_of`/parent relations and `verification_basis`; a name seen only in a
news report is `mention_only`, and names shared by unrelated companies are held
for review.

**Reporting and portability.** `scripts/coverage_report.py` writes
`qa/coverage-by-company-year.csv` and a boundary-stating summary;
`scripts/stage3_resume.py` runs the post-collection stage with the skill
located from `__file__`; `scripts/repair_discovery_window.py` re-judges stored
hits against the global window. No script requires a local workspace path, a
company count or a fixed date range.

**Candidate recovery.** Reopen legacy exclusions based on a missing plan or
inconclusive text matching. Retry failed publisher sources by batch and
admit reviewed events with verified evidence. See
`references/discovery-reconciliation.md`.

**Exit rotation is automatic.** `researchcore/egress.py` detects a blocked
address from the response body as well as the status code, backs the request
rate off and recovers it on its own, and moves to a different exit node
through the local sing-box control API when the block persists. A blocked
query is filed as a `blocked` receipt, never as a zero-result query.

**Reading is scope-safe.** `researchcore/extraction.py` decides what a number
means before it becomes a claim. An industry aggregate, a year-to-date total,
a remaining headcount, a furlough and another employer's action are not
counts. A threshold keeps its bound. A before/after construction yields the
difference. A page binds to a company only when a sentence names that company
as the party performing the reduction.

**The audit enforces the magnitude rule.** `researchcore/delivery_review.py`
rejects a count that would remove more than 45% of the event-time workforce or
that exceeds it. It blocks export even under `--allow-partial`.

**Identity attributes are recovered.** `scripts/complete_identity.py` reads
the registrant filings that are already in the workspace and recovers country,
listing venue, trading symbol and event-time firm size. Without a firm size
the magnitude gate cannot run.

**Gap closing is bundled.** `scripts/close_gaps.py` searches the companies and
years the main sweep did not cover, with several engines, twelve phrasings,
subject-position phrasings and a year-scoped sweep. `scripts/build_gap_targets.py`
produces the target list from the workspace and an optional baseline.

## Layout

```
SKILL.md                        this file's overview and command list
references/
  workflow.md                   the three ordered stages and the decision rules
  automated-collection.md       the unattended collection procedure
  identity-completion.md        reading country, venue, ticker and firm size
  discovery-reconciliation.md   task and receipt schemas
  announcement-coding.md        what counts as an event and how it is coded
  english-and-measurement.md    the English output rules
  ...                           the measurement contracts and review guidance
scripts/
  research.py                   the runtime commands
  run_collection.py             the whole round, resumable
  collect_discovery.py          executes the planned searches, emits receipts
  close_gaps.py                 multi-engine search for uncovered companies
  build_gap_targets.py          builds the gap-closing target list
  complete_identity.py          recovers identity attributes from filings
  coverage_report.py            per-company/year conversion and gap report
  build_entity_registry.py      evidence-carrying entity registry
  repair_discovery_window.py    re-judges stored hits on the global window
  stage3_resume.py              resumable post-collection stage
  test_extraction_rules.py      the scope-safe reading rules
  test_magnitude_gate.py        the audit's magnitude gate
  test_v282_contracts.py        ingest, plan-identity and absence contracts
  test_v283_contracts.py        clause attribution, date evidence and review contracts
  package_integrity.py          SHA256 manifest + runtime/name version check
  researchcore/
    egress.py                   rate limiting and exit-node rotation
    extraction.py               scope-safe number and percentage reading
    event_plans.py              page clustering and entity binding
    coding.py                   source-bound decisions and second reviews
    ...                         the runtime modules
assets/                         schemas, contracts, templates
```

## Install

Unzip into the skills directory. The package must contain the
`layoff-announcement-tracker-v283/` folder. Verify with:

```bash
python "$S/scripts/research.py" runtime-check
```

which must report `pass=true`, `runtime_version=2.8.3` and
`schema_version=1.6.0`.

## Run

```bash
python "$S/scripts/run_collection.py" --work "$W" --candidates-only
```

Read `references/first-run.md` for the staged walk-through, and
`references/automated-collection.md` before a full run.
