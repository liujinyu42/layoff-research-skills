# v2.8.4

- Add regional closure, consultation and earnings reduction discovery query families for all companies. Existing full-sweep query count increases from 16 to 22 per alias/year; this is a coverage tradeoff, not a measured speed improvement.
- Pass document form and reviewed event date from registered sources into plan construction. Periodic filings without explicit event dates produce review tasks instead of filing-date events.
- Generate grouped missing-date/count/share followups from current plans and decisions in the normal runner. Cached evidence is read first. Task generation does not execute a search or resolve a field automatically.
- Add portable evidence-closure instructions and benchmark isolation.
- Validation: 299 tests run, 298 passed, one skipped. Two existing query-count expectations updated; two targeted regression tests added.

## Limits
The IBM/Luminar workbook and its run workspace were not supplied in this request. The reported six missing events and seven extra records have not been independently adjudicated. No real-company collection was rerun. Existing workspace records require re-review; upgrading code does not retroactively correct them. Existing event_review dates must still be verified against source text.
