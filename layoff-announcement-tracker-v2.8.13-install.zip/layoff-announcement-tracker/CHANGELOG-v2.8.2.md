# layoff-announcement-tracker v2.8.2 — review response

Package v2.8.2 still runs runtime **2.8.0** and schema **1.6.0**, so existing
receipts keep their scope fingerprints. This release answers the code-review
and performance-plan findings. It changes what the runtime is allowed to claim;
it does not change the 50-column output contract.

## P0-1 — Incremental ingest no longer retires the corpus

`researchcore/sources.py:ingest()` was writing every source outside the
manifest back as `active=False`. A partial manifest (newly resolved publisher
addresses, one company's retry, repaired rows) therefore deactivated 14,906
sources and dropped the entity list derived from them.

* Ingest is now an upsert: a source not named by the manifest keeps its record,
  `active` flag, `plan_id`, snapshots and history.
* Retirement requires `retire_missing=True`, which is for an explicit full
  replacement. A retired source is not revived by a later partial manifest.
* The manifest stays authoritative for the rows it does list, including an
  empty `plan_id`; a repair that clears a retired binding still takes effect.

Acceptance is pinned by `scripts/test_ledger_repair.py`
(`test_incremental_ingest_keeps_the_existing_corpus`) and
`scripts/test_v282_contracts.py`.

## P0-2 — Plan identity is no longer date proximity

`researchcore/event_plans.py` clustered pages by day gaps, so consecutive
coverage of one employer could chain two separate announcements into one plan,
and two same-day regional plans could collapse. `scripts/reconcile_plans.py`
then matched six days apart and replaced the fresh date with the historical
one.

* A date only produces a candidate and one positive signal. `_same_plan()`
  decides on existing plan identity, disjoint affected regions, disjoint
  affected departments, headcount coverage (a company-wide total is not a local
  subset), and announcement-versus-implementation (`date_basis`).
* A page joins a cluster only when it is compatible with **every** member, so
  A–B–C can no longer chain A into C.
* Uncertain relations keep their source mapping as `needs_review` /
  `review_reason`; they are not confirmed events.
* Two clusters that fall back to the same date-derived id stay separate
  (`id_basis: "date"`); only an id the corpus already carries
  (`id_basis: "registered"`) may merge.
* `reconcile_plans.py` matches on a shared address or the same date plus a
  headline Jaccard ≥ 0.5. It never copies the historical date; a mismatch is a
  `date_conflict` in `qa/plan-review-queue.json` and `event_date_conflict` on
  the plan. An unmatched old event is preserved, not dropped.

## P0-3 — Unsupported evidence is withdrawn, not reinterpreted

The runtime turned inconsistent evidence into `reviewed_absent` and copied a
sibling variable's review fields.

* `coding.absence_check(variable, scopes, ledger)` recomputes the variable's
  own criterion over every applicable source and records `checked_length` and
  `match_count` per source.
* `coding.decision()` turns a negative finding into `unresolved` when the scope
  cannot be read in full (`absence_check_unavailable`), when the criterion
  matches (`negative_claim_contradicted`), or when no applicable source exists
  (`no_applicable_source`). Each carries a `followup` task.
* `coding.withdraw()` moves a value the evidence does not support to
  `unresolved`, keeps it in `withdrawn_value`, and records `missing_reason`.
* `workflow._check_absence()` rejects a missing check, a check written for a
  different variable, an invalid pattern, a missing reviewed scope, a
  non-reproducible `checked_length`/`match_count`, and any total match.
  `normalize()` and `_cached_decision()` both call it.
* `scripts/fill_profile_fields.py` uses the same rule instead of copying a
  sibling's reading.
* `audit` now reports `status_counts`, `withdrawn` and a `quality` block split
  into `structure`, `evidence`, `semantic` and `coverage`, with the boundary
  that PARTIAL is deliverable but completeness may not be manufactured by
  copying review fields, reviving sources or deleting failed decisions.

## P0-4 — Patch scripts moved into the package

`patches/correct_discovery_window.py` and `patches/stage3-resume.sh` hard-coded
one machine's workspace and the original skill path. They are replaced by:

* `scripts/repair_discovery_window.py` — `--work` required, skill located from
  `__file__`, optional `--import-results`.
* `scripts/stage3_resume.py` — `--work` required, ordered stage list, `--only`,
  `--from`, `--resume`, `--skip-export`, `--python`.
* `scripts/build_entity_registry.py` — `--work`, `--roster`, `--out`, no fixed
  company count or date range.

## P1-5 — Publication date and event date are separate

Discovery hits are windows-judged on the global event window
(`window_start`/`window_end` in the plan payload) instead of the per-query
year. `build_plans()` stores `publication_date`, `event_date`, `date_basis`,
and judges the window on the event date; a page with no usable date goes to
`pending_review` instead of `rejected`.

## P1-6 — Aggregate resolution is persistent and gaps stay visible

`scripts/register_candidates.py` journals every link in
`qa/aggregate-resolution.jsonl` with `status`, `error_class`, `attempt` and
`next_attempt`. Permanent classes (`paywall`, `no_search`, `not_found`) stop
retries for that link only; the publisher announcement, WARN notice, reprint or
other coverage is still searched. Domain-grouped workers share one session per
host. At the end of a round `qa/coverage-gaps.json` lists unregistered,
unreadable and unresolved candidates with the note that they are gaps, not
evidence of no layoffs.

## P1-7 — Checkpointed fetching

Each committed source is appended to `qa/ingest-journal.jsonl` with `flush` and
`fsync` before the ledger snapshot is rewritten every 25 commits. A restart
replays the journal and reuses a record only when `qa/verify` hashes still
match. A torn final line is the only record ignored. DNS resolution runs
through a bounded semaphore and a daemon thread with a deadline at the normal
`_download()` entry; a blocked host fails fast and `gaierror` is left to the
HTTP client instead of hanging a worker.

## P1-8 — Entity identity needs evidence

`researchcore/registry.py` records `entity_id`, `domains`, `brand_of`,
`name_collisions`, `verification_basis` and `identity_strength`. `own_source`
and `registry_filing` require at least one domain. A name that appears only in
news is `mention_only`; a name shared by unrelated companies is flagged and
held as `pending_review`. `scripts/build_entity_registry.py` builds the CSV and
downgrades a source without a domain to `news_mention`.

## Performance plan

Implemented:

1. Persistent ingest checkpoints (journal + periodic atomic snapshot).
2. Bounded concurrency and per-domain limiting (default 4 workers, one request
   per host, `min_interval`, DNS guard, per-domain accounting possible from the
   journal).
3. Document-level cache: normalized address, content hash, redirect aliases,
   company/source relations; one download per round and across rounds.
4. Aggregate resolution progress per link and reuse per domain.
5. Search-answer cache and historical-year check. `collect_discovery.py` caches
   a successful feed answer by engine and query in `discovery/cache/search`
   (`--cache-days`, default 30; `--no-cache` disables) and reuses it when a
   receipt is lost. When at least three dated results fall outside the query
   year and 60% or more are outside it, the receipt records
   `time_range_reliable: false` and says so in `stop_basis`; those hits are
   bucketed as `undated` with the reason `time range unreliable` instead of
   being counted as coverage of several historical years.
6. Incremental audit scope. Every delivery still runs the full global audit;
   `qa/audit-state.json` stores a per-entity fingerprint over decisions, source
   hashes, schema, runtime and reviewed scope, and `quality.scope` reports the
   `affected_entities` that changed since the previous audit.
7. Tool output stays summarized: the new commands print counts and paths, not
   per-row text.

Remaining limitation, stated so it is not mistaken for done: the search cache
is per query and engine, not a semantic deduplication of near-identical
queries across companies, and `time_range_reliable` is a heuristic over dated
results (it cannot judge a feed that returns no dates at all).

## Acceptance

* `scripts/test_v282_contracts.py` (23 cases): incremental upsert and explicit
  retirement, journal restart without a network call, one download for two
  companies, same-day different departments/regions, consecutive-date chain,
  global total vs local subset, same-event merge, undated page review, event
  date window, valid/missing/sibling/tampered absence checks, contradicted and
  unreadable scopes, withdrawn value validation, reconcile identity/date
  conflicts/preserved events, cached search answers.
* Full suite: `267 passed, 1 skipped, 17 subtests passed`.
* Offline end-to-end: a fresh temporary workspace with local CSV sources runs
  ingest, clustering, reconciliation, decisions, audit and the coverage report
  without a fixed company count or date range.
