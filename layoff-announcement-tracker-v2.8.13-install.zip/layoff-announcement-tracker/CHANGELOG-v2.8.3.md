# layoff-announcement-tracker v2.8.3 — review response

Package v2.8.3 runs runtime **2.8.3** and schema **1.6.0**. Every change below
is generic: the rules read sentences, clauses and metadata, and **no company
is special-cased anywhere**. The findings the release responds to were raised
by a two-company delivery audit, but each fix lives in the shared scope,
coding, review or packaging code and applies to every roster entity, every
window and every source type.

New contract regressions: `scripts/test_v283_contracts.py` (35 cases) with
fictional employers throughout. Full suite: **302 passed, 1 skipped,
17 subtests**.

## P0-1 — Figures never cross employers in a multi-employer sentence

*Root cause.* `scoped_count` and `scoped_percentage` read at sentence level: a
comparison sentence stating one figure per employer handed the tracked
employer whichever figure came first, regardless of whose it was.

* `researchcore/extraction.py` adds clause attribution:
  `CONTRAST_CONNECTOR` (`while` / `whereas` / `but` / `;`) and
  `COMMA_NAME_BOUNDARY` (comma or `and` before a capitalised name) split a
  sentence into clauses; plain `and` between two coordinated objects of one
  verb ("cut 1,000 jobs and 500 roles") is not a boundary.
* `employer_clause_offset()` returns the clause that carries the employer's
  own action; `scoped_count()` and `scoped_percentage()` anchor their figure
  search there, in either sentence order, and keep count and share in the
  same clause.
* Approximation qualifiers (`nearly`, `about`, `around`) survive on counts
  and shares alike.
* The cross-employer guard is clause-aware: another employer acting inside
  its own clause no longer disqualifies this employer's clause, and a
  suffixed own name ("Acme Corp said") is not treated as a foreign employer.
* `other_employers_in_sentence()` normalises the tracked names before
  comparison, so the employer itself is no longer reported as a foreign name.

## P0-2 — Announcement date and publication date are separate facts

*Root cause.* `announcement_date` copied `plan["event_date"]` and
`source_publication_date` copied the plan date back; precision was hardcoded
`"day"`. A follow-up report published on 1 May that says "in mid-April"
manufactured a day the source never states.

* `_publication_date()` reads the document metadata
  (`publication_date`/`source_date`/`published_at`/`date`).
* `_date_support_record()` derives the announcement date from a dated
  statement in the source body via `extraction.event_date_support()`:
  * day statement matching the plan date → observed, precision `day`,
    evidence quoting the statement;
  * month-only statement ("mid-April") → observed, precision `month`; the
    day is not inferred;
  * relative statement ("on Monday", "this week") → precision `relative`
    with the publication date recorded as `date_anchor`;
  * no statement → `unresolved` with
    `missing_reason="announcement_date_not_stated_in_source_body"` and the
    plan date kept in `withdrawn_value`;
  * conflicting statement → `unresolved` with
    `missing_reason="announcement_date_conflicts_with_source_body"`.
* `announcement_date_precision` follows the body's statement; a missing
  publication date is `unresolved`
  (`publication_date_not_in_source_metadata`), never the event date.

## P0-3 — The second review is a re-check, not a signature

*Root cause.* `build_second_reviews` confirmed every record with a fixed
sentence; it could not catch a first-round value that belonged to another
clause of a multi-employer sentence.

* `build_second_reviews()` now re-reads the bound evidence from the
  registered source and:
  * recomputes the clause-scoped value for numeric fields — a mismatch
    produces `revise` whose reason names both the recomputed and the recorded
    value ("the recorded figure matches another clause of a multi-employer
    sentence");
  * verifies the recorded announcement date against the evidence at the
    recorded precision — an unsupported date produces `revise`;
  * checks qualifier coherence — an `exact` qualifier over an
    approximation/bound quote produces `revise`;
  * produces `abstain` when the evidence is missing or unreadable — no
    confirmation on evidence that was not read;
  * produces `confirm` only when the re-read agrees, and the confirmation
    text states what was actually re-checked.
* Reviews carry `risk_flags` and `risk_rank` and are returned in risk order:
  `multi_employer_sentence` first, then `numeric_update`,
  `retrospective_source`, `mixed_population`, `event_relationship`.
* `generate_decisions.py` and `run_collection.py` pass the per-company alias
  map (`aliases_by_company`) into the review.

## P1 — Provenance, populations and versions

* **Information versions of a headcount.** `_count_versions()` records every
  reading the plan's ready sources state, classified by wording cues into
  `initial_report` / `confirmed` / `implementation_update`, each with its own
  `source_id` and `as_of`. The layoff-count decision carries
  `information_version`, `count_as_of` and `information_versions`; the
  initial report is never silently replaced by a later confirmation.
* **HTML text keeps inline tags inline.** `_normalize()` no longer joins
  every element with a newline: text nodes are concatenated as the markup
  contains them, `<br>` becomes a line break and block elements introduce
  paragraph breaks. A link-wrapped figure ("will lay off <a>2,800</a>
  people") stays one clause and the evidence offsets map back to a readable
  sentence.
* **Real-estate reductions are separate.** `REAL_ESTATE` detects
  office-space/footprint/sublease reductions; a property-shaped clause with
  no workforce unit records no headcount, while a genuine headcount survives
  a sublease mention in the same article.
* **Mixed populations state their basis.** A "lay off or furlough" figure is
  recorded with a `mixed population` basis instead of being dropped as a
  furlough or masquerading as permanent layoffs alone; a furlough-only
  population is still not a layoff count.
* **Retrospective sources are itemised.** A source published after the event
  carries `source_timing="retrospective"` on its framing decision, and
  `extraction.retrospective_event_mentions()` extracts each recap mention
  ("had cut 700 people in the first quarter") as a separate item with its own
  figures, stated time and `recap: true` — never promoted to an announcement
  date from the publication date alone.
* **Seed-to-event closure.** `seed_sweep.seed_closure(work)` writes
  `discovery/seed-closure.csv` plus `review/seed-closure.json`: every
  relevant seed ends in exactly one auditable state — `confirmed`, `linked`,
  `source_supported_exclusion` or `named_unresolved` — so a relevant seed
  that closed no event stays visible instead of disappearing.

## P2 — Visibility and packaging

* **Configuration-missing sources stay visible.** `sources.configuration_gaps(work)`
  reports every source blocked by operator configuration (the missing
  `SEC_USER_AGENT` being the recurring case) to
  `review/configuration-gaps.json`; `run_collection.py` logs the count. A
  configuration failure is not an exclusion and never deletes a source from
  a plan; the row stays active and retryable.
* **Delivery package integrity.** New `scripts/package_integrity.py` hashes
  every shipped file (SHA256, caches excluded), records the runtime version
  from `researchcore/__init__.py` and the schema version from
  `assets/event_schema.json`, maps a compact package token (`v283` →
  `2.8.3`) and emits an explicit warning when the package name claims a
  different version than the packaged runtime reports. The manifest is
  written to `integrity-manifest.json` and travels with the archive.
* **Runtime version.** `VERSION`/`RUNTIME_VERSION` is now `2.8.3`; the
  runtime-check self-test (`VERSION == RUNTIME_VERSION`, schema `1.6.0`)
  still passes, and the package, README and SKILL name v2.8.3 consistently.

## Test surface

* `scripts/test_v283_contracts.py` — 35 new cases: clause attribution under
  `while`/`whereas`/`and` in both orders, qualifier survival, coordinated
  objects, real-estate separation, mixed populations, date support (day /
  month / relative / absent / conflicting / metadata / missing metadata),
  second review (cross-employer rejection, agreeing confirmation, abstain,
  date evidence, qualifier coherence, risk ordering), count information
  versions, HTML inline/block handling, seed closure, configuration gaps,
  package integrity, retrospective mentions and timing.
* Existing suites unchanged and passing: **302 passed, 1 skipped, 17
  subtests**.
