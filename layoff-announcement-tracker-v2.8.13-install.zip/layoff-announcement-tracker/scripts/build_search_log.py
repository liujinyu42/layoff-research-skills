#!/usr/bin/env python3
"""Build the executed-search registry from the receipts.

The search-coverage contract asks for a registry of what was actually
searched, at the grain of company x window x channel x query. The receipts
hold exactly that: who was searched, in which window, with which query, and
whether the search ran.

A receipt that produced a registered plan is a `found_events` result. A
receipt that ran and produced nothing is a `none_found` result and carries
the stopping basis that makes it a coverage statement rather than a claim
about the world. A receipt that was refused is `blocked` and carries the
reason.

The channel is derived from the search family rather than recorded by the
collector, because the collector knows which kind of query it ran and the
registry has to speak the contract's vocabulary.

Usage:

    python "$S/scripts/build_search_log.py" --work "$W" [--out "$W/qa/search_log.csv"]
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

COLUMNS = ["company_id", "company", "window_start", "window_end", "channel",
           "query", "outcome", "executed_at", "stop_condition", "notes",
           "search_scope", "events_registered", "pages_reviewed"]

# Query intent does not change the channel where the search was executed.
CHANNEL_OF_FAMILY = {
    "official_notice": "news_index",
    "unit_notice": "news_index",
    "broad_news": "news_index",
    "alternative_news": "news_index",
    "layoff_tracker": "layoff_tracker",
    "regulator_warn": "regulator_warn",
    "sec_filing": "sec_edgar",
    "exchange_disclosure": "exchange_disclosure",
}


def reviewed_candidate_plans(work):
    """Link search receipts only to reviewed, included or merged hits."""
    path = work / "event_candidate_review.csv"
    if not path.is_file():
        return {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return {r["candidate_id"]: r["plan_id"] for r in csv.DictReader(handle)
                if r["disposition"] in {"included", "merged"} and r["plan_id"]}


def plans_from_receipt(receipt, candidate_plans):
    return sorted({candidate_plans[h["candidate_id"]] for h in receipt.get("hits", [])
                   if h.get("relevant") and h.get("candidate_id") in candidate_plans})


def pages_reviewed(work, receipt):
    """How many results the search actually returned.

    The capture is the feed's own document, so the number of entries in it is
    the number of results a reader would have seen. A registry that claims a
    window was searched has to say how much was read.
    """
    path = receipt.get("result_path")
    if not path:
        return 0
    target = Path(path)
    if not target.is_absolute():
        target = work / target
    if not target.is_file():
        return 0
    try:
        text = target.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return 0
    return text.count("<item>")


def seed_rows(work, candidate_plans):
    """The tracker searches recorded by the first stage.

    The first stage reads the layoff trackers themselves, so its receipts are
    the executed-search records of the tracker channel. A tracker that could
    not be read is recorded as blocked, which the contract treats as a named
    limitation rather than a search that found nothing.
    """
    path = work / "discovery/seed-receipts.json"
    if not path.is_file():
        return []
    receipts = json.loads(path.read_text(encoding="utf-8"))
    rows = []
    for receipt in receipts.values():
        channel = receipt.get("channel")
        if channel not in ("layoffs_fyi", "trueup", "thelayoff", "issuer_report"):
            continue
        company_id = receipt.get("company_id")
        if not company_id:
            continue
        # The tracker was read as a whole rather than queried, so the record
        # of what was asked is the address that was read.
        query = str(receipt.get("source_index_url") or "").strip()
        if len(query) < 5:
            query = str(receipt.get("source_label") or channel).strip()
        outcome = receipt.get("outcome")
        found = plans_from_receipt(receipt, candidate_plans) if outcome == "completed" else []
        registry_outcome = ("blocked" if outcome == "blocked" else
                            "out_of_scope" if outcome == "not_applicable" else
                            "pending" if outcome == "partial" else
                            "found_events" if found else "none_found")
        notes = str(receipt.get("stop_basis") or "").strip() if registry_outcome in {"blocked", "out_of_scope"} else ""
        start = receipt.get("window_start") or ""
        end = receipt.get("window_end") or ""
        rows.append({
            "company_id": company_id,
            "company": receipt.get("company") or "",
            "window_start": start,
            "window_end": end,
            "channel": "other" if channel == "issuer_report" else "layoff_tracker",
            "query": query,
            "outcome": registry_outcome,
            "executed_at": receipt.get("executed_at") or "",
            "stop_condition": (receipt.get("stop_condition")
                               or receipt.get("stop_basis") or "").strip(),
            "notes": notes,
            "search_scope": receipt.get("search_scope") or "window_sweep",
            "events_registered": ";".join(found),
            "pages_reviewed": receipt.get("pages_reviewed")
            if receipt.get("pages_reviewed") is not None
            else (receipt.get("window_sweep") or {}).get("pages_reviewed") or 0,
        })
    return rows


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", default="")
    args = parser.parse_args(argv)
    work = Path(args.work).resolve()

    candidate_plans = reviewed_candidate_plans(work)
    rows = seed_rows(work, candidate_plans)
    receipts = json.loads(
        (work / "discovery/receipts.json").read_text(encoding="utf-8"))
    for receipt in receipts.values():
        company_id = receipt.get("company_id")
        query = (receipt.get("query") or "").strip()
        if not company_id or len(query) < 5:
            continue
        channel = CHANNEL_OF_FAMILY.get(receipt.get("family"), "news_index")
        outcome = receipt.get("outcome")
        found = plans_from_receipt(receipt, candidate_plans) if outcome == "completed" else []
        registry_outcome = ("blocked" if outcome == "blocked" else
                            "pending" if outcome == "partial" else
                            "found_events" if found else "none_found")
        start = receipt.get("window_start") or ""
        end = receipt.get("window_end") or ""
        # A refusal is a named limitation, and the reason belongs in the
        # registry rather than in the report that reads it.
        notes = ""
        if registry_outcome == "blocked":
            reason = (receipt.get("stop_basis") or "").strip()
            notes = reason or ("The search endpoint refused the request on "
                               "every attempted engine.")
        rows.append({
            "company_id": company_id,
            "company": receipt.get("company") or "",
            "window_start": start,
            "window_end": end,
            "channel": channel,
            "query": query,
            "outcome": registry_outcome,
            "executed_at": receipt.get("executed_at") or "",
            "stop_condition": (receipt.get("stop_basis") or "").strip(),
            "notes": notes,
            "search_scope": "event_lookup" if receipt.get("family") == "seed_verification" else "window_sweep",
            "events_registered": ";".join(found),
            "pages_reviewed": pages_reviewed(work, receipt),
        })

    out = Path(args.out) if args.out else work / "qa/search_log.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in COLUMNS})

    counts = {}
    for row in rows:
        counts[row["outcome"]] = counts.get(row["outcome"], 0) + 1
    print(json.dumps({"output": str(out), "rows": len(rows), "outcomes": counts},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
