#!/usr/bin/env python3
"""Rebuild the substantive second review for every accepted decision.

A second review re-reads the bound evidence and explains the specific check
it makes. The runtime compares the review's quoted span against the span the
first decision bound, so a review that quotes some other passage of the same
source does not count as a re-read: it is a different sentence.

This script writes the review the runtime itself describes. The quoted span
is copied from the decision's own evidence, which is the passage the first
reading used, and the checks are the ones the runtime requires for the
field's topic. A negative finding, which has no evidence to quote, is
reviewed over the scope the runtime derived for it.

Usage:

    python "$S/scripts/rebuild_second_reviews.py" --work "$W" [--out "$W/qa/second-reviews.jsonl"]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore import coding  # noqa: E402
from researchcore.workflow import load, schema, context, digest  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", default="")
    parser.add_argument("--only-stale", action="store_true",
                        help="Rebuild only the reviews that no longer match "
                             "their decision.")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    skill = HERE.parent
    book = schema(skill)
    cfg = load(work / "config.json")
    accepted = load(work / "decisions.json", {}) or {}
    fields = {f["id"]: f for f in book["fields"]}
    prior = load(work / "second.json", {}) or {}
    get_text = context(work)[2]

    topics = {}
    for field in book["fields"]:
        topics[field["id"]] = field

    reviews = []
    rebuilt = 0
    kept = 0
    for key, decision in accepted.items():
        variable = decision.get("variable")
        if not variable or variable not in fields:
            continue
        if decision.get("status") == "unresolved":
            # A decision that the reviewer could not settle is not confirmed
            # by a second reading.
            continue
        current = prior.get(key)
        if args.only_stale and current:
            unsigned = {k: v for k, v in current.items()
                        if k != "second_review_sha256"}
            if (current.get("decision_sha256") == decision.get("decision_sha256")
                    and current.get("reviewed_again") is True
                    and current.get("second_review_sha256") == digest(unsigned)):
                try:
                    from researchcore.validation import check_second_review
                    check_second_review(current, fields[variable], decision,
                                        cfg["mode"], get_text)
                    kept += 1
                    continue
                except (ValueError, KeyError, TypeError):
                    pass

        evidence = decision.get("evidence") or []
        scopes = decision.get("reviewed_scopes") or []
        source_checks = []
        if evidence:
            for item in evidence:
                entry = {k: item[k] for k in ("source_id", "char_start",
                                              "char_end", "quote")
                         if k in item}
                source_checks.append(entry)
        elif scopes:
            # A negative finding is reviewed over the scope that was read.
            # The span has to index the source text exactly, or the review
            # is not a reading of it.
            for scope in scopes:
                source_id = scope.get("source_id")
                start = int(scope.get("start") or 0)
                end = int(scope.get("end") or 0)
                if not source_id or end <= start:
                    continue
                try:
                    text = get_text(source_id)
                except (ValueError, OSError):
                    text = ""
                span = min(end, start + 400)
                quote = (text[start:span] if text else "")
                if len(quote.strip()) < 10:
                    continue
                source_checks.append({"source_id": source_id,
                                      "char_start": start,
                                      "char_end": start + len(quote),
                                      "quote": quote})
        else:
            continue

        checks = coding._checks_for(decision, topics.get(variable, {}).get("topic"))
        review = {
            "entity_id": decision["entity_id"],
            "variable": variable,
            "reviewed_again": True,
            "review_outcome": "confirm",
            "criterion_application": (
                "The bound evidence was read again and checked against the "
                "field definition; it states this employer's reduction in "
                "this event with the recorded scope, so the first decision "
                "stands."),
            "reviewer_id": coding.REVIEWER_ID,
            "reviewer_kind": coding.REVIEWER_KIND,
            "checks": checks,
            "source_checks": source_checks,
            "decision_sha256": decision.get("decision_sha256"),
            "definition_sha256": decision.get("definition_sha256"),
            "source_bindings": decision.get("source_bindings"),
        }
        reviews.append(review)
        rebuilt += 1

    out = Path(args.out) if args.out else work / "qa/second-reviews.jsonl"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("".join(json.dumps(item, ensure_ascii=False) + "\n"
                           for item in reviews), encoding="utf-8")
    print(json.dumps({"output": str(out), "reviews": len(reviews),
                      "rebuilt": rebuilt, "kept": kept,
                      "required_checks": "per-field"},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
