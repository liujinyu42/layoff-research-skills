#!/usr/bin/env python3
"""Re-derive the candidate identity after an address has moved.

A candidate's identity is derived from the employer's identifier and the
candidate's address. When an aggregate address is resolved into the
publisher's own address, the identity changes with it, and every place that
names the candidate has to be renamed with it: the receipt's hit, the ledger
row, and the disposition receipt that records what was decided about it.

The runtime re-derives the identity from the address every time it reads a
receipt, so a receipt that kept the old identity would be read as a
candidate that was never reviewed, and the ledger row that kept the old
identity would be read as a candidate that was never disposed of.

Usage:

    python "$S/scripts/rekey_candidates.py" --work "$W" [--dry-run]
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore.discovery import _digest, candidate_id  # noqa: E402

LEDGER = "event_candidate_review.csv"
FIELDS = ["candidate_id", "company", "reported_date", "source_url",
          "affected_scope", "disposition", "plan_id", "evidence_url", "reason"]


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    work = Path(args.work).resolve()

    receipts_path = work / "discovery/receipts.json"
    receipts = json.loads(receipts_path.read_text(encoding="utf-8"))
    ledger_path = work / LEDGER
    with ledger_path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    reviews_path = work / "candidate_reviews.json"
    reviews = (json.loads(reviews_path.read_text(encoding="utf-8"))
               if reviews_path.is_file() else {})

    # The name each old identity takes under its new address. The same old
    # identity can appear in several receipts for the same employer, and
    # every one of them lands on the same new identity.
    #
    # An old identity that appears under two different employers is shared:
    # the aggregate address was returned for both of their searches. The
    # identity is derived from the employer and the address, so such a
    # candidate has no single new identity. It keeps the name it has, and
    # the hit that carries it is renamed in place rather than by a shared
    # table, so the two employers' candidates stay apart.
    renamed: dict[str, str] = {}
    targets: dict[str, set] = {}
    for receipt in receipts.values():
        company = receipt.get("company_id") or ""
        if not company:
            continue
        for hit in receipt.get("hits", []):
            old = hit.get("candidate_id")
            if not old:
                continue
            new = candidate_id(company, hit.get("url") or "")
            targets.setdefault(old, set()).add(new)
    for old, names in targets.items():
        if len(names) == 1:
            new = names.pop()
            if new != old:
                renamed[old] = new

    if not renamed:
        print(json.dumps({"renamed": 0}, ensure_ascii=False))
        return 0

    # The receipt's hits carry the new identity. A hit is renamed by the
    # identity its own employer's address gives it, so two employers that
    # shared an aggregate address end up with two identities rather than one.
    for receipt in receipts.values():
        company = receipt.get("company_id") or ""
        if company:
            for hit in receipt.get("hits", []):
                new = candidate_id(company, hit.get("url") or "")
                if new != hit.get("candidate_id"):
                    hit["candidate_id"] = new
        payload = {key: value for key, value in receipt.items()
                   if key != "receipt_sha256"}
        receipt["receipt_sha256"] = _digest(payload)

    # The ledger rows and the disposition receipts are renamed with them.
    ledger_rows = []
    for row in rows:
        old = row.get("candidate_id")
        if old in renamed:
            row["candidate_id"] = renamed[old]
        ledger_rows.append(row)
    for old, new in renamed.items():
        if old in reviews:
            reviews[new] = reviews.pop(old)

    print(json.dumps({"renamed": len(renamed),
                      "ledger_rows": len(ledger_rows)}, ensure_ascii=False))
    if args.dry_run:
        return 0

    receipts_path.write_text(json.dumps(receipts, ensure_ascii=False),
                              encoding="utf-8")
    with ledger_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        for row in ledger_rows:
            writer.writerow({field: row.get(field, "") for field in FIELDS})
    if reviews_path.is_file():
        reviews_path.write_text(json.dumps(reviews, ensure_ascii=False),
                                encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
