import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from collect_discovery import run_query
from collect_seeds import filing_hits
from researchcore import sources


class MacResumeTests(unittest.TestCase):
    def test_text_only_cache_and_issuer_screen(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "config.json").write_text(json.dumps(
                {"roster": [{"company_id": "acme"}]}))
            text = b"Acme recorded severance charges under its restructuring plan."
            (work / "annual.txt").write_bytes(text)
            row = {"source_id": "annual", "company_id": "acme",
                   "source_type": "sec_filing", "document_role": "annual_report",
                   "source_url": "https://www.sec.gov/Archives/annual.htm",
                   "status": "ready", "fy": 2024, "publication_date": "2025-01-30",
                   "text_path": "annual.txt", "text_sha256": hashlib.sha256(text).hexdigest(),
                   "raw_path": "missing.raw", "content_sha256": "original-hash"}
            other = {**row, "source_id": "annual2", "source_url": row["source_url"] + "2",
                     "status": "requires_visual_review"}
            old = {**row, "source_id": "old", "fy": 2018}
            (work / "sources.json").write_text(json.dumps({"sources": [row, other, old]}))
            window = ("2019-01-01", "2026-11-13")
            outcome, _, hits, coverage = filing_hits(work, "acme", window)
            self.assertEqual(outcome, "blocked")
            self.assertEqual([h["url"] for h in hits if h["relevant"]], [row["source_url"]])
            self.assertEqual([r["screen"] for r in coverage], [
                "reduction_keyword", "unavailable", "outside_window_or_identity_only"])
            self.assertEqual(filing_hits(work, "other", window)[0], "not_applicable")

            manifest = work / "manifest.json"
            manifest.write_text(json.dumps([row]))
            with patch.object(sources, "_download", side_effect=AssertionError("unexpected download")):
                cached, *_ = sources.ingest(work, manifest)
            self.assertEqual(cached["status"], "ready")
            self.assertTrue(cached["snapshot_missing"])
            (work / "annual.txt").write_text("edited")
            self.assertEqual(filing_hits(work, "acme", window)[0], "blocked")

    def test_google_requires_a_real_feed_for_completed_receipt(self):
        egress = Mock()
        egress.get.return_value = Mock(status_code=200, text="<html>Interstitial</html>")
        self.assertEqual(run_query(egress, "query"), (None, [], "gnews:invalid_rss"))
        egress.get.return_value.text = "<rss><channel/></rss>"
        self.assertEqual(run_query(egress, "query")[1:], ([], "gnews"))


if __name__ == "__main__":
    unittest.main()
