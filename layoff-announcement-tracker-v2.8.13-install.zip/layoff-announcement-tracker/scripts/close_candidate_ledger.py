#!/usr/bin/env python3
"""Bind ledger rows to existing evidence at the same employer.

Unmatched candidates remain open for substantive review.

Usage:

    python "$S/scripts/close_candidate_ledger.py" --work "$W" [--dry-run]
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore.candidate_review import FIELDS, reopen_rule_exclusion  # noqa: E402
from researchcore.discovery import _atomic  # noqa: E402
from researchcore.event_sources import is_event_source  # noqa: E402


def load_ledger(path: Path) -> list:
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = set(FIELDS) - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"ledger lacks columns: {sorted(missing)}")
        return [{key: (row.get(key) or "").strip() for key in FIELDS}
                for row in reader]


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    work = Path(args.work).resolve()

    sources = json.loads((work / "sources.json").read_text(encoding="utf-8"))
    source_items = sources["sources"] if isinstance(sources, dict) else sources
    entities = json.loads((work / "entities.json").read_text(encoding="utf-8"))

    # The address of every ready source, and the plans it belongs to. A
    # source is a candidate's evidence when it is ready and it is an event
    # source; a candidate points at a document, so the address is what binds.
    plans_by_address = {}
    address_by_plan: dict[str, set] = {}
    for source in source_items:
        if not source.get("active", True) or not is_event_source(source):
            continue
        address = (source.get("source_url") or "").strip()
        plan = (source.get("plan_id") or "").strip()
        entity = entities.get(plan, {})
        company = (entity.get("company") or "").strip()
        if not address or not company or source.get("company_id") != entity.get("company_id"):
            continue
        plans_by_address.setdefault((company, address), set()).add(plan)
        address_by_plan.setdefault(plan, set()).add(address)

    ledger_path = work / "event_candidate_review.csv"
    rows = load_ledger(ledger_path)

    included_plans = {row["plan_id"] for row in rows
                      if row["disposition"] == "included" and row["plan_id"]}
    bound = 0
    reopened = 0
    untouched = 0
    for row in rows:
        reopened += reopen_rule_exclusion(row)
        if row["disposition"] != "unresolved":
            continue
        # The evidence address is the document the candidate rests on; it is
        # where a publisher's own page was located. The source address is
        # where the candidate was found.
        addresses = [row["evidence_url"], row["source_url"]]
        matches = [(plan, address) for address in addresses if address
                   for plan in plans_by_address.get((row["company"], address), ())]
        candidates = {plan for plan, _ in matches}
        if len(candidates) == 1:
            plan = candidates.pop()
            row.update(plan_id=plan, evidence_url=matches[0][1],
                       disposition="merged" if plan in included_plans else "included",
                       reason="The same employer and source URL are bound to this registered plan.")
            included_plans.add(plan)
            bound += 1
        else:
            untouched += 1

    # Every ready source must be spoken for by a candidate, and every
    # registered plan must have one included candidate.
    added = 0
    for plan in sorted(set(entities)):
        if plan in included_plans:
            continue
        addresses = address_by_plan.get(plan) or set()
        if not addresses:
            continue
        address = sorted(addresses)[0]
        entity = entities[plan]
        rows.append({
            "candidate_id": f"src-{plan}",
            "company": entity.get("company", ""),
            "reported_date": plan.rsplit("-", 1)[-1],
            "source_url": address,
            "affected_scope": entity.get("company", ""),
            "disposition": "included",
            "plan_id": plan,
            "evidence_url": address,
            "reason": ("The workspace holds this document as a ready source "
                       "of the plan and no candidate had claimed it."),
        })
        included_plans.add(plan)
        added += 1

    summary = {"rows": len(rows), "bound_to_plan": bound, "reopened": reopened, "excluded": 0,
               "ambiguous_left_open": untouched, "rows_added_for_plans": added}
    print(json.dumps(summary, ensure_ascii=False))
    if args.dry_run:
        return 0

    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=FIELDS)
    writer.writeheader()
    writer.writerows(rows)
    _atomic(ledger_path, output.getvalue())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
