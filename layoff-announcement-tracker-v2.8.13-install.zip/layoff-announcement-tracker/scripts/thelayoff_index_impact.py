"""Offline impact report for TheLayoff index matching (read-only, no network).

Reads the index pages a collect_seeds run saved (``<capture-dir>/<letter>/page-N.html``
plus ``<letter>/_manifest.json``) and a receipts file, then re-runs the same
TheLayoffIndex matching code for each id and prints whether the board would
resolve, be ambiguous, or stay unresolved, whether the matched key is short,
and the top 3 word-overlap near-candidates. Nothing is fetched or written.

Usage:

    python "$S/scripts/thelayoff_index_impact.py" --work "$W" \\
        --capture-dir "$W/discovery/captures/seed/thelayoff/_index" \\
        --receipts "$W/discovery/seed-batch.json" [--all] [--json]

``--work`` supplies discovery/seed-plan.json and registry/entities.json (the same
names the collector used). By default only receipts with reason board_unresolved
are examined; ``--all`` examines every thelayoff receipt, ``--ids a,b`` picks ids.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import collect_seeds  # noqa: E402

SHORT_KEY = 4


def captured_fetch(capture_dir):
    """A fetch(url) -> (status, body) that serves the saved pages only."""
    pages = {}
    root = Path(capture_dir)
    for manifest_path in sorted(root.glob("*/_manifest.json")):
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for record in manifest.get("fetches", []):
            if record.get("path"):
                file = root / record["path"]
                if file.is_file():
                    pages[record["url"]] = (record["status"], file.read_text(encoding="utf-8"))
                    continue
            pages[record["url"]] = (record.get("status", 0), "")

    def fetch(url):
        return pages.get(url, (0, ""))

    return fetch, pages


def analyse(task, entries, index):
    names = collect_seeds.candidate_names(task, entries)
    matches, notes = index.lookup(names)
    row = {"company_id": task["company_id"], "company": task["company"], "names": names,
           "index_notes": notes, "matches": [], "near": [], "status": "unresolved"}
    if len(matches) == 1:
        slug_, display = next(iter(matches.items()))
        key = index.match_key(display, names)
        row.update(status="resolved", slug=slug_, display=display, key=key,
                   short_key=len(key.replace(" ", "")) <= SHORT_KEY)
        row["matches"] = [{"slug": slug_, "display": display}]
    elif matches:
        row["status"] = "ambiguous"
        row["matches"] = [{"slug": k, "display": v} for k, v in sorted(matches.items())]
    row["near"] = [{"slug": k, "display": v, "overlap": score}
                   for k, v, score in index.near_candidates(names, exclude=set(matches))]
    row["incomplete"] = any("incomplete" in note or "error" in note for note in notes)
    return row


def run(work, capture_dir, receipts_file, only_ids=None, include_all=False):
    work = Path(work)
    plan = json.loads((work / "discovery/seed-plan.json").read_text(encoding="utf-8"))
    tasks = {t["task_id"]: t for t in plan["tasks"] if t["channel"] == "thelayoff"}
    registry = {}
    registry_file = work / "registry/entities.json"
    if registry_file.is_file():
        payload = json.loads(registry_file.read_text(encoding="utf-8"))
        registry = payload.get("entries", payload)
    receipts = json.loads(Path(receipts_file).read_text(encoding="utf-8"))
    if isinstance(receipts, dict):
        receipts = list(receipts.values())
    fetch, pages = captured_fetch(capture_dir)
    index = collect_seeds.TheLayoffIndex(fetch)  # no capture_dir: read-only
    rows = []
    for receipt in receipts:
        task = tasks.get(receipt.get("task_id"))
        if task is None:
            continue
        if only_ids and task["company_id"] not in only_ids:
            continue
        if not only_ids and not include_all and receipt.get("reason") != collect_seeds.UNRESOLVED_REASON:
            continue
        rows.append(analyse(task, registry, index))
    summary = {"examined": len(rows), "captured_pages": len(pages)}
    for status in ("resolved", "ambiguous", "unresolved"):
        summary[status] = sum(1 for row in rows if row["status"] == status)
    summary["short_key"] = sum(1 for row in rows if row.get("short_key"))
    summary["incomplete_index"] = sum(1 for row in rows if row["incomplete"])
    return rows, summary


def format_text(rows, summary):
    lines = [f"examined {summary['examined']} id(s) from {summary['captured_pages']} captured index page(s): "
             f"{summary['resolved']} resolved, {summary['ambiguous']} ambiguous, "
             f"{summary['unresolved']} unresolved, {summary['short_key']} short-key, "
             f"{summary['incomplete_index']} with an incomplete index"]
    for row in rows:
        head = f"{row['company_id']}: {row['status']}"
        if row["status"] == "resolved":
            head += f" -> /{row['slug']} ({row['display']!r}, key {row['key']!r})"
            if row["short_key"]:
                head += " SHORT-KEY: verify"
        elif row["status"] == "ambiguous":
            head += " -> " + ", ".join(f"/{m['slug']} ({m['display']!r})" for m in row["matches"])
        if row["incomplete"]:
            head += " [index incomplete]"
        lines.append(head)
        if row["status"] != "resolved" and row["near"]:
            lines.append("    near (not accepted): " + "; ".join(
                f"{n['display']!r} (/{n['slug']}, overlap {n['overlap']})" for n in row["near"]))
    return "\n".join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--work", required=True)
    parser.add_argument("--capture-dir", required=True)
    parser.add_argument("--receipts", required=True)
    parser.add_argument("--ids", default="")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    ids = {item.strip() for item in args.ids.split(",") if item.strip()}
    rows, summary = run(args.work, args.capture_dir, args.receipts, ids or None, args.all)
    if args.json:
        print(json.dumps({"summary": summary, "rows": rows}, ensure_ascii=False, indent=1))
    else:
        print(format_text(rows, summary))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
