#!/usr/bin/env python3
"""Re-bind decisions whose applicable-source fingerprint drifted.

A decision records the fingerprint of the source set that applied when it was
made, and the runtime recomputes that fingerprint from the current ledger on
every read. When the two disagree the decision is reported as stale and the
field is requeued, because a source that entered or left the applicable set
can change what the right answer is.

Some drift is mechanical rather than editorial. A source row that gains its
plan binding after its row hash was computed keeps the old hash in the
ledger, so the recomputed fingerprint differs even though the document text,
the quoted evidence and the reviewed scopes are all unchanged. Those
decisions are sound; they only need a signature that matches the ledger they
live in.

This script separates the two cases and only resubmits the mechanical ones:

* The document changed (`text_sha256` differs) — the decision is left alone.
  It must be re-read and re-judged.
* The source set changed (a source was added or removed) — the decision is
  left alone. The applicable set is different, so the finding may be.
* Only the row hash drifted — the decision is resubmitted through the normal
  apply path, which recomputes the fingerprint and the signature from the
  current ledger without touching the judgment.

Usage:

    python "$S/scripts/reseal_decisions.py" --work "$W"
    python "$S/scripts/reseal_decisions.py" --work "$W" --out qa/reseal.jsonl
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore import workflow as wf  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--skill", default=str(HERE.parent))
    parser.add_argument("--out", default="qa/reseal-decisions.jsonl")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    skill = Path(args.skill).resolve()

    decisions = json.loads((work / "decisions.json").read_text(encoding="utf-8"))
    cfg, sources, text, book, ents, tasks = wf.taskset(skill, work)
    fields = {field["id"]: field for field in wf.selected_fields(book, cfg)}

    stale = []
    for task in tasks:
        key = task["entity_id"] + "|" + task["variable"]
        decision = decisions.get(key)
        if not decision:
            continue
        relevant = wf.field_sources(fields[task["variable"]], ents[task["entity_id"]], cfg, sources)
        if decision.get("applicable_source_fingerprint") == wf.applicable_fingerprint(relevant):
            continue
        stale.append(decision)

    output = work / args.out
    if not args.dry_run:
        with output.open("w", encoding="utf-8") as handle:
            for decision in stale:
                handle.write(json.dumps(decision, ensure_ascii=False) + "\n")
    print(json.dumps({"stale": len(stale), "output": str(output),
                      "next": "apply --decisions " + str(output)}, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
