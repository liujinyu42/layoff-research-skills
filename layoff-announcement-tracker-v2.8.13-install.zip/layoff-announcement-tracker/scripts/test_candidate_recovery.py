"""Exercise a legacy workspace and its first evidence-backed event offline."""
import csv
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from close_candidate_ledger import main as close_ledger
from register_candidates import build_manifest, unregistered_hits
from researchcore import candidate_review, sources, workflow
from researchcore.discovery import candidate_id


SKILL = Path(__file__).resolve().parents[1]
URL = "https://example.org/announcement"


class CandidateRecoveryTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.work = Path(tmp.name)
        self.roster = [{"company_id": name.lower(), "company": name}
                       for name in ("Example", "Another", "Excluded")]
        result = workflow.init(SKILL, self.work, self.roster, "2024:2024",
                               "2024-01-01", "2024-12-31")
        self.assertEqual(result["mode"], "events")
        self.cfg = workflow.load(self.work / "config.json")
        (self.work / "discovery").mkdir()
        (self.work / "discovery/reference-leads.csv").write_text(
            "company_id,source_url,lead_date,title\n" +
            "".join(f"{r['company_id']},{URL},2024-01-02,Example notice\n" for r in self.roster))
        self.ledger = self.work / "event_candidate_review.csv"
        self.write_csv(self.ledger, [
            dict(candidate_id=candidate_id("example", URL), company="Example", source_url=URL,
                 disposition="excluded", reason=candidate_review.LEGACY_RULE_EXCLUSIONS[0]),
            dict(candidate_id=candidate_id("excluded", URL), company="Excluded", source_url=URL,
                 disposition="excluded", reason="The notice explicitly says the offer is voluntary."),
        ], candidate_review.FIELDS)
        workflow.save(self.work / "entities.json", {})

    @staticmethod
    def write_csv(path, rows, fields):
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)

    def load_ledger(self):
        return {row["company"]: row for row in workflow.rows(self.ledger)}

    def test_reopen_register_review_and_bind_first_event(self):
        workflow.save(self.work / "sources.json", {"sources": []})
        close_ledger(["--work", str(self.work)])
        self.assertEqual(self.load_ledger()["Example"]["disposition"], "unresolved")
        self.assertEqual(self.load_ledger()["Excluded"]["disposition"], "excluded")
        candidate_review.prepare(self.work, self.cfg, {})
        hits = unregistered_hits(self.work)
        self.assertEqual({h["company_id"] for h in hits}, {"example", "another"})
        rows, _, _ = build_manifest(self.work, [h for h in hits if h["company_id"] == "example"])
        self.assertEqual(rows[0]["publication_date"], "")
        body = ("Example issued a public statement on June 20, 2024. "
                "It will dismiss members of the operations team. "
                "The statement describes the action as compulsory and does not disclose its size. "
                "Operations staff will be notified individually in the coming days.")
        local = self.work / "page.txt"
        local.write_text(body)
        rows[0]["local_path"] = str(local)
        manifest = self.work / "qa/full_manifest.csv"
        self.write_csv(manifest, rows, list(rows[0]))
        [source] = sources.ingest(self.work, manifest, offline=True)
        self.assertEqual(source["status"], "ready")
        sid = source["source_id"]

        def run_driver():
            return subprocess.run([sys.executable, str(SKILL / "scripts/run_collection.py"),
                                   "--work", str(self.work), "--skip-search", "--skip-retrieve",
                                   "--candidates-only"], capture_output=True, text=True)

        result = run_driver()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.load_ledger()["Example"]["disposition"], "unresolved")
        tasks = workflow.load(self.work / "review/candidate-tasks.json")
        self.assertTrue(any(t["candidate"]["company"] == "Example" and t["source_bindings"] for t in tasks))
        review_path = self.work / "qa/reviewed-event-sources.json"
        review = dict(company_id="example", event_date="2024-06-20", text_sha256=source["text_sha256"],
                      char_start=1, quote=body, reviewer_id="test",
                      entity_basis="The opening identifies Example.",
                      action_basis="The next two sentences establish compulsory dismissals.",
                      date_basis="The first sentence dates the public statement.")
        workflow.save(review_path, {sid: review})
        self.assertNotEqual(run_driver().returncode, 0)
        review["char_start"] = 0
        workflow.save(review_path, {sid: review})
        result = run_driver()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        [plan] = workflow.load(self.work / "qa/event-plans.json")["plans"]
        self.assertEqual(plan["event_date"], "2024-06-20")
        self.assertIsNone(plan["count"])
        ledger = self.load_ledger()
        self.assertEqual(ledger["Example"]["plan_id"], plan["plan_id"])
        self.assertEqual(ledger["Another"]["disposition"], "unresolved")
        self.assertEqual(ledger["Excluded"]["disposition"], "excluded")

    def test_selected_retry_retries_only_one_failed_source(self):
        manifest = self.work / "qa/full_manifest.csv"
        rows, _, _ = build_manifest(self.work, unregistered_hits(self.work))
        self.write_csv(manifest, rows, list(rows[0]))
        with patch("researchcore.sources._download", side_effect=ValueError("Unavailable")):
            sources.ingest(self.work, manifest)
        self.assertEqual(unregistered_hits(self.work), [])
        self.assertEqual(len(unregistered_hits(self.work, retry_failed=True)), 2)
        with patch("researchcore.sources._download", return_value=(b"Recovered text.", "text/plain", "")) as download:
            result = sources.ingest(self.work, manifest, new_only=True, retry_source_ids={rows[0]["source_id"]})
        self.assertEqual(download.call_count, 1)
        self.assertEqual([s["status"] for s in result], ["ready", "failed"])


if __name__ == "__main__":
    unittest.main()
