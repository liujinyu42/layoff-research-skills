#!/usr/bin/env python3
"""Rebuild receipts from captures the executor saved but never recorded.

The executor saves each result capture before it records the receipt, and it
flushes the receipt batch every fifty tasks. When the process is interrupted
between a capture and the flush, the capture survives and the receipt does
not, so the evidence is on disk but the contract does not know about it.

This tool reads the orphaned captures and writes the receipts they support.
The query comes from the plan, so the recorded query is the planned query
and not something reconstructed after the fact. The relevance verdict is
recomputed with the same rule the executor uses, so a rebuilt receipt is
indistinguishable from one the executor wrote.

Usage:

    python "$S/scripts/rebuild_receipts.py" --work "$W"
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urldefrag

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from collect_discovery import hit_relevant, is_generic, canonical  # noqa: E402

CAPTURE_DIR = "discovery/captures/search"


def read_json(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        return default


def parse_items(body):
    items = []
    try:
        root = ET.fromstring(body)
    except ET.ParseError:
        return items
    for node in root.iter("item"):
        def field(name):
            child = node.find(name)
            return (child.text or "").strip() if child is not None and child.text else ""
        link = field("link")
        if not link:
            for guid in node.iter("guid"):
                if guid.text and guid.text.startswith("http"):
                    link = guid.text.strip()
                    break
        source = ""
        source_url = ""
        for src in node.iter("source"):
            if src.text:
                source = src.text.strip()
            if src.get("url"):
                source_url = src.get("url")
            break
        items.append({"title": field("title"), "link": link, "source": source,
                      "source_url": source_url, "pub": field("pubDate")})
    return items


def iso_date(pub):
    import re
    for fmt in ("%a, %d %b %Y %H:%M:%S %Z", "%a, %d %b %Y %H:%M:%S %z",
                "%d %b %Y %H:%M:%S %Z", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(pub, fmt).date().isoformat()
        except Exception:  # noqa: BLE001
            continue
    return ""


def task_id_from_capture(name):
    """The task id a capture file was written for."""
    stem = os.path.splitext(name)[0]
    return stem.split("-2026")[0] if "-2026" in stem else stem


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", default="")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    plan = read_json(work / "discovery/plan.json", {}) or {}
    tasks = {t["task_id"]: t for t in plan.get("tasks", [])}
    if not tasks:
        print("no plan found; run discovery-plan first")
        return 0

    batch_path = Path(args.out) if args.out else work / "discovery/google-v261.json"
    batch = read_json(batch_path, []) or []
    recorded = {row.get("result_path") for row in batch}

    capture_dir = work / CAPTURE_DIR
    rebuilt = []
    for capture in sorted(capture_dir.glob("search-*.xml")):
        relative = os.path.relpath(capture, work)
        if relative in recorded:
            continue
        task_id = task_id_from_capture(capture.name)
        task = tasks.get(task_id)
        if not task:
            continue
        body = capture.read_text(encoding="utf-8", errors="replace")
        if "<item>" not in body:
            # The capture records that the endpoint refused. The executor
            # already wrote that task's blocked receipt, or will write it.
            continue
        items = parse_items(body)
        hits = []
        seen = set()
        aliases = task.get("aliases") or [task.get("company", "")]
        generic = any(is_generic(name) for name in aliases)
        for item in items:
            url = canonical(item["link"])
            if not url or url in seen:
                continue
            seen.add(url)
            relevant, reason = hit_relevant(item["title"], aliases, generic)
            hits.append({"url": url, "title": item["title"], "relevant": bool(relevant),
                         "exclusion_reason": "" if relevant else reason,
                         "publisher": item.get("source", ""),
                         "publisher_url": item.get("source_url", ""),
                         "reported_date": iso_date(item.get("pub", ""))})
        receipt = {"task_id": task_id, "query": task["query"],
                   "executed_at": dt.date.today().isoformat(),
                   "outcome": "completed",
                   "stop_basis": ("The planned query executed and every returned result was "
                                  "inspected for relevance; the feed returned "
                                  f"{len(items)} result(s) with no further pages offered."),
                   "result_path": relative, "hits": hits}
        rebuilt.append(receipt)

    print(f"captures without a receipt: {len(rebuilt)}")
    if args.dry_run:
        for receipt in rebuilt[:5]:
            print(f"  {receipt['task_id']} hits={len(receipt['hits'])}")
        return 0

    if rebuilt:
        # A task may appear twice when the executor wrote a receipt and a
        # later run wrote a newer capture for the same task. The newest
        # capture wins, because it is the answer the endpoint gave last.
        merged = {}
        for row in batch + rebuilt:
            merged[row.get("task_id")] = row
        final = list(merged.values())
        batch_path.write_text(json.dumps(final, ensure_ascii=False, indent=1),
                              encoding="utf-8")
        print(f"{len(rebuilt)} receipt(s) rebuilt; {len(final)} task(s) in {batch_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
