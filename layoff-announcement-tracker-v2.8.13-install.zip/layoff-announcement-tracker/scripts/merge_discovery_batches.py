"""Merge every Stage-2 batch file into the workspace receipt ledger.

The collector writes one batch file per run, and each run resumes from
`discovery/receipts.json`. A workspace where several rounds were executed
therefore holds valid receipts in `discovery/google-*.json` that the runtime
never sees: the ledger still shows those tasks as unexecuted, the collector
re-executes them, and the audit reports a coverage gap that no amount of
searching can close.

This script closes that gap. It gathers every receipt found in the workspace,
keeps the newest revision of each task, validates each one against the plan
and the receipt contract, and imports the survivors through the runtime's own
`discovery.import_results`. Nothing is written to the ledger directly: the
import path re-checks every rule and re-signs the receipt, so a receipt that
enters the ledger this way is indistinguishable from one the runtime imported
itself.

Usage:

    python "$S/scripts/merge_discovery_batches.py" --work "$W"
    python "$S/scripts/merge_discovery_batches.py" --work "$W" --dry-run
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from researchcore import discovery  # noqa: E402
from researchcore.workflow import load  # noqa: E402

# Files that are not collector batches: the ledger itself, its archives and
# the projections the runtime writes from it.
NOT_A_BATCH = {"receipts.json", "plan.json", "seed-plan.json", "seed-receipts.json",
                "seed-batch.json", "inbox.csv", "seed-inbox.csv"}


def _is_backup(name):
    return (".bak" in name or ".old-format" in name or ".retry-base" in name
            or name.startswith("history") or name.startswith("seed-history"))


def _batch_files(work):
    """Every file that may hold a collector batch, newest revision first."""
    directory = work / "discovery"
    if not directory.is_dir():
        return []
    files = []
    for path in sorted(directory.glob("*.json")):
        if path.name in NOT_A_BATCH or _is_backup(path.name):
            continue
        files.append(path)
    return files


def _receipts_in(path):
    """Read a file that may hold a batch list, a receipt map or neither."""
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return []
    if isinstance(data, dict):
        data = list(data.values())
    if not isinstance(data, list):
        return []
    return [item for item in data if isinstance(item, dict) and item.get("task_id")]


def _revision_key(receipt):
    """Order revisions of the same task: later execution wins, then the one
    that actually returned a document."""
    return (str(receipt.get("executed_at") or ""),
            1 if receipt.get("outcome") == "completed" else 0,
            len(receipt.get("hits") or []))


def _validate(work, receipt, tasks):
    """Return the reason a receipt cannot enter the ledger, or None."""
    task_id = receipt.get("task_id")
    task = tasks.get(task_id)
    if task is None:
        return "task_id is not in the current plan"
    if receipt.get("query") != task["query"]:
        return "the recorded query differs from the planned query"
    if receipt.get("outcome") not in {"completed", "blocked", "partial"}:
        return "invalid outcome"
    if len(str(receipt.get("stop_basis") or "").strip()) < 15:
        return "no specific stopping or blocking reason"
    result_path = receipt.get("result_path")
    if not result_path:
        return "no saved result page"
    path = (work / result_path).resolve()
    if not path.is_relative_to(work.resolve()) or not path.is_file():
        return "the saved result page is missing from the workspace"
    if not path.read_bytes():
        return "the saved result page is empty"
    hits = receipt.get("hits")
    if not isinstance(hits, list):
        return "hits must be a list"
    for hit in hits:
        if not isinstance(hit, dict):
            return "a hit is not an object"
        url = str(hit.get("url") or "").strip()
        if not url.startswith(("http://", "https://")):
            return "a hit lacks an absolute URL"
        if not hit.get("title") or type(hit.get("relevant")) is not bool:
            return "a hit lacks a title or a boolean relevance verdict"
        if not hit["relevant"] and not str(hit.get("exclusion_reason") or "").strip():
            return "an irrelevant hit lacks an exclusion reason"
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", default="")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    plan = json.loads((work / "discovery/plan.json").read_text(encoding="utf-8"))
    tasks = {item["task_id"]: item for item in plan["tasks"]}

    ledger_path = work / "discovery/receipts.json"
    ledger = json.loads(ledger_path.read_text(encoding="utf-8")) if ledger_path.is_file() else {}

    newest = {}
    sources = {}
    for path in _batch_files(work):
        for receipt in _receipts_in(path):
            task_id = receipt.get("task_id")
            if task_id not in tasks:
                continue
            current = newest.get(task_id)
            if current is None or _revision_key(receipt) > _revision_key(current):
                newest[task_id] = receipt
                sources[task_id] = path.name
    for task_id, receipt in ledger.items():
        if task_id not in tasks:
            continue
        current = newest.get(task_id)
        if current is None or _revision_key(receipt) > _revision_key(current):
            newest[task_id] = receipt
            sources[task_id] = "receipts.json"

    rejected = {}
    accepted = []
    for task_id, receipt in newest.items():
        problem = _validate(work, receipt, tasks)
        if problem:
            rejected[task_id] = problem
            continue
        accepted.append(receipt)

    pending = sum(1 for task_id in tasks if task_id not in accepted)
    print(f"planned tasks      : {len(tasks)}")
    print(f"receipts found     : {len(newest)}")
    print(f"accepted for import: {len(accepted)}")
    print(f"rejected           : {len(rejected)}")
    print(f"still without one  : {pending}")
    if rejected:
        counts = {}
        for reason in rejected.values():
            counts[reason] = counts.get(reason, 0) + 1
        for reason, count in sorted(counts.items(), key=lambda kv: -kv[1]):
            print(f"  rejected {count:>6}  {reason}")
    if args.dry_run:
        return 0
    if not accepted:
        print("nothing to import")
        return 0

    out = Path(args.out) if args.out else work / "discovery/merged-batches.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(accepted, ensure_ascii=False, indent=1), encoding="utf-8")
    cfg = load(work / "config.json")
    status = discovery.import_results(work, cfg, out)
    print(f"imported {len(accepted)} receipt(s)")
    print(f"ledger now holds   : {status.get('receipts', '?')} receipt(s)")
    print(f"pending tasks      : {status.get('pending_tasks')}")
    print(f"unique hits        : {status.get('unique_relevant_hits')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
