"""Contract regressions for the 2.8.2 review findings.

Each case pins a behaviour the previous release got wrong:

* an incremental manifest must not retire the corpus it does not list;
* a committed source must survive a lost ledger snapshot and a restart;
* one document downloaded for two companies is stored once and related twice;
* two pages merge only on identity, scope and headcount coverage, never on a
  date gap alone — same-day regional plans and consecutive coverage of one
  employer are not one event;
* a negative finding must carry its own variable's recomputable absence check
  and cannot reuse a sibling variable's reading declaration;
* reconciliation matches on evidence (shared address or same date plus similar
  headline) and never copies a historical date onto a fresh plan.
"""
import csv
import json
import tempfile
import unittest
from pathlib import Path

import reconcile_plans
from researchcore import coding
from researchcore import event_plans
from researchcore import sources as source_module
from researchcore import workflow as wf

MANIFEST_FIELDS = ["source_id", "company_id", "source_type", "source_url",
                   "local_path", "document_role", "fy", "plan_id",
                   "publication_date", "source_date", "exchange", "form",
                   "source_language"]


def manifest_row(source_id, company_id, url=None, plan_id=""):
    record = {field: "" for field in MANIFEST_FIELDS}
    record.update({
        "source_id": source_id,
        "company_id": company_id,
        "source_type": "news",
        "source_url": url or f"https://example.test/{source_id}",
        "document_role": "news_report",
        "plan_id": plan_id,
        "source_language": "en",
    })
    return record


PAD = ("The company employs people in many locations. "
       "This paragraph is background about the business and its operations. "
       "It carries no further figure or decision. ")


class IngestContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)
        (self.work / "qa").mkdir()
        (self.work / "config.json").write_text(json.dumps({
            "roster": [{"company_id": "acme-1", "company": "Acme"},
                       {"company_id": "beta-1", "company": "Beta"}]}), encoding="utf-8")
        self.manifest = self.work / "qa/full_manifest.csv"

    def write_manifest(self, rows):
        with self.manifest.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=MANIFEST_FIELDS)
            writer.writeheader()
            for record in rows:
                writer.writerow(record)

    def download(self, calls, body=b"Acme Corp said it will lay off 120 employees."):
        def fake(url):
            calls.append(url)
            return body, "text/plain", url
        return fake

    def test_committed_source_survives_a_lost_ledger_snapshot(self):
        self.write_manifest([manifest_row("news-a", "acme-1")])
        original = source_module._download
        source_module._download = self.download([])
        try:
            first = source_module.ingest(self.work, self.manifest)
        finally:
            source_module._download = original
        self.assertEqual(first[0]["status"], "ready")
        content_sha = first[0]["content_sha256"]
        # The snapshot is lost after the interruption; the recovery log and the
        # content-addressed files remain.
        (self.work / "sources.json").unlink()

        def refuse(_url):
            raise AssertionError("a committed source must not be fetched again")

        source_module._download = refuse
        try:
            second = source_module.ingest(self.work, self.manifest)
        finally:
            source_module._download = original
        self.assertEqual(second[0]["status"], "ready")
        self.assertEqual(second[0]["content_sha256"], content_sha)

    def test_one_document_is_downloaded_once_for_two_companies(self):
        shared = "https://example.test/shared-report"
        self.write_manifest([manifest_row("news-a", "acme-1", shared),
                             manifest_row("news-b", "beta-1", shared)])
        calls = []
        original = source_module._download
        source_module._download = self.download(calls)
        try:
            records = source_module.ingest(self.work, self.manifest, max_workers=1)
        finally:
            source_module._download = original
        self.assertEqual(len(calls), 1)
        self.assertEqual({record["status"] for record in records}, {"ready"})
        documents = json.loads(
            (self.work / "qa/document-index.json").read_text(encoding="utf-8"))["documents"]
        stored = [doc for doc in documents.values() if not doc.get("alias_of")]
        self.assertEqual(len(stored), 1)
        self.assertEqual(set(stored[0]["company_ids"]), {"acme-1", "beta-1"})
        self.assertEqual(set(stored[0]["source_ids"]), {"news-a", "news-b"})


def page(source_id, title, text, day="2025-03-04", event_date="", plan_id=""):
    return {"company_id": "acme-1", "source_id": source_id, "url": f"https://example.test/{source_id}",
            "title": title, "date": day, "event_date": event_date, "text": text + " " + PAD,
            "plan_id": plan_id}


IDENTITIES = {"acme-1": {"company": "Acme Corp", "firm_size": 20000}}


class PlanIdentityTests(unittest.TestCase):
    window = ("2019-01-01", "2026-12-31")

    def build(self, records):
        return event_plans.build_plans(records, IDENTITIES, *self.window)

    def test_same_day_different_departments_stay_two_plans(self):
        engineering = page("s1", "Acme cuts engineering roles",
                           "Acme Corp said the job cuts affect its engineering division in Texas.")
        sales = page("s2", "Acme cuts sales roles",
                     "Acme Corp said the job cuts affect its sales division in Texas.")
        plans, rejected, pending = self.build([engineering, sales])
        self.assertEqual(len(plans), 2)
        self.assertFalse(rejected)
        self.assertFalse(pending)

    def test_same_day_different_regions_stay_two_plans(self):
        germany = page("s1", "Acme cuts jobs in Germany",
                       "Acme Corp said the job cuts affect its operations in Germany.")
        canada = page("s2", "Acme cuts jobs in Canada",
                      "Acme Corp said the job cuts affect its operations in Canada.")
        plans, _rejected, _pending = self.build([germany, canada])
        self.assertEqual(len(plans), 2)

    def test_consecutive_coverage_does_not_chain_plans(self):
        """A-B and B-C overlap, but A and C name disjoint departments."""
        first = page("s1", "Acme cuts engineering jobs",
                     "Acme Corp said the job cuts affect its engineering division in Texas.",
                     day="2025-03-01")
        bridge = page("s2", "Acme confirms reductions",
                      "Acme Corp said the job cuts affect its engineering and sales "
                      "divisions in Texas.", day="2025-03-02")
        last = page("s3", "Acme cuts sales jobs",
                    "Acme Corp said the job cuts affect its sales division in Texas.",
                    day="2025-03-03")
        plans, _rejected, _pending = self.build([first, bridge, last])
        self.assertEqual(len(plans), 2)
        merged_ids = {source["source_id"] for plan in plans for source in plan["sources"]}
        self.assertEqual(merged_ids, {"s1", "s2", "s3"})
        self.assertFalse(any(plan.get("needs_review") for plan in plans))

    def test_company_wide_total_and_local_subset_are_not_merged(self):
        total = page("s1", "Acme cuts 1,000 jobs worldwide",
                     "Acme Corp said it will lay off 1,000 employees globally.")
        local = page("s2", "Acme cuts 200 jobs in Texas",
                     "Acme Corp said it will lay off 200 employees at its plant in Texas.")
        plans, _rejected, _pending = self.build([total, local])
        self.assertEqual(len(plans), 2)
        counts = sorted(plan["count"]["value"] for plan in plans if plan.get("count"))
        self.assertEqual(counts, [200, 1000])

    def test_same_event_merges_on_scope_and_headcount(self):
        report = page("s1", "Acme cuts engineering jobs in Texas",
                      "Acme Corp said the job cuts affect its engineering division in Texas.")
        followup = page("s2", "Acme confirms engineering cuts in Texas",
                        "Acme Corp said the job cuts affect its engineering division in Texas.",
                        day="2025-03-05")
        plans, _rejected, _pending = self.build([report, followup])
        self.assertEqual(len(plans), 1)
        self.assertEqual(plans[0]["n_sources"], 2)

    def test_undated_page_goes_to_review_not_rejection(self):
        undated = page("s1", "Acme cuts jobs",
                       "Acme Corp said the job cuts affect its engineering division in Texas.",
                       day="")
        plans, rejected, pending = self.build([undated])
        self.assertEqual(plans, [])
        self.assertEqual(rejected, [])
        self.assertEqual(len(pending), 1)
        self.assertIn("cannot be judged", pending[0]["review_reason"])

    def test_event_window_is_judged_on_the_event_date(self):
        # Published after the window closes, but the event itself is inside it.
        retrospective = page("s1", "Acme announces cuts",
                             "Acme Corp said the job cuts affect its engineering division in Texas.",
                             day="2027-02-01", event_date="2026-11-02")
        plans, rejected, _pending = self.build([retrospective])
        self.assertEqual(len(plans), 1)
        self.assertEqual(plans[0]["date_basis"], "event_date")
        self.assertFalse(rejected)


class SearchCacheTests(unittest.TestCase):
    def test_a_captured_answer_is_reused_without_a_request(self):
        import collect_discovery as cd
        with tempfile.TemporaryDirectory() as tmp:
            cache = Path(tmp)
            xml = ('<rss><channel><item><title>Acme cuts 100 jobs</title>'
                   '<link>https://example.test/a</link>'
                   '<pubDate>Mon, 10 Jun 2025 00:00:00 GMT</pubDate>'
                   '<source url="https://publisher.test">Publisher</source>'
                   '</item></channel></rss>')
            (cache / f"{cd.cache_key('Acme layoffs 2025', 'gnews')}.xml").write_text(
                xml, encoding="utf-8")

            class Refuse:
                calls = 0

                def get(self, _url):
                    Refuse.calls += 1
                    raise AssertionError("a cached query must not hit the network")

            raw, items, engine = cd.run_query(Refuse(), "Acme layoffs 2025", "gnews",
                                              cache_dir=cache, cache_days=30)
            self.assertEqual(engine, "gnews")
            self.assertEqual(len(items), 1)
            self.assertEqual(Refuse.calls, 0)
            self.assertIn("Acme cuts 100 jobs", raw)


class NegativeFindingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)
        self.texts = {}

    def ledger(self, source_id, text):
        path = self.work / "text" / source_id / "snapshot.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        self.texts[source_id] = text
        return {"source_id": source_id, "status": "ready",
                "text_path": path.relative_to(self.work).as_posix(),
                "_work": str(self.work)}

    def clean_decision(self, source_id="s1", text="The company reported stable operations."):
        ledger = {source_id: self.ledger(source_id, text)}
        scopes = [{"source_id": source_id, "start": 0, "end": len(text)}]
        return coding.decision(
            "plan-acme-1", "ma_activity", "reviewed_absent", None,
            "The applicable source states no transaction.",
            "No acquisition, merger or divestiture is reported.", [],
            _scopes=scopes, _sources=ledger)

    def test_valid_absence_check_is_recorded(self):
        decision = self.clean_decision()
        self.assertEqual(decision["status"], "reviewed_absent")
        check = decision["absence_check"]
        self.assertEqual(check["variable"], "ma_activity")
        self.assertEqual(check["total_matches"], 0)
        self.assertEqual(check["per_source"]["s1"]["checked_length"],
                         len(self.texts["s1"]))
        self.assertNotIn("_sources", decision)
        self.assertNotIn("_scopes", decision)

    def test_missing_absence_check_is_rejected(self):
        decision = self.clean_decision()
        decision.pop("absence_check")
        with self.assertRaisesRegex(ValueError, "requires absence_check"):
            wf._check_absence(decision, "ma_activity", decision["reviewed_scopes"],
                              lambda sid: self.texts[sid])

    def test_sibling_variable_declaration_is_rejected(self):
        decision = self.clean_decision()
        with self.assertRaisesRegex(ValueError, "cannot reuse"):
            wf._check_absence(decision, "stated_reason_text",
                              decision["reviewed_scopes"],
                              lambda sid: self.texts[sid])

    def test_check_must_cover_every_reviewed_scope(self):
        decision = self.clean_decision()
        decision["absence_check"]["per_source"]["other"] = {
            "checked_length": 10, "match_count": 0}
        with self.assertRaisesRegex(ValueError, "every reviewed scope"):
            wf._check_absence(decision, "ma_activity", decision["reviewed_scopes"],
                              lambda sid: self.texts[sid])

    def test_check_length_must_match_the_registered_text(self):
        decision = self.clean_decision()
        decision["absence_check"]["per_source"]["s1"]["checked_length"] += 1
        with self.assertRaisesRegex(ValueError, "checked_length"):
            wf._check_absence(decision, "ma_activity", decision["reviewed_scopes"],
                              lambda sid: self.texts[sid])

    def test_criterion_match_turns_the_negative_into_an_open_item(self):
        decision = self.clean_decision(
            text="Acme acquired Beta Corp in 2024 and completed the merger that year.")
        self.assertEqual(decision["status"], "unresolved")
        self.assertIsNone(decision["value"])
        self.assertIn("negative_claim_contradicted", decision["missing_reason"])
        self.assertIn("followup", decision)

    def test_unreadable_scope_turns_the_negative_into_an_open_item(self):
        source_id = "s1"
        ledger = {source_id: {"source_id": source_id, "status": "ready",
                              "text_path": "text/missing/snapshot.txt",
                              "_work": str(self.work)}}
        decision = coding.decision(
            "plan-acme-1", "ma_activity", "reviewed_absent", None,
            "The applicable source states no transaction.", "No transaction is reported.",
            [], _scopes=[{"source_id": source_id, "start": 0, "end": 10}],
            _sources=ledger)
        self.assertEqual(decision["status"], "unresolved")
        self.assertIn("absence_check_unavailable", decision["missing_reason"])

    def test_no_applicable_source_cannot_support_an_absence(self):
        decision = coding.decision(
            "plan-acme-1", "ma_activity", "reviewed_absent", None,
            "No source applies to this field.", "No transaction is reported.", [],
            _scopes=[], _sources={})
        self.assertEqual(decision["status"], "unresolved")
        self.assertEqual(decision["missing_reason"], "no_applicable_source")

    def test_withdrawn_value_must_be_unresolved_and_null(self):
        field = {"id": "ma_activity", "type": "binary", "source_roles": []}
        fields = {"ma_activity": field}
        entities = {"plan-acme-1": {"entity_id": "plan-acme-1", "company_id": "acme-1",
                                    "plan_id": "plan-acme-1"}}
        cfg = {"mode": "events", "roster": [{"company_id": "acme-1", "company": "Acme"}]}
        record = {
            "entity_id": "plan-acme-1", "variable": "ma_activity",
            "status": "observed", "value": 1, "withdrawn_value": 1,
            "reason": "Supported by the source.", "criterion_application": "Statement found.",
            "reviewer_id": "r", "reviewer_kind": "model", "evidence": [],
            "reviewed_scopes": [], "source_bindings": {},
            "definition_sha256": wf.digest(field),
            "applicable_source_fingerprint": wf.digest({}),
        }
        record["decision_sha256"] = wf.digest(record)
        with self.assertRaisesRegex(ValueError, "withdrawn value"):
            wf._cached_decision(record, cfg, {}, fields, entities, lambda _sid: "")

        withdrawn = coding.withdraw(
            {**record, "status": "observed", "value": 1}, "The figure was unsupported")
        withdrawn.pop("decision_sha256")
        withdrawn["decision_sha256"] = wf.digest(withdrawn)
        self.assertEqual(withdrawn["status"], "unresolved")
        self.assertIsNone(withdrawn["value"])
        wf._cached_decision(withdrawn, cfg, {}, fields, entities, lambda _sid: "")


class ReconcileTests(unittest.TestCase):
    def old_event(self, url="https://example.test/report"):
        return {"plan_id": "plan-old", "company_id": "acme-1",
                "event_date_hint": "2025-03-01",
                "primary": {"url": url, "title": "Acme cuts 100 jobs"},
                "sources": [{"url": url}]}

    def fresh_plan(self, url="https://example.test/report", day="2025-03-05",
                   title="Acme cuts 100 jobs"):
        return {"plan_id": "plan-acme-1-20250305", "company_id": "acme-1",
                "event_date": day, "primary_url": url, "title": title,
                "sources": [{"source_id": "s1", "url": url}]}

    def test_shared_source_adopts_the_known_id_without_copying_the_old_date(self):
        conflicts = []
        plans, matched, _new, preserved = reconcile_plans.reconcile(
            [self.old_event()], [self.fresh_plan()], conflicts)
        self.assertEqual(matched, 1)
        self.assertEqual(preserved, 0)
        plan = plans[0]
        self.assertEqual(plan["plan_id"], "plan-old")
        self.assertEqual(plan["event_date"], "2025-03-05")
        self.assertEqual(plan["event_date_conflict"], "2025-03-01")
        self.assertEqual(len(conflicts), 1)

    def test_a_date_gap_alone_is_not_a_match(self):
        fresh = self.fresh_plan(url="https://example.test/other", day="2025-03-04",
                                title="Unrelated market commentary")
        plans, matched, new, preserved = reconcile_plans.reconcile(
            [self.old_event()], [fresh])
        self.assertEqual(matched, 0)
        self.assertEqual(new, 1)
        self.assertEqual(preserved, 1)
        self.assertTrue(any(plan.get("preserved") for plan in plans))
        self.assertFalse(any(plan.get("matched_from") == fresh["plan_id"]
                             for plan in plans if not plan.get("preserved")))

    def test_same_date_and_similar_headline_can_match(self):
        fresh = self.fresh_plan(url="https://example.test/second", day="2025-03-01",
                                title="Acme cuts 100 jobs")
        _plans, matched, _new, preserved = reconcile_plans.reconcile(
            [self.old_event()], [fresh])
        self.assertEqual(matched, 1)
        self.assertEqual(preserved, 0)

    def test_plan_needing_review_is_not_confirmed(self):
        fresh = {**self.fresh_plan(), "needs_review": True,
                 "review_reason": "the pages share no identity signal"}
        plans, matched, new, preserved = reconcile_plans.reconcile(
            [self.old_event()], [fresh])
        self.assertEqual(matched, 0)
        self.assertEqual(new, 0)
        self.assertEqual(preserved, 1)
        self.assertEqual(len(plans), 1)


if __name__ == "__main__":
    unittest.main()
