"""Prepare source-based followups for unresolved event measurements.

No benchmark file is read. Tasks are deterministic and share one query per plan.
Run after apply, then resolve tasks using public sources before final delivery.
"""
import argparse
import json
from pathlib import Path
from researchcore.contracts import write_json


def prepare(work):
    work = Path(work)
    cfg = json.loads((work / 'config.json').read_text())
    names = {str(r['company_id']): r.get('company', str(r['company_id'])) for r in cfg['roster']}
    path = work / 'qa/event-plans.json'
    plans = json.loads(path.read_text()).get('plans', []) if path.exists() else []
    path = work / 'decisions.json'
    decisions = json.loads(path.read_text()) if path.exists() else {}
    tasks = []
    for plan in plans:
        fields = []
        for field in ('announcement_date', 'layoff_count', 'layoff_percentage'):
            record = decisions.get(plan['plan_id'] + '|' + field, {})
            if record.get('status') not in {'observed', 'reviewed_absent'}:
                fields.append(field)
        if not fields:
            continue
        name = names.get(str(plan['company_id']), str(plan['company_id']))
        tasks.append({'plan_id': plan['plan_id'], 'company_id': plan['company_id'],
                      'fields': fields, 'query': f'"{name}" layoffs {str(plan.get("event_date", ""))[:7]}',
                      'status': 'pending', 'source_ids': [r.get('source_id') for r in plan.get('sources', [])],
                      'instructions': 'Read cached sources first, then official notices and alternative reports. Preserve approximate counts, local denominators, announcement versus publication dates and plan updates. Submit evidence through apply; never fill from a benchmark.'})
    write_json(work / 'review/measurement-followups.json', {'tasks': tasks, 'complete': not tasks})
    return tasks


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', required=True)
    args = parser.parse_args()
    print(json.dumps({'pending_plans': len(prepare(args.work))}))
