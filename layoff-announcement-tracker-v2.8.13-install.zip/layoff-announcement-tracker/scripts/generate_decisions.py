#!/usr/bin/env python3
"""Generate the source-bound decisions and second reviews for the current run.

`run_collection.py` performs this work as one step of a full round. A run
that already has its plans clustered and its sources bound needs only the
coding step, and this script performs exactly that step and nothing else, so
that the coding can be repeated without repeating the retrieval.

The decisions are built from the sources that are registered and readable.
A field whose evidence is not available stays pending; it is never filled
with a value that no registered page supports.
"""

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
# The skill root is the directory that holds `assets/`, which is one level
# above this script; pointing the lookup at the script's own directory finds
# no schema and silently produces no field topics.
SKILL_ROOT = HERE.parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

import researchcore.coding as coding  # noqa: E402
import researchcore.event_plans as event_plans  # noqa: E402


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return default


def field_topics(skill_root):
    """The topic each field belongs to, read from the event schema.

    The topic decides which extra review checks a field's second review must
    carry, so it is read from the same book the runtime validates against.
    """
    import json as _json
    path = Path(skill_root) / "assets" / "event_schema.json"
    try:
        book = _json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}
    return {f.get("id"): f.get("topic") or "" for f in book.get("fields", [])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--skill", default=str(SKILL_ROOT))
    args = parser.parse_args()

    work = Path(args.work).resolve()
    plans = []
    for name in ("qa/event-plans.json", "qa/event-plans.fresh.json"):
        data = read_json(work / name, None)
        if isinstance(data, dict):
            data = data.get("plans", [])
        if isinstance(data, list) and data:
            plans = data
            break
    registry = read_json(work / "registry/entities.json", {}) or {}
    identities = registry.get("entries", registry)

    sources = {}
    for row in (read_json(work / "sources.json", {}) or {}).get("sources", []):
        sources[row["source_id"]] = {**row, "_work": str(work)}

    print(f"plans: {len(plans)} | sources: {len(sources)}")
    first_round = []
    aliases_by_company = {}
    for plan in plans:
        identity = identities.get(plan.get("company_id"), {})
        aliases = event_plans.company_aliases(identity)
        if not aliases:
            continue
        aliases_by_company[plan.get("company_id")] = list(aliases)
        first_round += coding.build_plan_decisions(
            plan, identity, sources, aliases, str(plan.get("event_date", ""))[:4])
    print(f"first-round decisions: {len(first_round)}")
    coding.write_jsonl(work / "qa/decisions-generated.jsonl", first_round)

    applied = read_json(work / "decisions.json", {}) or {}
    topics = field_topics(args.skill)
    second = coding.build_second_reviews(first_round, sources, applied, topics,
                                         aliases_by_company=aliases_by_company)
    coding.write_jsonl(work / "qa/second-generated.jsonl", second)
    print(f"second reviews: {len(second)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
