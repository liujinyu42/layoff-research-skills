#!/usr/bin/env python3
"""Lock the event-context reading rules.

The context of an event describes the employer as it stood when the
reduction was announced. Three failure modes are checked here, because each
of them produces a number that looks right and states the wrong thing:

* a figure that counts the people the reduction removes, read as the
  workforce;
* a figure that counts one country's staff, or an industry aggregate, read
  as the employer's workforce;
* a context date later than the event, read as the employer's state at the
  event.

Usage:

    python "$S/scripts/test_event_context.py"
"""
from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

spec = importlib.util.spec_from_file_location(
    "resolve_event_context", HERE / "resolve_event_context.py")
rec = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rec)


class EventContextRules(unittest.TestCase):
    def find(self, company, text, event_date="2025-01-01"):
        return rec.find_workforce(text, [rec.normalise(company)], event_date)

    def test_rejects_the_size_of_the_cut(self):
        self.assertIsNone(self.find(
            "Freshworks",
            "Nasdaq-listed SaaS platform Freshworks has announced a workforce "
            "reduction of 13% to streamline its operations, affecting 660 "
            "employees globally."))

    def test_rejects_a_cut_stated_in_the_past(self):
        self.assertIsNone(self.find(
            "Grab",
            "Grab laid off 360 employees in 2020 –- then about five percent of "
            "its full-time workforce -– as the pandemic hit demand."))

    def test_rejects_an_industry_aggregate(self):
        self.assertIsNone(self.find(
            "Google",
            "Google, Meta, Amazon and other tech companies have laid off more "
            "than 104,000 employees in the last year"))

    def test_rejects_a_regional_headcount(self):
        self.assertIsNone(self.find(
            "Oracle",
            "Industry trackers estimate that Oracle employs more than 40,000 "
            "people in India, making it one of the company's largest talent "
            "bases outside the US."))

    def test_rejects_a_workforce_that_only_existed_on_paper(self):
        self.assertIsNone(self.find(
            "Intel",
            "Intel is abandoning plans for a multibillion-dollar mega-fab in "
            "Germany that would have employed 3,000 workers, along with an "
            "assembly plant."))

    def test_accepts_the_employers_own_workforce(self):
        found = self.find(
            "HP",
            "HP has around 50,000 employees worldwide, which means the company "
            "will be letting go up to 12pc of its global workforce.")
        self.assertIsNotNone(found)
        self.assertEqual(found["value"], 50000)

    def test_accepts_a_list_of_countries_as_the_whole_workforce(self):
        found = self.find(
            "Freshworks",
            "Freshworks has more than 5,000 employees across India, Germany, "
            "France, the US, the UK, and the UAE, among others.")
        self.assertIsNotNone(found)
        self.assertEqual(found["value"], 5000)

    def test_reads_the_date_the_figure_refers_to(self):
        found = self.find(
            "Intuit",
            "Intuit had about 18,200 employees in seven countries as of July "
            "31, 2025, according to the company's annual report")
        self.assertIsNotNone(found)
        self.assertEqual(found["value"], 18200)
        self.assertEqual(found["as_of"], "2025-07-31")

    def test_a_figure_from_after_the_event_is_ranked_last(self):
        text = ("Acme employed 900 employees as of December 31, 2025. "
                "Acme employed 1,100 employees as of December 31, 2024.")
        found = self.find("Acme", text, event_date="2025-06-01")
        self.assertIsNotNone(found)
        self.assertEqual(found["as_of"], "2024-12-31")
        self.assertEqual(found["value"], 1100)

    def test_listing_needs_the_employer_in_the_sentence(self):
        text = ("GoDaddy's (NYSE: GDDY) revenue is topping expectations, but "
                "the company is laying off employees and restructuring its "
                "business because Covid-19 is impacting part of its business.")
        found = rec.find_listing(text, [rec.normalise("GoDaddy")])
        self.assertIsNotNone(found)
        self.assertEqual(found["venue"], "NYSE")
        self.assertEqual(found["ticker"], "GDDY")

    def test_business_description_needs_the_employer_in_the_subject(self):
        text = ("Freshworks, a US-based IT company, is laying off 13% of its "
                "workforce, or 660 employees, to streamline operations.")
        found = rec.find_business(text, [rec.normalise("Freshworks")])
        self.assertIsNotNone(found)
        self.assertTrue(found["quote"].startswith("Freshworks,"))

    def test_founding_year_is_read_from_the_report(self):
        text = ("GoDaddy was founded in 1997 and has become the most popular "
                "domain registrar in the world.")
        found = rec.find_founded(text, [rec.normalise("GoDaddy")])
        self.assertIsNotNone(found)
        self.assertEqual(found["year"], 1997)


if __name__ == "__main__":
    unittest.main(verbosity=2)
