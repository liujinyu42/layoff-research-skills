"""Collect one company's raw tracker rows, without following article links.

v2.8.7: backend-API-first pattern with two-tier pacing.
- layoffs.fyi company pages are client-side rendered shells (no table markup
  in the HTML) and tarpit plain HTTP clients under load, so the data-loader's
  backend API (https://layoffs-fyi.onrender.com/api/company/<slug>) is the
  primary channel. HTML parsing and --html are fallbacks.
- Anti-detection: browser-like headers, randomized jittered delays instead of
  fixed intervals (fixed spacing is a bot fingerprint), exponential backoff
  with Retry-After on 429/503/timeout, strict per-host serialisation, and
  receipt caching so re-runs do not re-request (use --refresh to force).
"""
import argparse, hashlib, json, random, re, time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urljoin
from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

VERSION = '2.8.7'
API_URL = 'https://layoffs-fyi.onrender.com/api/company/{slug}'
SITE_URL = 'https://layoffs.fyi/company/{slug}/'
# Two-tier pacing: the JSON API tolerates short gaps; the public HTML site
# stays at the conservative >=12 s policy. Jitter breaks fixed-interval
# fingerprints. Both are gaps BETWEEN requests to the same host.
API_GAP, API_JITTER = 3.0, 2.0        # effective 3-5 s between API calls
HTML_GAP, HTML_JITTER = 12.0, 6.0     # effective 12-18 s between page fetches
BACKOFF_BASE, BACKOFF_MAX = 10.0, 3   # 10 s, 20 s, 40 s (capped retries)
BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
                  'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
}


class Throttle:
    """Per-host serial pacing with jitter. One instance per host per run."""

    def __init__(self, stamp_path, gap, jitter):
        self.stamp = Path(stamp_path)
        self.gap, self.jitter = gap, jitter

    def wait(self):
        if self.stamp.exists():
            elapsed = time.time() - self.stamp.stat().st_mtime
            remaining = max(0.0, self.gap - elapsed)
        else:
            remaining = 0.0
        time.sleep(remaining + random.uniform(0, self.jitter))
        self.stamp.touch()


def backoff_sleep(attempt, headers=None):
    """Exponential backoff with jitter; honors Retry-After when present."""
    ra = None
    if headers is not None:
        try:
            ra = headers.get('Retry-After')
        except Exception:
            ra = None
    if ra:
        try:
            time.sleep(min(float(ra), 120.0) + random.uniform(0, 2))
            return
        except ValueError:
            pass
    time.sleep(min(BACKOFF_BASE * (2 ** attempt), 60.0) + random.uniform(0, 3))


def fetch_api(slug, api_thr):
    """Primary channel: backend JSON events, cached + retried."""
    url = API_URL.format(slug=quote(slug, safe=''))
    err = None
    for attempt in range(BACKOFF_MAX):
        try:
            api_thr.wait()
            with urlopen(Request(url, headers=BROWSER_HEADERS), timeout=30) as r:
                raw = r.read()
            return True, raw, None
        except HTTPError as e:
            err = f'HTTP {e.code}'
            if e.code in (429, 503):          # throttled: back off, maybe Retry-After
                backoff_sleep(attempt, e.headers)
                continue
            break                              # 404 etc.: no point retrying
        except (URLError, TimeoutError, OSError) as e:
            err = str(e)
            backoff_sleep(attempt)             # network hiccup: retry with backoff
    return False, b'', err


def parse_api(raw):
    data = json.loads(raw.decode('utf-8'))
    rows = [{
        'date': e.get('date'),
        'employees': e.get('count'),
        '%': e.get('percent'),
        'industry': e.get('industry'),
        'country': e.get('country'),
        'source': e.get('source'),
        'source_url': e.get('source'),
    } for e in data.get('events', [])]
    return data, rows


def parse(html, url):
    """Fallback channel: HTML table rows (usually empty on layoffs.fyi)."""
    soup = BeautifulSoup(html, 'html.parser')
    rows = []
    found = False
    for table in soup.select('table'):
        idx = None
        for tr in table.select('tr'):
            cells = tr.find_all(['th', 'td'], recursive=False)
            vals = [c.get_text(' ', strip=True) for c in cells]
            keys = [v.lower() for v in vals]
            fields = ['date', 'employees', '%', 'source']
            if all(k in keys for k in fields):
                idx = [keys.index(k) for k in fields]
                found = True
            elif idx and len(cells) > max(idx):
                row = dict(zip(fields, [vals[i] for i in idx]))
                a = cells[idx[-1]].find('a', href=True)
                row['source_url'] = urljoin(url, a['href']) if a else None
                rows.append(row)
    return found, rows


def main():
    p = argparse.ArgumentParser()
    for k in ('company', 'cid', 'work'):
        p.add_argument('--' + k, required=True)
    for k in ('slug', 'html'):
        p.add_argument('--' + k)
    p.add_argument('--start', type=int, default=2019)
    p.add_argument('--end', type=int, default=2026)
    p.add_argument('--refresh', action='store_true',
                   help='ignore cached receipts and re-request')
    a = p.parse_args()
    d = Path(a.work) / 'company-tables'
    d.mkdir(parents=True, exist_ok=True)
    slug = a.slug or re.sub(r'[^\w-]+', '-', a.company.casefold()).strip('-')
    url = SITE_URL.format(slug=quote(slug, safe=''))
    key = hashlib.sha256(url.encode()).hexdigest()[:20]
    api_raw = d / (key + '-api.json')
    raw = d / (key + '.html')
    result = dict(cid=a.cid, company=a.company, slug=slug, url=url,
                  api_url=API_URL.format(slug=slug),
                  query=f'{a.company} layoffs details from {a.start} to {a.end}',
                  rows=[], channel=None, cached=False)

    # 1) primary: backend API (cache first -- a re-run costs zero requests)
    if api_raw.exists() and not a.refresh:
        raw_api = api_raw.read_bytes()
        result['cached'] = True
        ok = True
        err = None
    else:
        api_thr = Throttle(d / 'last-request-api', API_GAP, API_JITTER)
        ok, raw_api, err = fetch_api(slug, api_thr)
        if ok:
            api_raw.write_bytes(raw_api)

    if ok:
        result['channel'] = 'backend_api'
        try:
            data, rows = parse_api(raw_api)
            result['rows'] = rows
            result['api_company_field'] = data.get('company')
        except Exception as e:
            result.update(status='parse_error', error=str(e), channel='backend_api')
            out = d / (key + '-' + quote(a.cid, safe='') + '.json')
            out.write_text(json.dumps(result, ensure_ascii=False, indent=2))
            print(out, result['status'])
            return
        result['status'] = 'rows_collected' if result['rows'] else 'empty_table_review'
    else:
        result['api_error'] = err

    # 2) fallback: HTML page parse (archived page, --html file, or fresh fetch)
    if not result['rows']:
        try:
            if a.html:
                raw.write_bytes(Path(a.html).read_bytes())
            elif not raw.exists():
                html_thr = Throttle(d / 'last-request-html', HTML_GAP, HTML_JITTER)
                html_thr.wait()
                with urlopen(Request(url, headers=BROWSER_HEADERS), timeout=30) as r:
                    data = r.read()
                raw.write_bytes(data)
            found, rows = parse(raw.read_bytes(), url)
            result['rows'] = rows
            result['channel'] = 'html_table'
            result['status'] = 'rows_collected' if rows else ('empty_table_review' if found else 'table_not_found')
        except HTTPError as e:
            result.update(status='blocked_or_failed', error=f'HTTP {e.code}',
                          channel='html_table')
            backoff_sleep(0, e.headers)
            result['retry_after'] = (e.headers or {}).get('Retry-After')
            out = d / (key + '-' + quote(a.cid, safe='') + '.json')
            out.write_text(json.dumps(result, ensure_ascii=False, indent=2))
            print(out, result['status'])
            return
        except Exception as e:
            result.update(status='blocked_or_failed', error=str(e), channel='html_table')
            out = d / (key + '-' + quote(a.cid, safe='') + '.json')
            out.write_text(json.dumps(result, ensure_ascii=False, indent=2))
            print(out, result['status'])
            return

    out = d / (key + '-' + quote(a.cid, safe='') + '.json')
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(out, result['status'], f"cached={result['cached']}")


if __name__ == '__main__':
    main()
