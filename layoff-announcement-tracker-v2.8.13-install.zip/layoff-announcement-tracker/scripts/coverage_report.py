#!/usr/bin/env python3
"""Per company x year conversion report for one workspace.

A row count is not a recall rate. What a delivery can state is how each
company-year moved from a search hit to a confirmed event, and where it did
not:

  search hits -> unique addresses -> readable text -> datable page
              -> bound event page -> plan -> confirmed event

Every dropped candidate is counted with its reason, and every page still
waiting for review is counted separately. A year with no confirmed event but
an unresolved or unreadable candidate is a coverage gap, not an absence.

Usage:
  python3 coverage_report.py --work WORK [--out qa/coverage-by-company-year.csv]
"""
import argparse
import collections
import csv
import io
import json
from pathlib import Path

FIELDS = ['company_id', 'company', 'year', 'search_hits', 'relevant_hits',
          'unique_urls', 'registered_sources', 'readable_sources',
          'dated_pages', 'event_candidate_pages', 'pages_merged', 'plans',
          'confirmed_events', 'excluded_pages', 'needs_review_pages',
          'needs_review_plans', 'date_conflicts', 'gap_reasons']


def load(path, default=None):
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except ValueError:
        return default


def reason_key(text):
    text = str(text or '').strip().lower()
    for prefix in ('the page does not bind', 'the page carries no',
                   'the event falls outside', 'the stated figure',
                   'the pages share no identity', 'the pages state different',
                   'the pages name different', 'one page states a company-wide',
                   'one page describes', 'the pages already carry',
                   'the page states no publication'):
        if text.startswith(prefix):
            return prefix
    return text[:80] or 'unspecified'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--work', required=True)
    parser.add_argument('--out', default='qa/coverage-by-company-year.csv')
    parser.add_argument('--config', default='config.json')
    args = parser.parse_args()

    work = Path(args.work).resolve()
    config = load(work / args.config, {}) or {}
    roster = {row['company_id']: row.get('company', row['company_id'])
              for row in config.get('roster', [])}
    batch = load(work / 'discovery/google-batch.json', []) or []
    sources = (load(work / 'sources.json', {}) or {}).get('sources', [])
    plans_payload = load(work / 'qa/event-plans.json', {}) or {}
    review_payload = load(work / 'qa/plan-review-queue.json', {}) or {}
    events = load(work / 'qa/events.json', []) or []
    gaps = load(work / 'qa/coverage-gaps.json', {}) or {}

    counts = collections.defaultdict(lambda: collections.Counter())
    reasons = collections.defaultdict(collections.Counter)
    seen_urls = collections.defaultdict(set)

    def bucket(company_id, year):
        return counts[(company_id, str(year or 'undated'))]

    for item in batch:
        company_id = item.get('company_id')
        for hit in item.get('hits') or []:
            if hit.get('time_range_reliable') is False:
                # The feed ignored the query year; its results cannot establish
                # coverage of any particular year.
                year = 'undated'
                reasons[(company_id, year)]['time range unreliable'] += 1
            else:
                year = (hit.get('reported_date') or '')[:4] or 'undated'
            row = bucket(company_id, year)
            row['search_hits'] += 1
            url = hit.get('url')
            if url:
                seen_urls[(company_id, year)].add(url)
            if hit.get('relevant'):
                row['relevant_hits'] += 1
            elif hit.get('exclusion_reason'):
                reasons[(company_id, str(year))][reason_key(hit['exclusion_reason'])] += 1
    for (company_id, year), urls in seen_urls.items():
        counts[(company_id, year)]['unique_urls'] += len(urls)

    for source in sources:
        if not source.get('active', True):
            continue
        # A source is counted in the year it was published, not in a separate
        # undated bucket, so the company-year row reconciles with its plans.
        year = ((source.get('publication_date') or source.get('source_date') or '')[:4]
                or 'undated')
        row = bucket(source.get('company_id'), year)
        row['registered_sources'] += 1
        if source.get('status') == 'ready' and int(source.get('n_chars') or 0) > 0:
            row['readable_sources'] += 1

    all_plans = list(plans_payload.get('plans', []))
    for plan in all_plans:
        year = (plan.get('event_date') or '')[:4] or 'undated'
        row = bucket(plan.get('company_id'), year)
        row['plans'] += 1
        row['event_candidate_pages'] += int(plan.get('n_sources') or 0)
        row['dated_pages'] += int(plan.get('n_sources') or 0)
        row['pages_merged'] += max(0, int(plan.get('n_sources') or 0) - 1)
        if plan.get('needs_review'):
            row['needs_review_plans'] += 1
            reasons[(plan.get('company_id'), year)][
                'plan review: ' + reason_key(plan.get('review_reason'))] += 1

    for page in plans_payload.get('rejected', []):
        year = (page.get('date') or page.get('event_date') or '')[:4] or 'undated'
        row = bucket(page.get('company_id'), year)
        row['excluded_pages'] += 1
        reasons[(page.get('company_id'), str(year))][
            'excluded: ' + reason_key(page.get('exclusion_reason'))] += 1

    for page in plans_payload.get('pending_review', []):
        row = bucket(page.get('company_id'), 'undated')
        row['needs_review_pages'] += 1
        reasons[(page.get('company_id'), 'undated')][
            'review: ' + reason_key(page.get('review_reason'))] += 1

    for conflict in review_payload.get('date_conflicts', []):
        year = (conflict.get('fresh_event_date') or '')[:4] or 'undated'
        row = bucket(conflict.get('company_id'), year)
        row['date_conflicts'] += 1
        reasons[(conflict.get('company_id'), year)]['date conflict'] += 1

    for event in events:
        year = (event.get('event_date') or event.get('event_date_hint') or '')[:4] or 'undated'
        bucket(event.get('company_id'), year)['confirmed_events'] += 1

    rows = []
    for (company_id, year), row in sorted(counts.items(), key=lambda item: (item[0][0], item[0][1])):
        values = {field: row.get(field, 0) for field in FIELDS if field not in
                  ('company_id', 'company', 'year', 'gap_reasons')}
        values.update(company_id=company_id, company=roster.get(company_id, company_id),
                      year=year,
                      gap_reasons='; '.join(f'{key} x{count}' for key, count
                                            in sorted(reasons[(company_id, year)].items())))
        rows.append(values)

    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=FIELDS)
    writer.writeheader()
    writer.writerows(rows)
    out_path = work / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(buffer.getvalue(), encoding='utf-8')

    summary = {
        'rows': len(rows),
        'search_hits': sum(row['search_hits'] for row in rows),
        'relevant_hits': sum(row['relevant_hits'] for row in rows),
        'unique_urls': sum(row['unique_urls'] for row in rows),
        'readable_sources': sum(row['readable_sources'] for row in rows),
        'dated_pages': sum(row['dated_pages'] for row in rows),
        'event_candidate_pages': sum(row['event_candidate_pages'] for row in rows),
        'pages_merged': sum(row['pages_merged'] for row in rows),
        'plans': sum(row['plans'] for row in rows),
        'confirmed_events': sum(row['confirmed_events'] for row in rows),
        'excluded_pages': sum(row['excluded_pages'] for row in rows),
        'needs_review_pages': sum(row['needs_review_pages'] for row in rows),
        'needs_review_plans': sum(row['needs_review_plans'] for row in rows),
        'date_conflicts': sum(row['date_conflicts'] for row in rows),
        'coverage_gaps': gaps,
        'boundary': ('Counts describe what was searched, read, dated and bound. '
                     'They are not a recall rate, and an unresolved candidate is '
                     'a gap, never evidence that no layoff was announced.'),
    }
    summary_path = work / 'qa/coverage-summary.json'
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({key: summary[key] for key in
                      ('rows', 'search_hits', 'relevant_hits', 'unique_urls',
                       'readable_sources', 'dated_pages', 'event_candidate_pages',
                       'plans', 'confirmed_events', 'needs_review_pages',
                       'needs_review_plans', 'date_conflicts')}, indent=2))
    print('wrote ' + str(out_path) + ' and ' + str(summary_path))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
