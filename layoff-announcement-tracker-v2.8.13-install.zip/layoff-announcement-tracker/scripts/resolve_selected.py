#!/usr/bin/env python3
"""Resolve the aggregate addresses of a chosen set of hits.

The general resolver walks every aggregate hit in the workspace, which is the
right thing for a full sweep and the wrong thing for a small repair: it
spends its budget on hits nobody is waiting for. This one takes the hits to
resolve as a file, so a repair touches only the hits that block the run.

Usage:

    python "$S/scripts/resolve_selected.py" --work "$W" --hits /tmp/hits.json
"""
from __future__ import annotations

import argparse
import json
import sys
import threading
from pathlib import Path
from urllib.parse import urldefrag

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import resolve_publishers as rp  # noqa: E402
from researchcore.egress import Egress  # noqa: E402


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--hits", required=True,
                        help="JSON file with a list of hit objects")
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--pace", type=float, default=0.5)
    parser.add_argument("--budget", type=float, default=45.0)
    parser.add_argument("--out", required=True)
    args = parser.parse_args(argv)

    work = Path(args.work).resolve()
    hits = json.loads(Path(args.hits).read_text(encoding="utf-8"))
    if isinstance(hits, dict):
        hits = hits.get("hits", [])

    by_domain = {}
    for hit in hits:
        domain = rp.normalise_domain(hit.get("publisher_url", ""))
        if not domain:
            continue
        by_domain.setdefault(domain, []).append(hit)
    print(f"hits: {len(hits)} across {len(by_domain)} publishers", flush=True)

    # The egress object owns the session, the rotation and the refusal
    # handling. A bare session would talk to a refused address forever.
    egress = Egress(floor=args.pace,
                    proxy="socks5h://127.0.0.1:2334")

    resolved, unresolved = [], []
    lock = threading.Lock()
    total = sum(len(group) for group in by_domain.values())
    done = 0

    def work_on(group):
        nonlocal done
        domain, group_hits = group
        # One site survey serves every article of this publisher.
        profile = rp.DomainProfile(egress.session(), domain,
                                   timeout=(4, args.budget),
                                   budget=args.budget * 2)
        for hit in group_hits:
            title = hit.get("title", "")
            try:
                url, strategy = rp.resolve(egress.session(), domain, title,
                                           budget=args.budget,
                                           profile=profile,
                                           reported_date=hit.get(
                                               "reported_date", ""))
            except Exception:  # noqa: BLE001
                url, strategy = None, "error"
            with lock:
                done += 1
                if url and rp.is_article_address(url):
                    resolved.append({"candidate_id": hit.get("candidate_id"),
                                     "resolved_url": url,
                                     "domain": domain,
                                     "strategy": strategy,
                                     "title": title})
                else:
                    unresolved.append({"candidate_id": hit.get("candidate_id"),
                                       "domain": domain,
                                       "strategy": strategy,
                                       "title": title})
                if done % 10 == 0 or done == total:
                    print(f"{done}/{total} | resolved {len(resolved)} | "
                          f"unresolved {len(unresolved)}", flush=True)

    threads = []
    for group in by_domain.items():
        thread = threading.Thread(target=work_on, args=(group,), daemon=True)
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join()

    Path(args.out).write_text(json.dumps(
        {"resolved": resolved, "unresolved": unresolved},
        ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({"resolved": len(resolved),
                      "unresolved": len(unresolved)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
