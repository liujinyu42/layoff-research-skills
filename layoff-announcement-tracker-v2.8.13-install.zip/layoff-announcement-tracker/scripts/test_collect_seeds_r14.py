"""R-14 tests: a guessed-slug 404 is never filed as completed.

All fetches are mocked, sleeps are patched, and workspaces live under tempfile;
nothing is written to the layoff-run output directory. The index fixtures only
mimic the structure of TheLayoff.com's /index/<letter> pages.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import collect_seeds
from researchcore import discovery, seed_sweep
from test_collect_seeds import board_page

NOT_FOUND = "<html><head><title>Page Not Found</title></head><body><h1>404</h1></body></html>"


def index_page(letter, page, total, entries, nxt="auto", mode="link"):
    """Index page fixture. ``total`` only feeds the "page N of M" hint text.

    ``nxt`` is the real next href ("auto" = page+1 while page < total, None = last page).
    ``mode`` is "link" (<link rel=next> in the head, as the site does) or "button"
    (only the visible "Next" pager button).
    """
    if nxt == "auto":
        nxt = f"/index/{letter}/page-{page + 1}" if page < total else None
    head = f'<link rel="next" href="{nxt}">' if nxt and mode == "link" else ""
    button = f'<a class="btn" href="{nxt}">Next&nbsp;&gt;</a>' if nxt and mode == "button" else ""
    links = "".join(f'<a href="/{slug}">{name}</a>' for slug, name in entries)
    pager = "".join(f'<a class="btn" href="/index/{letter}/page-{n}">{n}</a>' for n in range(1, total + 1)) + button
    return (f'<html><head>{head}</head><body><div id="content"><main><div class="header-ix">'
            f'<p>Alphabetical company index for letter/character "{letter.upper()}", '
            f'page {page} of {total}</p><div>{pager}</div></div>'
            f'<ul>{links}</ul></main></div></body></html>')


IBM_BOARD = board_page([("IBM announces layoffs", "2024-05-01", "/t/ibm1")], next_page=None)


class NameTests(unittest.TestCase):
    def test_variants_strip_corporate_suffixes_and_a_leading_the(self):
        self.assertEqual(collect_seeds.name_variants("International Business Machines Corporation"),
                         ["international business machines corporation", "international business machines"])
        self.assertEqual(collect_seeds.name_variants("Seagate Technology Holdings plc"),
                         ["seagate technology holdings plc", "seagate technology holdings",
                          "seagate technology"])
        self.assertIn("home depot", collect_seeds.name_variants("The Home Depot, Inc."))
        self.assertEqual(collect_seeds.name_variants("Inc"), ["inc"])

    def test_alias_slugs_come_from_roster_and_registry_names_and_skip_the_guess(self):
        task = {"company_id": "ibm", "company": "IBM", "aliases": ["IBM"]}
        entries = {"ibm": {"display_name": "IBM", "company_en": "IBM", "names": [
            {"name": "IBM"}, {"name": "International Business Machines Corporation"}]}}
        names = collect_seeds.candidate_names(task, entries)
        self.assertEqual(names, ["IBM", "International Business Machines Corporation"])
        slugs = collect_seeds.alias_slugs(names, exclude={"ibm"})
        self.assertEqual(slugs, ["international-business-machines-corporation",
                                 "international-business-machines"])
        self.assertLessEqual(len(collect_seeds.alias_slugs([f"Name{n} Inc" for n in range(30)])),
                             collect_seeds.MAX_ALIAS_SLUGS)


class IndexTests(unittest.TestCase):
    BASE = "https://www.thelayoff.com/index/"

    def make(self, pages, **kwargs):
        calls = []

        def fetch(url):
            calls.append(url)
            return pages.get(url, (404, NOT_FOUND))

        return collect_seeds.TheLayoffIndex(fetch, base="https://www.thelayoff.com", **kwargs), calls

    def test_parse_page_reads_entries_hint_and_the_real_next_link(self):
        html = index_page("i", 1, 3, [("international-business-machines", "IBM"), ("ibex", "IBEX")])
        entries, hint, nxt = collect_seeds.TheLayoffIndex.parse_page(html)
        self.assertEqual(entries, [("international-business-machines", "IBM"), ("ibex", "IBEX")])
        self.assertEqual(hint, 3)
        self.assertEqual(nxt, "/index/i/page-2")
        _, _, last = collect_seeds.TheLayoffIndex.parse_page(index_page("i", 3, 3, []))
        self.assertEqual(last, "")

    def test_lookup_crawls_every_page_of_the_letter_once(self):
        base = self.BASE + "i"
        index, calls = self.make({
            base: (200, index_page("i", 1, 2, [("ibex", "IBEX")])),
            base + "/page-2": (200, index_page("i", 2, 2, [("international-business-machines", "IBM")])),
        })
        matches, notes = index.lookup(["IBM", "International Business Machines Corporation"])
        self.assertEqual(matches, {"international-business-machines": "IBM"})
        self.assertEqual(calls, [base, base + "/page-2"])
        self.assertIn("2 page(s) read", notes[0])
        index.lookup(["IBM"])
        self.assertEqual(len(calls), 2, "a letter is crawled once and cached")

    def test_rel_next_is_followed_even_when_the_text_says_page_1_of_1(self):
        # Regression: /index/h said "page 1 of 1" but had a rel=next chain of pages.
        base = self.BASE + "h"
        pages = {
            base: (200, index_page("h", 1, 1, [("hp-x", "HPX")], nxt="/index/h/page-2")),
            base + "/page-2": (200, index_page("h", 2, 1, [("hilton", "Hilton")], nxt="/index/h/page-3")),
            base + "/page-3": (200, index_page("h", 3, 1, [("hewlett-packard", "Hewlett-Packard Co.")], nxt=None)),
        }
        index, calls = self.make(pages)
        matches, notes = index.lookup(["Hewlett-Packard Co", "HP Inc."])
        self.assertEqual(matches, {"hewlett-packard": "Hewlett-Packard Co."})
        self.assertEqual(len(calls), 3)
        self.assertNotIn("incomplete", notes[0])
        self.assertIn("3 page(s)", notes[0])

    def test_the_visible_next_button_is_followed_when_there_is_no_link_tag(self):
        base = self.BASE + "l"
        pages = {
            base: (200, index_page("l", 1, 1, [("lyft", "Lyft")], nxt="/index/l/page-2", mode="button")),
            base + "/page-2": (200, index_page("l", 2, 1, [("lending-club", "LendingClub")], nxt=None)),
        }
        index, calls = self.make(pages)
        matches, _ = index.lookup(["LendingClub"])
        self.assertEqual(matches, {"lending-club": "LendingClub"})
        self.assertEqual(len(calls), 2)

    def test_an_unreadable_index_page_is_reported_as_incomplete_with_its_page_number(self):
        base = self.BASE + "i"
        index, _ = self.make({base: (200, index_page("i", 1, 3, [("ibex", "IBEX")])),
                              base + "/page-2": (503, "")})
        matches, notes = index.lookup(["IBM"])
        self.assertEqual(matches, {})
        self.assertIn("index letter I incomplete", notes[0])
        self.assertIn("error at page 2 (HTTP 503)", notes[0])

    def test_page_cap_leaves_the_letter_incomplete_and_names_the_page(self):
        base = self.BASE + "m"
        pages = {base: (200, index_page("m", 1, 9, [("mara", "MARA")]))}
        for n in range(2, 10):
            pages[f"{base}/page-{n}"] = (200, index_page("m", n, 9, []))
        index, calls = self.make(pages, max_pages=3)
        _, notes = index.lookup(["Micron"])
        self.assertIn("index letter M incomplete: cap at page 3", notes[0])
        self.assertEqual(len(calls), 3)

    def test_default_cap_is_at_least_200(self):
        self.assertGreaterEqual(collect_seeds.THELAYOFF_INDEX_PAGES_MAX, 200)
        self.assertEqual(collect_seeds.THELAYOFF_INDEX_PAGES_MAX, 300)

    def test_a_large_letter_is_read_past_the_old_80_page_cap(self):
        base = self.BASE + "s"
        pages = {}
        for n in range(1, 97):
            url = base if n == 1 else f"{base}/page-{n}"
            shown = [("salesforce-com", "Salesforce.com")] if n == 96 else [(f"s{n}", f"S{n} Co")]
            pages[url] = (200, index_page("s", n, 96, shown))
        index, calls = self.make(pages)
        matches, notes = index.lookup(["Salesforce", "Salesforce, Inc."])
        self.assertEqual(len(calls), 96)
        self.assertNotIn("incomplete", notes[0])
        # R-19: "Salesforce.com" normalises to the same key as "Salesforce".
        self.assertEqual(matches, {"salesforce-com": "Salesforce.com"})

    def test_repeated_next_href_is_a_loop_guard_not_an_endless_crawl(self):
        base = self.BASE + "x"
        pages = {
            base: (200, index_page("x", 1, 1, [("xa", "XA")], nxt="/index/x/page-2")),
            base + "/page-2": (200, index_page("x", 2, 1, [("xb", "XB")], nxt="/index/x")),
        }
        index, calls = self.make(pages)
        _, notes = index.lookup(["Xerox"])
        self.assertEqual(len(calls), 2)
        self.assertIn("incomplete", notes[0])
        self.assertIn("repeated next link", notes[0])
        selfloop = {base: (200, index_page("x", 1, 1, [("xa", "XA")], nxt="/index/x"))}
        index, calls = self.make(selfloop)
        _, notes = index.lookup(["Xerox"])
        self.assertEqual(len(calls), 1)
        self.assertIn("repeated next link", notes[0])

    def test_entries_repeated_across_pages_are_deduplicated(self):
        base = self.BASE + "a"
        pages = {
            base: (200, index_page("a", 1, 2, [("acme", "Acme")])),
            base + "/page-2": (200, index_page("a", 2, 2, [("acme", "Acme")])),
        }
        index, _ = self.make(pages)
        self.assertEqual(index.letter("a")["entries"], [("acme", "Acme")])

    def test_initials_candidates_are_listed_but_never_accepted(self):
        base = self.BASE + "h"
        pages = {base: (200, index_page("h", 1, 1, [
            ("hewlett-packard", "Hewlett-Packard Co."), ("hilton", "Hilton")]))}
        index, _ = self.make(pages)
        matches, _ = index.lookup(["HP", "HP Inc."])
        self.assertEqual(matches, {})
        self.assertEqual(index.initials_candidates(["HP", "HP Inc."]),
                         {"hewlett-packard": "Hewlett-Packard Co."})


class ResolveBoardTests(unittest.TestCase):
    task = {"company_id": "ibm", "company": "IBM", "aliases": ["IBM"]}
    entries = {"ibm": {"names": [{"name": "International Business Machines Corporation"}]}}
    build = staticmethod(lambda value: "https://www.thelayoff.com/" + collect_seeds.slug(value))

    def test_registry_legal_name_resolves_without_the_index(self):
        seen = []

        def fetch(url):
            seen.append(url)
            if url.endswith("/international-business-machines"):
                return IBM_BOARD, 200
            return NOT_FOUND, 404
        result = collect_seeds.resolve_board("TheLayoff.com", self.build, self.task, self.entries,
                                             "https://www.thelayoff.com/ibm", fetch, index=None)
        self.assertTrue(result["found"])
        self.assertEqual(result["via"], "alias_slug")
        self.assertEqual(result["url"], "https://www.thelayoff.com/international-business-machines")
        self.assertEqual(seen[0], "https://www.thelayoff.com/international-business-machines-corporation")

    def test_a_non_404_alias_answer_stops_the_search_and_is_reported(self):
        def fetch(url):
            return "", 503
        result = collect_seeds.resolve_board("TheLayoff.com", self.build, self.task, self.entries,
                                             "https://www.thelayoff.com/ibm", fetch, index=None)
        self.assertFalse(result["found"])
        self.assertEqual(result["tried"][-1][1], 503)

    def test_ambiguous_index_matches_are_not_guessed(self):
        index = mock.Mock()
        index.lookup.return_value = ({"mara-inc": "MARA", "mara": "Mara"}, ["index letter M: 4 page(s) read"])
        index.initials_candidates.return_value = {}
        index.near_candidates.return_value = []
        result = collect_seeds.resolve_board(
            "TheLayoff.com", self.build, {"company_id": "mara", "company": "Mara", "aliases": []}, {},
            "https://www.thelayoff.com/mara", lambda url: (NOT_FOUND, 404), index=index)
        self.assertFalse(result["found"])
        text = collect_seeds.unresolved_board_basis("TheLayoff.com", result)
        self.assertIn("several boards", text)
        self.assertIn("mara-inc", text)


class ExecuteR14Tests(unittest.TestCase):
    ROSTER = (("ibm", "IBM"),)

    def run_collect(self, urls, roster=ROSTER, channel="thelayoff", extra=(), registry=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        work = Path(tmp.name)
        cfg = {"event_start": "2019-01-01", "event_end": "2026-11-13",
               "roster": [{"company_id": cid, "company": name} for cid, name in roster]}
        seed_sweep.plan(work, cfg)
        if registry:
            (work / "registry").mkdir()
            (work / "registry/entities.json").write_text(json.dumps({"entries": registry}), encoding="utf-8")
        out = work / "batch.json"
        argv = ["collect_seeds.py", "--work", str(work), "--out", str(out), "--only-channel", channel,
                "--workers", "1", "--pace", "0", "--host-confirm-interval", "0", *extra]
        requested = []

        def fake(url):
            requested.append(url)
            status, body = urls.get(url, (404, NOT_FOUND))
            return status, body

        with mock.patch.object(collect_seeds, "_plain_get", side_effect=fake), \
                mock.patch.object(collect_seeds.render_table, "render", return_value=None), \
                mock.patch.object(collect_seeds.time, "sleep"), \
                mock.patch.object(sys, "argv", argv):
            collect_seeds.main()
        return work, cfg, json.loads(out.read_text(encoding="utf-8")), requested

    def test_guessed_slug_404_with_no_board_found_is_not_completed(self):
        work, cfg, batch, requested = self.run_collect({}, extra=["--no-thelayoff-index"])
        receipt = batch[0]
        self.assertEqual(receipt["outcome"], "blocked")
        self.assertNotEqual(receipt["outcome"], "completed")
        self.assertEqual(receipt["reason"], "board_unresolved")
        self.assertEqual(receipt["hits"], [])
        self.assertIn("https://www.thelayoff.com/ibm -> HTTP 404", receipt["stop_basis"])
        self.assertIn("board_unresolved", receipt["stop_basis"])
        self.assertNotIn("holds no board", receipt["stop_basis"])
        self.assertEqual(requested, ["https://www.thelayoff.com/ibm"])

    def test_registry_alias_slug_finds_the_board_and_the_receipt_says_how(self):
        registry = {"ibm": {"display_name": "IBM", "names": [
            {"name": "IBM"}, {"name": "International Business Machines Corporation"}]}}
        urls = {"https://www.thelayoff.com/international-business-machines": (200, IBM_BOARD)}
        work, cfg, batch, requested = self.run_collect(urls, registry=registry)
        receipt = batch[0]
        self.assertEqual(receipt["outcome"], "completed")
        self.assertNotIn("reason", receipt)
        self.assertEqual(len(receipt["hits"]), 1)
        self.assertTrue(receipt["hits"][0]["relevant"])
        self.assertIn("https://www.thelayoff.com/international-business-machines", receipt["stop_basis"])
        self.assertIn("guessed address returned 404", receipt["stop_basis"])
        self.assertIn("alias_slug", receipt["stop_basis"])
        self.assertFalse(any("/index/" in url for url in requested))

    def test_site_index_finds_a_board_no_alias_guess_could(self):
        urls = {
            "https://www.thelayoff.com/index/i": (200, index_page("i", 1, 1, [
                ("international-business-machines", "IBM")])),
            "https://www.thelayoff.com/international-business-machines": (200, IBM_BOARD),
        }
        work, cfg, batch, requested = self.run_collect(urls)
        receipt = batch[0]
        self.assertEqual(receipt["outcome"], "completed")
        self.assertIn("site_index", receipt["stop_basis"])
        self.assertEqual(receipt["pages_reviewed"], 1)
        self.assertIn("/international-business-machines", receipt["stop_basis"])

    def test_index_without_a_match_is_blocked_and_names_what_was_read(self):
        urls = {"https://www.thelayoff.com/index/i": (200, index_page("i", 1, 1, [("ibex", "IBEX")]))}
        work, cfg, batch, requested = self.run_collect(urls)
        receipt = batch[0]
        self.assertEqual(receipt["outcome"], "blocked")
        self.assertEqual(receipt["reason"], "board_unresolved")
        self.assertIn("index letter I: 1 page(s) read", receipt["stop_basis"])
        self.assertIn("No index entry matched", receipt["stop_basis"])
        self.assertNotIn("INCOMPLETE", receipt["stop_basis"])

    def test_unresolved_after_an_incomplete_index_says_so_and_is_still_blocked(self):
        urls = {
            "https://www.thelayoff.com/index/i": (200, index_page("i", 1, 1, [("ibex", "IBEX")],
                                                                    nxt="/index/i/page-2")),
            "https://www.thelayoff.com/index/i/page-2": (200, index_page("i", 2, 1, [("ibi", "IBI")],
                                                                         nxt="/index/i/page-3")),
            "https://www.thelayoff.com/index/i/page-3": (503, ""),
        }
        work, cfg, batch, requested = self.run_collect(urls)
        receipt = batch[0]
        self.assertEqual(receipt["outcome"], "blocked")
        self.assertEqual(receipt["reason"], "board_unresolved")
        basis = receipt["stop_basis"]
        self.assertIn("index letter I incomplete: error at page 3 (HTTP 503)", basis)
        self.assertIn("INCOMPLETE", basis)
        self.assertIn("not a full index miss", basis)
        self.assertNotIn("No index entry matched", basis)

    def test_cap_reached_is_a_page_cap_stop_in_the_receipt(self):
        urls = {"https://www.thelayoff.com/index/i": (200, index_page("i", 1, 1, [("ibex", "IBEX")],
                                                                    nxt="/index/i/page-2")),
                "https://www.thelayoff.com/index/i/page-2": (200, index_page("i", 2, 1, [("ibi", "IBI")],
                                                                             nxt="/index/i/page-3"))}
        work, cfg, batch, requested = self.run_collect(urls, extra=["--thelayoff-index-max-pages", "2"])
        basis = batch[0]["stop_basis"]
        self.assertEqual(batch[0]["outcome"], "blocked")
        self.assertIn("index letter I incomplete: cap at page 2 (2-page cap; a next link remains)", basis)
        self.assertIn("INCOMPLETE", basis)
        self.assertNotIn("page-3", " ".join(requested))

    def test_board_beyond_the_old_cap_is_found_by_following_next(self):
        urls = {}
        for n in range(1, 91):
            url = "https://www.thelayoff.com/index/s" + ("" if n == 1 else f"/page-{n}")
            shown = [("salesforce-com", "Salesforce")] if n == 90 else [(f"s{n}", f"S{n} Co")]
            urls[url] = (200, index_page("s", n, 1, shown, nxt=(None if n == 90 else f"/index/s/page-{n + 1}")))
        urls["https://www.thelayoff.com/salesforce-com"] = (200, IBM_BOARD)
        work, cfg, batch, requested = self.run_collect(urls, roster=(("sf", "Salesforce"),))
        self.assertEqual(batch[0]["outcome"], "completed")
        self.assertIn("site_index", batch[0]["stop_basis"])
        self.assertIn("/salesforce-com", batch[0]["stop_basis"])

    def test_trueup_404_is_also_not_completed_and_has_no_index(self):
        work, cfg, batch, requested = self.run_collect({}, channel="trueup")
        self.assertEqual(batch[0]["outcome"], "blocked")
        self.assertEqual(batch[0]["reason"], "board_unresolved")
        self.assertIn("no index to search", batch[0]["stop_basis"])

    def full_batch(self, work, cfg, thelayoff_receipts, outcome_override=None):
        tasks = json.loads((work / "discovery/seed-plan.json").read_text())["tasks"]
        by_task = {r["task_id"]: r for r in thelayoff_receipts}
        rows = []
        for task in tasks:
            if task["task_id"] in by_task:
                row = dict(by_task[task["task_id"]])
                if outcome_override:
                    row["outcome"] = outcome_override
                rows.append(row)
                continue
            base = {"task_id": task["task_id"], "executed_at": "2026-11-13",
                    "result_path": thelayoff_receipts[0]["result_path"], "hits": []}
            if task["channel"] == "issuer_report":
                basis = "No issuer registration is registered, so the filing channel does not apply."
                rows.append({**base, "outcome": "not_applicable", "stop_basis": basis,
                             "applicability_basis": basis})
            else:
                rows.append({**base, "outcome": "completed",
                             "stop_basis": "The tracker was inspected and nothing more was needed."})
        path = work / "full.json"
        path.write_text(json.dumps(rows), encoding="utf-8")
        return path

    def test_real_seed_import_and_status_name_the_gap_and_discovery_can_proceed(self):
        work, cfg, batch, _ = self.run_collect({}, extra=["--no-thelayoff-index"])
        status = seed_sweep.import_receipts(work, cfg, self.full_batch(work, cfg, batch))
        gaps = [g for g in status["gaps"] if g["channel"] == "thelayoff"]
        self.assertEqual([g["reason"] for g in gaps], ["seed_blocked"])
        self.assertEqual(gaps[0]["receipt_reason"], "board_unresolved")
        self.assertNotIn("seed_blocked", discovery._SEED_BLOCKING)
        self.assertFalse(status["pass"])
        # seed_blocked is a contract gap: discovery-plan is allowed to run.
        plan = discovery.plan(work, cfg)
        self.assertIn("thelayoff", json.loads((work / "discovery/plan.json").read_text())["blocked_channels"])
        self.assertIsNotNone(plan)

    def test_the_same_receipt_filed_as_partial_would_stop_discovery_plan(self):
        work, cfg, batch, _ = self.run_collect({}, extra=["--no-thelayoff-index"])
        row = dict(batch[0], outcome="partial")
        row.pop("reason", None)
        path = self.full_batch(work, cfg, [row])
        status = seed_sweep.import_receipts(work, cfg, path)
        self.assertEqual([g["reason"] for g in status["gaps"] if g["channel"] == "thelayoff"],
                         ["seed_partial"])
        self.assertIn("seed_partial", discovery._SEED_BLOCKING)
        with self.assertRaises(ValueError):
            discovery.plan(work, cfg)


if __name__ == "__main__":
    unittest.main()
