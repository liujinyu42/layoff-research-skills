#!/usr/bin/env python3
"""Tests for the three registry builders.

Each of them turns something the workspace already holds into a submission
the runtime accepts. The failure modes they exist to prevent are the ones
that produce a registry that looks complete and says nothing:

* a hit counted as an event, which overstates coverage;
* an index query counted as a direct issuer or regulator search;
* a context value copied from a record without a quotation, which asserts
  a fact no source was asked about.
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import build_reason_codes as brc  # noqa: E402
import build_search_log as bsl  # noqa: E402
import fill_profile_fields as fpf  # noqa: E402


class ChannelTests(unittest.TestCase):
    def test_a_statutory_notice_query_on_the_news_index_stays_news_index(self):
        self.assertEqual(bsl.CHANNEL_OF_FAMILY["unit_notice"], "news_index")

    def test_an_issuer_notice_query_on_the_news_index_stays_news_index(self):
        self.assertEqual(bsl.CHANNEL_OF_FAMILY["official_notice"],
                         "news_index")

    def test_a_news_query_is_the_news_index(self):
        self.assertEqual(bsl.CHANNEL_OF_FAMILY["broad_news"], "news_index")
        self.assertEqual(bsl.CHANNEL_OF_FAMILY["alternative_news"], "news_index")


class ExchangeNameTests(unittest.TestCase):
    def test_the_filing_form_of_an_exchange_is_found(self):
        text = ("Name of each exchange on which registered Common stock, par "
                "value $0.01 per share HPQ New York Stock Exchange")
        span = fpf.find_span(text, "NYSE")
        self.assertIsNotNone(span)
        self.assertIn("New York Stock Exchange", span["quote"])

    def test_a_cik_is_found_without_its_leading_zeros(self):
        text = "Fiverr International Ltd. - 1762301 - 2026 "
        span = fpf.find_span(text, "0001762301")
        self.assertIsNotNone(span)
        self.assertIn("1762301", span["quote"])

    def test_a_value_that_is_not_in_the_text_is_not_located(self):
        self.assertIsNone(fpf.find_span("nothing here", "NASDAQ"))


class CueTests(unittest.TestCase):
    def test_a_cue_matches_at_a_word_start(self):
        self.assertTrue(brc.cue_hit("cost cutting in the unit", "cost"))
        self.assertFalse(brc.cue_hit("accosted the unit", "cost"))

    def test_a_cue_matches_case_insensitively(self):
        self.assertTrue(brc.cue_hit("Restructuring the team", "restructur"))


class AttributionTests(unittest.TestCase):
    def test_a_reporter_reading_is_not_a_company_statement(self):
        self.assertNotEqual(brc.LEVEL_OF_ATTRIBUTION.get(
            "news_reporter_attribution"), "company_direct")

    def test_a_company_statement_is(self):
        self.assertEqual(brc.LEVEL_OF_ATTRIBUTION.get("company_direct"),
                         "company_direct")


class FiscalDateTests(unittest.TestCase):
    def test_the_period_the_filing_covers_is_read(self):
        text = "FORM 20-F For the fiscal year ended December 31 , 2025 "
        self.assertEqual(fpf.fiscal_date(text), "2025-12-31")

    def test_the_start_of_the_period_is_read(self):
        text = "FORM 20-F For the fiscal year ended December 31 , 2025 "
        self.assertEqual(fpf.period_start(text), "2024-12-31")

    def test_a_text_without_a_period_yields_nothing(self):
        self.assertEqual(fpf.fiscal_date("no period here"), "")


class FoundingTests(unittest.TestCase):
    def test_a_founding_statement_is_found_with_its_year(self):
        text = ("We were incorporated in Israel under the Companies Law in "
                "April 2010, and our principal executive office is located at "
                "8 Eliezer Kaplan St., Tel Aviv 6473409, Israel.")
        span = fpf.founding_statement(text)
        self.assertIsNotNone(span)
        self.assertEqual(span["year"], 2010)

    def test_a_text_without_a_founding_statement_yields_nothing(self):
        self.assertIsNone(fpf.founding_statement("a short notice"))


class ProductsTests(unittest.TestCase):
    def test_a_products_statement_is_found(self):
        text = ("We provide a digital freelance marketplace that connects "
                "businesses with independent professionals around the world.")
        span = fpf.products_statement(text)
        self.assertIsNotNone(span)
        self.assertIn("marketplace", span["quote"])


if __name__ == "__main__":
    unittest.main()
