#!/usr/bin/env python3
"""Register discovered candidate pages as sources so they can become events.

A search hit is a pointer, not evidence. The runtime only accepts a decision
whose evidence span is bound to a registered source with a matching
`row_sha256` and `text_sha256`, so a page that was found but never registered
cannot support any claim — and its candidate can never leave the ledger. That
is the gap this script closes: it turns readable candidates into first-class
sources through the same `ingest` path the rest of the pipeline uses.

Two kinds of hit are distinguished, because they need different honesty:

* **Direct page** — a publisher article or an issuer filing. These are fetched
  and registered. A filing is the strongest possible source: it is the employer
  itself stating the action.
* **Aggregator redirect** — a news aggregator's opaque article id (for example
  `news.google.com/rss/articles/CBMi...`). Fetching it returns a JavaScript
  shell and the publisher URL is not recoverable from the response, so the page
  is recorded as *unreadable* rather than registered with the wrong content.

Usage:

    python "$S/scripts/register_candidates.py" --work "$W"
    python "$S/scripts/register_candidates.py" --work "$W" --limit 20
"""
from __future__ import annotations

import argparse
import csv
import io
import hashlib
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urldefrag, urlparse

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore import candidate_review, sources as source_module  # noqa: E402
from researchcore.discovery import _atomic  # noqa: E402
from researchcore.egress import Egress  # noqa: E402

MANIFEST_COLUMNS = ["source_id", "company_id", "source_type", "source_url", "local_path",
                    "document_role", "fy", "plan_id", "publication_date", "source_date",
                    "exchange", "form", "source_language"]

# A hit that points at an aggregator cannot be resolved to the publisher page
# from the response body; recording it as readable content would attribute the
# aggregator shell's text to the employer.
AGGREGATOR_HOSTS = ("news.google.com",)


def _iso(timestamp):
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat().replace("+00:00", "Z")


def read_csv(path):
    path = Path(path)
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_json(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        return default


def resolved_publishers(work):
    """The publisher addresses recovered for aggregator hits, by aggregator URL.

    A hit that points at an aggregator cannot be fetched, but the publisher's
    own address can be recovered from the publisher's domain and the article's
    title. When that recovery succeeded, the hit is registered against the
    publisher's page, because that page is the article itself.
    """
    payload = read_json(Path(work) / "qa/publisher-resolution.json", {}) or {}
    out = {}
    for record in payload.get("resolved", []):
        key = (record.get("aggregator_url") or "").split("?")[0]
        if key and record.get("resolved_url"):
            out[key] = record
    return out


def relevant_hits(work):
    """Every relevant lead, including optional user-supplied URLs."""
    return candidate_review.relevant_hits(work, read_json(Path(work) / "config.json", {}) or {})


def unregistered_hits(work, retry_failed=False):
    """Return open candidates without an active usable source."""
    ledger = {row["candidate_id"]: row for row in read_csv(Path(work) / "event_candidate_review.csv")}
    stored = {(s["company_id"], urldefrag(s.get("source_url") or "")[0]): s
              for s in source_module.read_sources(work).values() if s.get("active", True)}
    recovered = resolved_publishers(work)
    hits = []
    by_id = relevant_hits(work)
    cfg = read_json(Path(work) / "config.json", {}) or {}
    companies = {item["company"]: item["company_id"] for item in cfg.get("roster", [])}
    for cid, row in ledger.items():
        company_id = companies.get(row["company"])
        if cid not in by_id and company_id and row["source_url"]:
            by_id[cid] = {**row, "company_id": company_id, "title": row["affected_scope"],
                          "reported_date": ""}
    for cid, hit in by_id.items():
        row = ledger.get(cid, {})
        candidate_review.reopen_rule_exclusion(row)
        if row and row.get("disposition") != "unresolved":
            continue
        url = urldefrag(hit["source_url"])[0]
        evidence = urldefrag(row.get("evidence_url") or "")[0]
        reported_date = hit.get("reported_date") or ""
        if evidence and not is_aggregator(evidence):
            if evidence != url and not is_aggregator(url):
                reported_date = ""
            url = evidence
        elif is_aggregator(url):
            url = recovered.get(url.split("?")[0], {}).get("resolved_url") or url
        source = stored.get((hit["company_id"], url), {})
        if source.get("status") in {"ready", "requires_visual_review"}:
            continue
        if source.get("status") == "failed" and not retry_failed:
            continue
        hits.append({**hit, "source_url": url, "reported_date": reported_date})
    return hits


def is_aggregator(url):
    host = (urlparse(url).hostname or "").lower()
    return any(host == item or host.endswith("." + item) for item in AGGREGATOR_HOSTS)


def source_id_for(url, company_id):
    """Stable id: the page's own address plus the company it belongs to."""
    digest = hashlib.sha256(url.encode("utf-8")).hexdigest()[:16]
    suffix = str(company_id or "").rsplit("-", 1)[-1] or "unknown"
    return f"news-{digest}-{suffix}"


def document_role_for(url):
    """(source_type, document_role, form) for a page, from its publisher."""
    host = (urlparse(url).hostname or "").lower()
    if host == "sec.gov" or host.endswith(".sec.gov"):
        # A filing is the registrant speaking, not a reporter describing it, so
        # it is the strongest evidence tier available for a count.
        return "sec_filing", "event_filing", ""
    trackers = ("thelayoff.com", "layoffs.fyi", "trueup.io")
    if any(host == domain or host.endswith("." + domain) for domain in trackers):
        return "news", "tracker_record", ""
    return "news", "news_report", ""


def build_manifest(work, candidates):
    """Existing manifest plus one row per readable candidate page."""
    existing = [row for row in read_csv(Path(work) / "qa/full_manifest.csv")
                if (row.get("active") or "").lower() != "false"]
    current = source_module.read_sources(work)
    for row in existing:
        source = current.get(row["source_id"], {})
        if source.get("active", True) and source.get("plan_id") and not row.get("plan_id"):
            row["plan_id"] = source["plan_id"]
    existing_ids = {row["source_id"] for row in existing}
    existing.extend(row for row in current.values()
                    if row.get("active", True) and row["source_id"] not in existing_ids)
    rows = {row["source_id"]: row for row in existing}
    addresses = {(row["company_id"], urldefrag(row.get("source_url") or "")[0]) for row in rows.values()}
    recovered = resolved_publishers(work)
    added, skipped = [], []
    for candidate in candidates:
        url = urldefrag(candidate.get("source_url") or "")[0]
        if not url.startswith("http"):
            skipped.append({"candidate_id": candidate["candidate_id"], "reason": "not an absolute HTTP address"})
            continue
        publisher = None
        if is_aggregator(url):
            # The aggregator's own address cannot be fetched, but the
            # publisher's page can. When the publisher's address was
            # recovered, the candidate is registered against it, because that
            # page is the article; otherwise the candidate stays unreadable.
            record = recovered.get(url.split("?")[0])
            if not record:
                skipped.append({"candidate_id": candidate["candidate_id"],
                                "reason": "the hit points at an aggregator redirect, not the publisher page"})
                continue
            publisher = record
            url = urldefrag(record.get("resolved_url") or "")[0]
            if not url.startswith("http"):
                skipped.append({"candidate_id": candidate["candidate_id"],
                                "reason": "the publisher address was recovered but is not an absolute HTTP address"})
                continue
        source_id = source_id_for(url, candidate.get("company_id"))
        address_key = (candidate["company_id"], url)
        if address_key in addresses:
            continue
        if source_id in rows:
            source_id = f"{source_id}-{candidate['company_id']}"
        source_type, role, form = document_role_for(url)
        date = (candidate.get("reported_date") or "")[:10]
        row = {column: "" for column in MANIFEST_COLUMNS}
        row.update({"source_id": source_id, "company_id": candidate.get("company_id"),
                    "source_type": source_type, "source_url": url, "document_role": role,
                    "publication_date": date, "source_date": date, "form": form,
                    "source_language": "en"})
        rows[source_id] = row
        addresses.add(address_key)
        added.append(row)
    return list(rows.values()), added, skipped


AGGREGATE_JOURNAL = "qa/aggregate-resolution.jsonl"
PERMANENT_RESOLUTION_ERRORS = {"paywall", "no_search", "not_found"}


def _resolution_failure_class(exc, strategy=""):
    """Sort a resolution failure so the next attempt is scheduled, not repeated."""
    text = (str(exc) + " " + str(strategy or "")).lower()
    if "paywall" in text or "subscri" in text or "metered" in text:
        return "paywall"
    if "captcha" in text or "blocked" in text or "403" in text or "forbidden" in text:
        return "blocked"
    if "timed out" in text or "timeout" in text or "deadline" in text:
        return "timeout"
    if "no search" in text or "search endpoint" in text or "no endpoint" in text:
        return "no_search"
    if "no candidate" in text or "not found" in text or "404" in text:
        return "not_found"
    return "error"


def _aggregate_journal_path(work):
    return Path(work) / AGGREGATE_JOURNAL


def replay_aggregate_journal(work):
    """The latest resolution record per candidate, including failures.

    Each link is committed on its own, so an interrupted resolution round
    keeps every address it already found and every failure it already
    classified instead of starting over.
    """
    path = _aggregate_journal_path(work)
    records = {}
    if not path.is_file():
        return records
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if isinstance(record, dict) and record.get("candidate_id"):
            records[record["candidate_id"]] = record
    return records


def _append_aggregate_journal(work, record):
    path = _aggregate_journal_path(work)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _next_attempt(error_class, attempt):
    if error_class in PERMANENT_RESOLUTION_ERRORS:
        return None
    seconds = min(3600 * (2 ** max(0, attempt - 1)), 7 * 86400)
    return _iso(time.time() + seconds)


def resolve_aggregates(work, candidates, limit=0, pace=0.5, budget=20.0,
                       max_workers=4, retry_after=None):
    """Turn an aggregator address into the publisher's own address.

    A search feed points at the publisher's article through the aggregator's
    own redirect, and that redirect cannot be read as an article: the
    address is an encoded pointer that no client resolves. The publisher's
    own domain is recorded alongside it, and the publisher's own site is
    asked for the article by its title. A candidate that resolves becomes a
    registrable source; one that does not stays a candidate, with its failure
    class and next attempt recorded.

    Progress is committed per link, so an interrupted round resumes where it
    stopped instead of re-asking every publisher. Paid walls and publishers
    with no search endpoint are terminal for this route: they are not retried
    on a timer, because repeating them cannot succeed. Their candidates remain
    coverage gaps until an official notice, a WARN filing or another report of
    the same event is found.
    """
    import resolve_publishers as rp
    from researchcore.egress import Egress

    journal = replay_aggregate_journal(work)
    resolved = {}
    grouped = {}
    now = time.time()
    deferred = 0
    for candidate in candidates:
        url = urldefrag(candidate.get("source_url") or "")[0]
        if not is_aggregator(url):
            continue
        domain = rp.normalise_domain(candidate.get("publisher_url", "")
                                      or candidate.get("publisher_domain", ""))
        if not domain:
            continue
        previous = journal.get(candidate["candidate_id"]) or {}
        if previous.get("status") == "resolved" and previous.get("resolved_url"):
            resolved[candidate["candidate_id"]] = {
                "url": previous["resolved_url"], "strategy": previous.get("strategy", "")}
            continue
        due = str(previous.get("next_attempt") or "")
        if due and due > (retry_after or _iso(now)):
            deferred += 1
            continue
        grouped.setdefault(domain, []).append(candidate)

    if deferred:
        print(f"  deferred by backoff: {deferred} candidate(s)", flush=True)
    if not grouped:
        return resolved
    total = sum(len(group) for group in grouped.values())
    done = [0]
    lock = threading.Lock()

    def work_domain(item):
        domain, group = item
        egress = Egress(floor=pace)
        session = egress.session()
        profile = rp.DomainProfile(session, domain, budget=budget * 2)
        for candidate in group:
            previous = journal.get(candidate["candidate_id"]) or {}
            attempt = int(previous.get("attempt") or 0) + 1
            record = {"candidate_id": candidate["candidate_id"],
                      "aggregator_url": candidate.get("source_url", ""),
                      "domain": domain, "attempt": attempt,
                      "attempted_at": _iso(time.time())}
            try:
                address, strategy = rp.resolve(
                    session, domain, candidate.get("title", ""),
                    budget=budget, profile=profile,
                    reported_date=candidate.get("reported_date", ""))
            except Exception as exc:  # noqa: BLE001 - a failure is a journal record
                error_class = _resolution_failure_class(exc)
                record.update(status="failed", error_class=error_class,
                              error=str(exc)[:400],
                              next_attempt=_next_attempt(error_class, attempt))
            else:
                if address:
                    record.update(status="resolved", resolved_url=address,
                                  strategy=strategy, error_class=None)
                else:
                    error_class = _resolution_failure_class("", strategy)
                    record.update(status="unresolved", error_class=error_class,
                                  strategy=strategy,
                                  next_attempt=_next_attempt(error_class, attempt))
            _append_aggregate_journal(work, record)
            with lock:
                journal[candidate["candidate_id"]] = record
                done[0] += 1
                if record["status"] == "resolved":
                    resolved[candidate["candidate_id"]] = {
                        "url": record["resolved_url"],
                        "strategy": record.get("strategy", "")}
                if done[0] % 50 == 0:
                    print(f"  resolved {done[0]}/{total}; "
                          f"{len(resolved)} address(es) found", flush=True)
            if limit and done[0] >= limit:
                return

    workers = max(1, min(int(max_workers), len(grouped)))
    if workers == 1:
        for item in grouped.items():
            work_domain(item)
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            list(pool.map(work_domain, list(grouped.items())))
    return resolved


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--pace", type=float, default=0.05)
    parser.add_argument("--resolve", action="store_true",
                        help="resolve aggregator addresses to the publisher's own page")
    parser.add_argument("--resolve-budget", type=float, default=20.0)
    parser.add_argument("--resolve-workers", type=int, default=4,
                        help="bounded concurrency across publisher domains")
    parser.add_argument("--retry-aggregates", action="store_true",
                        help="ignore the recorded next-attempt time and retry now")
    parser.add_argument("--retry-failed", action="store_true",
                        help="retry failed publisher fetches in the selected batch")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    candidates = unregistered_hits(work, retry_failed=args.retry_failed)
    if args.resolve:
        candidates.sort(key=lambda hit: not is_aggregator(hit["source_url"]))
    else:
        candidates.sort(key=lambda hit: is_aggregator(hit["source_url"]))
    if args.limit:
        candidates = candidates[:args.limit]
    print(f"unregistered relevant candidate(s): {len(candidates)}", flush=True)

    if args.resolve:
        resolved = resolve_aggregates(
            work, candidates, budget=args.resolve_budget,
            max_workers=args.resolve_workers,
            retry_after="9999" if args.retry_aggregates else None)
        print(f"aggregator address(es) resolved: {len(resolved)}", flush=True)
        path = work / "qa/publisher-resolution.json"
        report = read_json(path, {}) or {}
        addresses = resolved_publishers(work)
        for candidate in candidates:
            found = resolved.get(candidate["candidate_id"])
            if found:
                original = candidate["source_url"]
                addresses[original.split("?")[0]] = {
                    "candidate_id": candidate["candidate_id"], "aggregator_url": original,
                    "resolved_url": found["url"], "strategy": found["strategy"],
                }
                candidate["source_url"] = found["url"]
        report["resolved"] = list(addresses.values())
        _atomic(path, json.dumps(report, ensure_ascii=False, indent=1))

    rows, added, skipped = build_manifest(work, candidates)
    print(f"readable pages to register: {len(added)}; "
          f"left as unreadable candidates: {len(skipped)}", flush=True)

    manifest = work / "qa/candidate_manifest.csv"
    fields = list(dict.fromkeys([*MANIFEST_COLUMNS, *source_module.OPTIONAL_FIELDS]))
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    _atomic(manifest, output.getvalue())
    print(f"manifest written: {manifest} ({len(rows)} row(s))", flush=True)

    stored = source_module.read_sources(work)
    if candidates and (added or args.retry_failed or any(s["source_id"] not in stored for s in rows)):
        started = time.time()
        selected = {(c["company_id"], urldefrag(c["source_url"])[0]) for c in candidates}
        retry_ids = {s["source_id"] for s in rows
                     if (s["company_id"], urldefrag(s.get("source_url") or "")[0]) in selected}
        recorded = source_module.ingest(work, manifest, new_only=True,
                                        retry_source_ids=retry_ids if args.retry_failed else ())
        counts = {}
        for record in recorded:
            counts[record.get("status")] = counts.get(record.get("status"), 0) + 1
        print(f"ingest finished in {time.time() - started:.0f}s; statuses: {counts}", flush=True)

    skipped_path = work / "qa/candidate-unreadable.json"
    skipped_path.write_text(json.dumps(skipped, ensure_ascii=False, indent=1), encoding="utf-8")
    _atomic(work / "qa/full_manifest.csv", output.getvalue())
    print(f"unreadable candidates recorded: {skipped_path}", flush=True)

    # A candidate that could not be read is a coverage gap, not evidence that
    # the employer did not announce a reduction. It stays counted here until a
    # readable official notice, WARN filing or other report of the same event
    # is registered.
    journal = replay_aggregate_journal(work)
    by_class = {}
    unresolved_aggregates = 0
    for candidate in candidates:
        if not is_aggregator(candidate.get("source_url") or ""):
            continue
        record = journal.get(candidate["candidate_id"]) or {}
        if record.get("status") != "resolved":
            unresolved_aggregates += 1
            error_class = record.get("error_class") or "not_attempted"
            by_class[error_class] = by_class.get(error_class, 0) + 1
    _atomic(work / "qa/coverage-gaps.json", json.dumps({
        "unregistered_candidates": len(candidates),
        "registered_this_round": len(added),
        "unreadable_candidates": len(skipped),
        "unresolved_aggregates": unresolved_aggregates,
        "unresolved_by_class": by_class,
        "note": ("Unresolved and unreadable candidates are coverage gaps. They "
                 "never support a conclusion that no layoff was announced."),
    }, ensure_ascii=False, indent=1))
    print(f"coverage gaps: {len(skipped)} unreadable, "
          f"{unresolved_aggregates} unresolved aggregate(s) {by_class}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
