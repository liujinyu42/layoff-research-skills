"""Produce a compact lead index and evidence excerpts with character offsets."""
import argparse
import json
import re
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

def canonical(url):
    parts = urlsplit(url)
    query = '&'.join(x for x in parts.query.split('&') if not x.lower().startswith(('utm_', 'fbclid=', 'gclid=')))
    return urlunsplit((parts.scheme.lower(), parts.netloc, parts.path, query, ''))

def packet(receipt):
    groups = {}
    for i, row in enumerate(receipt['rows']):
        url = row.get('source_url') or row.get('source') or ''
        link = canonical(url) if isinstance(url,str) and url.startswith(('http://','https://')) else ''
        fields = [row.get('date'), row.get('employees'), row.get('%'), row.get('country'), link]
        # Unlinked leads cannot be safely grouped. Retain rows that differ in any metadata.
        identity = dict(row)
        if link:
            for key in ('source_url','source'):
                if identity.get(key)==url:
                    identity[key]=link
        key = json.dumps(identity,sort_keys=True) if link else str(i)
        groups.setdefault(key,[[],*fields])[0].append(i)
    return {'columns':['raw_indices','date','employees','percent_raw','country','url'],'leads':list(groups.values())}

def excerpts(text, terms):
    pattern = r'layoffs?|laid off|redundan\w*|restructur\w*|job cuts?|workforce|terminat\w*|severance|positions? eliminated'
    if terms:
        pattern += '|'+'|'.join(map(re.escape,terms))
    intervals = []
    for match in re.finditer(pattern,text,re.I):
        a,b=max(0,match.start()-220),min(len(text),match.end()+280)
        if intervals and a <= intervals[-1][1]:
            intervals[-1][1]=b
        else:
            intervals.append([a,b])
    return intervals

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('text',type=Path)
    p.add_argument('--term',action='append',default=[])
    p.add_argument('--offset',type=int,default=0)
    a=p.parse_args()
    body=a.text.read_text()
    hits=excerpts(body,a.term)
    chunks=[(start,min(start+750,end)) for begin,end in hits for start in range(begin,end,750)]
    selected=chunks[a.offset:a.offset+5]
    print(json.dumps(dict(total=len(chunks),next_offset=a.offset+5 if a.offset+5<len(chunks) else None,
        excerpts=[[s,e,body[s:e]] for s,e in selected]),ensure_ascii=False))
