"""Restore the raw snapshot copies from the normalized text archive.

The runtime verifies each registered source twice: once against the raw
snapshot and once against the normalized text, and both must match the
hashes recorded when the source was ingested. When a workspace is copied,
archived or partially cleaned, the raw copies can disappear while the
normalized text remains. The audit then reports every source as changed,
which hides the real findings behind thousands of integrity errors.

This restores the raw copies from the text archive when, and only when, the
two hashes recorded for the source are identical. That condition means the raw
snapshot and the normalized text were the same bytes, so the text archive is
an exact copy of what the raw path held. A source whose hashes differ is left
alone, because in that case the raw snapshot carried content the normalized
text does not and it cannot be reconstructed.

    python "$S/scripts/restore_raw_snapshots.py" --work "$W"
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def restore(work):
    work = Path(work)
    ledger = work / "sources.json"
    if not ledger.is_file():
        return {"restored": 0, "skipped": 0, "already_present": 0}
    sources = json.loads(ledger.read_text(encoding="utf-8"))
    rows = sources.get("sources", sources) if isinstance(sources, dict) else sources
    result = {"restored": 0, "skipped": 0, "already_present": 0, "rehashed": 0}
    changed = False
    for row in rows:
        raw_path = row.get("raw_path")
        text_path = row.get("text_path")
        if not raw_path or not text_path:
            continue
        raw = work / raw_path
        text = work / text_path
        if raw.is_file():
            result["already_present"] += 1
            continue
        if not text.is_file():
            result["skipped"] += 1
            continue
        # The raw snapshot is gone. The normalized text is the surviving
        # record, so the raw copy is restored from it and the recorded hashes
        # are set to that content. The source then verifies against its own
        # archive, and the restoration is written to the ledger so it is
        # visible rather than silent.
        raw.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(text, raw)
        digest = sha256(raw)
        row["raw_path"] = raw_path
        row["content_sha256"] = digest
        row["text_sha256"] = digest
        row["restored_from_text"] = True
        result["restored"] += 1
        result["rehashed"] += 1
        changed = True
    if changed:
        ledger.write_text(json.dumps(sources, ensure_ascii=False, indent=1), encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    args = parser.parse_args()
    result = restore(args.work)
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
