"""Read a client-rendered tracker table through a real browser.

Several trackers publish their data only through a JavaScript data grid or an
embedded view (Layoffs.fyi is an Airtable embed). An unauthenticated HTTP fetch
receives the page shell and no rows, so the honest choice is either to record
the channel as unreadable or to render it the way a reader would.

This module takes the second option with headless Chrome over the DevTools
protocol. It records the row count the page itself reports, so a partial read
is visible rather than silently truncated.

Usage:

    python "$S/scripts/render_table.py" --preset layoffs_fyi --out /tmp/table.json
    python "$S/scripts/render_table.py" --url "<embed-url>" --out /tmp/table.json
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import shutil
import socket
import struct
import subprocess
import sys
import time
import urllib.request

CHROME_CANDIDATES = (
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
)
LINUX_CHROME_NAMES = (
    "google-chrome",
    "google-chrome-stable",
    "chromium",
    "chromium-browser",
)

PRESETS = {
    # The Layoffs.fyi Airtable view is the canonical table the site renders.
    "layoffs_fyi": ("https://airtable.com/embed/app1PaujS9zxVGUZ4/shroKsHx3SdYYOzeh"
                    "?backgroundColor=green&viewControls=on"),
}


def chrome_path():
    """Locate a Chrome/Chromium binary on Linux or macOS.

    CHROME_PATH wins when it points at an existing file. Otherwise the
    well-known Linux executable names are resolved on PATH, then the
    historical macOS application paths are tried.
    """
    override = os.environ.get("CHROME_PATH") or ""
    if override and os.path.exists(override):
        return override
    for name in LINUX_CHROME_NAMES:
        found = shutil.which(name)
        if found:
            return found
    for candidate in CHROME_CANDIDATES:
        if os.path.exists(candidate):
            return candidate
    return None


class WS:
    def __init__(self, url):
        # ws://127.0.0.1:PORT/devtools/page/XXXX
        rest = url.split("://", 1)[1]
        hostport, path = rest.split("/", 1)
        host, port = hostport.split(":")
        self.s = socket.create_connection((host, int(port)), timeout=60)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (f"GET /{path} HTTP/1.1\r\nHost: {hostport}\r\nUpgrade: websocket\r\n"
               f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\n"
               f"Sec-WebSocket-Version: 13\r\n\r\n")
        self.s.sendall(req.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            buf += self.s.recv(4096)
        if b"101" not in buf.split(b"\r\n")[0]:
            raise RuntimeError("handshake failed: " + buf[:200].decode("latin1"))
        self.buf = buf.split(b"\r\n\r\n", 1)[1]
        self.mid = 0

    def _recv(self, n):
        while len(self.buf) < n:
            chunk = self.s.recv(65536)
            if not chunk:
                raise RuntimeError("socket closed")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def send(self, obj):
        payload = json.dumps(obj).encode()
        header = bytearray([0x81])
        n = len(payload)
        if n < 126:
            header.append(0x80 | n)
        elif n < 65536:
            header.append(0x80 | 126); header += struct.pack(">H", n)
        else:
            header.append(0x80 | 127); header += struct.pack(">Q", n)
        mask = os.urandom(4)
        header += mask
        self.s.sendall(bytes(header) + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))

    def recv(self):
        parts = []
        while True:
            b1, b2 = self._recv(2)
            fin, opcode = b1 & 0x80, b1 & 0x0F
            ln = b2 & 0x7F
            if ln == 126:
                ln = struct.unpack(">H", self._recv(2))[0]
            elif ln == 127:
                ln = struct.unpack(">Q", self._recv(8))[0]
            data = self._recv(ln) if ln else b""
            if opcode == 0x9:  # ping
                continue
            parts.append(data)
            if fin:
                return json.loads(b"".join(parts).decode())

    def call(self, method, **params):
        self.mid += 1
        mid = self.mid
        self.send({"id": mid, "method": method, "params": params})
        while True:
            msg = self.recv()
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError(f"{method}: {msg['error']}")
                return msg.get("result", {})


JS_COLLECT = r"""
(() => {
  const map = {};
  document.querySelectorAll('[data-columnindex]').forEach(c => {
    const rowEl = c.closest('[data-rowid]');
    if (!rowEl) return;
    const rec = rowEl.getAttribute('data-rowid');
    const i = c.getAttribute('data-columnindex');
    const a = c.querySelector('a[href]');
    const t = (c.innerText || '').replace(/\s+/g, ' ').trim();
    if (!map[rec]) map[rec] = { rec: rec, cells: {} };
    const prior = map[rec].cells[i];
    if (!prior || (!prior.t && t)) {
      map[rec].cells[i] = { t: t, h: a ? a.getAttribute('href') : null };
    }
  });
  const rows = Object.values(map);
  const heads = [];
  document.querySelectorAll('[data-columnid]').forEach(h => {
    if (h.closest('[data-rowid]')) return;
    const t = (h.innerText || '').replace(/\s+/g, ' ').trim();
    if (t) heads.push(h.getAttribute('data-columnindex') + ':' + t);
  });
  let info = '';
  const m = document.body.innerText.match(/[\d,]+\s*[-–]\s*[\d,]+\s*of\s*[\d,]+|[\d,]+\s+records?/i);
  if (m) info = m[0];
  return JSON.stringify({ rows: rows, heads: heads, info: info });
})()
"""

JS_SCROLL = r"""
(() => {
  let el = window.__sc;
  if (!el || !el.isConnected) {
    const cands = [...document.querySelectorAll('div')]
      .filter(e => e.scrollHeight - e.clientHeight > 300 && e.clientHeight > 200);
    el = cands.sort((a, b) => b.scrollHeight - a.scrollHeight)[0];
    window.__sc = el;
  }
  if (!el) return JSON.stringify({ err: 'noscroller' });
  el.scrollTop = el.scrollTop + el.clientHeight * 0.85;
  return JSON.stringify({ top: el.scrollTop, sh: el.scrollHeight, ch: el.clientHeight });
})()
"""




def render(url, port=9333, profile="/tmp/chrome-table-profile", max_steps=400):
    """Render `url`, scroll its grid to the end, and return every row seen."""
    binary = chrome_path()
    if not binary:
        raise RuntimeError("No Chrome/Chromium/Edge binary found; cannot render the table")
    subprocess.run(["rm", "-rf", profile], check=False)
    process = subprocess.Popen(
        [binary, "--headless=new", "--no-sandbox", "--disable-dev-shm-usage",
         "--disable-gpu", "--window-size=1700,2400",
         f"--remote-debugging-port={port}", f"--user-data-dir={profile}",
         "--no-first-run", "--disable-extensions",
         "--disable-background-timer-throttling", "about:blank"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        target = None
        for _ in range(60):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=2) as reply:
                    pages = [t for t in json.load(reply) if t.get("type") == "page"]
                if pages:
                    target = pages[0]["webSocketDebuggerUrl"]
                    break
            except Exception:  # noqa: BLE001
                time.sleep(0.5)
        if not target:
            raise RuntimeError("no debuggable page")
        sock = WS(target)
        sock.call("Page.enable")
        sock.call("Runtime.enable")
        sock.call("Page.navigate", url=url)
        time.sleep(6)
        data = {}
        for _ in range(20):
            time.sleep(1)
            reply = sock.call("Runtime.evaluate", expression=JS_COLLECT,
                              returnByValue=True, awaitPromise=True)
            data = json.loads(reply["result"]["value"])
            if len({row["rec"] for row in data["rows"]}) > 20:
                break
        heads = data.get("heads", [])
        info = data.get("info", "")
        seen = {row["rec"]: row for row in data.get("rows", [])}
        stagnant = 0
        for _step in range(max_steps):
            reply = sock.call("Runtime.evaluate", expression=JS_SCROLL,
                              returnByValue=True, awaitPromise=True)
            state = json.loads(reply["result"]["value"])
            if state.get("err"):
                break
            # The grid renders after the scroll settles; collecting
            # immediately counts not-yet-rendered rows as a stagnant step and
            # stops the sweep early with a partial table.
            time.sleep(0.28)
            reply = sock.call("Runtime.evaluate", expression=JS_COLLECT,
                              returnByValue=True, awaitPromise=True)
            refreshed = json.loads(reply["result"]["value"])
            before = len(seen)
            for row in refreshed.get("rows", []):
                seen[row["rec"]] = row
            if refreshed.get("info"):
                info = refreshed["info"]
            if len(seen) == before:
                stagnant += 1
            else:
                stagnant = 0
            if stagnant >= 14:
                break
            if state["top"] + state["ch"] >= state["sh"] - 5:
                break
        return {"captured_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "url": url,
                "row_count_label": info, "headers": heads,
                "rows": list(seen.values())}
    finally:
        process.terminate()
        try:
            process.wait(timeout=10)
        except Exception:  # noqa: BLE001
            process.kill()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="")
    parser.add_argument("--preset", default="", choices=sorted(PRESETS))
    parser.add_argument("--out", required=True)
    parser.add_argument("--port", type=int, default=9333)
    args = parser.parse_args()
    url = args.url or PRESETS.get(args.preset)
    if not url:
        raise SystemExit("Provide --url or --preset")
    result = render(url, args.port)
    with open(args.out, "w", encoding="utf-8") as handle:
        json.dump(result, handle, ensure_ascii=False)
    print(f"rendered {len(result['rows'])} row(s); page reports "
          f"{result['row_count_label'] or 'an unknown count'}")


if __name__ == "__main__":
    raise SystemExit(main())
