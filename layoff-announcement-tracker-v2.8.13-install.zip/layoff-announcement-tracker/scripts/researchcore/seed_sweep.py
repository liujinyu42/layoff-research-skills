"""Stage 1: source-first layoff seed collection before Google verification.

Trackers and filings produce candidates, not accepted events. Every roster company
must have a receipt for every planned channel before stage-2 discovery is planned.
"""
from __future__ import annotations

import csv
import datetime as dt
import io
import re
from pathlib import Path
from urllib.parse import urldefrag, urlsplit

from . import discovery


CHANNELS = {
    'layoffs_fyi': {
        'label': 'Layoffs.fyi',
        'url': 'https://layoffs.fyi/',
        'instruction': 'Inspect the accessible table/export or public company records for the full requested window.'
    },
    'trueup': {
        'label': 'TrueUp Tech Layoffs Tracker',
        'url': 'https://www.trueup.io/job-trend/tech-layoffs',
        'instruction': 'Inspect the current tracker and available historical records for the full requested window.'
    },
    'thelayoff': {
        'label': 'TheLayoff.com',
        'url': 'https://www.thelayoff.com/',
        'instruction': 'Inspect the company board and relevant dated posts; treat anonymous claims as unverified leads.'
    },
    'issuer_report': {
        'label': '10-K/20-F/annual or interim report',
        'url': None,
        'instruction': 'For an applicable issuer, inspect reports covering the requested window for announced or implemented reductions; otherwise record a specific not_applicable basis.'
    },
}


def _aliases(company):
    return discovery._aliases(company)


def _tasks(cfg):
    start = dt.date.fromisoformat(cfg['event_start'])
    end = dt.date.fromisoformat(cfg['event_end'])
    if start > end:
        raise ValueError('event_start must precede event_end')
    tasks = []
    for company in cfg['roster']:
        aliases = _aliases(company)
        for channel, metadata in CHANNELS.items():
            scope = {'stage': 'initial_seed', 'company_id': company['company_id'],
                     'company': company['company'], 'aliases': aliases,
                     'window_start': start.isoformat(), 'window_end': end.isoformat(),
                     'channel': channel}
            tasks.append({**scope, 'task_id': 'seed-' + discovery._digest(scope)[:20],
                          'source_label': metadata['label'], 'source_index_url': metadata['url'],
                          'instruction': metadata['instruction'], 'scope_sha256': discovery._digest(scope)})
    return tasks


def plan(work, cfg):
    work = Path(work)
    payload = {'version': 2, 'stage': 'initial_seed', 'tasks': _tasks(cfg),
               'next': 'Execute every company x channel seed task, preserve captures, then seed-import. Do not plan Google verification until this stage passes.',
               'boundary': 'Tracker hits and report mentions are candidates; none is accepted without source and semantic verification.'}
    discovery._save(work / 'discovery/seed-plan.json', payload)
    return status(work, cfg)


def _normalize_hit(task, hit):
    url = str(hit.get('url') or '').strip()
    parsed = urlsplit(url)
    if parsed.scheme not in {'http', 'https'} or not parsed.netloc:
        raise ValueError('Seed hits require absolute HTTP URLs')
    if not str(hit.get('title') or '').strip() or type(hit.get('relevant')) is not bool:
        raise ValueError('Each seed hit needs title and a boolean relevant flag')
    if not hit['relevant'] and not str(hit.get('exclusion_reason') or '').strip():
        raise ValueError('Irrelevant seed hits require an exclusion reason')
    reported = str(hit.get('reported_date') or '').strip()
    if reported:
        dt.date.fromisoformat(reported)
    return {'url': url, 'title': str(hit['title']).strip(), 'relevant': hit['relevant'],
            'exclusion_reason': str(hit.get('exclusion_reason') or ''),
            'reported_date': reported or None,
            'candidate_id': discovery.candidate_id(task['company_id'], url)}


def import_receipts(work, cfg, path):
    """Validate and atomically archive stage-1 receipts before updating current state."""
    work = Path(work)
    tasks = {item['task_id']: item for item in _tasks(cfg)}
    batch = discovery._read(Path(path), None)
    if not isinstance(batch, list):
        raise ValueError('Seed import must be a JSON array')
    receipts, seen = [], set()
    for item in batch:
        task_id = item.get('task_id')
        if task_id not in tasks or task_id in seen:
            raise ValueError('Unknown or duplicate seed task_id: ' + str(task_id))
        seen.add(task_id)
        task = tasks[task_id]
        dt.date.fromisoformat(item['executed_at'])
        outcome = item.get('outcome')
        if outcome not in {'completed', 'blocked', 'partial', 'not_applicable'}:
            raise ValueError('Invalid seed outcome')
        if outcome == 'not_applicable' and task['channel'] != 'issuer_report':
            raise ValueError('not_applicable is only available for issuer_report; tracker/channel failure remains blocked or partial')
        if len(str(item.get('stop_basis') or '').strip()) < 15:
            raise ValueError('Seed collection requires a specific stopping, blocking or applicability basis')
        if outcome == 'not_applicable' and len(str(item.get('applicability_basis') or '').strip()) < 15:
            raise ValueError('not_applicable issuer_report requires a specific applicability_basis')
        relative_path, capture_hash = discovery._capture(work, item['result_path'])
        hits = item.get('hits')
        if not isinstance(hits, list):
            raise ValueError('hits must contain every returned seed inspected for relevance')
        if outcome == 'not_applicable' and hits:
            raise ValueError('not_applicable tasks cannot contain seed hits')
        normalized = [_normalize_hit(task, hit) for hit in hits]
        receipt = {**task, 'executed_at': item['executed_at'], 'outcome': outcome,
                   'stop_basis': item['stop_basis'],
                   'applicability_basis': item.get('applicability_basis'),
                   'result_path': relative_path, 'result_sha256': capture_hash, 'hits': normalized}
        # Optional window_sweep coverage fields from the collector. When
        # present they must use the contract names pages_reviewed (a
        # non-negative integer) and stop_condition (a specific basis).
        window_sweep = item.get('window_sweep')
        if window_sweep is not None and not isinstance(window_sweep, dict):
            raise ValueError('window_sweep must be an object')
        pages = item.get('pages_reviewed')
        stop_condition = item.get('stop_condition')
        search_scope = item.get('search_scope')
        if isinstance(window_sweep, dict):
            if window_sweep.get('pages_reviewed') is not None:
                pages = window_sweep.get('pages_reviewed')
            if not str(stop_condition or '').strip() and window_sweep.get('stop_condition'):
                stop_condition = window_sweep.get('stop_condition')
        if (pages is not None or search_scope == 'window_sweep'
                or isinstance(window_sweep, dict)):
            try:
                if isinstance(pages, bool) or pages in (None, ''):
                    raise ValueError
                pages = int(pages)
                if pages < 0:
                    raise ValueError
            except (TypeError, ValueError) as exc:
                raise ValueError('window_sweep requires pages_reviewed as a non-negative integer') from exc
            if len(str(stop_condition or '').strip()) < 15:
                raise ValueError('window_sweep requires a coverage stopping basis')
            stop_condition = str(stop_condition).strip()
            oldest_reached = item.get('oldest_post_date_reached')
            if isinstance(window_sweep, dict) and 'oldest_post_date_reached' in window_sweep:
                oldest_reached = window_sweep.get('oldest_post_date_reached')
            if 'oldest_post_date_reached' in item:
                oldest_reached = item.get('oldest_post_date_reached')
            if oldest_reached not in (None, ''):
                try:
                    dt.date.fromisoformat(str(oldest_reached))
                except ValueError as exc:
                    raise ValueError('oldest_post_date_reached must be an ISO date') from exc
                oldest_reached = str(oldest_reached)
            else:
                oldest_reached = None
            receipt['pages_reviewed'] = pages
            receipt['stop_condition'] = stop_condition
            receipt['search_scope'] = search_scope or 'window_sweep'
            receipt['oldest_post_date_reached'] = oldest_reached
            retries = item.get('later_page_retries')
            if isinstance(window_sweep, dict) and 'later_page_retries' in window_sweep:
                retries = window_sweep.get('later_page_retries')
            if 'later_page_retries' in item:
                retries = item.get('later_page_retries')
            if retries in (None, ''):
                retries = 0
            else:
                try:
                    if isinstance(retries, bool):
                        raise ValueError
                    retries = int(retries)
                    if retries < 0:
                        raise ValueError
                except (TypeError, ValueError) as exc:
                    raise ValueError('later_page_retries must be a non-negative integer') from exc
            receipt['later_page_retries'] = retries
            receipt['window_sweep'] = {
                'pages_reviewed': pages,
                'stop_condition': stop_condition,
                'oldest_post_date_reached': oldest_reached,
                'later_page_retries': retries,
            }
        # Optional machine-readable reason for a blocked/partial receipt (for
        # example cloudflare_403_persistent or http_403_persistent). It must be
        # a short snake_case token so it cannot carry free text into the ledger.
        reason = item.get('reason')
        if reason not in (None, ''):
            if not isinstance(reason, str) or not re.fullmatch(r'[a-z][a-z0-9_]{2,63}', reason):
                raise ValueError('receipt reason must be a short snake_case token')
            if outcome == 'completed' or outcome == 'not_applicable':
                raise ValueError('receipt reason is only valid on blocked or partial receipts')
            receipt['reason'] = reason
        receipt['receipt_sha256'] = discovery._digest(receipt)
        receipts.append(receipt)
    with discovery._import_lock(work):
        current = discovery._read(work / 'discovery/seed-receipts.json', {})
        for receipt in receipts:
            discovery._save(work / 'discovery/seed-history' / (receipt['receipt_sha256'] + '.json'), receipt)
            current[receipt['task_id']] = receipt
        discovery._save(work / 'discovery/seed-receipts.json', current)
    return status(work, cfg)


def relevant_hits(work):
    """Current deduplicated relevant seeds used to build stage-2 verification tasks."""
    work = Path(work)
    path = work / 'discovery/seed-inbox.csv'
    if not path.is_file():
        return []
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return [row for row in csv.DictReader(handle) if row.get('relevant') == 'true']


CLOSURE_STATES = ('confirmed', 'linked', 'source_supported_exclusion', 'named_unresolved')


def seed_closure(work):
    """An auditable terminal state for every relevant seed.

    A relevant seed that reaches no event is the leak the delivery audit
    measured: the seed was found and marked relevant, but nothing records what
    became of it, so the year gap it should have closed silently stayed open.
    Every relevant seed ends in exactly one state:

    * ``confirmed`` — its candidate is bound to a confirmed event plan;
    * ``linked`` — its candidate is bound to a plan that still needs review,
      or was merged into another plan;
    * ``source_supported_exclusion`` — its candidate was excluded on a recorded
      exclusion basis;
    * ``named_unresolved`` — no terminal disposition exists yet; the row keeps
      the open reason so the gap stays visible.

    The result is written to ``discovery/seed-closure.csv`` and returned as a
    summary. Nothing here promotes a seed to an event: only an existing
    candidate disposition can do that.
    """
    work = Path(work)
    ledger_path = work / 'event_candidate_review.csv'
    ledger = {}
    if ledger_path.is_file():
        with ledger_path.open(encoding='utf-8-sig', newline='') as handle:
            for row in csv.DictReader(handle):
                if row.get('candidate_id'):
                    ledger[row['candidate_id']] = row
    plans = {plan.get('plan_id'): plan
             for plan in (discovery._read(work / 'qa/event-plans.json', {}) or {}).get('plans', [])}
    rows = []
    for hit in relevant_hits(work):
        candidate_id = hit.get('candidate_id') or ''
        entry = ledger.get(candidate_id)
        disposition = (entry or {}).get('disposition') or ''
        plan_id = (entry or {}).get('plan_id') or ''
        reason = (entry or {}).get('reason') or (hit.get('exclusion_reason') or '')
        plan = plans.get(plan_id)
        if disposition in {'included', 'merged'} and plan_id:
            if disposition == 'merged' or (plan and plan.get('needs_review')):
                state = 'linked'
                detail = 'candidate bound to plan ' + plan_id + ' (merged or under review)'
            else:
                state = 'confirmed'
                detail = 'candidate bound to confirmed plan ' + plan_id
        elif disposition == 'excluded':
            state = 'source_supported_exclusion'
            detail = reason or 'excluded on a recorded exclusion basis'
        elif disposition in {'included', 'merged'}:
            state = 'named_unresolved'
            detail = 'disposition ' + disposition + ' without a plan binding'
        else:
            state = 'named_unresolved'
            detail = reason or 'no terminal disposition recorded for this relevant seed'
        rows.append({'candidate_id': candidate_id, 'company_id': hit.get('company_id') or '',
                     'company': hit.get('company') or '', 'source_url': hit.get('source_url') or '',
                     'title': hit.get('title') or '', 'reported_date': hit.get('reported_date') or '',
                     'closure_state': state, 'plan_id': plan_id, 'detail': detail})
    fields = ['candidate_id', 'company_id', 'company', 'source_url', 'title',
              'reported_date', 'closure_state', 'plan_id', 'detail']
    buffer = io.StringIO(newline='')
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    for row in sorted(rows, key=lambda item: (item['closure_state'], item['candidate_id'])):
        writer.writerow(row)
    discovery._atomic(work / 'discovery/seed-closure.csv', buffer.getvalue())
    summary = {state: sum(1 for row in rows if row['closure_state'] == state)
               for state in CLOSURE_STATES}
    summary['relevant_seeds'] = len(rows)
    summary['pass'] = summary['named_unresolved'] == 0
    discovery._save(work / 'review/seed-closure.json',
                    {'summary': {k: v for k, v in summary.items() if k != 'pass'},
                     'pass': summary['pass'],
                     'boundary': 'A closure state is bookkeeping, not event truth; '
                                 'named_unresolved rows name the open gap.'})
    return summary


def status(work, cfg):
    work = Path(work)
    tasks = _tasks(cfg)
    receipts = discovery._read(work / 'discovery/seed-receipts.json', {})
    pending, gaps, inbox = [], [], {}
    relevant_ids = set()
    for task in tasks:
        receipt = receipts.get(task['task_id'])
        reason = None
        if receipt is None:
            reason = 'seed_not_executed'
        else:
            unsigned = {key: value for key, value in receipt.items() if key != 'receipt_sha256'}
            if (receipt.get('scope_sha256') != task['scope_sha256']
                    or receipt.get('receipt_sha256') != discovery._digest(unsigned)):
                reason = 'seed_receipt_changed'
            else:
                try:
                    _, actual_hash = discovery._capture(work, receipt['result_path'])
                    if actual_hash != receipt.get('result_sha256'):
                        reason = 'seed_capture_changed'
                except (OSError, ValueError, KeyError):
                    reason = 'seed_capture_unavailable'
            acceptable = receipt.get('outcome') == 'completed' or (
                receipt.get('outcome') == 'not_applicable' and task['channel'] == 'issuer_report')
            if reason is None and not acceptable:
                reason = 'seed_' + str(receipt.get('outcome'))
            for hit in receipt.get('hits', []):
                cid = hit['candidate_id']
                row = inbox.setdefault(cid, {'candidate_id': cid, 'company_id': task['company_id'],
                                             'company': task['company'], 'source_url': hit['url'],
                                             'title': hit['title'], 'reported_date': hit.get('reported_date'),
                                             'channels': set(), 'task_ids': set(), 'relevant': False})
                row['channels'].add(task['channel'])
                row['task_ids'].add(task['task_id'])
                row['relevant'] = row['relevant'] or hit['relevant']
                if hit['relevant']:
                    relevant_ids.add(cid)
        if reason:
            gap = {'contract': 'initial_seed', 'reason': reason, 'task_id': task['task_id'],
                   'company_id': task['company_id'], 'channel': task['channel']}
            if receipt is not None and receipt.get('reason'):
                gap['receipt_reason'] = receipt['reason']
            gaps.append(gap)
            pending.append({**task, 'reason': reason})
    fields = ['candidate_id', 'company_id', 'company', 'source_url', 'title', 'reported_date',
              'channels', 'task_ids', 'relevant']
    buffer = io.StringIO(newline='')
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    for row in sorted(inbox.values(), key=lambda item: item['candidate_id']):
        writer.writerow({**row, 'channels': ';'.join(sorted(row['channels'])),
                         'task_ids': ';'.join(sorted(row['task_ids'])),
                         'relevant': str(row['relevant']).lower()})
    discovery._atomic(work / 'discovery/seed-inbox.csv', buffer.getvalue())
    result = {'pass': not gaps, 'stage': 'initial_seed', 'tasks': len(tasks),
              'pending_tasks': len(pending), 'unique_relevant_seeds': len(relevant_ids), 'gaps': gaps,
              'next': 'seed-import outstanding captures' if gaps else 'Run discovery-plan for Google seed verification and company/year gap searches.',
              'boundary': 'A completed seed sweep documents inspected channels, not event truth or exhaustive coverage.'}
    discovery._save(work / 'review/seed-next.json', {'pending': pending, 'gaps': gaps,
                                                     'inbox': 'discovery/seed-inbox.csv'})
    return result
