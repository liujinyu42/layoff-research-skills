"""Local discovery planning and receipt checks for the host's search tools."""
from __future__ import annotations

import csv
from contextlib import contextmanager
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
from urllib.parse import urldefrag, urlsplit


# Receipt states that mean the step did not happen or its evidence was altered.
# `seed_blocked` is deliberately absent: the receipt exists, the capture is
# intact and the refusal is named, so it is a coverage gap to report rather
# than a reason to stop the round.
_SEED_BLOCKING = {"seed_not_executed", "seed_partial", "seed_receipt_changed",
                  "seed_capture_changed", "seed_capture_unavailable"}


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def _atomic(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _save(path, value):
    _atomic(path, json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def _read(path, default):
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else default


@contextmanager
def _import_lock(work):
    """Fail safely on overlapping writers; the caller can retry the whole batch."""
    lock = work / "discovery/import.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise ValueError("Discovery import is already running; retry after its lock is released") from exc
    try:
        with os.fdopen(fd, "w", encoding="ascii") as handle:
            handle.write(str(os.getpid()))
        yield
    finally:
        lock.unlink()


def _aliases(company):
    extra = company.get("aliases") or []
    if isinstance(extra, str):
        extra = extra.split(";")
    return sorted({str(name).strip() for name in [company["company"], *extra]
                   if str(name).strip()}, key=str.casefold)


def _term_families():
    """Reduction vocabulary grouped by the kind of evidence each word carries.

    The terms are listed individually rather than as a boolean group. Google
    News RSS treats a parenthesised OR group as one required condition, so
    `("Acme") (layoffs OR "job cuts") 2024` returns nothing unless a single
    article satisfies the whole group. Splitting the group into one query per
    term and unioning the results recovers every article that any single term
    matched, which is what the family was meant to cover.

    Each family names the term that reaches layoff events most reliably. That
    term is the primary probe; the remaining terms are asked in the deep pass.
    A term that names a corporate act ("announcement", "filing") reaches the
    filings that announce a reduction, and it also reaches a large amount of
    unrelated company news, which the relevance filter and the entity binding
    rule discard downstream.
    """
    return (
        ("broad_news", ("layoffs", "job cuts", "redundancies")),
        ("unit_notice", ("WARN", "layoff notice", "team cuts", "local layoffs")),
        ("alternative_news", ("laid off", "cuts jobs", "staff cuts", "job losses", "restructuring")),
        ("official_notice", ("announcement", "statement", "notice", "filing")),
        ("regional_closure", ("plant closure", "research center closure", "local redundancies", "consultation layoffs")),
        ("earnings_reduction", ("earnings workforce reduction", "restructuring layoffs")),
    )


def _quote(value):
    return '"' + str(value).replace('"', '') + '"'


def _tasks(cfg, deep=False):
    """One planned query per company, year and term.

    The primary pass asks the single term that reaches layoff events most
    reliably, so the coverage floor costs one request per company and year.
    The deep pass then asks every remaining term: the alternative phrasings,
    the unit notices, and the corporate acts that announce a reduction. Both
    passes are planned up front, so the receipt contract stays one-to-one
    with the plan and a company with no readable announcement still has every
    term asked of it.
    """
    start, end = (dt.date.fromisoformat(cfg[key]) for key in ("event_start", "event_end"))
    if start > end:
        raise ValueError("event_start must precede event_end")
    tasks = []
    for company in cfg["roster"]:
        aliases = _aliases(company)
        for year in range(start.year, end.year + 1):
            lower = max(start, dt.date(year, 1, 1)).isoformat()
            upper = min(end, dt.date(year, 12, 31)).isoformat()
            for family, terms in _term_families():
                # The primary pass uses the first family and its first term;
                # the deep pass asks every term of every family.
                selected = terms if deep else terms[:1]
                if not deep and family != "broad_news":
                    continue
                for term in selected:
                    if deep and family == "broad_news" and term == terms[0]:
                        # The primary pass already asks this term.
                        continue
                    # One query per name the company is known by. A company
                    # that is reported under a second name would be missed by
                    # a query that names only the first, and a query that
                    # names several at once asks for all of them in the same
                    # article. The name is part of the scope, so each name
                    # gets its own receipt.
                    for name in aliases:
                        scope = {"company_id": company["company_id"], "company": company["company"],
                                 "aliases": aliases, "window_start": lower, "window_end": upper,
                                 "family": family, "term": term,
                                 "pass": "deep" if deep else "primary"}
                        if len(aliases) > 1:
                            scope["name"] = name
                        task_id = "search-" + _digest(scope)[:20]
                        term_part = _quote(term) if " " in term else term
                        tasks.append({**scope, "task_id": task_id,
                                      "query": f"{_quote(name)} {term_part} {year}",
                                      "scope_sha256": _digest(scope)})
    return tasks


def candidate_id(company_id, url):
    """Stable discovery identity; this does not identify or merge a layoff plan."""
    return "hit-" + _digest([company_id, urldefrag(url)[0]])[:24]


def _verification_tasks(work, cfg):
    """One exact-title Google task per stage-1 seed, in addition to annual gap sweeps."""
    from . import seed_sweep
    roster = {item['company_id']: item for item in cfg['roster']}
    tasks = []
    for seed in seed_sweep.relevant_hits(work):
        company = roster.get(seed['company_id'])
        if company is None:
            continue
        aliases = _aliases(company)
        title = seed['title'].replace('"', '').strip()
        scope = {'stage': 'google_verification', 'company_id': company['company_id'],
                 'company': company['company'], 'aliases': aliases,
                 'window_start': cfg['event_start'], 'window_end': cfg['event_end'],
                 'family': 'seed_verification', 'seed_candidate_id': seed['candidate_id']}
        # The company name is quoted on its own and the title is quoted on its
        # own, with no boolean operator between them: the engine matches the
        # title phrase, and the company phrase narrows it.
        name_part = " ".join(_quote(name) for name in aliases[:2])
        tasks.append({**scope, 'task_id': 'verify-' + _digest(scope)[:20],
                      'query': f'{name_part} "{title}"', 'scope_sha256': _digest(scope)})
    return tasks


def _all_tasks(work, cfg):
    """Every planned Stage-2 query: the primary sweep, the deep sweep and the
    seed verifications.

    The deep sweep covers every term of every family, while the primary sweep
    asks each family for its strongest term only. Both are planned up front so
    that the receipt contract stays one-to-one with the plan, and so that a
    company with no readable announcement still has every term asked of it.
    """
    return _tasks(cfg) + _tasks(cfg, deep=True) + _verification_tasks(work, cfg)


def plan(work, cfg):
    """Stage 2 starts once every stage-1 receipt exists and is intact.

    A channel that answered with a refusal is a recorded coverage limitation,
    not an unexecuted step: the receipt exists, the capture is intact and the
    refusal is named. Gating on it would let one permanently unreachable
    tracker block every later round, which is why `blocked` is treated the way
    the audit already treats it — a gap to report, not a reason to stop.
    Missing, partial or altered receipts still stop the run.
    """
    from . import seed_sweep
    work = Path(work)
    seed_status = seed_sweep.status(work, cfg)
    fatal = [gap for gap in seed_status.get("gaps", [])
             if gap.get("reason") in _SEED_BLOCKING]
    if fatal:
        raise ValueError('Initial tracker/report seed sweep is incomplete; run seed-status '
                         'and finish stage 1 before Google verification '
                         '(' + ', '.join(sorted({gap['reason'] for gap in fatal})) + ')')
    tasks = _all_tasks(work, cfg)
    payload = {"version": 2, "stage": "google_verification_and_gap_discovery", "tasks": tasks,
               "window_start": cfg["event_start"], "window_end": cfg["event_end"],
               "blocked_channels": sorted({gap.get("channel") or "" for gap in seed_status.get("gaps", [])}),
               "boundary": "Google verifies each seed and searches each company/year for omissions; receipts do not prove exhaustive public-event coverage."}
    _save(work / "discovery/plan.json", payload)
    return status(work, cfg, _candidates(work))


def _candidates(work):
    path = work / 'event_candidate_review.csv'
    if not path.is_file():
        return []
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def _capture(work, result_path):
    path = Path(result_path)
    path = (path if path.is_absolute() else work / path).resolve()
    if not path.is_relative_to(work.resolve()) or not path.is_file():
        raise ValueError("result_path must identify a saved search result inside the workspace")
    raw = path.read_bytes()
    if not raw:
        raise ValueError("Saved search result is empty")
    return str(path.relative_to(work.resolve())), hashlib.sha256(raw).hexdigest()


def import_results(work, cfg, path):
    """Validate a batch, archive receipts, then atomically replace current state.

    Repeating an identical import is idempotent. Replacing a task receipt archives
    both revisions. Current inbox and pending files are reproducible projections.
    """
    work = Path(work)
    from . import seed_sweep
    seed_status = seed_sweep.status(work, cfg)
    # Same blocking set as `plan`: only an unexecuted, partial or altered
    # receipt stops the round. A refused channel is a named coverage gap, and
    # gating on it would let one permanently unreachable tracker stop every
    # later round.
    unexecuted = [gap for gap in seed_status.get('gaps', [])
                  if gap.get('reason') in _SEED_BLOCKING]
    if unexecuted:
        raise ValueError('Initial tracker/report seed sweep is incomplete; Google result import is not yet allowed')
    tasks = {item["task_id"]: item for item in _all_tasks(work, cfg)}
    batch = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if not isinstance(batch, list):
        raise ValueError("Search import must be a JSON array")
    receipts = []
    seen = set()
    for item in batch:
        task_id = item.get("task_id")
        if task_id not in tasks or task_id in seen:
            raise ValueError("Unknown or duplicate task_id: " + str(task_id))
        seen.add(task_id)
        task = tasks[task_id]
        if item.get("query") != task["query"]:
            raise ValueError("Record the planned broad query; targeted event searches cannot replace it")
        dt.date.fromisoformat(item["executed_at"])
        if item.get("outcome") not in {"completed", "blocked", "partial"}:
            raise ValueError("Invalid search outcome")
        if len(str(item.get("stop_basis") or "").strip()) < 15:
            raise ValueError("A specific search stopping or blocking reason is required")
        relative_path, capture_hash = _capture(work, item["result_path"])
        hits = item.get("hits")
        if not isinstance(hits, list):
            raise ValueError("hits must contain every returned result inspected for relevance")
        normalized = []
        for hit in hits:
            url = str(hit.get("url") or "").strip()
            parsed = urlsplit(url)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise ValueError("Search hits require absolute HTTP URLs")
            if not hit.get("title") or type(hit.get("relevant")) is not bool:
                raise ValueError("Each hit needs title and a boolean relevant flag")
            if not hit["relevant"] and not str(hit.get("exclusion_reason") or "").strip():
                raise ValueError("Irrelevant results require an exclusion reason")
            reported = str(hit.get("reported_date") or "").strip()
            if reported:
                dt.date.fromisoformat(reported)
            normalized.append({"url": url, "title": str(hit["title"]),
                               "relevant": hit["relevant"],
                               "exclusion_reason": str(hit.get("exclusion_reason") or ""),
                               "publisher": str(hit.get("publisher") or "").strip(),
                               "publisher_url": str(hit.get("publisher_url") or "").strip(),
                               "reported_date": reported,
                               "candidate_id": candidate_id(task["company_id"], url)})
        receipt = {**task, "executed_at": item["executed_at"], "outcome": item["outcome"],
                   "stop_basis": item["stop_basis"], "result_path": relative_path,
                   "result_sha256": capture_hash, "hits": normalized}
        receipt["receipt_sha256"] = _digest(receipt)
        receipts.append(receipt)
    with _import_lock(work):
        current = _read(work / "discovery/receipts.json", {})
        for receipt in receipts:
            _save(work / "discovery/history" / (receipt["receipt_sha256"] + ".json"), receipt)
            current[receipt["task_id"]] = receipt
        _save(work / "discovery/receipts.json", current)
    return status(work, cfg, _candidates(work))


def status(work, cfg, candidates):
    """Stage-2 receipts plus reconciliation of both Google hits and stage-1 seeds."""
    work = Path(work)
    tasks = _all_tasks(work, cfg)
    receipts = _read(work / "discovery/receipts.json", {})
    candidates = list(candidates)
    by_id = {row.get("candidate_id"): row for row in candidates}
    roster = {item['company_id']: item for item in cfg['roster']}
    pending, gaps, inbox = [], [], {}
    relevant_ids = set()
    for task in tasks:
        receipt = receipts.get(task["task_id"])
        reason = None
        if receipt is None:
            reason = "search_not_executed"
        else:
            unsigned = {key: value for key, value in receipt.items() if key != "receipt_sha256"}
            if receipt.get("scope_sha256") != task["scope_sha256"] or receipt.get("receipt_sha256") != _digest(unsigned):
                reason = "search_receipt_changed"
            else:
                try:
                    _, actual_hash = _capture(work, receipt["result_path"])
                    if actual_hash != receipt.get("result_sha256"):
                        reason = "search_capture_changed"
                except (OSError, ValueError, KeyError):
                    reason = "search_capture_unavailable"
            if reason is None and receipt.get("outcome") != "completed":
                reason = "search_" + str(receipt.get("outcome"))
            for hit in receipt.get("hits", []):
                cid = hit["candidate_id"]
                row = inbox.setdefault(cid, {"candidate_id": cid, "company_id": task["company_id"],
                                           "company": task["company"], "source_url": hit["url"],
                                           "title": hit["title"], "task_ids": set(), "relevant": False,
                                           # The publisher that carries the article is
                                           # recorded, so an aggregator address can be
                                           # traced back to the page it points at.
                                           "publisher": hit.get("publisher", ""),
                                           "publisher_url": hit.get("publisher_url", ""),
                                           "reported_date": hit.get("reported_date", "")})
                row["task_ids"].add(task["task_id"])
                row["relevant"] = row["relevant"] or hit["relevant"]
                if not row.get("publisher_url"):
                    row["publisher_url"] = hit.get("publisher_url", "")
                if not row.get("publisher"):
                    row["publisher"] = hit.get("publisher", "")
                if not row.get("reported_date"):
                    row["reported_date"] = hit.get("reported_date", "")
                if hit["relevant"]:
                    relevant_ids.add(cid)
                    candidate = by_id.get(cid)
                    if candidate is None:
                        gaps.append({"contract": "discovery", "reason": "search_hit_unaccounted",
                                     "candidate_id": cid, "source_url": hit["url"]})
                    elif (candidate.get("company_id") not in {None, "", task["company_id"]}
                          or candidate.get("company") not in task["aliases"]
                          or urldefrag(candidate.get("source_url") or "")[0] != urldefrag(hit["url"])[0]):
                        gaps.append({"contract": "discovery", "reason": "candidate_identity_mismatch",
                                     "candidate_id": cid})
        if reason:
            gaps.append({"contract": "discovery", "reason": reason, "task_id": task["task_id"]})
            pending.append({**task, "reason": reason})
    # A seed cannot bypass candidate reconciliation merely because it arrived before Google.
    from . import seed_sweep
    for seed in seed_sweep.relevant_hits(work):
        cid = seed['candidate_id']
        relevant_ids.add(cid)
        candidate = by_id.get(cid)
        company = roster.get(seed['company_id'], {})
        if candidate is None:
            gaps.append({'contract': 'initial_seed', 'reason': 'seed_hit_unaccounted',
                         'candidate_id': cid, 'source_url': seed['source_url']})
        elif (candidate.get('company_id') not in {None, '', seed['company_id']}
              or candidate.get('company') not in _aliases(company)
              or urldefrag(candidate.get('source_url') or '')[0] != urldefrag(seed['source_url'])[0]):
            gaps.append({'contract': 'initial_seed', 'reason': 'seed_candidate_identity_mismatch',
                         'candidate_id': cid})
    fields = ["candidate_id", "company_id", "company", "source_url", "title",
              "task_ids", "relevant", "publisher", "publisher_url", "reported_date"]
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    for row in sorted(inbox.values(), key=lambda item: item["candidate_id"]):
        writer.writerow({**row, "task_ids": ";".join(sorted(row["task_ids"]))})
    _atomic(work / "discovery/inbox.csv", buffer.getvalue())
    result = {"pass": not gaps, "stage": "google_verification_and_gap_discovery",
              "tasks": len(tasks), "seed_verification_tasks": len(_verification_tasks(work, cfg)),
              "pending_tasks": len(pending), "unique_relevant_hits": len(relevant_ids), "gaps": gaps,
              "boundary": "Every seed has a verification task and every company/year has gap searches; neither proves exhaustive web coverage."}
    _save(work / "review/discovery-next.json", {"pending": pending, "gaps": gaps,
                                               "inbox": "discovery/inbox.csv"})
    return result
