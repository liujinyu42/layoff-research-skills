"""Shared entity registry and year-to-year comparability metadata.

A name key is a placeholder, not an identity. This module records which legal entities a
company_id covers, when each name was valid, and how it relates to parents and
subsidiaries. Comparability records then decide whether two years may be divided at all.
"""
from __future__ import annotations

import datetime
import re
from pathlib import Path

from . import contracts

NAME_TYPES = {'legal', 'brand', 'subsidiary', 'parent', 'trading', 'former'}
SCOPES = {'consolidated', 'parent_only', 'segment', 'unknown'}
IDENTITY_FIELDS = ('registrant_cik', 'current_registrant_cik', 'parent_cik',
                   'official_website', 'business_description', 'shared_registrant_basis',
                   'historical_lookup_basis')
VERIFICATION_BASES = {'own_source', 'registry_filing', 'news_mention', 'cross_reference'}


def _cik(value, field='CIK'):
    if value in (None, ''):
        return None
    text = str(value).strip()
    if not text.isdigit() or len(text) > 10:
        raise ValueError(field + ' must contain digits only and at most ten digits')
    return text.zfill(10)


def _cik_list(value):
    if value in (None, ''):
        return []
    items = value if isinstance(value, list) else str(value).replace(',', ';').split(';')
    return sorted({_cik(item, 'historical_ciks') for item in items if str(item).strip()})


def _related(entries, left, right):
    """True only for a recorded parent/child chain, not for similar names."""
    for start, target in ((left, right), (right, left)):
        seen, cursor = set(), start
        while cursor and cursor not in seen:
            if cursor == target:
                return True
            seen.add(cursor)
            cursor = (entries.get(cursor) or {}).get('parent_company_id')
    return False


def _domains(value):
    """Bare hostnames only: a domain is evidence of an entity, not a URL string."""
    items = value if isinstance(value, list) else re.split(r'[;,]', str(value or ''))
    out = []
    for item in items:
        host = str(item).strip().lower()
        if not host:
            continue
        host = re.sub(r'^https?://', '', host).split('/')[0]
        if not re.fullmatch(r'(?:[a-z0-9-]+\.)+[a-z]{2,}', host):
            raise ValueError('domains must be bare hostnames such as example.com')
        out.append(host)
    return sorted(set(out))


def _path(work):
    return Path(work) / 'registry' / 'entities.json'


def _comparability_path(work):
    return Path(work) / 'registry' / 'comparability.json'


def init(skill, work, cfg):
    entries = {}
    for row in cfg['roster']:
        entries[row['company_id']] = {'company_id': row['company_id'],
                                      'display_name': row['company'],
                                      'company_en': row.get('company_en'),
                                      'status': 'unverified',
                                      'names': [{'name': row['company'], 'name_type': 'legal',
                                                 'valid_from': None, 'valid_to': None,
                                                 'verified': False, 'source_id': None}],
                                      'country': row.get('country'), 'registration_id': None,
                                      'entity_id': row['company_id'], 'domains': [],
                                      'brand_of': None, 'name_collisions': [],
                                      'verification_basis': None, 'identity_strength': 'none',
                                      'registrant_cik': _cik(row.get('cik'), 'registrant_cik'),
                                      'current_registrant_cik': None, 'parent_cik': None,
                                      'historical_ciks': [], 'official_website': None,
                                      'business_description': None, 'shared_registrant_basis': None,
                                      'historical_lookup_basis': None,
                                      'parent_company_id': None, 'children': [],
                                      'listing_history': [], 'verification': None}
    payload = {'entries': entries, 'rule': 'A provisional name key is not an identity. Verify before pairing tables.'}
    contracts.write_json(_path(work), payload)
    return {'registry': str(_path(work)), 'entries': len(entries), 'unverified': len(entries),
            'next': 'registry-verify with one row per legal entity, brand or subsidiary'}


def read(work):
    return contracts.read_json(_path(work), {'entries': {}}) or {'entries': {}}


def _date(value, field):
    if value in (None, ''):
        return None
    try:
        return datetime.date.fromisoformat(str(value))
    except ValueError as exc:
        raise ValueError(field + ' must be an ISO date') from exc


def verify(skill, work, path, cfg, sources, get_text):
    registry = read(work)
    entries = registry['entries']
    errors, applied = [], []
    for number, row in enumerate(contracts.parse_rows(path), 1):
        try:
            company = str(row.get('company_id') or '').strip()
            if company not in entries:
                raise ValueError('company_id is not in the roster: ' + (company or '(empty)'))
            name = str(row.get('name') or '').strip()
            if len(name) < 2:
                raise ValueError('a verified name needs at least two characters')
            name_type = str(row.get('name_type') or 'legal').strip()
            if name_type not in NAME_TYPES:
                raise ValueError('name_type must be one of ' + ', '.join(sorted(NAME_TYPES)))
            valid_from = _date(row.get('valid_from'), 'valid_from')
            valid_to = _date(row.get('valid_to'), 'valid_to')
            if valid_from and valid_to and valid_from > valid_to:
                raise ValueError('valid_from is after valid_to')
            source_id = str(row.get('source_id') or '').strip()
            quote = row.get('quote')
            if source_id not in sources or sources[source_id].get('status') != 'ready':
                raise ValueError('verification needs a ready registered source')
            if not isinstance(quote, str) or len(quote.strip()) < 10:
                raise ValueError('verification needs a verbatim span of at least ten characters')
            text = get_text(source_id)
            if text.count(quote) != 1:
                raise ValueError('verification span is missing or ambiguous; supply a unique quotation')
            parent = str(row.get('parent_company_id') or '').strip() or None
            if parent and parent not in entries:
                raise ValueError('parent_company_id is not in the roster: ' + parent)
            if parent == company:
                raise ValueError('a company cannot be its own parent')
            basis = str(row.get('verification_basis') or 'own_source').strip()
            if basis not in VERIFICATION_BASES:
                raise ValueError('verification_basis must be one of '
                                 + ', '.join(sorted(VERIFICATION_BASES)))
            entity_id = str(row.get('entity_id') or company).strip()
            if not re.fullmatch(r'[A-Za-z0-9_.:-]{2,64}', entity_id):
                raise ValueError('entity_id must be a short stable identifier')
            domains = _domains(row.get('domains'))
            if basis in {'own_source', 'registry_filing'} and not domains:
                # A legal entity is identified by more than its name. Without a
                # domain or registrant identifier, name similarity cannot say
                # which entity a page is about.
                raise ValueError('verification with a primary source needs at least one '
                                 'domain for this entity')
            brand_of = str(row.get('brand_of') or '').strip() or None
            if brand_of and brand_of not in entries:
                raise ValueError('brand_of is not in the roster: ' + brand_of)
            entry = entries[company]
            # A recovery workspace may start from a minimal roster mapping
            # written by hand; an absent name list is an empty one.
            entry.setdefault('names', [])
            entry['names'] = [item for item in entry['names']
                              if not (item['name'] == name and item['name_type'] == name_type
                                      and item.get('valid_from') == (valid_from.isoformat() if valid_from else None)
                                      and item.get('valid_to') == (valid_to.isoformat() if valid_to else None))]
            entry['names'].append({'name': name, 'name_type': name_type,
                                   'valid_from': valid_from.isoformat() if valid_from else None,
                                   'valid_to': valid_to.isoformat() if valid_to else None,
                                   'verified': True, 'source_id': source_id,
                                   'verification_basis': basis,
                                   'quote_sha256': contracts.digest({'q': quote})})
            for key in ('country', 'registration_id'):
                if row.get(key):
                    entry[key] = str(row[key]).strip()
            for key in ('registrant_cik', 'current_registrant_cik', 'parent_cik'):
                if row.get(key) not in (None, ''):
                    entry[key] = _cik(row[key], key)
            if row.get('historical_ciks') not in (None, ''):
                entry['historical_ciks'] = _cik_list(row['historical_ciks'])
            for key in ('official_website', 'business_description', 'shared_registrant_basis',
                        'historical_lookup_basis'):
                if row.get(key) not in (None, ''):
                    entry[key] = str(row[key]).strip()
            if entry.get('shared_registrant_basis') and len(entry['shared_registrant_basis']) < 15:
                raise ValueError('shared_registrant_basis must explain the evidenced shared filer relationship')
            website = entry.get('official_website')
            if website and not website.startswith(('https://', 'http://')):
                raise ValueError('official_website must be an absolute HTTP(S) URL')
            if parent:
                entry['parent_company_id'] = parent
            entry['entity_id'] = entity_id
            if domains:
                entry['domains'] = sorted(set(entry.get('domains') or []) | set(domains))
            if brand_of:
                entry['brand_of'] = brand_of
            entry['verification_basis'] = basis
            entry['identity_strength'] = (
                'mention_only' if basis == 'news_mention' else 'strong')
            entry['status'] = 'verified'
            entry['verification'] = {'source_id': source_id, 'verified_at': contracts.now(),
                                     'reviewer_kind': row.get('reviewer_kind') or 'model',
                                     'reviewer_id': row.get('reviewer_id'),
                                     'basis': basis}
            applied.append({'company_id': company, 'name': name, 'name_type': name_type})
        except (ValueError, KeyError, TypeError, OSError) as exc:
            errors.append({'row': number, 'company_id': row.get('company_id'), 'error': str(exc)})
    entity_ids = {}
    for company, entry in entries.items():
        if entry.get('status') == 'verified':
            entity_ids.setdefault(entry.get('entity_id') or company, []).append(company)
    for entity, companies in sorted(entity_ids.items()):
        if len(companies) > 1:
            for company in companies:
                errors.append({'company_id': company, 'entity_id': entity,
                               'error': 'entity_id is used by more than one roster company'})
    # A name two unrelated roster entities both use cannot identify a legal
    # entity. An identity verified only by a mention moves to review instead of
    # passing as verified: a unique-looking name is not a unique legal entity.
    names = {}
    for company, entry in entries.items():
        for item in entry.get('names', []):
            if item.get('verified'):
                names.setdefault(item['name'].casefold(), set()).add(company)
    pending = []
    for name, companies in sorted(names.items()):
        if len(companies) < 2:
            continue
        for left in sorted(companies):
            for right in sorted(companies):
                if left >= right or _related(entries, left, right):
                    continue
                for company in (left, right):
                    entry = entries[company]
                    collisions = entry.setdefault('name_collisions', [])
                    if name not in collisions:
                        collisions.append(name)
                    if entry.get('identity_strength') == 'mention_only':
                        entry['status'] = 'pending_review'
                        entry['pending_reason'] = (
                            'the name is also used by another roster entity and a '
                            'mention cannot distinguish the legal entity')
                        pending.append(company)
    report = {'pass': not errors, 'errors': errors, 'verified_names': len(applied),
              'pending_review': sorted(set(pending)),
              'identity_strength': {
                  'strong': sum(1 for entry in entries.values()
                                if entry.get('status') == 'verified'
                                and entry.get('identity_strength') == 'strong'),
                  'mention_only': sum(1 for entry in entries.values()
                                      if entry.get('identity_strength') == 'mention_only'),
                  'unverified': sum(1 for entry in entries.values()
                                    if entry.get('status') == 'unverified')}}
    if errors:
        return report
    contracts.write_json(_path(work), registry)
    return report


def check(skill, work, cfg):
    registry = read(work)
    entries = registry.get('entries', {})
    errors, warnings = [], []
    roster_rows = {row['company_id']: row for row in cfg['roster']}
    roster = set(roster_rows)
    for company, entry in entries.items():
        parent = entry.get('parent_company_id')
        seen, cursor = set(), company
        while cursor:
            if cursor in seen:
                errors.append({'company_id': company, 'error': 'parent chain contains a cycle'})
                break
            seen.add(cursor)
            cursor = (entries.get(cursor) or {}).get('parent_company_id')
        if parent and parent not in roster:
            warnings.append({'company_id': company,
                             'warning': 'parent is outside the requested roster; cross-table pairing needs it'})
        spans = {}
        for item in entry.get('names', []):
            if not item.get('verified'):
                continue
            key = (item['name'].casefold(), item['name_type'])
            spans.setdefault(key, []).append((item.get('valid_from'), item.get('valid_to')))
        for key, windows in spans.items():
            ordered = sorted(windows, key=lambda window: window[0] or '')
            for index in range(1, len(ordered)):
                previous_end, current_start = ordered[index - 1][1], ordered[index][0]
                if previous_end is None or current_start is None or current_start <= previous_end:
                    errors.append({'company_id': company,
                                   'error': 'overlapping validity windows for ' + key[0] + ' (' + key[1] + ')'})
        registrant = _cik(entry.get('registrant_cik'), 'registrant_cik')
        current = _cik(entry.get('current_registrant_cik'), 'current_registrant_cik')
        roster_cik = _cik((roster_rows.get(company) or {}).get('cik'), 'roster CIK')
        historical = set(_cik_list(entry.get('historical_ciks')))
        historical_basis = bool(str(entry.get('historical_lookup_basis') or '').strip())
        if registrant and current and registrant != current and not (registrant in historical and historical_basis):
            errors.append({'company_id': company, 'error': 'registrant_cik conflicts with verified current_registrant_cik; '
                           'a former CIK requires historical_ciks plus historical_lookup_basis'})
        if registrant and roster_cik and registrant != roster_cik and not (roster_cik in historical and historical_basis):
            errors.append({'company_id': company, 'error': 'registry registrant_cik conflicts with the CIK actually supplied in the roster'})
        if current and roster_cik and current != roster_cik and not (roster_cik in historical and historical_basis):
            errors.append({'company_id': company, 'error': 'roster CIK conflicts with verified current_registrant_cik; '
                           'do not collect current filings under a former registrant without an explicit historical basis'})
        if entry.get('status') != 'verified':
            warnings.append({'company_id': company, 'warning': 'identity not verified'})
        elif not entry.get('official_website') or not entry.get('business_description'):
            warnings.append({'company_id': company,
                             'warning': 'record official_website and business_description to resolve name ambiguity; name similarity alone is insufficient'})
    cik_groups = {}
    for company, entry in entries.items():
        cik = _cik(entry.get('registrant_cik'), 'registrant_cik')
        if cik:
            cik_groups.setdefault(cik, []).append(company)
    for cik, companies in sorted(cik_groups.items()):
        if len(companies) < 2:
            continue
        for index, left in enumerate(companies):
            for right in companies[index + 1:]:
                if _related(entries, left, right):
                    continue
                left_basis = entries[left].get('shared_registrant_basis') and entries[left].get('status') == 'verified'
                right_basis = entries[right].get('shared_registrant_basis') and entries[right].get('status') == 'verified'
                if not (left_basis or right_basis):
                    errors.append({'company_id': left, 'other_company_id': right, 'registrant_cik': cik,
                                   'error': 'different company_id values share one registrant CIK without a verified parent/brand chain or shared_registrant_basis'})
    pending = [{'company_id': company,
                'reason': entry.get('pending_reason') or 'identity pending review'}
               for company, entry in sorted(entries.items())
               if entry.get('status') == 'pending_review']
    collisions = [{'company_id': company, 'names': sorted(entry.get('name_collisions') or [])}
                  for company, entry in sorted(entries.items())
                  if entry.get('name_collisions')]
    return {'pass': not errors, 'errors': errors, 'warnings': warnings,
            'verified': sum(1 for entry in entries.values() if entry.get('status') == 'verified'),
            'unverified': sum(1 for entry in entries.values() if entry.get('status') != 'verified'),
            'pending_review': pending, 'name_collisions': collisions,
            'identity_strength': {
                'strong': sum(1 for entry in entries.values()
                              if entry.get('identity_strength') == 'strong'),
                'mention_only': sum(1 for entry in entries.values()
                                    if entry.get('identity_strength') == 'mention_only'),
                'none': sum(1 for entry in entries.values()
                            if not entry.get('identity_strength'))},
            'shared_cik_groups': {cik: companies for cik, companies in cik_groups.items() if len(companies) > 1},
            'boundary': 'Verification binds names, registrant identifiers, websites and parent/brand relations to sources; it is not a complete corporate-tree audit.'}


def import_comparability(skill, work, path, cfg):
    rows = contracts.parse_rows(path)
    errors, records = [], {}
    for number, row in enumerate(rows, 1):
        try:
            company = str(row.get('company_id') or '').strip()
            if company not in {item['company_id'] for item in cfg['roster']}:
                raise ValueError('company_id is not in the roster: ' + (company or '(empty)'))
            fy = int(row.get('fy'))
            start = _date(row.get('period_start'), 'period_start')
            end = _date(row.get('period_end'), 'period_end')
            if not start or not end or start >= end:
                raise ValueError('period_start and period_end must be ISO dates with start before end')
            days = (end - start).days + 1
            if not 300 <= days <= 400:
                raise ValueError('an annual period should be 300 to 400 days; ' + str(days) + ' recorded')
            currency = str(row.get('currency') or '').strip().upper()
            if len(currency) != 3 or not currency.isalpha():
                raise ValueError('currency must be an explicit ISO code')
            scope = str(row.get('consolidation_scope') or '').strip()
            if scope not in SCOPES:
                raise ValueError('consolidation_scope must be one of ' + ', '.join(sorted(SCOPES)))
            records[f'{company}:{fy}'] = {'company_id': company, 'fy': fy,
                                          'period_start': start.isoformat(), 'period_end': end.isoformat(),
                                          'period_days': days, 'currency': currency,
                                          'consolidation_scope': scope,
                                          'restatement_version': str(row.get('restatement_version') or 'original').strip(),
                                          'source_id': str(row.get('source_id') or '').strip() or None,
                                          'notes': str(row.get('notes') or '').strip() or None}
        except (ValueError, KeyError, TypeError) as exc:
            errors.append({'row': number, 'company_id': row.get('company_id'), 'error': str(exc)})
    if errors:
        return {'pass': False, 'errors': errors}
    prior = contracts.read_json(_comparability_path(work), {}) or {}
    prior.update(records)
    contracts.write_json(_comparability_path(work), prior)
    return {'pass': True, 'records': len(records), 'total': len(prior),
            'output': str(_comparability_path(work))}


def compare(skill, work, company, fy_left, fy_right):
    records = contracts.read_json(_comparability_path(work), {}) or {}
    left = records.get(f'{company}:{fy_left}')
    right = records.get(f'{company}:{fy_right}')
    if not left or not right:
        missing = [label for label, item in ((f'{company}:{fy_left}', left), (f'{company}:{fy_right}', right)) if not item]
        raise ValueError('No comparability record for ' + ', '.join(missing))
    reasons = []
    if left['currency'] != right['currency']:
        reasons.append({'reason': 'currency_changed', 'left': left['currency'], 'right': right['currency']})
    if abs(left['period_days'] - right['period_days']) > 10:
        reasons.append({'reason': 'period_length_differs', 'left': left['period_days'],
                        'right': right['period_days']})
    if left['consolidation_scope'] != right['consolidation_scope']:
        reasons.append({'reason': 'consolidation_scope_changed', 'left': left['consolidation_scope'],
                        'right': right['consolidation_scope']})
    if left['restatement_version'] != right['restatement_version']:
        reasons.append({'reason': 'restatement_version_differs', 'left': left['restatement_version'],
                        'right': right['restatement_version']})
    return {'company_id': company, 'fy_left': int(fy_left), 'fy_right': int(fy_right),
            'comparable': not reasons, 'reasons': reasons,
            'advice': 'A growth rate across incomparable periods is not a measurement. Keep both levels and '
                      'state the break.' if reasons else 'Periods share currency, length, scope and restatement version.'}
