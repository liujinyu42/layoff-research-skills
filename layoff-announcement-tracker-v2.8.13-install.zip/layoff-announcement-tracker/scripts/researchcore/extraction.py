"""Extract event facts from retrieved reports with scope-safe numeric rules.

The previous collection round recorded four systematic numeric defects that
the audit report surfaced as "magnitude anomalies":

* an industry-wide aggregate ("over 100,000 positions eliminated across major
  companies like Microsoft, Intel, Google") was recorded as one company's
  layoff count;
* a threshold ("over 61,000") was recorded as an exact point estimate;
* a year-to-date attribution to a cause ("AI is now blamed for 50,000 job cuts
  this year") was recorded as this employer's own event count;
* a before/after construction ("cut its support team from 9,000 to 5,000")
  was read as the number 9,000 rather than the difference.

Every rule here exists to make a number mean what the sentence says before it
becomes a claim. A number that cannot be attributed to this employer in this
event is not recorded at all.
"""
from __future__ import annotations

import re

# --- reduction vocabulary -------------------------------------------------
REDUCE = re.compile(
    r"\b(lay(?:ing|s|ed)?[\s-]?offs?|job\s+cuts?|cuts?\s+(?:jobs?|staff|roles?|positions?)|"
    r"(?:laid|lay|laying)\s+off\s+(?:about|around|roughly|nearly|approximately|some|"
    r"over|more\s+than|at\s+least|up\s+to)?\s*\d|"
    r"cut(?:s|ting)?\s+(?:about|around|roughly|nearly|approximately|some|over|"
    r"more\s+than|at\s+least|up\s+to)?\s*\d|"
    r"workforce\s+reduction(?:s)?|redundan(?:cies|cy|t)|downsiz(?:e|ed|ing)|"
    r"eliminat(?:e|ed|ing)\s+(?:\w+\s+){0,3}(?:positions|jobs|roles)|"
    r"shed(?:ding)?\s+\w+\s+jobs|trim(?:ming)?\s+(?:the\s+)?(?:workforce|headcount|staff)|"
    r"cut(?:s|ting)?\s+\w+\s+(?:jobs|roles|positions)|restructur(?:e|ing|al)|"
    r"headcount\s+reduction|slash(?:es|ed|ing)\s+(?:jobs|positions)|"
    r"staff\s+cuts?|job\s+loss(?:es)?|voluntary\s+separation(?:s)?|"
    r"voluntary\s+severance|separat(?:ion|ing)\s+package|"
    r"cost[- ]cutting|workforce\s+action)",
    re.I)

# --- number reading --------------------------------------------------------
COUNT = re.compile(
    r"(?<![\d.])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*"
    r"(?:\+|k\b|m\b|million|billion)?\s*"
    r"(?:of\s+)?(?:its|the|their|our|his|her)?\s*"
    r"(jobs?|employees?|staff|people|roles?|positions?|workers?|persons?|"
    r"team\s+members?|heads\b|slots?|seats?)", re.I)

PCT = re.compile(r"(?<![\d.])(\d{1,3}(?:\.\d+)?)\s*(?:%|per\s?cent)(?![\w])", re.I)

MULT = {"k": 1_000, "m": 1_000_000, "million": 1_000_000, "billion": 1_000_000_000}

# Qualifiers that make a number a bound rather than a point.
THRESHOLD = re.compile(
    r"\b(over|more\s+than|more\s+than\s+about|at\s+least|up\s+to|no\s+more\s+than|"
    r"nearly|almost|around|about|approximately|roughly|some|as\s+many\s+as|"
    r"between|estimated\s+at|an\s+estimated)\s*$", re.I)

# Signals that a number describes a population other than this event.
AGGREGATE = re.compile(
    r"\b(across\s+(?:the\s+)?(?:industry|sector|market|tech|companies|employers)|"
    r"industry[- ]wide|sector[- ]wide|market[- ]wide|"
    r"in\s+(?:the\s+)?(?:industry|sector|market)\s+(?:overall|as\s+a\s+whole)|"
    r"the\s+(?:tech\s+)?industry\s+is|companies\s+like|"
    r"among\s+(?:major\s+)?(?:tech\s+)?companies|"
    r"so\s+far\s+(?:this\s+year|in\s+\d{4})|"
    r"year[- ]to[- ]date|ytd|in\s+\d{4}\s+so\s+far|"
    r"this\s+year\s+(?:so\s+far|has\s+seen)|"
    r"tech\s+layoffs\s+\d{4}|layoffs?\s+\d{4}\s*[:\-])\b", re.I)

# Causality attribution to a trend rather than to this employer's action.
TREND_ATTRIBUTION = re.compile(
    r"\b(blamed?\s+for|attributed\s+to|credited\s+to|due\s+to|because\s+of|"
    r"driven\s+by|as\s+\w+\s+(?:is|are)\s+blamed|"
    r"the\s+(?:rise|surge|wave|trend|boom)\s+of)\b", re.I)

# Another employer's own action inside the same sentence. "Microsoft said it
# would lay off 10,000 workers while Google announced no changes" mentions
# Google, but the number belongs to Microsoft.
# The name must be a real proper noun with a capital letter at the start: the
# pattern used to match the pronouns and common nouns that stand between an
# employer and its own verb ("the company would cut 1,500", "it is laying off
# 8,000", "that will cut 3,300"), which discarded that employer's own figure.
# It must also not be a clause connector.
OTHER_EMPLOYER_ACTION = re.compile(
    r"\b(?P<other>(?<![a-z])[A-Z][A-Za-z0-9&.\-]{1,30})\s+"
    r"(?:said|says|announced|announces|reported|reports|plans|plan|will|would|"
    r"is\s+cutting|is\s+laying\s+off|cut|lay\s+off|lays\s+off)\s+"
    r"(?:it\s+)?(?:would\s+|will\s+|could\s+)?"
    r"(?:about|around|roughly|nearly|approximately|over|more\s+than|at\s+least|up\s+to)?\s*"
    r"(?:\w+\s+){0,3}?\d{1,3}(?:,\d{3})+", re.M)

# A construction where the number is a before-state, not the affected count.
BEFORE_AFTER = re.compile(
    r"(?:from|cut\s+(?:its\s+)?\w+\s+from|reduced\s+from|shrank\s+from|"
    r"down\s+from|trimmed\s+from|headcount\s+from)\s+"
    r"(\d{1,3}(?:,\d{3})+|\d+)\s*(?:\w+\s+){0,3}?(?:to|down\s+to)\s+"
    r"(\d{1,3}(?:,\d{3})+|\d+)", re.I)

# The number counts people who remain, not those removed.
REMAINING = re.compile(
    r"\b(remaining|left\s+with|now\s+(?:has|employs|fields)|"
    r"retained|still\s+(?:has|employs)|headcount\s+of|"
    r"workforce\s+of|employs\s+(?:about\s+|around\s+|nearly\s+)?)\b", re.I)

# A workforce figure rather than a reduction figure.
# `employs?\b` needs the boundary: without it "employees" matches "employ" and
# a sentence like "lays off 174 employees" is misread as a workforce total,
# which then discards a valid count.
WORKFORCE_TOTAL = re.compile(
    r"\b(?:employs?\b|employed|had\s+\d[\d,]*\s+(?:employees|staff|people|workers)|"
    r"workforce\s+of|headcount\s+of|total\s+(?:employees|staff|people)|"
    r"company\s+has\s+\d[\d,]*\s+(?:employees|staff|people))", re.I)

# A sentence that denies a reduction. "ServiceNow pledged to not lay off any of
# its 11,000 employees" states the opposite of an event; the workforce figure
# next to the denied verb used to be recorded as a layoff count.
NEGATED = re.compile(
    r"\b(?:not|no|never|neither|nor|without)\s+(?:\w+\s+){0,3}?"
    r"(?:lay(?:ing|s|ed)?\s*off|cut(?:s|ting)?\s+(?:jobs?|staff|roles?)|"
    r"job\s+cuts?|reduc(?:e|ing|tion)|eliminat(?:e|ing)|downsiz(?:e|ing))\b|"
    r"\b(?:pledged|vowed|promised|committed|agreed|decided|plans?|intends?)\s+"
    r"(?:to\s+)?(?:not|no)\b|"
    r"\b(?:will|would|does|do|did|is|are|has|have)\s+not\s+(?:\w+\s+){0,2}?"
    r"(?:lay(?:ing)?\s*off|cut|eliminate|reduce|downsize)\b|"
    r"\b(?:no\s+(?:plans?|intention)\s+to|rules?\s+out|denied|denies)\b", re.I)

# Counts that are explicitly not layoffs.
# A figure introduced by a growth verb is hiring, not a reduction. "plan to grow
# our overall headcount this year with over 500 roles" states the opposite of a
# layoff, and reading it as a count inverts the event.
HIRING = re.compile(
    r"\b(?:grow|growing|grown|hire|hiring|hires|add|adding|expand|expanding|"
    r"increase|increasing|investing|invest)\b[^.;]{0,60}?"
    r"\b(?:headcount|workforce|roles|people|staff|employees|team|engineers)\b", re.I)


NOT_A_LAYOFF = re.compile(
    r"\b(furlough|vacant|vacancy|open\s+(?:positions|roles|reqs?|requisitions?)|"
    r"unfilled|job\s+openings?|positions?\s+open|"
    r"remaining\s+(?:headcount|employees|staff|workers)|"
    r"remaining\s+workforce|hiring\s+freeze|"
    r"total\s+(?:workforce|employees|staff)\s+(?:of|at)|"
    r"company\s+(?:has|employs)|has\s+\d[\d,]*\s+employees|"
    r"employees\s+worldwide|total\s+employees)\b", re.I)

# Years mentioned inside a sentence; a figure tied to a different year is
# background, not this event.
YEAR = re.compile(r"\b(20\d{2})\b")

# The sentence must place the number next to the reduction, not near a
# different number (for example "cut 300 jobs from a team of 9,000").
CUT_TARGET = re.compile(
    r"(cut|cuts|laid\s+off|laying\s+off|lay\s+off|eliminat\w+|"
    r"reduc\w+|slash\w+|shed\w+|trim\w+|downsiz\w+)\s+"
    r"(?:about|around|roughly|nearly|approximately|over|more\s+than|at\s+least|up\s+to)?\s*"
    r"(?:\w+\s+){0,3}?(\d{1,3}(?:,\d{3})+|\d+)", re.I)

# An employer-specific action. The employer must be the subject of the
# reduction, not one of several companies listed inside an industry roundup.
# "the tech industry ... 100,000 positions eliminated across major companies
# like Microsoft, Intel, Google" names Google but attributes no action to it.
# The pattern is: the employer name, an optional short verb phrase, then the
# reduction verb.
REDUCTION_VERB = (r"(?:cut|cuts|cutting|laid\s+off|lay\s+off|laying\s+off|lays\s+off|"
                  r"eliminate|eliminates|eliminated|eliminating|reduce|reduces|reduced|reducing|"
                  r"slash|slashes|slashed|slashing|shed|sheds|shedding|trim|trims|trimming|"
                  r"downsize|downsizing|restructure|restructures|restructuring)")

EMPLOYER_AS_SUBJECT = re.compile(
    r"(?P<name>[A-Z][\w&.\-]{1,28}(?:\s+[A-Z][\w&.\-]{1,28}){0,2})\s+"
    r"(?:" + REDUCTION_VERB + r")\b", re.M)

# "Groupon will cut", "Twitter is cutting", "UiPath to lay off": the employer
# is the subject when a modal or auxiliary separates it from the verb.
EMPLOYER_AS_SUBJECT_AUX = re.compile(
    r"(?P<name>[A-Z][\w&.\-]{1,28}(?:\s+[A-Z][\w&.\-]{1,28}){0,2})\s+"
    r"(?:will|would|is|are|has|have|had|to|plans?\s+to|plans?|"
    r"confirms?|confirmed)\s+(?:\w+\s+){0,2}?" + REDUCTION_VERB + r"\b", re.M)

# "Intel plans another round of layoffs": the employer is the subject and the
# reduction appears as a noun phrase rather than as a verb.
REDUCTION_NOUN = (r"(?:another\s+|a\s+|another\s+round\s+of\s+)?"
                  r"(?:round\s+of\s+)?(?:layoffs?|job\s+cuts?|staff\s+cuts?|"
                  r"workforce\s+reductions?|redundancies)")
EMPLOYER_AS_SUBJECT_NOUN = re.compile(
    r"(?P<name>[A-Z][\w&.\-]{1,28}(?:\s+[A-Z][\w&.\-]{1,28}){0,2})\s+"
    r"(?:will|would|is|are|has|have|had|to|plans?\s+to|plans?|announced|said|"
    r"confirms?|confirmed|is\s+set\s+to|is\s+expected\s+to)\s+"
    r"(?:\w+\s+){0,3}?" + REDUCTION_NOUN + r"\b", re.M)

# "the company said it would cut 350 roles": the employer is referred to
# pronominally after being named in the same sentence.
# "Uber Technologies (UBER) has just announced a restructuring that will cut
# 3,300 jobs": the employer is the subject, an announcement verb intervenes,
# and the reduction verb follows a lowercase-only qualifier. The filler is
# restricted to lowercase words so the match cannot jump across another
# employer's capitalised name.
EMPLOYER_ANNOUNCE_ACTION = re.compile(
    r"(?P<name>[A-Z][\w&.\-]{1,28}(?:\s+[A-Z][\w&.\-]{1,28}){0,2})\s*"
    r"(?:\([A-Z.]{1,8}\))?\s*"
    r"(?:(?:has|have|had|is|are|was|were|will|would|just|recently|also|now|to)\s+){0,3}"
    r"(?:announced|announces|announcing|said|says|saying|confirmed|confirms|"
    r"unveiled|unveils|revealed|reveals|plans|planned|expects|expected)\b"
    r"(?:\s+[a-z][\w'\-,]*){0,8}\s+"
    r"(?:will|would|to|is|are|that\s+will|which\s+will)?\s*"
    r"(?:\w+\s+){0,2}?" + REDUCTION_VERB + r"\b", re.M)

PRONOMINAL_ACTION = re.compile(
    r"\b(?:it|they|he|she|the\s+company|the\s+firm|the\s+group)\b[^.]{0,40}?"
    + REDUCTION_VERB + r"\b", re.I)

# The employer named in a prepositional slot rather than as the grammatical
# subject. These pages are about the employer's reduction even though the
# sentence's subject is something else:
#   "Magna Steyr to cut 500 jobs amid EV startup Fisker's financial woes"
#   "'AI-first' push leads to 250 layoffs at Fiverr"
EMPLOYER_IN_OBJECT = re.compile(
    r"(?:at|amid|by|inside|within|across|from|for|of|hit|impacting|affecting)\s+"
    r"(?:the\s+)?(?P<name>[A-Z][\w&.\-]{1,28}(?:\s+[A-Z][\w&.\-]{1,28}){0,2})\b", re.I)

# A role title carrying the employer's name: "Fiverr CEO said ...".
EMPLOYER_ROLE = re.compile(
    r"(?P<name>[A-Z][\w&.\-]{1,28}(?:\s+[A-Z][\w&.\-]{1,28}){0,2})\s*'?\s+"
    r"(?:CEO|CFO|COO|CTO|chief\s+\w+|president|founder|spokesman|spokeswoman|"
    r"spokesperson|chairman|chairwoman|chairperson|head\s+of\s+\w+)\b", re.M)

# The reduction noun sits next to the employer without a verb:
# "250 layoffs at Fiverr", "Fiverr layoffs".
EMPLOYER_WITH_NOUN = re.compile(
    r"(?P<name>[A-Z][\w&.\-]{1,28}(?:\s+[A-Z][\w&.\-]{1,28}){0,2})\s+"
    r"(?:layoffs?|job\s+cuts?|staff\s+cuts?|reductions?|workforce\s+reduction)", re.M)


# A statement that recaps rather than announces: a cumulative total, an
# earlier round, or a figure from a previous year.
RECAP = re.compile(
    r"\b(since|in\s+total|cumulatively|previous(?:ly)?|earlier\s+round|prior\s+round|"
    r"last\s+year|had\s+announced|had\s+planned|a\s+year\s+earlier|"
    r"announced\s+(?:in|back\s+in)\s+(?:january|february|march|april|may|june|july|"
    r"august|september|october|november|december)\s+\d{4})\b", re.I)

MONTHS = {name: index for index, name in enumerate(
    ("january", "february", "march", "april", "may", "june", "july",
     "august", "september", "october", "november", "december"), 1)}

MONTH_YEAR = re.compile(r"\b(" + "|".join(MONTHS) + r")\s+(\d{4})\b", re.I)

# A range, which needs both bounds and the range qualifier.
RANGE = re.compile(r"\b(\d[\d,]*(?:\.\d+)?)\s*(?:or|to|–|—|-)\s*(\d[\d,]*(?:\.\d+)?)\b", re.I)

# --- clause attribution ----------------------------------------------------
# One sentence can state a figure for each of two employers: "Stripe said it
# would lay off 14% of its workforce, about 1,000 people, while Lyft will cut
# nearly 700 employees, or 13% of its staff." A sentence-level attribution
# takes the first percentage for whichever company is queried, which produced
# a cross-company misattribution in the delivery audit. The figures are
# re-read from the clause that carries the employer's own action instead.
CONTRAST_CONNECTOR = re.compile(r"\b(?:while|whereas|but)\b|;", re.I)
# A comma or "and" followed by a capitalised name starts a clause about a
# different subject. Splitting on every "and" would tear apart "cut 1,000
# jobs and 500 roles"; splitting only before a capitalised name keeps the
# coordinated objects of one verb inside their clause.
COMMA_NAME_BOUNDARY = re.compile(r"(?:,\s+|\band\s+)(?P<name>[A-Z][\w&.\-]+)")

# A property reduction is not an employee reduction: "sublease part of its
# office space", "reduce its real-estate footprint". The two actions are
# recorded separately, and a square-footage figure must never stand in for a
# headcount.
REAL_ESTATE = re.compile(
    r"\b(office\s+(?:space|footprint|square\s+feet|sq\.?\s*ft|lease|leases|portfolio)|"
    r"subleas\w+|real[-\s]estate|workspace|coworking|square\s+feet\s+of\s+office|"
    r"shrink(?:ing|s)?\s+(?:its\s+)?office|reduc\w+\s+(?:its\s+)?office\s+"
    r"(?:space|footprint|by))\b", re.I)

# A mixed population states the reduction as layoffs *and* furloughs. The
# figure is a real reduction count, but its basis is the mixed population the
# source words, not permanent layoffs alone.
MIXED_POPULATION = re.compile(
    r"\blay\s+off\s+(?:or|and)\s+furlough\b|\bfurlough\s+(?:or|and)\s+lay\s+off\b"
    r"|\blayoffs?\s+and\s+furloughs?\b|\bfurloughs?\s+and\s+layoffs?\b", re.I)


def is_recap(sentence, event_year=None, event_month=None):
    """True when the sentence recounts rather than announces this event."""
    if RECAP.search(sentence):
        return True
    if event_year:
        years = set(re.findall(r"\b((?:19|20)\d{2})\b", sentence))
        if years and event_year not in years:
            # The sentence may name a different month of the same year.
            for _month, year in MONTH_YEAR.findall(sentence):
                if year == event_year:
                    years = set()
                    break
            if years:
                return True
    if event_month:
        named = {MONTHS[name.lower()] for name, _year in MONTH_YEAR.findall(sentence)
                 if name.lower() in MONTHS}
        if named and event_month not in named:
            return True
    return False


def states_range(sentence, value):
    """True when the sentence states a numeric range rather than a point."""
    for match in RANGE.finditer(sentence):
        low, high = match.group(1).replace(",", ""), match.group(2).replace(",", "")
        try:
            low, high = float(low), float(high)
        except ValueError:
            continue
        if low == high:
            continue
        if value is not None and not (low <= value <= high):
            continue
        return True
    return False


def _scale(value, suffix):
    suffix = (suffix or "").strip().lower()
    if suffix in MULT:
        return int(round(value * MULT[suffix]))
    if suffix == "b":
        return int(round(value * 1_000_000_000))
    return int(round(value))


def normalise(name):
    """Comparable form of a company or employer name."""
    return re.sub(r"[^a-z0-9]+", " ", str(name or "").lower()).strip()


def _is_own_name(token, aliases):
    """True when a capitalized token is part of this employer's own name.

    The other-employer pattern captures the last capitalized token before a
    verb, so a full corporate name ("Acme Corp said") yields "Corp". A suffix
    of a known alias is this employer, not a second company.
    """
    candidate = normalise(token)
    if not candidate:
        return False
    for alias in aliases:
        name = normalise(alias)
        if candidate == name or name.endswith(" " + candidate):
            return True
    return False


def parse_number(text, after=None):
    """Return (value, qualifier, raw) for the count belonging to this employer.

    A sentence can carry several figures: "While Google dominated 2023 with its
    astounding 12,000 job cuts, SAP laid off 8,000 of its employees". Taking the
    first count attached the wrong employer's number to the event, which is the
    single largest accuracy complaint in the delivery audit. When `after` is
    given, only counts at or after that offset are eligible, so the caller can
    pin the search to the clause that follows the employer's own mention.
    """
    candidates = [match for match in COUNT.finditer(text)
                  if after is None or match.start() >= after]
    if not candidates:
        return None, None, ""
    match = candidates[0]
    raw = match.group(1)
    suffix = match.group(2) or ""
    try:
        value = _scale(float(raw.replace(",", "")), suffix)
    except ValueError:
        return None, None, ""
    # The qualifier sits immediately before the number. The window is wide
    # enough to catch an adverb that stands between the verb and the figure.
    window = text[max(0, match.start() - 60):match.start()]
    qualifier = "exact"
    if THRESHOLD.search(window):
        qualifier = "approximately"
        if re.search(r"\b(over|more\s+than|at\s+least)\b[^\d]{0,12}$", window, re.I):
            qualifier = "more_than"
        elif re.search(r"\b(up\s+to|no\s+more\s+than)\b[^\d]{0,12}$", window, re.I):
            qualifier = "up_to"
        elif re.search(r"\b(less\s+than|fewer\s+than|under)\b[^\d]{0,12}$", window, re.I):
            qualifier = "less_than"
    return value, qualifier, match.group(0).strip()


def sentences(text):
    """Split into sentence-ish units while keeping absolute offsets.

    A period only ends a sentence when it is not part of a decimal ("6.4%"),
    an abbreviation ("Inc.", "U.S.") or an initial. Treating every period as a
    boundary used to cut "6.4% of its workforce" away from the layoff clause,
    which made the percentage unreadable for an otherwise valid sentence.
    """
    out = []
    boundary = re.compile(r"[.!?](?=\s+[A-Z\u201c\"']|\s*$)")
    position = 0
    length = len(text)
    while position < length:
        end = None
        # A newline is a boundary too: retrieved pages interleave navigation
        # and bylines with the article, and gluing them onto the first
        # sentence buries the figure inside a page of menu text.
        newline = text.find("\n", position)
        for match in boundary.finditer(text, position):
            if newline >= 0 and match.end() > newline:
                break
            candidate = match.end()
            # A decimal point or an abbreviation is not a boundary. The lookahead
            # already rejects a digit before the period, so only guard the
            # abbreviation case here.
            before = text[max(0, match.start() - 5):match.start() + 1]
            if re.search(r"(?:\b(?:Inc|Ltd|Corp|Co|vs|etc|No|St|Dr|Mr|Ms|Jr|Sr|"
                         r"Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sept|Sep|Oct|Nov|Dec|"
                         r"Mon|Tue|Wed|Thu|Fri|Sat|Sun|Ave|Blvd|Dept|Est|Fig)\.)$",
                         before, re.I):
                continue
            end = candidate
            break
        if newline >= 0 and (end is None or newline < end):
            end = newline
        if end is None:
            end = length
        seg = text[position:end]
        if len(seg.strip()) >= 15:
            out.append((position, seg))
        position = end
        while position < length and text[position] in " \n\t":
            position += 1
    return out


def company_in_sentence(sentence, aliases):
    low = sentence.lower()
    for alias in aliases:
        token = re.escape(alias.lower())
        if re.search(r"\b" + token + r"\b", low):
            return alias
    return None


def employer_is_subject(sentence, aliases):
    """True when this employer is the one performing the reduction.

    A roundup sentence that lists several employers ("across major companies
    like Microsoft, Intel, Google") names the company but attributes no action
    to it, so its figures are not this employer's event.

    The employer may appear as the grammatical subject, as the subject of a
    modal construction, in a prepositional slot ("250 layoffs at Fiverr"), or
    through a role title ("Fiverr CEO said"). Body text lower-cases the name
    in mid-sentence, so the slot patterns match case-insensitively.
    """
    names = {normalise(a) for a in aliases if a}

    def matches(candidate):
        candidate = normalise(candidate)
        if not candidate:
            return False
        for alias in names:
            if candidate == alias or candidate.startswith(alias + " ") or alias in candidate:
                return True
        return False

    for pattern in (EMPLOYER_AS_SUBJECT, EMPLOYER_AS_SUBJECT_AUX,
                    EMPLOYER_AS_SUBJECT_NOUN, EMPLOYER_ANNOUNCE_ACTION):
        for match in pattern.finditer(sentence):
            if matches(match.group("name")):
                return True
    # The employer can also be identified by the slot it occupies rather than
    # by being the grammatical subject: "500 jobs amid Fisker's woes", "250
    # layoffs at Fiverr", "Fiverr CEO said we had to downsize". These pages
    # describe the employer's own reduction, so they bind.
    for pattern in (EMPLOYER_IN_OBJECT, EMPLOYER_ROLE, EMPLOYER_WITH_NOUN):
        for match in pattern.finditer(sentence):
            if matches(match.group("name")):
                # Another employer may be the one performing the action in the
                # same sentence: "Microsoft said it would lay off 10,000
                # workers while Google announced no changes". The slot match
                # alone does not settle who acted.
                other = OTHER_EMPLOYER_ACTION.search(sentence)
                if other and not matches(other.group("other")):
                    continue
                return True
    # A lowercase mid-sentence mention followed by the employer's own action:
    # "Flywire cuts 10% of staff", "GitLab and GitHub both move to cut jobs".
    for alias in names:
        if not alias or len(alias) < 3:
            continue
        pattern = (r"\b" + re.escape(alias) + r"\b[^.]{0,40}?" + REDUCTION_VERB + r"\b")
        if re.search(pattern, sentence, re.I):
            # The employer may be the subject, or one of several subjects that
            # share the action. It is not the subject when another employer
            # performs the action in the same clause.
            other = OTHER_EMPLOYER_ACTION.search(sentence)
            if other and not matches(other.group("other")):
                continue
            return True
        # "GitLab and GitHub both move to cut jobs": the employer is one of
        # several subjects sharing one action. The verb must be a reduction
        # verb: "Google announced no changes" is not one.
        if re.search(r"\b" + re.escape(alias) + r"\b\s+(?:and\s+\w+(?:\s+\w+)?\s+)?"
                     r"(?:both\s+|all\s+|each\s+)?(?:move|plan|said|slash|cut|trim|"
                     r"reduce|eliminate|downsiz\w*)\w*\b", sentence, re.I):
            return True
    # "UiPath said it would cut 350 roles": the employer is named and the
    # action follows through a pronoun in the same sentence. The pronoun must
    # not belong to another employer named in the same sentence, which is the
    # case in "Microsoft said it would lay off 10,000 workers while Google
    # announced no changes".
    if PRONOMINAL_ACTION.search(sentence):
        # Another employer may be named in the same sentence and be the one
        # performing the action: "Microsoft said it would lay off 10,000
        # workers while Google announced no changes". The pronoun belongs to
        # that employer, not to ours.
        others = other_employers_in_sentence(sentence, names)
        if others:
            return False
        for alias in names:
            if re.search(r"\b" + re.escape(alias.lower()) + r"\b", sentence, re.I):
                return True
    return False


CAPITALISED_NAME = re.compile(r"\b[A-Z][A-Za-z&.\-]{1,28}\b")
NAME_STOPWORDS = {
    "the", "a", "an", "this", "that", "these", "those", "it", "they", "he", "she",
    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
    "january", "february", "march", "april", "may", "june", "july", "august",
    "september", "october", "november", "december", "according", "sources",
    "reuters", "bloomberg", "techcrunch", "forbes", "bbc", "cnn", "wsj",
    "new", "york", "times", "wall", "street", "journal", "post", "news",
    "read", "more", "share", "comments", "advertisement", "subscribe", "sign",
    "up", "log", "in", "home", "search", "menu", "close", "next", "previous",
    "about", "contact", "privacy", "terms", "cookies", "help", "support",
    "latest", "top", "story", "stories", "photo", "photos", "video", "videos",
    "podcast", "markets", "technology", "business", "world", "sport", "health",
    "science", "opinion", "live", "analysis", "explainer", "video", "gallery",
    # Corporate designators and role titles are part of a company name or of a
    # person's title, never a competing employer. Treating them as one blocked
    # valid binding: "Uber Technologies ... will cut" and "Twilio CEO Jeff
    # Lawson announced ... the company would cut" both failed to bind.
    "inc", "corp", "corporation", "company", "co", "ltd", "limited", "llc", "plc",
    "gmbh", "holdings", "holding", "group", "technologies", "technology",
    "systems", "solutions", "labs", "laboratories", "international", "global",
    "worldwide", "industries", "industrial", "services", "partners", "ventures",
    "capital", "studios", "networks", "platforms", "interactive", "digital",
    "software", "media", "entertainment", "analytics", "dynamics", "robotics",
    "therapeutics", "biosciences", "pharmaceuticals", "pharma", "energy",
    "motors", "airlines", "foods", "brands", "retail", "financial", "bank",
    "insurance", "health", "care", "sciences", "works", "products", "supply",
    "ceo", "cfo", "coo", "cto", "cpo", "ciso", "president", "founder",
    "co-founder", "chairman", "chairwoman", "chairperson", "spokesman",
    "spokeswoman", "spokesperson", "chief", "executive", "officer", "director",
    "head", "manager", "vp", "senior", "former", "current", "interim",
    # Person names appear next to a role title. They are not employers, and
    # counting them made a pronoun look ambiguous.
    "jeff", "mark", "elon", "satya", "andy", "sundar", "tim", "brian", "david",
    "john", "james", "michael", "robert", "daniel", "susan", "jane", "lisa",
    "lawson", "zuckerberg", "musk", "nadella", "jassy", "pichai", "cook",
    # Countries, regions and cities appear inside a sentence that reports one
    # employer's action ("Salesforce's India employees ... following the US
    # firm's announcement"). Treating a place as a competing employer left the
    # pronoun looking ambiguous and dropped a valid count.
    "india", "china", "japan", "korea", "taiwan", "singapore", "germany",
    "france", "britain", "england", "europe", "america", "canada", "australia",
    "brazil", "mexico", "israel", "ireland", "spain", "italy", "netherlands",
    "sweden", "norway", "denmark", "finland", "poland", "portugal", "uk",
    "us", "usa", "asia", "emea", "apac", "latam", "california", "texas",
    "london", "berlin", "paris", "tokyo", "seoul", "beijing", "shanghai",
    "bengaluru", "bangalore", "mumbai", "delhi", "dublin", "tel", "aviv",
    "seattle", "austin", "boston", "chicago", "denver", "atlanta", "miami",
    "toronto", "vancouver", "sydney", "melbourne", "zurich", "amsterdam",
}


def other_employers_in_sentence(sentence, our_names):
    """Capitalised names in the sentence that are not the employer we track.

    A roundup or a comparison sentence names several companies. When one of
    them performs the action and the pronoun follows, the figure belongs to
    that company.
    """
    found = set()
    ours = {normalise(name) for name in (our_names or []) if name}
    for token in CAPITALISED_NAME.finditer(sentence):
        name = token.group(0)
        key = normalise(name)
        if key in NAME_STOPWORDS or len(key) < 3:
            continue
        if any(key == n or key in n or n in key for n in ours):
            continue
        found.add(name)
    return found


def _employer_offset(sentence, aliases):
    """Offset where this employer's own clause begins inside the sentence.

    A comparison sentence names several employers and states a figure for each.
    The count that belongs to the tracked employer sits in the clause that
    starts at its own mention, so the caller anchors the number search here
    rather than at the start of the sentence.
    """
    return employer_clause_offset(sentence, aliases)


def _clause_boundaries(sentence):
    """Offsets where a clause about a different subject begins.

    Two kinds of boundary exist: an explicit contrast connector ("while",
    "whereas", "but", a semicolon), and a comma or "and" followed by a
    capitalised name, which introduces the next employer's clause. Plain "and"
    between two coordinated objects of one verb ("cut 1,000 jobs and 500
    roles") is not a boundary because no capitalised name follows.
    """
    bounds = {0}
    for match in CONTRAST_CONNECTOR.finditer(sentence):
        bounds.add(match.end())
    for match in COMMA_NAME_BOUNDARY.finditer(sentence):
        bounds.add(match.start("name"))
    return sorted(bounds)


def clause_span(sentence, position):
    """(start, end) of the clause that contains `position`."""
    bounds = _clause_boundaries(sentence)
    before = [b for b in bounds if b <= position]
    after = [b for b in bounds if b > position]
    start = max(before) if before else 0
    end = min(after) if after else len(sentence)
    return start, end


def employer_clause_offset(sentence, aliases):
    """Start of the clause that carries this employer's own action.

    The tracked employer may be named in a clause that belongs to another
    employer ("In addition to Google's cuts, Acme laid off 300") or after a
    contrast connector ("..., while Acme will cut 700"). Anchoring the figure
    search at this offset, rather than at the first mention or at offset zero,
    keeps each employer's own figure out of the other's record.
    """
    lowered = sentence.lower()
    positions = []
    for alias in aliases:
        token = normalise(alias)
        if not token:
            continue
        index = lowered.find(token)
        if index >= 0:
            positions.append(index)
    if not positions:
        return None
    # When the employer is named more than once, prefer the mention that sits
    # inside a clause with its own reduction verb: the first mention may be a
    # passing reference inside another employer's clause.
    for position in sorted(positions):
        start, end = clause_span(sentence, position)
        window = sentence[start:end]
        if REDUCE.search(window):
            return start
    position = min(positions)
    start, _end = clause_span(sentence, position)
    return start


def scoped_count(text, aliases, event_year=None):
    """Find a count that this employer is announcing in this event.

    Returns a dict with the value and its evidence, or None when no sentence
    supports a count for this employer.
    """
    for start, sentence in sentences(text):
        alias = company_in_sentence(sentence, aliases)
        if not alias:
            continue
        if not REDUCE.search(sentence):
            continue
        # A figure describing a different population is not this event's count.
        # A mixed population ("lay off or furlough 2,800") is still a reduction
        # count, but its basis records the mixture instead of permanent layoffs
        # alone, so the furlough guard does not apply to it.
        mixed = bool(MIXED_POPULATION.search(sentence))
        if not mixed and NOT_A_LAYOFF.search(sentence):
            continue
        # A sentence that denies the reduction carries no count for it.
        if NEGATED.search(sentence):
            continue
        # Industry aggregates are not one employer's event.
        if AGGREGATE.search(sentence) and not re.search(
                r"\b(?:its|their)\b[^.]{0,40}\b\d", sentence, re.I):
            continue
        before_after = BEFORE_AFTER.search(sentence)
        # A trend attribution only disqualifies the figure it introduces, not
        # the whole sentence: "cut its support team from 9,000 to 5,000 and AI
        # is now blamed for 50,000 job cuts this year" still states a valid
        # before/after reduction.
        trend = TREND_ATTRIBUTION.search(sentence)
        if trend and before_after is None:
            continue
        # A sentence that recounts an earlier round or a cumulative total does
        # not carry this event's count.
        if is_recap(sentence, event_year):
            continue
        # The employer must be the actor performing the reduction, not a name
        # listed inside a multi-company roundup.
        if not employer_is_subject(sentence, aliases):
            continue
        if before_after:
            before = int(before_after.group(1).replace(",", ""))
            after = int(before_after.group(2).replace(",", ""))
            if before > after:
                return {"value": before - after, "qualifier": "exact",
                        "raw": before_after.group(0),
                        "basis": "difference between the stated pre- and post-reduction team size",
                        "char_start": start}
        # Anchor the figure search to the clause that carries this employer's
        # own action. A comparison sentence states one figure per employer; a
        # sentence-level read hands the tracked employer whichever figure comes
        # first, regardless of whose it is.
        anchor = employer_clause_offset(sentence, aliases)
        clause_start_pos, clause_end_pos = (clause_span(sentence, anchor)
                                            if anchor is not None else (0, len(sentence)))
        clause = sentence[clause_start_pos:clause_end_pos]
        # A number introduced by another employer's verb belongs to that
        # employer, not to this one, even when this company is named nearby.
        # The pattern sees the last capitalized token before the verb, so for
        # "Acme Corp said" it reports "Corp" — a suffix of this employer's own
        # name, not another employer. Rejecting it would drop every count in a
        # sentence that names the employer by its full corporate name. When the
        # other employer acts in its own clause, the clause-anchored read below
        # already keeps its figure out of this record; only an action inside
        # this employer's own clause disqualifies the clause.
        other = OTHER_EMPLOYER_ACTION.search(sentence)
        if other and not _is_own_name(other.group("other"), aliases):
            other_start, _other_end = clause_span(sentence, other.start())
            if other_start == clause_start_pos:
                continue
        value, qualifier, raw = parse_number(clause)
        if value is None and anchor is not None:
            value, qualifier, raw = parse_number(sentence, after=anchor)
        if value is None or value < 5:
            continue
        if states_range(sentence, value):
            continue
        # A workforce total is the denominator of a percentage, not the
        # number of people removed.
        if WORKFORCE_TOTAL.search(sentence) and CUT_TARGET.search(sentence) is None:
            continue
        if REMAINING.search(sentence) and CUT_TARGET.search(sentence) is None:
            continue
        # A figure introduced by a growth verb counts hires, not cuts. The test
        # is on the clause that introduces this number, because one sentence can
        # announce cuts and hiring in turn.
        if HIRING.search(sentence):
            position = sentence.find(raw) if raw else -1
            if position > 0 and HIRING.search(sentence[max(0, position - 90):position]):
                continue
        # A property reduction states a real-estate figure, not a headcount;
        # the two actions are recorded separately. The clause is skipped only
        # when the reduction it describes is property-shaped and names no
        # workforce unit at all: an article that mentions a sublease while
        # reporting a genuine headcount must keep the headcount.
        basis = "role count stated in the report"
        workforce_word = re.search(
            r"\b(employees?|workers?|staff|jobs|roles|positions|workforce|"
            r"headcount|people)\b", clause, re.I)
        if mixed:
            basis = ("mixed population: the source words the figure as layoffs "
                     "and furloughs together, so it is not a permanent-layoff-only count")
        elif not workforce_word and (REAL_ESTATE.search(clause)
                                     or (REAL_ESTATE.search(sentence)
                                         and REDUCE.search(clause))):
            continue
        return {"value": value, "qualifier": qualifier, "raw": raw,
                "basis": basis, "char_start": start}
    return None


def scoped_percentage(text, aliases, event_year=None, after_start=None):
    """Find a workforce percentage that this employer announced.

    `after_start` restricts the search to sentences at or after that offset,
    which lets a caller read the percentage from the same sentence that
    carries the headcount.

    Within a sentence the share is read from the clause that carries this
    employer's own action. A comparison sentence that states one share per
    employer ("Stripe said it would lay off 14% of its workforce, about 1,000
    people, while Lyft will cut nearly 700 employees, or 13% of its staff")
    must give each employer its own figure; a sentence-level first match
    recorded the first company's share for the second.
    """
    for start, sentence in sentences(text):
        if after_start is not None and start < after_start:
            continue
        alias = company_in_sentence(sentence, aliases)
        if not alias:
            continue
        if not (REDUCE.search(sentence) or "workforce" in sentence.lower()):
            continue
        if AGGREGATE.search(sentence):
            continue
        if is_recap(sentence, event_year):
            continue
        anchor = employer_clause_offset(sentence, aliases)
        clause_start_pos, clause_end_pos = (clause_span(sentence, anchor)
                                            if anchor is not None else (0, len(sentence)))
        clause = sentence[clause_start_pos:clause_end_pos]
        # A property reduction names a real-estate share ("reduce its office
        # space by 70%"), not a workforce share; the two are recorded
        # separately.
        if REAL_ESTATE.search(clause) and not re.search(
                r"\b(employees?|workers?|staff|jobs|roles|positions|workforce|"
                r"headcount|people)\b", clause, re.I):
            continue
        match = PCT.search(clause)
        if not match:
            continue
        # A stated range is two bounds, not a point: "between 25% and 30% of
        # its workforce". The denominator follows the second figure, so the
        # range must be resolved before the "of ..." clause is read.
        spread = re.match(r"\s*(?:%|per\s?cent)?\s*(?:and|to|–|—|-)\s*"
                          r"(\d{1,3}(?:\.\d+)?)\s*(?:%|per\s?cent)",
                          clause[match.end():match.end() + 40], re.I)
        denominator = ""
        if spread:
            after_upper = clause[match.end() + spread.end():match.end() + spread.end() + 60]
            den = re.match(r"\s*of\s+(?P<den>[^.;,]{3,50})", after_upper, re.I)
            if den:
                denominator = "of " + den.group("den").strip()
            lower = float(match.group(1))
            upper = float(spread.group(1))
            if denominator and lower <= upper:
                return {"value": None, "qualifier": "range", "lower": lower,
                        "upper": upper, "denominator": denominator,
                        "char_start": start}
            continue
        tail = clause[match.end():match.end() + 60]
        den = re.match(r"\s*of\s+(?P<den>[^.;,]{3,50})", tail, re.I)
        if den:
            denominator = "of " + den.group("den").strip()
        # A share expressed against a workforce named before the figure:
        # "reduce its headcount by 6%". The denominator is the workforce the
        # sentence already mentions, not an "of ..." clause.
        if not denominator:
            head = clause[max(0, match.start() - 60):match.start()]
            if re.search(r"\b(?:headcount|workforce|staff|team|employees)\b", head, re.I) \
                    and re.search(r"\bby\s*$", head, re.I):
                denominator = "of workforce"
        if not denominator:
            continue
        window = clause[max(0, match.start() - 40):match.start()]
        qualifier = "exact"
        if THRESHOLD.search(window):
            qualifier = "approximately"
        return {"value": float(match.group(1)), "qualifier": qualifier,
                "denominator": denominator, "char_start": start}
    return None


def plausibility(value, firm_size=None, share=None):
    """Reject a count that cannot describe one employer in one event.

    `share` is the announced percentage when known; a count and a percentage
    of the same workforce must agree within a wide tolerance or one of them is
    wrong. A count is also implausible when it would remove an implausible
    share of a known workforce, even when it stays under the absolute total:
    cutting 50,000 of 76,000 employees is an order of magnitude larger than
    any real single-company layoff round.
    """
    if value is None:
        return True, ""
    if value > 2_000_000:
        return False, "the figure exceeds any plausible single-employer event"
    if firm_size and value > firm_size:
        return False, (f"the figure {value} exceeds the event-time firm size {firm_size}; "
                       "it is more likely a workforce total or an industry aggregate")
    if firm_size and value >= 1_000:
        removed_share = value / float(firm_size) * 100.0
        if removed_share > 45:
            return False, (f"the figure {value} would remove {removed_share:.0f}% of the "
                           f"event-time workforce of {firm_size}; that is far beyond any "
                           "single announced reduction round and is more likely an "
                           "aggregate or a year-to-date total")
    if firm_size and share is not None:
        implied = firm_size * share / 100.0
        if implied and value > implied * 3 and value > 1000:
            return False, (f"the count {value} is more than three times the share implied by "
                           f"{share}% of {firm_size}; the two statements do not describe "
                           "the same event")
    return True, ""


# --- event-date statements ---------------------------------------------------
FULL_DATE = re.compile(
    r"\b(" + "|".join(MONTHS) + r")\s+(\d{1,2})(?:st|nd|rd|th)?\s*,?\s*((?:19|20)\d{2})\b",
    re.I)
DAY_FIRST_DATE = re.compile(
    r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(" + "|".join(MONTHS) + r")\s+((?:19|20)\d{2})\b", re.I)
ABBR_MONTH_DATE = re.compile(
    r"\b(jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)\.?\s+(\d{1,2})(?:st|nd|rd|th)?"
    r"\s*,?\s*((?:19|20)\d{2})\b", re.I)
MONTH_ABBR = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
              "jul": 7, "aug": 8, "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12}
# A fuzzy month statement supports month precision only: "in mid-April",
# "late 2020", "earlier this month".
FUZZY_MONTH = re.compile(
    r"\b((?:early|mid|late)[- ])?(" + "|".join(MONTHS) + r")\b(?!.\s*\d{1,2})", re.I)
RELATIVE_DATE = re.compile(
    r"\b(this\s+week|last\s+week|this\s+month|last\s+month|earlier\s+this\s+week|"
    r"on\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)|"
    r"(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday))\b", re.I)


def _date_precision_and_value(sentence):
    """(precision, 'YYYY-MM-DD' or 'YYYY-MM') for a date in a sentence."""
    for pattern, order in ((FULL_DATE, "mdy"), (DAY_FIRST_DATE, "dmy")):
        match = pattern.search(sentence)
        if not match:
            continue
        if order == "mdy":
            month_name, day, year = match.group(1).lower(), int(match.group(2)), match.group(3)
        else:
            day, month_name, year = int(match.group(1)), match.group(2).lower(), match.group(3)
        month = MONTHS.get(month_name)
        if month and 1 <= day <= 31:
            return "day", f"{year}-{month:02d}-{day:02d}"
    match = ABBR_MONTH_DATE.search(sentence)
    if match:
        month = MONTH_ABBR.get(match.group(1).lower().rstrip("."))
        day, year = int(match.group(2)), match.group(3)
        if month and 1 <= day <= 31:
            return "day", f"{year}-{month:02d}-{day:02d}"
    match = MONTH_YEAR.search(sentence)
    if match:
        month = MONTHS[match.group(1).lower()]
        return "month", f"{match.group(2)}-{month:02d}"
    match = FUZZY_MONTH.search(sentence)
    if match:
        month = MONTHS[match.group(2).lower()]
        # "may" the modal verb is not the month; without an early/mid/late
        # qualifier the bare word carries no date statement.
        if month == 5 and not match.group(1):
            return None, None
        return "month", month
    return None, None


def event_date_support(text, aliases):
    """The sentence that states when this employer's announcement happened.

    Returns a dict with the supported precision ("day" or "month"), the date
    the statement supports ("YYYY-MM-DD" for day precision), the offset of the
    sentence in the text and the sentence itself, or None when no applicable
    sentence states a date. A relative statement ("on Monday", "this week")
    is reported as precision "relative" so the caller can anchor it on the
    document's publication date instead of inventing a day.
    """
    for start, sentence in sentences(text):
        if not (aliases and company_in_sentence(sentence, aliases)):
            continue
        if not REDUCE.search(sentence):
            continue
        precision, value = _date_precision_and_value(sentence)
        if precision:
            return {"precision": precision, "date": value,
                    "char_start": start, "sentence": sentence}
        if RELATIVE_DATE.search(sentence):
            return {"precision": "relative", "date": None,
                    "char_start": start, "sentence": sentence}
    return None


def retrospective_event_mentions(text, aliases=None):
    """Itemised event mentions inside a retrospective report.

    A follow-up article recaps earlier rounds ("after cutting 700 people in
    the first quarter, the company is now shrinking its offices"). Each recap
    mention is a separate item with its own figures and its own stated time;
    folding them into one event, or promoting a recap mention to an event date
    on the strength of the article's publication date alone, produced phantom
    announcements in the delivery audit. Every mention carries `recap: true`
    so a caller can only turn it into an event after independent
    corroboration.
    """
    mentions = []
    for start, sentence in sentences(text):
        if not REDUCE.search(sentence):
            continue
        if not is_recap(sentence) and not RECAP.search(sentence):
            # A recap item may also be flagged by its own retrospective verbs.
            if not re.search(r"\b(had\s+(?:cut|laid|announced)|previously|"
                             r"in\s+the\s+first\s+(?:quarter|half)|q[1-4]\b)", sentence, re.I):
                continue
        if aliases and not company_in_sentence(sentence, aliases):
            continue
        precision, value = _date_precision_and_value(sentence)
        mention = {"char_start": start, "sentence": sentence.strip(),
                   "recap": True, "date_precision": precision}
        if precision == "day":
            mention["date"] = value
        elif precision == "month":
            mention["month"] = value if isinstance(value, str) else f"month-{value:02d}"
        elif RELATIVE_DATE.search(sentence):
            mention["relative_date"] = True
        count_match = COUNT.search(sentence)
        if count_match:
            raw = count_match.group(1)
            try:
                mention["count"] = _scale(float(raw.replace(",", "")),
                                          count_match.group(2) or "")
                mention["count_raw"] = count_match.group(0).strip()
            except ValueError:
                pass
        pct_match = PCT.search(sentence)
        if pct_match:
            mention["percentage"] = float(pct_match.group(1))
        mentions.append(mention)
    return mentions
