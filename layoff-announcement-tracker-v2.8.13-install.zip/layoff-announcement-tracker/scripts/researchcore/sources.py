"""Immutable source snapshots and incremental text delivery, without semantic extraction.

Document content is data. This module never executes instructions found in a source.
"""
from __future__ import annotations

import collections
import csv
import hashlib
import io
import json
import os
import re
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlparse, urlsplit, urlunsplit

MAX_BYTES = 25 * 1024 * 1024
RETRY_STATUSES = {429, 500, 502, 503, 504}
PERMANENT_CLASSES = {"http_404", "http_410", "unsupported_format", "too_large"}
# A configuration failure (for example a missing SEC_USER_AGENT) is fixed by the
# operator, not by waiting. It is never treated as permanent, never backed off,
# and is always retried on the next sync.
CONFIG_CLASSES = {"sec_user_agent"}
# Structural toolbar markers and the two specific donation-banner phrases. The
# bare words "Wayback Machine" and "_wm." were dropped: a legitimate raw capture
# can mention the Wayback Machine, and failing it loses a real source.
WAYBACK_WRAPPER_MARKERS = (
    "wm-ipp",
    "web-static.archive.org",
    "Keep the news in the Wayback Machine",
    "Please Don't Scroll Past This",
    "BEGIN WAYBACK TOOLBAR",
    "bundle-playback.js",
)
_WAYBACK_WEB = re.compile(
    r"^(https?://(?:www\.)?web\.archive\.org/web/)(\d{4,14})([a-z]{0,3}_?)?(/.*)$",
    re.I,
)
_HTTP_CLASS = re.compile(r"\b(\d{3})\s+(?:Client|Server)\s+Error", re.I)
ALLOWED_TYPES = {
    "company_announcement", "sec_filing", "exchange_filing", "news",
    "layoffs_fyi", "company_profile", "company_annual_report", "warn", "company_registry", "company_disclosure",
}
ALLOWED_ROLES = {
    "annual_report", "annual_financials", "company_report", "layoff_announcement", "event_filing",
    "news_report", "tracker_record", "official_disclosure", "financial_statements",
    "company_profile", "company_registry", "proxy", "compensation_report",
}
OPTIONAL_FIELDS = (
    "source_url", "local_path", "document_role", "fy", "plan_id",
    "publication_date", "source_date", "exchange", "form", "target_fy_basis", "target_fy_status", "accession", "period",
)


class SourceFetchError(ValueError):
    def __init__(self, message, status=None, error_class=None):
        super().__init__(message)
        self.status = status
        self.error_class = error_class


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _slug(source_id: str) -> str:
    stem = re.sub(r"[^A-Za-z0-9_-]", "_", source_id)[:60] or "source"
    return stem + "-" + _sha(source_id.encode())[:12]


def _load_manifest(path: Path) -> tuple[list[dict], str]:
    raw = path.read_bytes()
    text = raw.decode("utf-8-sig")
    if path.suffix.lower() == ".csv":
        csv.field_size_limit(max(csv.field_size_limit(), 2**31 - 1))
        rows = list(csv.DictReader(io.StringIO(text)))
    elif text.lstrip().startswith("["):
        rows = json.loads(text)
    else:
        rows = [json.loads(line) for line in text.splitlines() if line.strip()]
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Source manifest must contain objects")
    return rows, _sha(raw)


def _roster(work: Path) -> set[str]:
    config = json.loads((work / "config.json").read_text(encoding="utf-8"))
    roster = config.get("roster")
    if not isinstance(roster, list):
        raise ValueError("config.json must contain roster list")
    ids = [str(row.get("company_id", "")) if isinstance(row, dict) else str(row) for row in roster]
    if any(not value for value in ids) or len(ids) != len(set(ids)):
        raise ValueError("Roster contains empty or duplicate company_id")
    return set(ids)


def _validate(rows: list[dict], company_ids: set[str]) -> list[dict]:
    seen = set()
    result = []
    for index, raw in enumerate(rows, 1):
        row = dict(raw)
        for field in ("source_id", "company_id", "source_type"):
            if not isinstance(row.get(field), str) or not row[field].strip():
                raise ValueError(f"Source row {index}: {field} required as text")
            row[field] = row[field].strip()
        if row["source_id"] in seen:
            raise ValueError("Duplicate source_id: " + row["source_id"])
        seen.add(row["source_id"])
        if row["company_id"] not in company_ids:
            raise ValueError("Unknown company_id: " + row["company_id"])
        if row["source_type"] not in ALLOWED_TYPES:
            raise ValueError("Unsupported source_type: " + row["source_type"])
        role = str(row.get("document_role") or "").strip()
        if role and role not in ALLOWED_ROLES:
            raise ValueError("Unsupported document_role: " + role + "; use one of " + ", ".join(sorted(ALLOWED_ROLES)))
        for field in OPTIONAL_FIELDS:
            row.setdefault(field, "")
        if row["fy"] not in (None, ""):
            try:
                value = int(row["fy"])
            except (ValueError, TypeError) as exc:
                raise ValueError(f"Source row {index}: fy must be an integer") from exc
            if isinstance(row["fy"], float) and row["fy"] != value:
                raise ValueError(f"Source row {index}: fy must be an integer")
            row["fy"] = value
        else:
            row["fy"] = None
        if not row.get("source_url") and not row.get("local_path"):
            # Keep the registered task: absent locations become a failed row in ingest.
            row["local_path"] = ""
        result.append(row)
    return result


def read_sources(work: Path) -> dict[str, dict]:
    path = Path(work) / "sources.json"
    if not path.is_file():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("sources", []) if isinstance(payload, dict) else payload
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Invalid sources ledger")
    if len({row["source_id"] for row in rows}) != len(rows):
        raise ValueError("Duplicate source identity in ledger")
    return {row["source_id"]: row for row in rows}


def _bound_path(work: Path, relative: str) -> Path:
    path = (work / relative).resolve()
    if not path.is_relative_to(work.resolve()):
        raise ValueError("Snapshot path escapes workspace")
    return path


def text_for(work: Path, entry: dict) -> str:
    """Deliver exact normalized text only after raw and text integrity checks.

    The raw snapshot and the normalized text are both verified against the
    hashes recorded when the source was ingested. When the raw snapshot is
    gone but the normalized text still matches its recorded hash, the text is
    delivered and the source is marked as snapshot-missing, so a workspace that
    was archived or partially cleaned reports that specific gap instead of
    failing every read. A source whose raw snapshot still exists must still
    match its hash; a changed raw snapshot is an integrity error.
    """
    work = Path(work)
    if entry.get("status") != "ready":
        raise ValueError("Source text is not ready: " + str(entry.get("status")))
    raw_path = _bound_path(work, entry["raw_path"])
    text_path = _bound_path(work, entry["text_path"])
    text_raw = text_path.read_bytes()
    if _sha(text_raw) != entry["text_sha256"]:
        raise ValueError("Normalized source text changed: " + entry["source_id"])
    if raw_path.is_file():
        raw = raw_path.read_bytes()
        if _sha(raw) != entry["content_sha256"]:
            raise ValueError("Raw source changed: " + entry["source_id"])
    else:
        # The normalized text is intact; the raw snapshot is not available.
        entry["snapshot_missing"] = True
    return text_raw.decode("utf-8")


def _wayback_identity_url(url: str) -> str:
    """Insert the Wayback id_ modifier so the raw capture is fetched, not the toolbar wrapper.

    The manifest source_url is left unchanged by the caller. Existing modifiers
    (id_, js_, cs_, im_, if_, and similar) are not rewritten.
    """
    match = _WAYBACK_WEB.match(url or "")
    if not match:
        return url
    prefix, stamp, modifier, rest = match.groups()
    if modifier:
        return url
    return f"{prefix}{stamp}id_{rest}"


def _is_wayback_url(url: str) -> bool:
    host = (urlparse(url or "").hostname or "").lower()
    return host == "web.archive.org" or host.endswith(".web.archive.org")


def _is_wayback_wrapper(raw: bytes) -> bool:
    text = raw[:200_000].decode("utf-8", "replace")
    lowered = text.lower()
    return any(marker.lower() in lowered for marker in WAYBACK_WRAPPER_MARKERS)


def _classify_message(message: str) -> str:
    text = message or ""
    if "exceeds 25 MiB" in text:
        return "too_large"
    if text.startswith("Unsupported source format") or "Unsupported source format:" in text:
        return "unsupported_format"
    if "no extractable text" in text:
        return "no_text"
    if "SEC_USER_AGENT" in text:
        return "sec_user_agent"
    if "wrapper/banner page" in text or "wayback_wrapper" in text:
        return "wayback_wrapper"
    lowered = text.lower()
    if "timed out" in lowered or "timeout" in lowered or "read timed out" in lowered:
        return "timeout"
    if "ssl" in lowered or "certificate" in lowered:
        return "ssl"
    if "failed to resolve" in lowered or "nameresolutionerror" in lowered or "connection" in lowered or "max retries" in lowered:
        return "connection"
    match = _HTTP_CLASS.search(text) or re.search(r"\bhttp[_\s-]?(\d{3})\b", text, re.I)
    if match:
        return "http_" + match.group(1)
    return "request"


def _error_class(exc: BaseException) -> str:
    if isinstance(exc, SourceFetchError) and exc.error_class:
        return exc.error_class
    if isinstance(exc, SourceFetchError) and exc.status:
        return f"http_{exc.status}"
    return _classify_message(str(exc))


def _parse_when(value) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        stamp = datetime.fromisoformat(text)
    except ValueError:
        return None
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezone.utc)
    return stamp


def _backoff_seconds(failure_count: int) -> int:
    return min(3600 * 2 ** max(int(failure_count) - 1, 0), 86400)


def _skip_failed(prior: dict, row: dict, row_sha: str, refresh: bool, retry_failed: bool) -> bool:
    """Reuse a recorded failure when a retry would not change the outcome yet."""
    if refresh or retry_failed or not prior or prior.get("status") != "failed":
        return False
    if prior.get("source_url") != row.get("source_url"):
        return False
    if prior.get("row_sha256") and prior.get("row_sha256") != row_sha:
        return False
    error_class = prior.get("error_class") or _classify_message(str(prior.get("error") or ""))
    if error_class in CONFIG_CLASSES or _classify_message(str(prior.get("error") or "")) in CONFIG_CLASSES:
        return False
    if error_class in PERMANENT_CLASSES:
        return True
    last = _parse_when(prior.get("last_attempt") or prior.get("checked_at"))
    if last is None:
        return False
    count = int(prior.get("failure_count") or 1)
    now = datetime.now(timezone.utc)
    from datetime import timedelta
    return now < last + timedelta(seconds=_backoff_seconds(count))


def _request_body(url: str, headers: dict) -> tuple[bytes, str, str]:
    """Fetch one URL, retrying only transient transport and 429/5xx responses.

    The final address is returned as well: a publisher redirect is the alias
    that the document cache records, so the same article is never downloaded
    twice under two addresses.
    """
    import requests
    last = None
    for attempt in range(3):
        try:
            with requests.get(url, headers=headers, timeout=30, stream=True) as response:
                if response.status_code in RETRY_STATUSES and attempt < 2:
                    time.sleep(0.5 * (attempt + 1))
                    continue
                if response.status_code >= 400:
                    kind = "Client Error" if response.status_code < 500 else "Server Error"
                    reason = (getattr(response, "reason", None) or "").strip() or "Error"
                    final = getattr(response, "url", None) or url
                    raise SourceFetchError(
                        f"Source request failed: {response.status_code} {kind}: {reason} for url: {final}",
                        status=response.status_code,
                        error_class=f"http_{response.status_code}",
                    )
                chunks = []; size = 0
                for chunk in response.iter_content(65536):
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise ValueError("Source exceeds 25 MiB snapshot limit")
                    chunks.append(chunk)
                return (b"".join(chunks),
                        response.headers.get("Content-Type", "").split(";", 1)[0].lower(),
                        str(getattr(response, "url", None) or url))
        except SourceFetchError:
            raise
        except requests.RequestException as exc:
            last = exc
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    raise SourceFetchError("Source request failed: " + str(last), error_class=_classify_message(str(last)))


# --- bounded DNS resolution ------------------------------------------------
# macOS getaddrinfo can block for minutes or indefinitely, and the requests
# timeout does not cover it. Resolution therefore runs in a daemon thread with
# a deadline and a bounded number of concurrent lookups: a hung resolver costs
# one thread, and every later request to the same host fails fast instead of
# starting another. A name that does not resolve at all is left to the HTTP
# client, which reports its own connection error.
_DNS_SLOTS = threading.BoundedSemaphore(8)
_DNS_RESOLVED: set[str] = set()
_DNS_BLOCKED: set[str] = set()
_DNS_HOSTS_LOCK = threading.Lock()


def _dns_guard_enabled() -> bool:
    return os.environ.get("LAYOFF_DNS_GUARD", "1") != "0"


def _resolve_guard(url: str, timeout: float = 10.0) -> None:
    if not _dns_guard_enabled():
        return
    host = (urlparse(url or "").hostname or "").lower()
    if not host:
        return
    with _DNS_HOSTS_LOCK:
        if host in _DNS_RESOLVED:
            return
        if host in _DNS_BLOCKED:
            raise SourceFetchError("DNS resolution already timed out for " + host,
                                   error_class="dns_timeout")
    if not _DNS_SLOTS.acquire(blocking=False):
        raise SourceFetchError("DNS resolution capacity is exhausted; retry later",
                               error_class="dns_saturated")
    holder: dict = {}

    def _work() -> None:
        try:
            holder["value"] = socket.getaddrinfo(host, None)
        except BaseException as exc:  # noqa: BLE001 - reported through holder
            holder["error"] = exc

    try:
        thread = threading.Thread(target=_work, name="dns-guard", daemon=True)
        thread.start()
        thread.join(timeout)
        if thread.is_alive():
            with _DNS_HOSTS_LOCK:
                _DNS_BLOCKED.add(host)
            raise SourceFetchError(
                "DNS resolution did not finish within %.0fs for %s" % (timeout, host),
                error_class="dns_timeout")
    finally:
        _DNS_SLOTS.release()
    if "value" in holder:
        with _DNS_HOSTS_LOCK:
            _DNS_RESOLVED.add(host)
    elif isinstance(holder.get("error"), socket.gaierror):
        return  # let the HTTP client report the connection failure
    else:
        raise SourceFetchError("DNS resolution failed for " + host,
                               error_class="connection")


def _download(url: str) -> tuple[bytes, str, str]:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("Only explicit http/https source URLs may be fetched")
    headers = {"User-Agent": "LayoffResearchSkills/1.6.0", "Accept": "text/html,application/pdf,text/plain"}
    hostname = (parsed.hostname or "").lower()
    if hostname == "sec.gov" or hostname.endswith(".sec.gov"):
        agent = os.environ.get("SEC_USER_AGENT", "")
        if not agent or "@" not in agent or not agent.isascii():
            raise ValueError("SEC_USER_AGENT must contain an actual ASCII contact and email")
        headers["User-Agent"] = agent
    fetch_url = _wayback_identity_url(url)
    _resolve_guard(fetch_url)
    raw, mime, final = _request_body(fetch_url, headers)
    if _is_wayback_url(fetch_url) and _is_wayback_wrapper(raw):
        time.sleep(0.5)
        raw, mime, final = _request_body(fetch_url, headers)
        if _is_wayback_wrapper(raw):
            raise SourceFetchError(
                "Wayback returned a wrapper/banner page instead of the raw capture",
                error_class="wayback_wrapper",
            )
    return raw, mime, final


# --- document identity and reuse -------------------------------------------
# The same article is routinely returned for several queries, several years and
# even several companies. A source is a (document, company) relation, not a
# copy of the page: the page is downloaded, normalized and hashed once, and each
# relation points at the same immutable snapshot.
TRACKING_PARAMETERS = {
    "gclid", "dclid", "fbclid", "msclkid", "yclid", "igshid", "mc_cid", "mc_eid",
    "ref", "ref_src", "referrer", "source", "cmpid", "ncid", "smid", "sr_share",
    "mkt_tok", "spm", "share", "utm_source", "utm_medium", "utm_campaign",
    "utm_term", "utm_content", "utm_id", "utm_name", "utm_reader",
}


def _normalize_url(url: str) -> str:
    """Conservative document identity.

    Only the fragment and known tracking parameters are dropped. Query
    parameters that can select content (id, page, article, date) are kept, so
    two genuinely different pages never collapse into one snapshot.
    """
    text = (url or "").strip()
    if not text:
        return ""
    parts = urlsplit(text)
    query = [(key, value) for key, value in parse_qsl(parts.query, keep_blank_values=True)
             if key.lower() not in TRACKING_PARAMETERS]
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path or "/",
                       urlencode(query), ""))


def _documents_path(work: Path) -> Path:
    return Path(work) / "qa" / "document-index.json"


def _read_documents(work: Path) -> dict:
    path = _documents_path(work)
    if not path.is_file():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    return payload.get("documents", {}) if isinstance(payload, dict) else {}


def _write_documents(work: Path, documents: dict) -> None:
    _write_json(_documents_path(work), {"version": "1.0.0", "documents": documents})


def _verified_snapshot(work: Path, entry: dict) -> bool:
    """True only when the recorded snapshot still matches its hashes."""
    try:
        raw_path = _bound_path(work, entry["raw_path"])
        text_path = _bound_path(work, entry["text_path"])
        if not raw_path.is_file() or not text_path.is_file():
            return False
        if _sha(text_path.read_bytes()) != entry.get("text_sha256"):
            return False
        return _sha(raw_path.read_bytes()) == entry.get("content_sha256")
    except (KeyError, ValueError, OSError):
        return False


SNAPSHOT_EVERY = 25
JOURNAL_NAME = "qa/ingest-journal.jsonl"


def _journal_path(work: Path) -> Path:
    return Path(work) / JOURNAL_NAME


def replay_journal(work: Path) -> dict[str, dict]:
    """Completed source records written before an interruption.

    A torn final line is the only record ignored: every earlier line was
    flushed to disk after its source was committed. The latest record for a
    source wins.
    """
    path = _journal_path(work)
    if not path.is_file():
        return {}
    done: dict[str, dict] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if isinstance(record, dict) and record.get("source_id"):
            done[record["source_id"]] = record
    return done


def _append_journal(work: Path, entry: dict) -> None:
    path = _journal_path(work)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def _compact_journal(work: Path, entries: dict[str, dict]) -> None:
    """Keep the recovery log bounded by rewriting one record per source."""
    path = _journal_path(work)
    if not path.is_file():
        return
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        for source_id in sorted(entries):
            handle.write(json.dumps(entries[source_id], ensure_ascii=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


class _DomainLimiter:
    """One request at a time per host, with a minimum interval between them."""

    def __init__(self, min_interval: float = 0.0):
        self.min_interval = max(0.0, float(min_interval))
        self._guard = threading.Lock()
        self._locks: dict[str, threading.Lock] = {}
        self._last: dict[str, float] = {}

    def _lock(self, key: str) -> threading.Lock:
        with self._guard:
            return self._locks.setdefault(key, threading.Lock())

    def wait(self, url: str) -> None:
        host = (urlparse(url or "").hostname or "").lower()
        lock = self._lock(host)
        lock.acquire()
        try:
            previous = self._last.get(host)
            if previous is not None and self.min_interval:
                delay = self.min_interval - (time.time() - previous)
                if delay > 0:
                    time.sleep(delay)
        finally:
            # The lock is released by the caller once the request finishes, so
            # the interval is measured from the end of the previous request.
            pass
        self._last[host] = time.time()

    def release(self, url: str) -> None:
        host = (urlparse(url or "").hostname or "").lower()
        self._lock(host).release()


def _suffix_for(url: str) -> str:
    return Path(urlparse(url or "").path).suffix.lower()


def configuration_gaps(work):
    """A persistent, visible record of every source blocked by configuration.

    A missing operator credential (SEC_USER_AGENT is the recurring case) used
    to delete the affected sources from the round: the plan lost the issuer
    filings it was entitled to, and nothing in the workspace said so. A
    configuration failure is not an absence of sources and not an exclusion —
    the row stays active, stays retryable, and is reported here until the
    operator fixes the configuration. The report is written to
    ``review/configuration-gaps.json`` so a run that never fetched its SEC
    sources is visible in the delivery review rather than silent.
    """
    work = Path(work)
    ledger_path = work / "sources.json"
    if not ledger_path.is_file():
        return []
    try:
        ledger = (json.loads(ledger_path.read_text(encoding="utf-8"))
                  or {}).get("sources", [])
    except (OSError, ValueError):
        return []
    gaps = []
    for source in ledger:
        if source.get("error_class") not in CONFIG_CLASSES:
            continue
        gaps.append({
            "source_id": source.get("source_id"),
            "company_id": source.get("company_id"),
            "plan_id": source.get("plan_id") or "",
            "source_url": source.get("source_url"),
            "document_role": source.get("document_role"),
            "status": "configuration_missing",
            "error_class": source.get("error_class"),
            "error": source.get("error"),
            "followup": ("supply the operator configuration this source needs "
                         "and re-sync; the source is never dropped from the plan"),
        })
    if gaps:
        report = work / "review/configuration-gaps.json"
        report.parent.mkdir(parents=True, exist_ok=True)
        report.write_text(json.dumps(
            {"gaps": gaps, "count": len(gaps),
             "boundary": "A configuration-missing source is not an exclusion and "
                         "not an absence; it stays active and retryable.",
             "checked_at": _now()}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8")
    return gaps


def _normalize(raw: bytes, suffix: str, mime: str) -> tuple[str, list[dict], list[int], str]:
    if raw.startswith(b"%PDF") or suffix == ".pdf" or mime == "application/pdf":
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(raw)); parts = []; pages = []; visual = []; offset = 0
        for number, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ""
            if not text.strip() and len(page.images):
                visual.append(number)
            if parts:
                parts.append("\n\n"); offset += 2
            pages.append({"page": number, "start": offset, "end": offset + len(text)})
            parts.append(text); offset += len(text)
        text = "".join(parts)
        state = "requires_visual_review" if visual or not text.strip() else "ready"
        return text, pages, visual, state
    if suffix in {".htm", ".html"} or mime == "text/html" or raw.lstrip()[:100].lower().startswith((b"<!doctype html", b"<html")):
        from bs4 import BeautifulSoup, NavigableString, Tag
        soup = BeautifulSoup(raw, "html.parser")
        for node in soup(["script", "style", "noscript"]):
            node.decompose()
        # Paragraph boundaries and inline tags are kept apart. Joining every
        # element with a newline used to tear an inline link apart: a sentence
        # like "will lay off <a>2,800</a> people" came back as three
        # line-broken fragments, the clause splitter then separated the
        # employer from its own figure, and the evidence offsets no longer
        # mapped onto a readable sentence. Text nodes are concatenated as the
        # markup contains them (whitespace between inline elements is source
        # whitespace, not a boundary); only block elements introduce a
        # paragraph break, and <br> becomes a single line break.
        for br in soup.find_all("br"):
            br.replace_with("\n")
        block_tags = {"p", "div", "section", "article", "header", "footer", "nav",
                      "aside", "main", "h1", "h2", "h3", "h4", "h5", "h6",
                      "li", "tr", "table", "ul", "ol", "dl", "dt", "dd",
                      "blockquote", "pre", "figure", "figcaption", "hr", "form",
                      "select", "option", "tbody", "thead", "td", "th"}
        parts: list[str] = []

        def _walk(node):
            for child in getattr(node, "children", []):
                if isinstance(child, NavigableString):
                    parts.append(str(child))
                elif isinstance(child, Tag):
                    if child.name in block_tags:
                        parts.append("\n\n")
                        _walk(child)
                        parts.append("\n\n")
                    else:
                        _walk(child)

        _walk(soup)
        text = "".join(parts)
        text = re.sub(r"[ \t\r\f\v]+", " ", text)
        text = re.sub(r" ?\n ?", "\n", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip(), [], [], "ready"
    if suffix in {".txt", ".md", ".csv"} or mime.startswith("text/"):
        return raw.decode("utf-8-sig"), [], [], "ready"
    if suffix in {".jpg", ".jpeg", ".png", ".tif", ".tiff"} or mime.startswith("image/"):
        return "", [], [1], "requires_visual_review"
    raise ValueError("Unsupported source format: " + (suffix or mime or "unknown"))


def _base_entry(row: dict, prior: dict, manifest_sha: str, row_sha: str) -> dict:
    """The manifest row plus the bookkeeping the ledger keeps across rounds.

    The manifest is authoritative for the sources it lists, including an empty
    plan_id: a repair that deliberately clears a retired binding must be able to
    do so. Sources the manifest does not list are preserved wholesale (see
    `ingest`), which is where an incremental round keeps older bindings.
    """
    return {**row, "active": True, "manifest_sha256": manifest_sha,
            "row_sha256": row_sha, "checked_at": _now(), "from_cache": False}


def _failed_entry(current: dict, prior: dict, error: BaseException) -> dict:
    current.update(
        status="failed",
        error=str(error),
        error_class=_error_class(error),
        failure_count=int(prior.get("failure_count") or 0) + 1,
        last_attempt=_now(),
        acquired_at=None,
    )
    if prior:
        current["previous_version"] = {k: prior[k] for k in
                                       ["content_sha256", "text_sha256", "raw_path",
                                        "text_path", "acquired_at"] if k in prior}
    return current


def _fetch_payload(row: dict) -> dict:
    """Download and normalize one declared URL; no workspace writes here.

    Network and parsing run in worker threads and return a payload. The main
    thread is the only writer of the ledger, the journal and the snapshots, so
    a worker can never leave a half-committed source behind.
    """
    if not row.get("source_url"):
        raise ValueError("Neither local_path nor source_url provided")
    if row.get("_offline"):
        raise ValueError("Offline source has no usable current snapshot")
    raw, mime, final_url = _download(row["source_url"])
    if len(raw) > MAX_BYTES:
        raise ValueError("Source exceeds 25 MiB snapshot limit")
    suffix = row.get("_suffix") or _suffix_for(row["source_url"])
    text, pages, visual, state = _normalize(raw, suffix, mime)
    if state == "ready" and not text.strip():
        raise ValueError("Source has no extractable text")
    return {"raw": raw, "mime": mime, "final_url": final_url, "suffix": suffix,
            "content_sha": _sha(raw), "text": text, "pages": pages,
            "visual": visual, "state": state}


def _document_lookup(documents: dict, url: str) -> dict | None:
    key = _normalize_url(url)
    record = documents.get(key)
    if isinstance(record, dict) and record.get("alias_of"):
        record = documents.get(record["alias_of"])
    return record if isinstance(record, dict) else None


def _index_document(documents: dict, row: dict, entry: dict, final_url: str = "") -> None:
    """Record the (document, company) relation without copying the page."""
    key = _normalize_url(row.get("source_url") or "")
    if not key or entry.get("status") not in {"ready", "requires_visual_review"}:
        return
    previous = documents.get(key, {}) if isinstance(documents.get(key), dict) else {}
    record = {
        "url": key,
        "content_sha256": entry.get("content_sha256"),
        "text_sha256": entry.get("text_sha256"),
        "raw_path": entry.get("raw_path"),
        "text_path": entry.get("text_path"),
        "n_chars": entry.get("n_chars"),
        "page_spans": entry.get("page_spans"),
        "visual_pages": entry.get("visual_pages"),
        "status": entry.get("status"),
        "mime": entry.get("mime"),
        "company_ids": sorted(set(previous.get("company_ids") or []) | {row["company_id"]}),
        "source_ids": sorted(set(previous.get("source_ids") or []) | {row["source_id"]}),
        "aliases": sorted(set(previous.get("aliases") or []) | {key}),
    }
    alias = _normalize_url(final_url) if final_url else ""
    if alias and alias != key:
        record["aliases"] = sorted(set(record["aliases"]) | {alias})
        documents[alias] = {"url": alias, "alias_of": key,
                            "content_sha256": entry.get("content_sha256")}
    documents[key] = record


def ingest(work: Path, manifest_path: Path, offline: bool = False, refresh: bool = False,
           retry_failed: bool = False, new_only: bool = False, retry_source_ids=(),
           retire_missing: bool = False, max_workers: int = 4,
           min_interval: float = 0.0, snapshot_every: int = SNAPSHOT_EVERY) -> list[dict]:
    """Snapshot all declared sources; reuse valid unchanged snapshots; retain failed tasks.

    This is an incremental upsert. A source that this manifest no longer names
    keeps its previous record, including its active flag and its plan binding.
    Retiring a source requires an explicit full-replacement call
    (`retire_missing=True`); a partial manifest (identity pages, a repaired
    batch, one company's retry) must never deactivate the rest of the corpus.

    Completed sources are committed one at a time: each success is appended to
    `qa/ingest-journal.jsonl` and flushed, and the ledger snapshot is rewritten
    atomically every `snapshot_every` commits. A restart therefore reuses the
    pages that were already downloaded instead of fetching them again, and only
    a torn final journal line is ignored.

    Fetching runs in a bounded worker pool while the main thread commits.
    Concurrency is limited per host as well, so a single slow site cannot
    multiply requests by the pool size. The same document downloaded for two
    companies is stored once and related twice.
    """
    work = Path(work).resolve(); manifest_path = Path(manifest_path).resolve()
    rows, manifest_sha = _load_manifest(manifest_path)
    rows = _validate(rows, _roster(work))
    old = read_sources(work)
    journal = replay_journal(work)
    documents = _read_documents(work)
    for row in rows:
        prior = old.get(row["source_id"], {})
        if prior and prior.get("company_id") != row["company_id"]:
            raise ValueError("Existing source_id cannot change company_id: " + row["source_id"])

    merged: dict[str, dict] = dict(old)
    output: list[dict | None] = [None] * len(rows)
    journal_records = {sid: record for sid, record in journal.items()}
    pending: list[dict] = []
    committed = [0]

    def snapshot() -> None:
        _write_json(work / "sources.json",
                    {"version": "1.6.0", "manifest_sha256": manifest_sha,
                     "sources": list(merged.values())})

    def commit(index: int, row: dict, prior: dict, row_sha: str, payload: dict) -> None:
        current = _base_entry(row, prior, manifest_sha, row_sha)
        try:
            if payload.get("error") is not None:
                raise payload["error"]
            content_sha = payload["content_sha"]
            if (prior.get("status") == "ready"
                    and content_sha == prior.get("content_sha256") and not refresh):
                text_for(work, prior)
                current.update({k: prior[k] for k in [
                    "raw_path", "content_sha256", "text_path", "text_sha256", "n_chars",
                    "page_spans", "visual_pages", "status", "acquired_at", "mime"
                ] if k in prior})
                current["from_cache"] = True
            else:
                slug = _slug(row["source_id"])
                extension = (payload["suffix"]
                             if re.fullmatch(r"\.[A-Za-z0-9]{1,8}", payload["suffix"] or "")
                             else ".bin")
                raw_path = work / "raw" / slug / (content_sha + extension)
                raw_path.parent.mkdir(parents=True, exist_ok=True)
                existing = raw_path.read_bytes() if raw_path.exists() else None
                if existing is not None and _sha(existing) != content_sha:
                    raise ValueError("Immutable snapshot path was modified")
                if existing is None:
                    raw_path.write_bytes(payload["raw"])
                text_raw = payload["text"].encode("utf-8")
                text_path = work / "text" / slug / (content_sha + ".txt")
                text_path.parent.mkdir(parents=True, exist_ok=True)
                existing_text = text_path.read_bytes() if text_path.exists() else None
                if existing_text is not None and existing_text != text_raw:
                    raise ValueError("Immutable normalized text path was modified")
                if existing_text is None:
                    text_path.write_bytes(text_raw)
                current.update(
                    raw_path=raw_path.relative_to(work).as_posix(), content_sha256=content_sha,
                    text_path=text_path.relative_to(work).as_posix(),
                    text_sha256=_sha(text_raw), n_chars=len(payload["text"]),
                    page_spans=payload["pages"], visual_pages=payload["visual"],
                    status=payload["state"], acquired_at=_now(), mime=payload["mime"])
            if prior and prior.get("content_sha256") not in (None, "", content_sha):
                current["previous_version"] = {k: prior[k] for k in
                                               ["content_sha256", "text_sha256", "raw_path",
                                                "text_path", "acquired_at"] if k in prior}
        except Exception as exc:  # noqa: BLE001 - a source failure is a ledger record
            current = _failed_entry(current, prior, exc)
        output[index] = current
        merged[row["source_id"]] = current
        if current.get("status") in {"ready", "requires_visual_review"}:
            journal_records[row["source_id"]] = current
            _append_journal(work, current)
        _index_document(documents, row, current, payload.get("final_url", ""))
        committed[0] += 1
        if snapshot_every and committed[0] % max(1, int(snapshot_every)) == 0:
            snapshot()

    for index, row in enumerate(rows):
        prior = old.get(row["source_id"], {})
        row_sha = _sha(json.dumps(row, ensure_ascii=False, sort_keys=True).encode())
        if (not refresh and prior.get("status") != "ready"):
            # A source that was downloaded and committed before an interruption
            # is read from the recovery log; its hashes decide whether it is
            # still usable.
            recorded = journal.get(row["source_id"], {})
            if (recorded.get("row_sha256") == row_sha
                    and recorded.get("status") in {"ready", "requires_visual_review"}
                    and _verified_snapshot(work, recorded)):
                prior = {**recorded}
        current = _base_entry(row, prior, manifest_sha, row_sha)
        retry = prior.get("status") == "failed" and (retry_failed or row["source_id"] in retry_source_ids)
        if new_only and not retry and prior and prior.get("row_sha256") == row_sha:
            output[index] = {**prior, "active": True, "manifest_sha256": manifest_sha}
            merged[row["source_id"]] = output[index]
            continue
        if _skip_failed(prior, row, row_sha, refresh, retry):
            error_class = prior.get("error_class") or _classify_message(str(prior.get("error") or ""))
            current.update(
                status="failed",
                error=prior.get("error"),
                error_class=error_class,
                failure_count=int(prior.get("failure_count") or 1),
                last_attempt=prior.get("last_attempt") or prior.get("checked_at"),
                acquired_at=None,
                from_cache=True,
            )
            if prior.get("previous_version"):
                current["previous_version"] = prior["previous_version"]
            output[index] = current
            merged[row["source_id"]] = current
            continue
        local = row.get("local_path")
        if local:
            try:
                path = Path(local)
                path = path if path.is_absolute() else manifest_path.parent / path
                if not path.is_file():
                    raise ValueError("Local source is missing: " + str(path))
                if path.stat().st_size > MAX_BYTES:
                    raise ValueError("Source exceeds 25 MiB snapshot limit")
                raw = path.read_bytes()
                suffix = path.suffix.lower()
                text, pages, visual, state = _normalize(raw, suffix, "")
                if state == "ready" and not text.strip():
                    raise ValueError("Source has no extractable text")
                commit(index, row, prior, row_sha, {
                    "raw": raw, "mime": "", "final_url": "", "suffix": suffix,
                    "content_sha": _sha(raw), "text": text, "pages": pages,
                    "visual": visual, "state": state})
            except Exception as exc:  # noqa: BLE001
                output[index] = _failed_entry(current, prior, exc)
                merged[row["source_id"]] = output[index]
            continue
        if (prior.get("status") == "ready" and prior.get("source_url") == row.get("source_url")
                and not refresh):
            try:
                text_for(work, prior)
                raw_path = _bound_path(work, prior["raw_path"])
                if raw_path.is_file():
                    current.update({k: prior[k] for k in [
                        "raw_path", "content_sha256", "text_path", "text_sha256", "n_chars",
                        "page_spans", "visual_pages", "status", "acquired_at", "mime"
                    ] if k in prior})
                    current["from_cache"] = True
                    output[index] = current
                    merged[row["source_id"]] = current
                    _index_document(documents, row, current)
                    continue
                current.update({k: prior[k] for k in [
                    "raw_path", "content_sha256", "text_path", "text_sha256", "n_chars",
                    "page_spans", "visual_pages", "status", "acquired_at", "mime"
                ] if k in prior})
                current.update(from_cache=True, snapshot_missing=True)
                output[index] = current
                merged[row["source_id"]] = current
                continue
            except (ValueError, OSError):
                pass  # fall through to a fresh fetch
        document = _document_lookup(documents, row.get("source_url") or "")
        if document and document.get("status") in {"ready", "requires_visual_review"} \
                and not refresh and _verified_snapshot(work, document):
            current.update({k: document[k] for k in [
                "raw_path", "content_sha256", "text_path", "text_sha256", "n_chars",
                "page_spans", "visual_pages", "status", "mime"
            ] if k in document})
            current["from_cache"] = True
            current["document_reused"] = True
            current["acquired_at"] = current.get("acquired_at") or _now()
            output[index] = current
            merged[row["source_id"]] = current
            _index_document(documents, row, current)
            continue
        pending.append({"index": index, "row": row, "prior": prior, "row_sha": row_sha,
                        "offline": offline})

    if pending:
        limiter = _DomainLimiter(min_interval)
        workers = 1 if offline else max(1, int(max_workers))
        # The same address registered for two employers is one document. Group
        # the rows before fetching so it is downloaded and parsed once, then
        # related to each company that registers it.
        groups = []
        by_target = {}
        for task in pending:
            url = task["row"].get("source_url") or ""
            key = ((_normalize_url(url), _suffix_for(url)) if url
                   else ("row", str(task["index"])))
            if key in by_target:
                by_target[key]["tasks"].append(task)
            else:
                group = {"url": url, "tasks": [task]}
                by_target[key] = group
                groups.append(group)

        def fetch(group):
            row = dict(group["tasks"][0]["row"])
            row["_offline"] = offline
            row["_suffix"] = _suffix_for(row.get("source_url") or "")
            url = row.get("source_url") or ""
            if offline:
                return {"error": ValueError("Offline source has no usable current snapshot")}
            limiter.wait(url)
            try:
                return _fetch_payload(row)
            except Exception as exc:  # noqa: BLE001 - reported to the main thread
                return {"error": exc}
            finally:
                limiter.release(url)

        def commit_group(group, payload):
            for task in group["tasks"]:
                commit(task["index"], task["row"], task["prior"], task["row_sha"], payload)

        if workers == 1:
            for group in groups:
                commit_group(group, fetch(group))
        else:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {pool.submit(fetch, group): group for group in groups}
                for future in as_completed(futures):
                    group = futures[future]
                    try:
                        payload = future.result()
                    except Exception as exc:  # noqa: BLE001
                        payload = {"error": exc}
                    commit_group(group, payload)

    # Incremental upsert: a source outside this manifest keeps its record and
    # its active flag. Only an explicit full replacement may retire sources,
    # and a retired source is never revived by a later partial manifest.
    active_ids = {row["source_id"] for row in rows}
    for source_id, previous in old.items():
        if source_id in active_ids:
            continue
        if retire_missing:
            merged[source_id] = {**previous, "active": False, "retired_from_manifest": True,
                                 "retired_at": _now()}
        else:
            merged[source_id] = previous
    snapshot()
    _write_documents(work, documents)
    _compact_journal(work, journal_records)
    return [entry for entry in output if entry is not None]

