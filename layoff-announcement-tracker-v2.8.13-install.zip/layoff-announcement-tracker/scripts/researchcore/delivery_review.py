"""Check review coverage against current decisions and source manifests."""
import csv
import re
from datetime import date


AMOUNTS = (
    "training_costs_amount", "ai_investment_amount", "tech_opex_amount",
    "rd_expense", "capitalized_software_amount", "revenue", "operating_income",
    "restructuring_charges", "total_comp_expense", "ai_executive_comp_amount",
)

_NUMBER = re.compile(r"\d[\d,]*(?:\.\d+)?")
# HTML extraction often inserts newlines inside one sentence. Normalize them before
# semantic checks; otherwise a historical year and its count can evade the recap gate.
_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z\u201c\"'])")
_ABBREVIATION = re.compile(
    r"(?:\b(?:Inc|Ltd|Corp|Co|vs|etc|No|St|Dr|Mr|Ms|Jr|Sr|Jan|Feb|Mar|Apr|Jun|"
    r"Jul|Aug|Sept|Sep|Oct|Nov|Dec|Mon|Tue|Wed|Thu|Fri|Sat|Sun|Ave|Blvd|Dept|"
    r"Est|Fig|U\.S|U\.K)\.)$", re.I)
_HEADCOUNT = (
    # A workforce total introduced by a possessive determiner: "cut 300 of its
    # 9,000 employees". Plain "of N employees" is not enough, because "lays off
    # its India team of 250 employees" states the number cut, not the total.
    re.compile(r"\b(?:of|out of|from|among)\s+(?:its|the|their|our)\s+"
               r"(?:total\s+)?(?:nearly|about|around|roughly|approximately|some|"
               r"more than|over)?\s*([\d][\d,]{2,})\s+"
               r"(?:employees|staff|workers|people|roles|headcount)", re.I),
    re.compile(r"\b(?:workforce|headcount|staff|payroll)\s+(?:of|stands? at|totals?)\s+"
               r"(?:nearly|about|around|roughly|approximately)?\s*([\d][\d,]{2,})", re.I),
    re.compile(r"\bemploys?\s+(?:nearly|about|around|roughly|approximately|some|"
               r"more than|over)?\s*([\d][\d,]{2,})\s+"
               r"(?:employees|staff|workers|people)", re.I),
)
_SINCE = re.compile(r"\b(since|in total|cumulatively|previous(?:ly)?|earlier round|prior round|last year|had announced)\b", re.I)
_MONTHS = {name: index for index, name in enumerate(
    ("january", "february", "march", "april", "may", "june", "july",
     "august", "september", "october", "november", "december"), 1)}
_MONTH_YEAR = re.compile(r"\b(" + "|".join(_MONTHS) + r")\s+(\d{4})\b", re.I)
_YEAR = re.compile(r"\b(?:in|during)\s+((?:19|20)\d{2})\b", re.I)
_RANGE = re.compile(r"\b([\d][\d,]*(?:\.\d+)?)\s*(?:or|to|–|—|-)\s*([\d][\d,]*(?:\.\d+)?)\b", re.I)
_LAYOFF = re.compile(r"\b(lay(?:s|ing)?\s*off|laid\s+off|job\s+cuts?|cuts?|cutting|"
                     r"reduc(?:e|es|ing|tion)|eliminat(?:e|es|ing)|workforce\s+reduction)\b", re.I)
_PERCENT = re.compile(r"\d+(?:\.\d+)?\s*(?:%|percent\b)", re.I)
_AFFECTED = re.compile(r"\b(?:laid\s+off|lay(?:s|ing)?\s*off|cut(?:s|ting)?|eliminat(?:e|es|ing))\s+"
                       r"(?:about|around|roughly|approximately|nearly|some|more than|over)?\s*"
                       r"([\d][\d,]{2,})\s+(?:employees|staff|workers|people|roles|jobs|positions)\b", re.I)
_DATE_BASES = {"announcement", "company_statement", "news_reported_announcement", "regulatory_notice", "warn_notice"}
_COUNTRY_NAMES = frozenset("""
afghanistan albania algeria andorra angola argentina armenia australia austria azerbaijan bahamas bahrain bangladesh barbados belarus belgium belize benin bhutan bolivia bosniaandherzegovina botswana brazil brunei bulgaria burkinafaso burundi caboverde cambodia cameroon canada centralafricanrepublic chad chile china colombia comoros costarica croatia cuba cyprus czechia czechrepublic denmark djibouti dominica dominicanrepublic ecuador egypt elsalvador equatorialguinea eritrea estonia eswatini ethiopia fiji finland france gabon gambia georgia germany ghana greece grenada guatemala guinea guineabissau guyana haiti honduras hungary iceland india indonesia iran iraq ireland israel italy ivorycoast jamaica japan jordan kazakhstan kenya kiribati kuwait kyrgyzstan laos latvia lebanon lesotho liberia libya liechtenstein lithuania luxembourg madagascar malawi malaysia maldives mali malta marshallislands mauritania mauritius mexico micronesia moldova monaco mongolia montenegro morocco mozambique myanmar namibia nauru nepal netherlands newzealand nicaragua niger nigeria northkorea northmacedonia norway oman pakistan palau panama papuanewguinea paraguay peru philippines poland portugal qatar romania russia rwanda saintkittsandnevis saintlucia saintvincentandthegrenadines samoa sanmarino saotomeandprincipe saudiarabia senegal serbia seychelles sierraleone singapore slovakia slovenia solomonislands somalia southafrica southkorea southsudan spain srilanka sudan suriname sweden switzerland syria taiwan tajikistan tanzania thailand timorleste togo tonga trinidadandtobago tunisia turkey turkmenistan tuvalu uganda ukraine unitedarabemirates unitedkingdom uk greatbritain england scotland wales unitedstates us usa unitedstatesofamerica uruguay uzbekistan vanuatu vatican venezuela vietnam yemen zambia zimbabwe hongkong macau puertorico bermuda caymanislands jersey guernsey isleofman greenland faroeislands gibraltar curacao aruba britishvirginislands europeanunion
""".split())


def _number(text):
    try:
        return float(str(text).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def _quotes(decision):
    return "\n".join(str(item.get("quote") or "") for item in decision.get("evidence", [])
                     if isinstance(item, dict))


def _sentences(text):
    """Split into sentences without breaking on a decimal or an abbreviation.

    A plain split on [.!?] cut "Toast Inc. said it plans to lay off 550
    employees" into "Toast Inc." and a second sentence with no employer name,
    which then failed the employer-naming check on otherwise valid evidence.
    """
    normalized = re.sub(r"\s+", " ", text or "").strip()
    parts = []
    start = 0
    for match in _SPLIT.finditer(normalized):
        boundary = match.start()
        before = normalized[max(0, boundary - 6):boundary + 1]
        if _ABBREVIATION.search(before):
            continue
        # A decimal point never ends a sentence.
        if boundary >= 1 and normalized[boundary - 1] == "." \
                and boundary >= 2 and normalized[boundary - 2].isdigit():
            continue
        parts.append(normalized[start:boundary])
        start = match.end()
    parts.append(normalized[start:])
    return [part.strip() for part in parts if part.strip()]


def _mentions(text, number):
    for token in _NUMBER.findall(text or ""):
        value = _number(token)
        if value is not None and abs(value - number) < 0.5:
            return True
    return False


def _aliases(record):
    value = (record or {}).get("aliases") or []
    if isinstance(value, str):
        value = value.split(";")
    return [str(item).strip() for item in value if str(item).strip()]


def _names(entity, entities, roster=None):
    own = set()
    record = (entities or {}).get(entity) or {}
    company_id = record.get("company_id")
    records = [record]
    if company_id:
        records += [item for item in (roster or []) if item.get("company_id") == company_id]
    for item in records:
        for key in ("company", "company_en"):
            value = str(item.get(key) or "").strip().lower()
            if len(value) >= 2:
                own.add(value)
        for value in _aliases(item):
            if len(value) >= 2:
                own.add(value.lower())
    return own


def _other_company(sentence, entity, entities, roster=None):
    """Another roster company named in the sentence.

    The match is case sensitive on purpose: a roster name can be an ordinary
    English word ("ON", "Sea", "Here"), and a lowercased search then treats
    every "on" in the sentence as a competing employer.
    """
    target = ((entities or {}).get(entity) or {}).get("company_id")
    records = list((entities or {}).items())
    records += [("roster:" + str(item.get("company_id")), item) for item in (roster or [])]
    for other, record in records:
        if other == entity or (target and record.get("company_id") == target):
            continue
        names = [record.get(key) for key in ("company", "company_en")] + _aliases(record)
        for value in names:
            name = str(value or "").strip()
            if len(name) >= 2 and re.search(r"\b" + re.escape(name) + r"\b", sentence):
                return name
    return ""


def _country_key(value):
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())


def _derived_difference_ok(decision, span, value):
    """True when the count is the difference between two figures the source states.

    "Salesforce cut its support team from 9,000 to 5,000" states a pre- and a
    post-reduction size. The reduction is 4,000, which the source implies but
    never prints. Recording the difference is the correct reading; it must be
    accepted only when the decision declares that basis and the evidence
    contains both endpoints.
    """
    basis = str((decision or {}).get("layoff_count_basis") or "").lower()
    if "difference" not in basis:
        return False
    values = [_number(token) for token in _NUMBER.findall(span)]
    for left in values:
        for right in values:
            if left is None or right is None or left == right:
                continue
            if abs(abs(left - right) - value) < 0.5:
                return True
    return False


def _is_workforce_share(sentence):
    """True when the percentage in this sentence is a share of the workforce.

    The check must not demand a layoff_percentage for a share-price fall
    ("shares down 40%"), a pay cut ("CEO taking 98 percent pay cut") or a
    margin. Only "X% of its workforce/staff/employees/team" is a layoff share.
    """
    for match in _PERCENT.finditer(sentence or ""):
        tail = sentence[match.end():match.end() + 40]
        window = sentence[max(0, match.start() - 30):match.start()]
        if re.match(r"\s*(?:of\s+)?(?:its|the|their|our|a)?\s*(?:total\s+)?"
                    r"(?:global\s+|full-time\s+|entire\s+)?"
                    r"(?:workforce|staff|employees|team|headcount|payroll|people)\b",
                    tail, re.I):
            return True
        if re.search(r"\b(?:workforce|headcount|staff|employees|team|payroll)\b"
                     r"\s+(?:by|of|to|at)\s*$", window, re.I):
            return True
    return False


def _is_reduction_object(sentence, position):
    """True when the figure at `position` is the *object* of the reduction.

    "Lucid plans to lay off a total of around 1,300 employees" states the
    number cut; "cut 300 jobs from a team of 9,000" states the workforce the
    cut came out of. Only the second form is a denominator, and the check must
    not fire on the first, which is how most outlets word a layoff count.
    """
    prefix = sentence[max(0, position - 70):position]
    # A workforce-size frame immediately before the figure makes it a
    # denominator: "a workforce of 9,000", "employs 9,000", "staff of 9,000".
    if re.search(r"\b(?:workforce|headcount|staff|payroll|team)\b\s+(?:of\s+|"
                 r"stands?\s+at\s+|totals?\s+)?$", prefix, re.I):
        return False
    if re.search(r"\b(?:employs?|employed|has|with)\s+(?:a\s+)?(?:total\s+)?"
                 r"(?:workforce|headcount|staff|payroll)\b[^.;]{0,15}$", prefix, re.I):
        return False
    if re.search(r"\b(?:from|out\s+of|among)\s+(?:a\s+)?(?:team|workforce|staff|"
                 r"headcount|payroll|base)\b[^.;]{0,20}$", prefix, re.I):
        return False
    # Otherwise the figure is governed by the reduction verb and is the count.
    return bool(re.search(
        r"\b(?:lay(?:s|ing)?\s*off|laid\s+off|cut(?:s|ting)?|eliminat(?:e|es|ing)|"
        r"slash(?:es|ed|ing)|shed(?:s|ding)?|trimm?(?:s|ing)?)\b[^.;]{0,50}$",
        prefix, re.I))


def _year_mismatch(plan, sentence):
    """True when the sentence dates the figure to a different year than the event.

    Both "in 2022" and "in November 2022" count: the earlier form missed
    "cut another 862 positions in November 2022", which is a recap of a prior
    round. A month difference inside the event's own year is not a mismatch.
    """
    if not plan:
        return False
    years = [int(year) for year in _YEAR.findall(sentence)]
    years += [int(year) for _month, year in _MONTH_YEAR.findall(sentence)]
    return any(year != plan[0] for year in years)


def _range_mentions(sentence, value):
    for left, right in _RANGE.findall(sentence):
        lo, hi = _number(left), _number(right)
        if lo is not None and hi is not None and lo <= value <= hi and lo != hi:
            return True
    return False


def _relative_owner(sentence, number, entity, entities):
    """Return another company that owns a 'which laid off N' relative clause."""
    position = None
    for match in _NUMBER.finditer(sentence):
        value = _number(match.group(0))
        if value is not None and abs(value - number) < 0.5:
            position = match.start()
            break
    if position is None:
        return ""
    prefix = sentence[max(0, position - 60):position]
    if not re.search(r"\b(?:which|who)\s+(?:laid\s+off|lay\s+off|cut|cuts|is\s+cutting|will\s+cut)\s*$",
                     prefix, re.I):
        return ""
    best = None
    for other, record in (entities or {}).items():
        for key in ("company", "company_en"):
            name = str((record or {}).get(key) or "").strip()
            if len(name) < 4:
                continue
            for match in re.finditer(r"\b" + re.escape(name.lower()) + r"\b",
                                     sentence[:position].lower()):
                if best is None or match.start() > best[0]:
                    best = (match.start(), other, name)
    return best[2] if best and best[1] != entity else ""


def _month_matches(plan, sentence):
    for month, year in _MONTH_YEAR.findall(sentence):
        if plan != (int(year), _MONTHS[month.lower()]):
            return False
    return True


def _plan_parts(value):
    match = re.match(r"(\d{4})-(\d{2})", str(value or ""))
    return (int(match.group(1)), int(match.group(2))) if match else None


def _has_name(sentence, names):
    lowered = sentence.lower()
    return any(re.search(r"\b" + re.escape(name) + r"\b", lowered) for name in names)


def _v240_semantic_gaps(decisions, entities, roster):
    """Stricter event semantics introduced in 2.4.0; kept separate for readable tests."""
    gaps = []

    def cell(entity, variable):
        return decisions.get(entity + "|" + variable, {})

    for entity in sorted({key.split("|")[0] for key in decisions}):
        announced = cell(entity, "announcement_date")
        if announced.get("status") == "observed":
            basis = announced.get("date_basis")
            if basis not in _DATE_BASES:
                gaps.append({"contract": "measure_coherence", "reason": entity +
                             ": observed announcement_date requires date_basis=" + "/".join(sorted(_DATE_BASES)) +
                             "; a publication or effective date is not an announcement date"})
        plan = _plan_parts(announced.get("value"))
        own = _names(entity, entities, roster)
        for prefix, label in (("layoff_count", "count"), ("layoff_percentage", "percentage")):
            point = cell(entity, prefix)
            lower = cell(entity, prefix + "_lower")
            upper = cell(entity, prefix + "_upper")
            qualifier = cell(entity, prefix + "_qualifier")
            q = qualifier.get("value")
            observed = lambda item: item.get("status") == "observed"
            if prefix == "layoff_percentage" and any(observed(item) for item in (point, lower, upper, qualifier)):
                if not observed(qualifier):
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": percentage qualifier is required"})
                elif q in {"exact", "approximately"}:
                    if not observed(point) or observed(lower) or observed(upper):
                        gaps.append({"contract": "measure_coherence", "reason": entity +
                                     ": exact/approximate percentage requires a point and null lower/upper bounds"})
                elif q in {"more_than", "at_least"}:
                    if observed(point) or not observed(lower) or observed(upper):
                        gaps.append({"contract": "measure_coherence", "reason": entity +
                                     ": lower-threshold percentage requires only layoff_percentage_lower"})
                elif q in {"less_than", "up_to"}:
                    if observed(point) or observed(lower) or not observed(upper):
                        gaps.append({"contract": "measure_coherence", "reason": entity +
                                     ": upper-threshold percentage requires only layoff_percentage_upper"})
                elif q == "range":
                    if observed(point) or not observed(lower) or not observed(upper):
                        gaps.append({"contract": "measure_coherence", "reason": entity +
                                     ": percentage range requires only explicit lower and upper bounds"})
                elif q == "unknown" and any(observed(item) for item in (point, lower, upper)):
                    gaps.append({"contract": "measure_coherence", "reason": entity +
                                 ": unknown percentage qualifier cannot carry numeric values"})
            lo = lower.get("value") if observed(lower) else None
            hi = upper.get("value") if observed(upper) else None
            if isinstance(lo, (int, float)) and isinstance(hi, (int, float)) and lo > hi:
                gaps.append({"contract": "measure_coherence", "reason": entity + ": " + prefix + " lower bound exceeds upper bound"})
            candidates = [item for item in (point, lower, upper) if observed(item)]
            for item in candidates:
                value = item.get("value")
                if not isinstance(value, (int, float)):
                    continue
                span = _quotes(item)
                for sentence in _sentences(span):
                    if not _mentions(sentence, value):
                        continue
                    if not _has_name(sentence, own):
                        other = _other_company(sentence, entity, entities, roster)
                        detail = "; other employer=" + other if other else ""
                        gaps.append({"contract": "measure_coherence", "reason": entity +
                                     ": " + label + " evidence sentence must name the target employer or a registered alias" + detail})
                    # A month difference inside the event's own year is
                    # reporting lag on the same event, not a recap. Only a
                    # different year or an explicit cumulative frame makes a
                    # figure historical.
                    if _SINCE.search(sentence) or _year_mismatch(plan, sentence):
                        gaps.append({"contract": "measure_coherence", "reason": entity +
                                     ": " + label + " evidence is a historical/cumulative claim rather than the current event"})
                    if prefix == "layoff_count" and q != "range" and _range_mentions(sentence, value):
                        gaps.append({"contract": "measure_coherence", "reason": entity +
                                     ": evidence states a numeric range; use qualifier=range with both bounds, not a point/threshold"})
        country = cell(entity, "country")
        if country.get("status") == "observed":
            value = str(country.get("value") or "").strip()
            if _country_key(value) not in _COUNTRY_NAMES:
                gaps.append({"contract": "measure_coherence", "reason": entity +
                             ": country must be a controlled country/jurisdiction name without an address, city or postal code"})
    return gaps


def _captured_numbers(pattern, text):
    """Yield numbers captured by a semantic pattern, normalized for comparison."""
    for match in pattern.finditer(text or ""):
        token = match.groupdict().get("number") or match.group(1)
        value = _number(token)
        if value is not None:
            yield value


# These patterns bind a number to its local role. A sentence may legitimately contain
# both 982 terminations and 288 furloughs; only the furlough-owned number is rejected.
_REMAINING_BEFORE = re.compile(
    r"\b(?:reduce|reducing|reduction|cut|cutting|layoff|layoffs|downsizing)\b[^.!?;]{0,140}?"
    r"\b(?:(?<!up )to|leaving|leave|retain|retaining|have|having)\s+(?:approximately|about|around|roughly|nearly)?\s*"
    r"(?P<number>[\d][\d,]*(?:\.\d+)?)\s+(?:employees|staff|workers|people|roles|headcount)\b", re.I)
_REMAINING_AFTER = re.compile(
    r"\b(?P<number>[\d][\d,]*(?:\.\d+)?)\s+(?:employees|staff|workers|people|roles|headcount)\b"
    r"[^.!?;]{0,70}\b(?:remain|remaining|will remain|after the reduction|following the layoffs)\b", re.I)
_FURLOUGH_BEFORE = re.compile(
    r"\bfurlough(?:s|ed|ing)?\b[^.!?;]{0,90}?\b(?P<number>[\d][\d,]*(?:\.\d+)?)\s*"
    r"(?:employees|staff|workers|people|roles|jobs|positions)?\b", re.I)
_FURLOUGH_AFTER = re.compile(
    r"\b(?P<number>[\d][\d,]*(?:\.\d+)?)\s+(?:employees|staff|workers|people|roles|jobs|positions)\b"
    r"[^.!?;]{0,55}\bfurlough(?:s|ed|ing)?\b", re.I)
_OPEN_BEFORE = re.compile(
    r"\b(?:open|vacant|unfilled)\s+(?P<number>[\d][\d,]*(?:\.\d+)?)\s+"
    r"(?:positions|jobs|roles|vacancies)\b", re.I)
_OPEN_AFTER = re.compile(
    r"\b(?P<number>[\d][\d,]*(?:\.\d+)?)\s+(?:open|vacant|unfilled)\s+"
    r"(?:positions|jobs|roles|vacancies)\b|\b(?P<number_alt>[\d][\d,]*(?:\.\d+)?)\s+"
    r"(?:positions|jobs|roles|vacancies)\s+(?:are|were|remain|currently)?\s*(?:open|vacant|unfilled)\b", re.I)
_GEO_AFTER = re.compile(
    r"\b(?P<number>[\d][\d,]*(?:\.\d+)?)\s+(?:employees|staff|workers|people|roles|jobs|positions)\b"
    r"(?P<context>[^.!?;]{0,100})", re.I)
_GEO_BEFORE = re.compile(
    r"\b(?P<context>in\s+(?:the\s+)?(?:u\.?s\.?a?|united\s+states|international|emea|apac|europe|asia)|"
    r"internationally|outside\s+(?:the\s+)?(?:u\.?s\.?a?|united\s+states))[^.!?;]{0,70}?\b"
    r"(?P<number>[\d][\d,]*(?:\.\d+)?)\s+(?:employees|staff|workers|people|roles|jobs|positions)\b", re.I)
_GEO_MARKER = re.compile(
    r"\b(?:u\.?s\.?a?|united\s+states|international(?:ly)?|outside\s+(?:the\s+)?(?:u\.?s\.?a?|united\s+states)|"
    r"emea|apac|europe|asia)\b", re.I)


def _geographic_components(text):
    values = []
    for match in _GEO_AFTER.finditer(text or ""):
        if _GEO_MARKER.search(match.group("context")):
            values.append(_number(match.group("number")))
    values.extend(_captured_numbers(_GEO_BEFORE, text))
    return {value for value in values if value is not None}


def _complete_geographic_review(decision, components):
    review = decision.get("geographic_component_review") or {}
    if review.get("status") != "complete" or len(str(review.get("basis") or "").strip()) < 15:
        return False
    recorded = {_number(item.get("value") if isinstance(item, dict) else item)
                for item in review.get("components", [])}
    return components.issubset(recorded - {None})


def _v251_count_semantics(entity, decision, value, text):
    """Reject counts whose cited number is a remainder, furlough, vacancy or partial geography."""
    gaps = []
    for sentence in _sentences(text):
        if not _mentions(sentence, value):
            continue
        if any(any(abs(found - value) < 0.5 for found in _captured_numbers(pattern, sentence))
               for pattern in (_REMAINING_BEFORE, _REMAINING_AFTER)):
            gaps.append({"contract": "measure_coherence", "reason": entity +
                         ": cited number is remaining headcount after a reduction, not the layoff count"})
        if any(any(abs(found - value) < 0.5 for found in _captured_numbers(pattern, sentence))
               for pattern in (_FURLOUGH_BEFORE, _FURLOUGH_AFTER)):
            gaps.append({"contract": "measure_coherence", "reason": entity +
                         ": cited number belongs to furloughs; do not substitute temporary furloughs for involuntary layoffs"})
        open_values = list(_captured_numbers(_OPEN_BEFORE, sentence))
        for match in _OPEN_AFTER.finditer(sentence):
            token = match.groupdict().get("number") or match.groupdict().get("number_alt")
            parsed = _number(token)
            if parsed is not None:
                open_values.append(parsed)
        if any(abs(found - value) < 0.5 for found in open_values):
            gaps.append({"contract": "measure_coherence", "reason": entity +
                         ": cited number belongs to open/vacant positions, not employees laid off"})
        components = _geographic_components(sentence)
        if len(components) >= 2 and any(abs(found - value) < 0.5 for found in components) \
                and not _complete_geographic_review(decision, components):
            gaps.append({"contract": "measure_coherence", "reason": entity +
                         ": evidence states multiple geographic workforce components; review all US/international components and record complete geographic_component_review before using one component"})
    return gaps


def _magnitude_gaps(entity, cell):
    """Reject a count that cannot describe one employer in one event.

    A delivery audit of the previous collection round found industry
    aggregates and year-to-date totals recorded as a single employer's layoff
    count ("Google 100,000" from a sentence about 100,000 positions eliminated
    across several companies). The absolute ceiling applies on its own.

    The event-time firm size is a second, softer reference. It comes from a
    registrant filing, which may describe a different year than the event, so
    a count that exceeds it is reported rather than treated as proof of
    error. What is treated as an error is a count that would remove an
    implausible share of that workforce.
    """
    gaps = []
    count = cell("layoff_count")
    if count.get("status") != "observed":
        return gaps
    value = count.get("value")
    if not isinstance(value, (int, float)):
        return gaps
    firm = cell("firm_size")
    size = firm.get("value") if firm.get("status") == "observed" else None
    percentage = cell("layoff_percentage")
    share = percentage.get("value") if percentage.get("status") == "observed" else None
    if value > 2_000_000:
        gaps.append({"contract": "measure_coherence",
                     "reason": entity + ": layoff_count " + str(int(value)) +
                     " exceeds any plausible single-employer event; it is more likely an "
                     "industry aggregate or a workforce total"})
        return gaps
    if not isinstance(size, (int, float)) or size <= 0:
        return gaps
    if value >= 1000:
        removed = value / float(size) * 100.0
        if removed > 45:
            gaps.append({"contract": "measure_coherence",
                         "reason": entity + ": layoff_count " + str(int(value)) +
                         " would remove " + format(removed, ".0f") + "% of the event-time "
                         "workforce of " + str(int(size)) +
                         "; that is beyond any single announced reduction round"})
    if isinstance(share, (int, float)) and share > 0:
        implied = size * share / 100.0
        if implied and value > implied * 3 and value > 1000:
            gaps.append({"contract": "measure_coherence",
                         "reason": entity + ": layoff_count " + str(int(value)) +
                         " is more than three times the share implied by " +
                         format(share, "g") + "% of " + str(int(size)) +
                         "; the count and the percentage do not describe the same event"})
    return gaps


def measure_gaps(decisions, entities=None, roster=None):
    """Reject event measures whose value, owner, timing or qualifier contradicts evidence."""
    gaps = []
    gaps.extend(_v240_semantic_gaps(decisions, entities or {}, roster or []))

    def cell(entity, variable):
        return decisions.get(entity + "|" + variable, {})

    for entity in sorted({key.split("|")[0] for key in decisions}):
        qualifier = cell(entity, "layoff_count_qualifier")
        count = cell(entity, "layoff_count")
        lower = cell(entity, "layoff_count_lower")
        upper = cell(entity, "layoff_count_upper")
        q = qualifier.get("value")
        if qualifier.get("status") == "observed":
            if q == "exact":
                if count.get("status") != "observed" or not isinstance(count.get("value"), (int, float)):
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier exact requires a numeric layoff_count point value"})
            elif q in {"more_than", "at_least"}:
                if count.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": a one-sided lower threshold (" + q + ") cannot be stored as a layoff_count point value; set layoff_count null and use layoff_count_lower"})
                if lower.get("status") != "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier " + q + " requires an observed layoff_count_lower"})
                if upper.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier " + q + " must leave layoff_count_upper null"})
            elif q in {"less_than", "up_to"}:
                if count.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": a one-sided upper threshold (" + q + ") cannot be stored as a layoff_count point value; set layoff_count null and use layoff_count_upper"})
                if upper.get("status") != "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier " + q + " requires an observed layoff_count_upper"})
                if lower.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier " + q + " must leave layoff_count_lower null"})
            elif q == "range":
                if count.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": a range cannot be stored as a layoff_count point value"})
                if lower.get("status") != "observed" or upper.get("status") != "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier range requires both layoff_count_lower and layoff_count_upper"})
            elif q == "unknown" and count.get("status") == "observed":
                gaps.append({"contract": "measure_coherence", "reason": entity + ": an unknown qualifier cannot carry a layoff_count point value"})
        lo = lower.get("value") if lower.get("status") == "observed" else None
        hi = upper.get("value") if upper.get("status") == "observed" else None
        if isinstance(lo, (int, float)) and isinstance(hi, (int, float)) and lo > hi:
            gaps.append({"contract": "measure_coherence", "reason": entity + ": layoff_count_lower exceeds layoff_count_upper"})
        pct = cell(entity, "layoff_percentage")
        denominator = cell(entity, "layoff_percentage_denominator")
        if pct.get("status") == "observed" and denominator.get("status") != "observed":
            gaps.append({"contract": "measure_coherence", "reason": entity + ": an observed layoff_percentage requires an observed layoff_percentage_denominator"})
        point = count if count.get("status") == "observed" else (lower if lower.get("status") == "observed" else upper)
        value = point.get("value") if point.get("status") == "observed" else None
        span = _quotes(point)
        if isinstance(value, (int, float)):
            gaps.extend(_v251_count_semantics(entity, point, value, span))
            firm = cell(entity, "firm_size")
            firm_value = firm.get("value") if firm.get("status") == "observed" else None
            if isinstance(firm_value, (int, float)) and firm_value > 0:
                if value > firm_value:
                    gaps.append({"contract": "measure_coherence", "reason": entity + f": layoff count {value} exceeds firm_size {firm_value}"})
                elif value == firm_value:
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": layoff count equals firm_size; a total workforce is not a layoff count"})
            if span and not _mentions(span, value):
                # A before/after construction states two endpoints, not the
                # difference: "cut its support team from 9,000 to 5,000". The
                # recorded count is the arithmetic the source implies, so the
                # value itself never appears. Accept it only when the basis
                # field declares a difference and both endpoints are cited.
                if not _derived_difference_ok(
                        {"layoff_count_basis": cell(entity, "layoff_count_basis").get("value")},
                        span, value):
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": layoff count value does not occur in its cited evidence"})
            if any(abs((_number(match.group(1)) or -1) - value) < 0.5
                   and not _is_reduction_object(span, match.start())
                   for pattern in _HEADCOUNT for match in pattern.finditer(span)):
                gaps.append({"contract": "measure_coherence", "reason": entity + ": layoff count equals a stated employee total (denominator), not the number cut"})
            plan = _plan_parts(cell(entity, "announcement_date").get("value"))
            for sentence in _sentences(span):
                if not _mentions(sentence, value):
                    continue
                recap = bool(_SINCE.search(sentence))
                # A month difference inside the same year is reporting lag on
                # the same event ("published in March, announced in January"),
                # not a recap. A different year, or an explicit cumulative
                # frame, is what makes a figure historical.
                if not recap and plan:
                    recap = _year_mismatch(plan, sentence)
                if recap:
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": count sentence is a cumulative or earlier-round recap, not the announced event"})
                    break
                own = _names(entity, entities)
                if own and not any(name in sentence.lower() for name in own):
                    other = _other_company(sentence, entity, entities)
                    if other:
                        gaps.append({"contract": "measure_coherence", "reason": entity + ": count sentence belongs to another company (" + other + ")"})
                        break
                relative = _relative_owner(sentence, value, entity, entities)
                if relative:
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": count is governed by a relative clause naming another company (" + relative + ")"})
                    break
            # A share recorded as an interval satisfies the pairing: the source
            # states "between 25% and 30% of its workforce", which is two bounds
            # and no point value, so layoff_percentage stays null by design.
            pct_recorded = (pct.get("status") == "observed"
                            or cell(entity, "layoff_percentage_lower").get("status") == "observed"
                            or cell(entity, "layoff_percentage_upper").get("status") == "observed")
            if not pct_recorded:
                for sentence in _sentences(span):
                    if not (_mentions(sentence, value) and _PERCENT.search(sentence)
                            and _LAYOFF.search(sentence)):
                        continue
                    # Only a workforce share belongs in layoff_percentage. A
                    # share-price move or a pay cut next to a layoff verb is a
                    # different quantity: "lays off 200 employees; shares down
                    # more than 40%", "laying off 1,300 employees, CEO taking
                    # 98 percent pay cut".
                    if not _is_workforce_share(sentence):
                        continue
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": the count sentence also states a workforce percentage; record layoff_percentage"})
                    break
        elif pct.get("status") == "observed":
            pct_span = _quotes(pct)
            match = _AFFECTED.search(pct_span)
            # A headcount stated in the percentage sentence belongs to this
            # event only when that sentence is about the workforce share, not
            # when it reports an unrelated figure beside it.
            if match and _is_workforce_share(pct_span):
                gaps.append({"contract": "measure_coherence", "reason": entity + ": percentage evidence states an affected headcount; record layoff_count"})
        country = cell(entity, "country")
        if country.get("status") == "observed":
            value = str(country.get("value") or "").strip()
            if len(value) > 60 or value.count(".") > 1:
                gaps.append({"contract": "measure_coherence", "reason": entity + ": country must be a country or jurisdiction, not a company description"})
        gaps.extend(_magnitude_gaps(entity, lambda variable: cell(entity, variable)))
    grouped = {}
    for entity in {key.split("|")[0] for key in decisions}:
        plan_date = str(cell(entity, "announcement_date").get("value") or "")[:10]
        company = (entities.get(entity) or {}).get("company_id")
        try:
            parsed = date.fromisoformat(plan_date)
        except (TypeError, ValueError):
            continue
        if company:
            grouped.setdefault(company, []).append((parsed, entity))
    for items in grouped.values():
        items.sort()
        for index, (left_date, left) in enumerate(items):
            for right_date, right in items[index + 1:]:
                if (right_date - left_date).days > 14:
                    break
                left_rel = cell(left, "plan_relationship")
                right_rel = cell(right, "plan_relationship")
                if left_rel.get("status") != "observed" or right_rel.get("status") != "observed":
                    continue
                if "unresolved" in (left_rel.get("value"), right_rel.get("value")):
                    gaps.append({"contract": "measure_coherence", "reason": left + " and " + right + ": near-simultaneous plans cannot remain unresolved"})
                    continue
                if left_rel.get("value") != "independent" or right_rel.get("value") != "independent":
                    continue
                if left_rel.get("plan_link_basis") or right_rel.get("plan_link_basis"):
                    continue
                gaps.append({"contract": "measure_coherence", "reason": left + " and " + right + ": plans within 14 days are both independent; set related_plan_id or record plan_link_basis"})
    return gaps


def review_gaps(work, mode, entities, decisions, sources):
    event_mode = mode == "events"
    filename = "event_candidate_review.csv" if event_mode else "filing_amount_followup.csv"
    required = (
        ("candidate_id", "company", "reported_date", "source_url", "affected_scope",
         "disposition", "plan_id", "evidence_url", "reason")
        if event_mode else
        ("company_id", "variable", "source_id", "text_sha256", "section", "fiscal_period", "result")
    )
    gaps = []

    def gap(reason):
        gaps.append({"contract": "delivery_review", "reason": reason})

    try:
        with (work / filename).open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if not set(required).issubset(reader.fieldnames or ()):
                raise ValueError("Missing required columns")
            rows = [{key: (row.get(key) or "").strip() for key in required} for row in reader]
    except (OSError, ValueError, csv.Error) as exc:
        gap(f"{filename}: {exc}")
        return gaps

    if event_mode:
        from .event_sources import is_event_source
        seen, included = set(), set()
        ready_pairs = {(src.get("plan_id"), src.get("source_url")) for src in sources.values()
                       if is_event_source(src)}
        for row in rows:
            cid, disposition, plan = (row[key] for key in ("candidate_id", "disposition", "plan_id"))
            if not cid or cid in seen or not all(row[key] for key in ("company", "source_url", "reason")):
                gap(f"Invalid or duplicate candidate: {cid}")
            seen.add(cid)
            if disposition in {"included", "merged"}:
                if plan not in entities or (plan, row["evidence_url"]) not in ready_pairs:
                    gap(f"Candidate {cid} lacks a registered plan or ready evidence source")
                elif disposition == "included":
                    included.add(plan)
            elif disposition == "unresolved":
                gap(f"Unresolved event candidate: {cid}")
            elif disposition != "excluded" or plan:
                gap(f"Invalid disposition or plan link for candidate: {cid}")
        recorded_urls = {row["source_url"] for row in rows} | {row["evidence_url"] for row in rows}
        try:
            with (work / "tracker_seed.csv").open(encoding="utf-8-sig", newline="") as handle:
                seed_reader = csv.DictReader(handle)
                if not {"candidate_id", "tracker", "source_url"}.issubset(seed_reader.fieldnames or ()):
                    raise ValueError("Missing required columns")
                seed_ids = set()
                for seed in seed_reader:
                    cid = (seed.get("candidate_id") or "").strip()
                    if not cid or cid in seed_ids or not seed.get("tracker") or not seed.get("source_url"):
                        gap(f"Invalid or duplicate tracker seed: {cid}")
                    elif cid not in seen:
                        gap(f"Tracker seed has no candidate disposition: {cid}")
                    seed_ids.add(cid)
        except (OSError, ValueError, csv.Error) as exc:
            gap(f"tracker_seed.csv: {exc}")
        for url in sorted({url for _, url in ready_pairs if url} - recorded_urls):
            gap(f"Ready event source has no candidate disposition: {url}")
        for plan in sorted(set(entities) - included):
            gap(f"Registered plan lacks an included candidate: {plan}")

        return gaps

    by_company = {}
    for eid, entity in entities.items():
        by_company.setdefault(entity["company_id"], set()).add(eid)
    checked = set()
    for row in rows:
        source = sources.get(row["source_id"], {})
        if (source.get("status") != "ready" or not row["text_sha256"]
                or source.get("text_sha256") != row["text_sha256"]
                or source.get("company_id") != row["company_id"]
                or not all(row[key] for key in ("section", "fiscal_period", "result"))):
            gap(f"Invalid or stale amount follow-up: {row['company_id']} / {row['variable']}")
            continue
        checked.add((row["company_id"], row["variable"]))
    for company, entity_ids in sorted(by_company.items()):
        for variable in AMOUNTS:
            if all(decisions.get(f"{eid}|{variable}", {}).get("value") is None for eid in entity_ids):
                if (company, variable) not in checked:
                    gap(f"Missing amount follow-up: {company} / {variable}")
    return gaps
