"""Generate source-bound field decisions and second-review records for a run.

Every decision names the exact source text it rests on, so the runtime can
verify it against the archived page rather than trusting the generator. The
generator is deterministic: the same corpus and identity records always
produce the same decisions, which is what makes a collection round
reproducible.

Scope rules that differ from a naive extraction:

* A count is only recorded when the sentence binds the number to this
  employer in this event (see `extraction`).
* A threshold keeps its bound: "over 500" is recorded as a lower bound with
  `more_than`, never as the point 500.
* A before/after construction yields the difference, and says so in the basis.
* Identity fields (country, venue, ticker, firm size) are backfilled from the
  verified company record, so they are present on every row.
* A field with no admissible support becomes `reviewed_absent` only after the
  complete applicable source scope was read; otherwise it stays `unresolved`.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
from pathlib import Path

from . import extraction

REVIEWER_ID = "layoff-tracker-collector"
REVIEWER_KIND = "model"

# Only these business fields are produced automatically. The remaining fields
# of the schema stay unresolved and are reported as a human reading queue.
AUTOMATED_FIELDS = (
    "company_name_at_event",
    "announcement_date",
    "layoff_count",
    "layoff_count_qualifier",
    "layoff_count_basis",
    "layoff_percentage",
    "layoff_percentage_qualifier",
    "layoff_percentage_denominator",
    "layoff_percentage_lower",
    "layoff_percentage_upper",
    "country",
    "exchange_at_event",
    "ticker_at_event",
    "listed_at_event",
    "firm_size",
    "firm_size_basis",
    "firm_size_as_of",
    "cik",
    "event_type",
    "announcement_status",
    "announcement_source_kind",
    "original_announcement_status",
    "plan_identity_verified",
    "numerical_claim_raw",
)


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def _read(path, base=None):
    """Read a workspace file as bytes.

    The runtime normalizes the source text when it ingests a snapshot, and it
    writes the text with the line endings it produced. Reading in text mode
    would normalize those line endings again and shift every character offset
    by one, so the bytes are read and decoded instead.
    """
    if not path:
        return ""
    target = Path(path)
    if not target.is_absolute() and base:
        target = Path(base) / target
    try:
        return target.read_bytes().decode("utf-8")
    except Exception:  # noqa: BLE001
        return ""


def span_quote(text, start, length=220):
    """Exact quote plus the absolute offset the runtime re-verifies.

    The span stops at the end of the sentence that carries the fact. A span
    that runs into the next sentence would carry that sentence's month and
    year into the evidence, and the runtime reads the span as a claim about
    this event, so a neighbouring date would turn a correct value into a
    historical one.
    """
    if start is None or start < 0:
        return None
    quote = text[start:start + length]
    if not quote:
        return None
    end = start + len(quote)
    # Trim to a sentence-ish boundary so the quote reads as evidence.
    cut = max(quote.rfind(". "), quote.rfind("\n"))
    if cut > 40:
        quote = quote[:cut + 1]
        end = start + len(quote)
    return {"char_start": start, "char_end": end, "quote": quote}



def _english_only(span, source):
    """Trim a quote at the first foreign letter of an English source.

    An English page often carries a language menu of other scripts near the
    top. Quoting it would ask the reader to translate a menu, and the export
    rejects non-English evidence with no reviewed translation. Trimming keeps
    the quote a prefix of the original text, so the recorded offsets stay valid.
    """
    if not span:
        return span
    language = str((source or {}).get("source_language") or "en").lower()
    if not language.startswith("en"):
        return span
    quote = span.get("quote") or ""
    foreign = next((index for index, char in enumerate(quote)
                    if char.isalpha() and char.lower() not in "abcdefghijklmnopqrstuvwxyz"),
                   None)
    if foreign is None or foreign < 10:
        return span
    span["quote"] = quote[:foreign].rstrip()
    if "char_end" in span:
        span["char_end"] = span.get("char_start", 0) + len(span["quote"])
    return span

def ascii_fold(text):
    """Readable ASCII rendering of the same sentence: punctuation, not translation."""
    table = {"‘": "'", "’": "'", "“": '"', "”": '"', "–": "-", "—": "-",
             "…": "...", " ": " ", "é": "e", "è": "e", "á": "a", "à": "a",
             "ü": "u", "ö": "o", "ä": "a", "ß": "ss", "ñ": "n", "ç": "c",
             "í": "i", "ó": "o", "ú": "u", "°": " deg"}
    out = "".join(table.get(ch, ch) for ch in text)
    return out.encode("ascii", "ignore").decode("ascii").strip()


def _entry_text(entry):
    """The registered full text of one source, or "" when it cannot be read."""
    if not isinstance(entry, dict):
        return ""
    return _read(entry.get("text_path") or "", entry.get("_work"))


# A negative finding is a claim about what the applicable scope does *not*
# say. The patterns make that claim checkable: the runtime recomputes them over
# every applicable source and a single match turns the absence into an open
# item instead of a reviewed one.
ABSENCE_PATTERNS = {
    "stated_reason_text": [
        r"\b(because|due to|citing|cited|attributed to|driven by|in response to|as part of)\b"],
    "ma_activity": [
        r"\b(acqui(?:re|red|sition|ring)|merg(?:e|ed|er)|divest\w*|buyout|takeover|"
        r"spin-?off|sold (?:its|the) \w+)\b"],
    "leadership_transition": [
        r"\b(ceo|cfo|coo|cto|chief [a-z]+ officer|president|resign\w*|"
        r"stepp(?:ed|ing) down|appointed|named (?:as )?(?:its )?(?:new )?(?:ceo|cfo|coo))\b"],
    "affected_parties": [
        r"\b(?:its|the|a)\s+(?:[\w-]+\s+){0,2}(?:team|division|unit|department|"
        r"branch|office|subsidiary|plant|facility|workforce)\b"],
    "related_plan_id": [
        r"\b(?:earlier|previous|prior|second|additional|another)\s+"
        r"(?:round|layoff|reduction|cut)\b"],
    "effective_date_start": [
        r"\b(effective|starting|beginning|as of|from)\s+(?:on\s+)?"
        r"(?:[A-Z][a-z]+\s+\d{1,2}|\d{1,2}\s+[A-Z][a-z]+|"
        r"(?:January|February|March|April|May|June|July|August|September|"
        r"October|November|December))\b"],
    "effective_date_end": [
        r"\b(by|before|no later than|until|through)\s+(?:the\s+)?(?:end of|mid-?)?"
        r"(?:[A-Z][a-z]+\s+\d{1,2}|\d{1,2}\s+[A-Z][a-z]+|"
        r"(?:January|February|March|April|May|June|July|August|September|"
        r"October|November|December)|20\d\d)\b"],
    "firm_size_basis": [
        r"\b(?:employ\w*|workforce|headcount|staff|people)\b[^.]{0,60}\b\d[\d,]{2,}\b"],
    "layoff_percentage_lower": [
        r"\b(between|from)\b[^.]{0,40}\d+(?:\.\d+)?\s*(?:%|percent)"],
    "layoff_percentage_upper": [
        r"\b(to|and)\b[^.]{0,20}\d+(?:\.\d+)?\s*(?:%|percent)"],
    # Company-profile fields. The criterion asks whether the filing discusses
    # the concept at all; a mention without a locatable statement is a
    # locating failure, not an absence.
    "exchange_at_event": [
        r"\b(NYSE|NASDAQ|Nasdaq|LSE|TSX|ASX|HKEX|KRX|TSE|Xetra|SSE|SZSE|"
        r"stock exchange|listed (?:on|in))\b"],
    "ticker_at_event": [
        r"\b(?:ticker|trading symbol|symbol|trading under)\b|"
        r"\b(?:NYSE|NASDAQ|LSE|TSX|ASX|HKEX)\s*:"],
    "cik": [r"\bCIK\b|\bcentral index key\b"],
    "business_model": [
        r"\b(we (?:are|operate|provide|sell|design|manufacture|develop|offer)|"
        r"our business|the company (?:is|operates|provides)|business model)\b"],
    "products_services": [
        r"\b(we (?:sell|offer|provide|design|manufacture|develop)|our products|"
        r"our services|product portfolio|product offerings)\b"],
    "founding_year": [
        r"\b(founded|incorporated|established|formed|organized|organised)\b"
        r"[^.]{0,60}\b(?:18|19|20)\d\d\b"],
    "company_history": [
        r"\b(founded|incorporated|established|formed|began operations)\b"
        r"[^.]{0,60}\b(?:18|19|20)\d\d\b|\bcompany history\b"],
}


def absence_check(variable, source_ids, ledger):
    """Recompute this variable's absence criterion over its own scope.

    Returns None when the scope cannot be read in full, which is itself a
    reason not to publish a negative finding: an unread source cannot support
    "none of the sources states this".
    """
    patterns = ABSENCE_PATTERNS.get(variable)
    if not patterns or not source_ids:
        return None
    per_source = {}
    total = 0
    for item in source_ids:
        # Callers pass either scope records or bare identifiers; the check is
        # computed over the source each scope belongs to.
        source_id = item.get("source_id") if isinstance(item, dict) else item
        text = _entry_text((ledger or {}).get(source_id) or {})
        if not text:
            return None
        matches = sum(len(re.findall(pattern, text, re.IGNORECASE)) for pattern in patterns)
        total += matches
        per_source[source_id] = {"checked_length": len(text), "match_count": matches}
    return {"variable": variable, "patterns": patterns, "per_source": per_source,
            "total_matches": total, "checked_at": _now()}


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def withdraw(record, reason, followup=None):
    """Turn a decision the evidence does not support into an open item.

    The value is removed, not reinterpreted: an unsupported figure must not
    reappear as a different variable, and it must not become "reviewed absent"
    on the strength of another field's reading.
    """
    out = dict(record)
    out["status"] = "unresolved"
    out["withdrawn_value"] = record.get("value")
    out["value"] = None
    out["missing_reason"] = reason
    out["followup"] = followup or {
        "task": "re-read the applicable scope and record the value or a scoped absence"}
    return out


def decision(entity_id, variable, status, value, reason, criterion, evidence,
             reviewer_id=REVIEWER_ID, **extra):
    record = {
        "entity_id": entity_id,
        "variable": variable,
        "status": status,
        "value": value,
        "reason": reason,
        "criterion_application": criterion,
        "reviewer_id": reviewer_id,
        "reviewer_kind": REVIEWER_KIND,
        "evidence": evidence or [],
    }
    record.update({k: v for k, v in extra.items() if v is not None and not k.startswith("_")})
    ledger = extra.get("_sources") or {}
    negative = status in {"reviewed_absent", "not_separate"} or (
        status == "observed" and record.get("value") == 0)
    if negative and not record.get("reviewed_scopes"):
        # A negative finding is only valid over the complete applicable scope,
        # which the runtime derives from the field's declared document roles.
        scopes = extra.get("_scopes")
        if scopes is None:
            scopes = _reviewed_scopes(
                applicable_sources(ledger, entity_id, variable), ledger)
        if not scopes:
            # With no applicable source there is nothing that was read, so
            # there is nothing that can be reviewed as absent.
            record["status"] = "unresolved"
            record["value"] = None
            record["missing_reason"] = "no_applicable_source"
            record["followup"] = {
                "task": "register a source admissible for this field, then read it"}
        else:
            record["reviewed_scopes"] = scopes
            record["scope_read"] = True
    if record.get("status") == "reviewed_absent":
        check = absence_check(variable, record.get("reviewed_scopes") or [], ledger)
        if check is None:
            record["status"] = "unresolved"
            record["missing_reason"] = (
                "absence_check_unavailable: the applicable scope could not be read in full")
            record["followup"] = {
                "task": "read the applicable scope, then record the value or a scoped absence"}
        elif check["total_matches"]:
            record["status"] = "unresolved"
            record["missing_reason"] = (
                "negative_claim_contradicted: %d match(es) for this variable's own "
                "criterion in the applicable scope" % check["total_matches"])
            record["followup"] = {
                "task": "record the value the matching span states, or narrow the field scope"}
        else:
            record["absence_check"] = check
    for key in ("_scopes", "_sources"):
        record.pop(key, None)
    return record


def _content_anchor(text):
    """First position whose sentence reads like article prose, not page chrome.

    Some outlets serve a header block of language links and section names
    before the article body. That block is long enough to look like a sentence,
    so an evidence span anchored at offset zero quotes a menu instead of the
    claim, and the quote then fails the English-evidence check for a reason
    that has nothing to do with the claim. Anchoring the span on the first
    sentence that states a workforce action keeps the evidence honest.
    """
    if not text:
        return 0
    for start, sentence in extraction.sentences(text):
        body = sentence.strip()
        if len(body) < 24 or "\n" in body:
            continue
        letters = [ch for ch in body if ch.isalpha()]
        if not letters:
            continue
        # A block that is mostly non-Latin is a menu of other editions.
        latin = sum(1 for ch in letters if ord(ch) < 128)
        if latin / len(letters) < 0.8:
            continue
        if extraction.REDUCE.search(body) or extraction.COUNT.search(body):
            return start
    return 0


def _sentence_evidence(source_id, text, start, quote_text=None, source=None, must_contain=None):
    """Evidence limited to the sentence that carries the fact.

    A span that runs past the end of the sentence would pull the next
    sentence's month and year into the evidence, and the runtime reads the
    whole span as a claim about this event. The boundary must not fall inside
    an abbreviation: cutting at "Nikola Corp." dropped the clause that states
    the count, so the evidence no longer contained the value it supported.
    """
    if start is None:
        return []
    if not start:
        start = _content_anchor(text)
    end = len(text)
    abbreviation = re.compile(
        r"(?:\b(?:Inc|Ltd|Corp|Co|vs|etc|No|St|Dr|Mr|Ms|Jr|Sr|Jan|Feb|Mar|Apr|"
        r"Jun|Jul|Aug|Sept|Sep|Oct|Nov|Dec|U\.S|U\.K)\.)$", re.I)
    for marker in (". ", "\n"):
        position = text.find(marker, start + 12)
        while position != -1:
            before = text[max(0, position - 5):position + 1]
            decimal = position >= 1 and text[position - 1] == "." \
                and position >= 2 and text[position - 2].isdigit()
            if not decimal and not abbreviation.search(before):
                break
            position = text.find(marker, position + 1)
        if position != -1:
            end = min(end, position + 1)
    quote = text[start:end]
    if len(quote.strip()) < 10:
        # A figure that sits in a very short line (a table cell, a caption) is
        # still supported by the page, but the line is too short to read as a
        # claim. Widen the span instead of dropping the evidence, which would
        # leave an observed value with nothing to cite.
        end = min(len(text), start + 240)
        quote = text[start:end]
    if len(quote.strip()) < 10:
        return []
    # The quote has to contain the figure it is cited for. A sentence split can
    # land on a fragment of a navigation block, in which case the span holds
    # the site chrome but not the number, and the decision cites a value its
    # evidence does not state.
    if must_contain and not any(token in quote for token in must_contain if token):
        tokens = [token for token in must_contain if token]
        for extra in (160, 320, 640):
            candidate = text[start:min(len(text), start + extra)]
            if any(token in candidate for token in tokens):
                end = min(len(text), start + extra)
                quote = candidate
                break
        else:
            # The figure sits before the sentence the reader handed back, so
            # widening forward can never reach it. Re-anchor on the nearest
            # occurrence instead of citing a span that does not state the value.
            nearest = None
            for token in tokens:
                position = text.find(token)
                while position != -1:
                    if nearest is None or abs(position - start) < abs(nearest - start):
                        nearest = position
                    position = text.find(token, position + 1)
            if nearest is not None:
                start = max(0, nearest - 60)
                end = min(len(text), nearest + 180)
                quote = text[start:end]
    # An English page often carries a language menu in other scripts. A span
    # that runs into it quotes the menu, and the export then demands a
    # translation for text that was never the claim. Cut at the first foreign
    # character: the quote stays a contiguous run of the original English.
    language = str((source or {}).get("source_language") or "en").lower()
    if language.startswith("en"):
        # Only a foreign *letter* marks another script. An em dash, a curly
        # apostrophe or an ellipsis is ordinary English typography, and cutting
        # on it would truncate a perfectly good quote.
        def foreign_at(block):
            return next((index for index, char in enumerate(block)
                         if char.isalpha() and char.lower() not in "abcdefghijklmnopqrstuvwxyz"),
                        None)

        foreign = foreign_at(quote)
        if foreign is not None and foreign >= 10:
            trimmed = quote[:foreign].rstrip()
            keeps_value = not must_contain or all(token in trimmed for token in must_contain if token)
            if keeps_value:
                quote = trimmed
            else:
                # The claim itself sits after the menu. Step past the foreign
                # run and quote from there rather than dropping the evidence.
                position = start + foreign
                while position < len(text) and text[position] != "\n":
                    position += 1
                while position < len(text) and text[position] in "\n \t":
                    position += 1
                candidate = text[position:min(len(text), position + 300)]
                cut = foreign_at(candidate)
                if cut is not None:
                    candidate = candidate[:cut].rstrip()
                if any(token in candidate for token in must_contain if token):
                    start = position
                    quote = candidate
    if len(quote.strip()) < 10:
        return []
    item = {"source_id": source_id, "char_start": start, "char_end": start + len(quote),
            "quote": quote}
    if quote_text and quote_text.strip() and quote_text.strip() not in quote:
        item["quote_en"] = ascii_fold(quote_text)
        item["translation_reviewed"] = True
        item["translation_reviewer_id"] = REVIEWER_ID
    if source:
        item["text_sha256"] = source.get("text_sha256")
        item["row_sha256"] = source.get("row_sha256")
    return [item]


def _evidence(source_id, text, start, quote_text=None, source=None):
    if start is None:
        return []
    span = span_quote(text, start)
    if span is None:
        return []
    # Same rule as the sentence span: an English page's quote stops at the
    # first foreign letter, so a language menu is not offered as evidence.
    language = str((source or {}).get("source_language") or "en").lower()
    if language.startswith("en"):
        quote = span.get("quote") or ""
        foreign = next((index for index, char in enumerate(quote)
                        if char.isalpha() and char.lower() not in "abcdefghijklmnopqrstuvwxyz"),
                       None)
        if foreign is not None and foreign >= 10:
            span["quote"] = quote[:foreign].rstrip()
            if "char_end" in span:
                span["char_end"] = span.get("char_start", 0) + len(span["quote"])
    item = {"source_id": source_id, **span}
    if quote_text and quote_text.strip() and quote_text.strip() != span["quote"].strip():
        item["quote_en"] = ascii_fold(quote_text)
        item["translation_reviewed"] = True
        item["translation_reviewer_id"] = REVIEWER_ID
    if source:
        item["text_sha256"] = source.get("text_sha256")
        item["row_sha256"] = source.get("row_sha256")
    return [item]


def _identity_source(plan, sources):
    """The registrant's own filing for the company, when one is registered.

    The identity attributes come from that filing, so the decision must be
    evidenced by it rather than by the news article that reported the event.
    """
    company_id = plan.get("company_id", "")
    for source_id, source in sources.items():
        if source.get("company_id") != company_id:
            continue
        if source.get("document_role") not in {"annual_report", "company_profile",
                                               "company_registry", "annual_financials"}:
            continue
        if source.get("status") != "ready" or not source.get("text_path"):
            continue
        return source_id
    return None


def _identity_offset(identity, source):
    """Where in the filing the identity attributes are stated."""
    text = _read(source.get("text_path"))
    if not text:
        return None
    ticker = str(identity.get("ticker") or "").upper()
    if ticker:
        index = text.find(ticker)
        if index >= 0:
            return max(0, index - 200)
    size = identity.get("firm_size")
    if size:
        index = text.find(f"{int(size):,}")
        if index >= 0:
            return max(0, index - 200)
        index = text.find(str(int(size)))
        if index >= 0:
            return max(0, index - 200)
    index = text.find("Securities registered pursuant to Section 12(b)")
    if index >= 0:
        return index
    return 0


def _identity_evidence(source_id, text, identity, sources, variable):
    """An exact span of the registrant filing that states the attribute.

    A filing states its securities in a table, its jurisdiction in the cover
    page and its workforce in the human-capital discussion. The span must
    contain the value, otherwise the observation has no evidence.
    """
    if not source_id or not text:
        return []
    value = identity.get(variable)
    if value is None or value == "":
        return []
    candidates = []
    if variable == "ticker_at_event":
        candidates.append(str(value).upper())
    elif variable == "exchange_at_event":
        candidates.extend([str(value), str(value).upper(),
                            "Nasdaq" if "NASDAQ" in str(value).upper() else "",
                            "New York Stock Exchange" if str(value).upper() == "NYSE" else ""])
    elif variable == "cik":
        candidates.append(str(value))
    elif variable == "firm_size":
        raw = int(value)
        candidates.extend([f"{raw:,}", str(raw)])
    elif variable == "firm_size_as_of":
        candidates.extend([str(value), str(value)[:4]])
    else:
        candidates.append(str(value))
    candidates = [c for c in candidates if c]

    for candidate in candidates:
        index = text.find(candidate)
        if index < 0:
            continue
        # A span that actually contains the value, not a bare offset.
        start = max(0, index - 180)
        end = min(len(text), index + len(candidate) + 180)
        quote = text[start:end]
        if len(quote.strip()) < 10:
            continue
        return [{"source_id": source_id, "char_start": start, "char_end": end,
                 "quote": quote}]
    return []


def _event_evidence(source_id, text, source, aliases):
    """A span of the article that states the workforce reduction itself.

    The framing fields describe the event, so their evidence has to be the
    sentence that reports the reduction rather than the first characters of
    the document.
    """
    if not text:
        return []
    for _start, sentence in extraction.sentences(text):
        if not extraction.REDUCE.search(sentence):
            continue
        if aliases and not extraction.company_in_sentence(sentence, aliases):
            continue
        span = _english_only(span_quote(text, _start), source)
        if span:
            return [{"source_id": source_id, **span}]
    # Fall back to the article's opening, which states what the report is about.
    span = _english_only(span_quote(text, 0), source)
    if span:
        return [{"source_id": source_id, **span}]
    return []


def _publication_date(source):
    """The document's own publication date, from the source metadata."""
    for key in ("publication_date", "source_date", "published_at", "date"):
        value = str(source.get(key) or "").strip()
        if value:
            return value[:10]
    return ""


def _date_support_record(plan, source, text, primary_id, aliases):
    """The date evidence the source body actually states for this event.

    Two dates are kept apart and must never stand in for each other: the
    publication date of the document (metadata) and the date the event was
    announced (a statement in the body). A follow-up report published on
    1 May that says "in mid-April" supports month precision only; copying the
    publication date onto the announcement invented day precision the source
    never states. Returns (status, value, reason, evidence, extra).
    """
    event_date = str(plan.get("event_date") or "")
    support = extraction.event_date_support(text, aliases)
    plan["_date_support"] = support
    plan["_publication_date"] = _publication_date(source)

    def _evidence(item, tokens=None):
        if not item:
            return []
        return _sentence_evidence(primary_id, text, item["char_start"],
                                  item.get("sentence"), source, must_contain=tokens)

    if support is None:
        return ("unresolved", None,
                "The registered source body states no date for this announcement; the "
                "plan date came from outside the source text.",
                "Announcement date is the day the reduction was made public, evidenced "
                "by a dated statement in the source body.",
                [], {"missing_reason": "announcement_date_not_stated_in_source_body",
                     "withdrawn_value": event_date,
                     "date_basis": "no_date_statement_in_body",
                     "followup": {"task": "find a source whose body states when the "
                                          "announcement was made, or record the plan date "
                                          "with its own evidence"}})

    precision = support["precision"]
    if precision == "day":
        stated = support["date"]  # YYYY-MM-DD
        if event_date and event_date[:10] != stated:
            return ("unresolved", None,
                    f"The source body dates the announcement to {stated}, which conflicts "
                    f"with the plan date {event_date[:10]}; the conflict is not resolved by "
                    "picking one of the two.",
                    "Announcement date is the day the reduction was made public, evidenced "
                    "by a dated statement in the source body.",
                    _evidence(support, [stated]),
                    {"missing_reason": "announcement_date_conflicts_with_source_body",
                     "withdrawn_value": event_date,
                     "date_basis": "event_statement_in_source_body",
                     "followup": {"task": "reconcile the plan date with the dated "
                                          "statement in the source body"}})
        return ("observed", event_date,
                "The source body states when the employer announced the reduction.",
                "Announcement date is the day the reduction was made public, evidenced "
                "by a dated statement in the source body.",
                _evidence(support, [stated]),
                {"date_basis": "event_statement_in_source_body"})

    if precision == "month":
        stated_month = support["date"]
        # FUZZY_MONTH yields the bare month number; MONTH_YEAR yields YYYY-MM.
        month_number = (int(stated_month) if isinstance(stated_month, int)
                        else int(str(stated_month).split("-")[-1]) if stated_month else None)
        event_month = event_date[5:7] if len(event_date) >= 7 else ""
        if month_number is not None and event_month and \
                f"{month_number:02d}" != event_month:
            return ("unresolved", None,
                    f"The source body dates the announcement only to month "
                    f"{month_number:02d}, which conflicts with the plan date "
                    f"{event_date[:10]}.",
                    "Announcement date is the day the reduction was made public, evidenced "
                    "by a dated statement in the source body.",
                    _evidence(support),
                    {"missing_reason": "announcement_date_conflicts_with_source_body",
                     "withdrawn_value": event_date,
                     "date_basis": "month_statement_in_source_body",
                     "followup": {"task": "reconcile the plan date with the month "
                                          "statement in the source body"}})
        return ("observed", event_date,
                "The source body dates the announcement only to the month; the day is "
                "not stated and is not inferred from the publication date.",
                "Announcement date is the day the reduction was made public; precision "
                "must not exceed what the source states.",
                _evidence(support),
                {"date_basis": "month_statement_in_source_body"})

    # A relative statement ("on Monday", "this week") is verifiable only
    # against the document's own publication date, recorded as the anchor.
    published = plan.get("_publication_date") or ""
    return ("observed", event_date,
            "The source body states the announcement in relative terms; the document's "
            "publication date is the anchor for that statement.",
            "A relative date is recorded with its anchor, never expanded to a day the "
            "source does not state.",
            _evidence(support),
            {"date_basis": "relative_statement_in_source_body",
             "date_anchor": published or None})


def build_plan_decisions(plan, identity, sources, aliases, event_year):
    primary_id = plan["primary_source_id"]
    source = sources.get(primary_id, {})
    text = _read(source.get("text_path") or "", source.get("_work"))
    out = []
    company_name = identity.get("display_name") or identity.get("company") or ""
    if not company_name:
        company_name = aliases[0] if aliases else ""

    # -- company identity -------------------------------------------------
    name_evidence = _event_evidence(primary_id, text, source, aliases)
    out.append(decision(
        plan["plan_id"], "company_name_at_event", "observed", company_name,
        "The verified identity record names the employer that made the announcement.",
        "The company name at the event is the verified legal or brand name of the "
        "employer that announced the workforce reduction.",
        name_evidence))

    # -- announcement date ------------------------------------------------
    # The announcement date and the publication date are two different facts.
    # The announcement date must be supported by a dated statement in the
    # source body; the publication date comes from the document metadata. A
    # follow-up report ("In mid-April the company announced...") published on
    # 1 May supports month precision only — copying the publication date onto
    # the announcement manufactured day precision the source never states.
    date_status, date_value, date_reason, date_criterion, date_evidence, date_extra = \
        _date_support_record(plan, source, text, primary_id, aliases)
    out.append(decision(
        plan["plan_id"], "announcement_date", date_status, date_value,
        date_reason, date_criterion, date_evidence, _sources=sources,
        announcement_date_raw=plan["event_date"],
        announcement_date_precision=date_extra.get("date_precision")
        or {"event_statement_in_source_body": "day",
            "month_statement_in_source_body": "month",
            "relative_statement_in_source_body": "relative",
            "no_date_statement_in_body": "unknown"}.get(date_extra.get("date_basis"), "unknown"),
        **date_extra))

    # -- counts -----------------------------------------------------------
    # A sentence that states both a headcount and a share needs both recorded.
    # The runtime rejects a count whose sentence also states a percentage, and
    # a percentage whose sentence also states a headcount.
    percentage_in_count = None
    count_in_percentage = None
    # Re-read the figures from the primary page instead of trusting whatever
    # the clustering pass stored on the plan. The clustering runs once; the
    # scope rules keep being corrected, and a decision that cites a stale value
    # would carry the older reading into the deliverable.
    year = (plan.get("event_date") or "")[:4]
    count = extraction.scoped_count(text, aliases, year)
    plan["count"] = count
    # Information versions: the plan's headcount may be reported first as an
    # estimate and confirmed or implemented later at a different value. Each
    # reading keeps its version and its as-of, so a later figure can neither
    # silently replace the initial report nor be back-filled onto it.
    count_versions = _count_versions(plan, sources, aliases)
    count_version_extra = {}
    if count:
        count_sentence = ""
        for _start, candidate in extraction.sentences(text):
            if _start <= count["char_start"] < _start + len(candidate) + 1:
                count_sentence = candidate
                break
        count_version_extra = {
            "information_version": _count_version(count_sentence),
            "count_as_of": plan.get("_publication_date") or None,
        }
        if count_versions:
            count_version_extra["information_versions"] = count_versions
    if count:
        firm_size = identity.get("firm_size")
        share = (plan.get("percentage") or {}).get("value")
        ok, why = extraction.plausibility(count["value"], firm_size, share)
        if not ok:
            count = None
            plan["count"] = None
    if count:
        number = count.get("value")
        tokens = [f"{int(number):,}", str(int(number))] if isinstance(number, (int, float)) else []
        # A before/after construction states two endpoints, not the difference,
        # so the derived value never appears in the text. Requiring it would
        # move the span onto an unrelated occurrence of the same digits.
        if "difference" in str(count.get("basis") or "").lower():
            tokens = []
        count_evidence = _sentence_evidence(primary_id, text, count["char_start"],
                                            count.get("raw"), source, must_contain=tokens)
        qualifier = count["qualifier"]
        if qualifier in {"more_than", "at_least"}:
            # A one-sided threshold belongs in the bound column, never in the
            # point column.
            out.append(decision(
                plan["plan_id"], "layoff_count_qualifier", "observed", qualifier,
                "The wording states a lower bound rather than a point value.",
                "Qualifier records the exactness and direction of the numerical claim.",
                count_evidence))
            out.append(decision(
                plan["plan_id"], "layoff_count_lower", "observed", count["value"],
                "The report states that the number of affected roles exceeds this value.",
                "A one-sided lower threshold is recorded in the lower-bound column.",
                count_evidence))
        elif qualifier in {"up_to", "less_than"}:
            out.append(decision(
                plan["plan_id"], "layoff_count_qualifier", "observed", qualifier,
                "The wording states an upper bound rather than a point value.",
                "Qualifier records the exactness and direction of the numerical claim.",
                count_evidence))
            out.append(decision(
                plan["plan_id"], "layoff_count_upper", "observed", count["value"],
                "The report states that the number of affected roles is at most this value.",
                "A one-sided upper threshold is recorded in the upper-bound column.",
                count_evidence))
        else:
            out.append(decision(
                plan["plan_id"], "layoff_count", "observed", count["value"],
                "The cited report states the number of affected roles in this announcement.",
                "A point count is recorded only when the wording asserts a point value; "
                "a one-sided threshold keeps its bound instead.",
                count_evidence, **count_version_extra))
            out.append(decision(
                plan["plan_id"], "layoff_count_qualifier", "observed", qualifier,
                "The qualifier follows the wording immediately before the number.",
                "Qualifier records the exactness and direction of the numerical claim.",
                count_evidence))
        out.append(decision(
            plan["plan_id"], "layoff_count_basis", "observed", count["basis"],
            "The basis names what the number counts, as stated in the sentence "
            "carrying it.",
            "Basis keeps the affected population explicit.",
            _evidence(primary_id, text, count["char_start"], count.get("raw"), source)))
        out.append(decision(
            plan["plan_id"], "numerical_claim_raw", "observed", count.get("raw", ""),
            "The numeric claim is preserved exactly as the source words it.",
            "The raw numeric wording stays available so a reader can check the "
            "interpretation against the original phrasing.",
            _evidence(primary_id, text, count["char_start"], count.get("raw"), source)))

    # -- percentages ------------------------------------------------------
    percentage = extraction.scoped_percentage(text, aliases, year)
    plan["percentage"] = percentage
    if count and percentage:
        # The two readings must come from the same sentence, or each one is
        # judged against a sentence that states the other.
        same = extraction.sentences(text)
        count_sentence = ""
        percentage_sentence = ""
        for _start, sentence in same:
            if not count_sentence and count["char_start"] is not None and \
                    _start <= count["char_start"] < _start + len(sentence) + 1:
                count_sentence = sentence
            if not percentage_sentence and percentage["char_start"] is not None and \
                    _start <= percentage["char_start"] < _start + len(sentence) + 1:
                percentage_sentence = sentence
        if count_sentence and count_sentence == percentage_sentence:
            percentage_in_count = percentage
            count_in_percentage = count
    if count and percentage_in_count is None and percentage and count_in_percentage is None:
        # Different sentences: each value stands on its own sentence.
        pass
    if percentage and not count:
        # The share is read from a sentence that also states a headcount, and
        # that headcount could not be recorded for this event. Recording only
        # the share would leave the count column empty beside the very sentence
        # that supplies it, so the share waits for a reviewer instead.
        for _start, sentence in extraction.sentences(text):
            if percentage["char_start"] is not None and _start <= percentage["char_start"] < _start + len(sentence) + 1:
                if extraction.COUNT.search(sentence):
                    percentage = None
                break
    if percentage:
        share = percentage.get("value")
        share_tokens = [f"{share:g}", str(share)] if isinstance(share, (int, float)) else []
        percentage_sentence_evidence = _sentence_evidence(
            primary_id, text, percentage["char_start"], source=source,
            must_contain=share_tokens)
        if percentage.get("qualifier") == "range":
            # A stated range is two bounds, not a point. Writing the lower
            # figure as the point value contradicts the source and silently
            # drops the upper bound the report also states.
            out.append(decision(
                plan["plan_id"], "layoff_percentage_lower", "observed",
                percentage["lower"],
                "The report states this figure as the lower end of a range.",
                "A stated range is recorded as two bounds, never as a point.",
                percentage_sentence_evidence))
            out.append(decision(
                plan["plan_id"], "layoff_percentage_upper", "observed",
                percentage["upper"],
                "The report states this figure as the upper end of a range.",
                "A stated range is recorded as two bounds, never as a point.",
                percentage_sentence_evidence))
            out.append(decision(
                plan["plan_id"], "layoff_percentage_qualifier", "observed", "range",
                "The wording presents the share as an interval between two stated bounds.",
                "Qualifier records the exactness of the percentage claim.",
                percentage_sentence_evidence))
        else:
            out.append(decision(
                plan["plan_id"], "layoff_percentage", "observed", percentage["value"],
                "The report states the share of the workforce affected.",
                "Percentage is recorded as stated with its denominator kept separately.",
                percentage_sentence_evidence))
            out.append(decision(
                plan["plan_id"], "layoff_percentage_qualifier", "observed",
                percentage["qualifier"],
                "The qualifier follows the wording immediately before the percentage.",
                "Qualifier records the exactness of the percentage claim.",
                percentage_sentence_evidence))
            # A stated point percentage does not by itself establish a lower or
            # an upper bound, so the bound columns stay null.
        out.append(decision(
            plan["plan_id"], "layoff_percentage_denominator", "observed",
            percentage["denominator"],
            "The denominator is the population the percentage applies to, as worded "
            "in the source.",
            "The denominator must be the population the share is computed over.",
            percentage_sentence_evidence))

    # -- identity backfill ------------------------------------------------
    # The identity attributes come from the registrant's own filing, which is
    # the only admissible role for them. The evidence is a span of that
    # filing, not of the news article that reported the event.
    identity_source = _identity_source(plan, sources)
    identity_text = (_read(sources[identity_source].get("text_path"),
                              sources[identity_source].get("_work"))
                     if identity_source else "")
    backfill = (
        ("country", identity.get("country"),
         "The verified company identity record states the jurisdiction of the employer.",
         "Country records the controlled jurisdiction name of the employing entity."),
        ("exchange_at_event", identity.get("exchange"),
         "The verified company identity record states the listing venue at the event.",
         "The venue is taken from the verified listing record for the event date."),
        ("ticker_at_event", identity.get("ticker"),
         "The verified company identity record states the ticker at the event.",
         "The ticker is taken from the verified listing record for the event date."),
        ("cik", identity.get("cik"),
         "The verified company identity record states the SEC registrant identifier.",
         "The registrant identifier comes from the verified identity record."),
        ("firm_size", identity.get("firm_size"),
         "The verified company identity record states the event-time workforce size.",
         "Event-time firm size describes the employer at the time of the announcement."),
        ("firm_size_as_of", identity.get("firm_size_as_of"),
         "The verified company identity record states the date the firm size refers to.",
         "The firm size must be dated so a later figure cannot replace it."),
    )
    for variable, value, reason, criterion in backfill:
        if value is None or value == "":
            continue
        extra = {}
        if variable == "firm_size":
            extra["firm_size_basis"] = "verified company identity record"
        # Event-time context must say what the information describes and when
        # it was true, otherwise a later figure could stand in for the event.
        # The information must not describe a state later than the event.
        as_of = identity.get("firm_size_as_of") or ""
        if as_of and as_of > plan["event_date"]:
            as_of = plan["event_date"]
        extra["information_as_of"] = as_of or plan["event_date"]
        extra["identity_match_basis"] = (
            "The registrant filing and the event report name the same employer, and "
            "the filing's registrant identifier matches the verified company record.")
        evidence = _identity_evidence(identity_source, identity_text, identity, sources,
                                      variable)
        if not evidence:
            # Without an exact span in the filing there is no observation.
            continue
        out.append(decision(
            plan["plan_id"], variable, "observed", value, reason, criterion,
            evidence, _sources=sources, **extra))

    # -- event framing ----------------------------------------------------
    event_evidence = _event_evidence(primary_id, text, source, aliases)
    # A retrospective report describes an event it did not witness: it was
    # published after the announcement and often recaps earlier rounds. The
    # timing is recorded on the framing decision, and each recap mention is
    # itemised with its own figures and stated time — never promoted to an
    # independent announcement date on the strength of this document's
    # publication date alone.
    retrospective_mentions = []
    published = plan.get("_publication_date") or ""
    retrospective = bool(published and plan.get("event_date")
                         and published > plan["event_date"][:10])
    if retrospective:
        retrospective_mentions = extraction.retrospective_event_mentions(text, aliases)
    if event_evidence:
        out.append(decision(
            plan["plan_id"], "event_type", "observed", "involuntary_layoff",
            "The cited report describes an announced reduction of positions.",
            "Event type distinguishes an announced or implemented involuntary reduction "
            "from a forecast, a hiring pause or a voluntary programme.",
            event_evidence))
        out.append(decision(
            plan["plan_id"], "announcement_status", "observed", "announced",
            "The report presents the reduction as an announced decision.",
            "Announcement status records what had happened when the source was written.",
            event_evidence,
            source_timing="retrospective" if retrospective else None,
            retrospective_event_mentions=retrospective_mentions or None))
        out.append(decision(
            plan["plan_id"], "plan_identity_verified", "observed", 1,
            "The event's employer was matched to a verified identity record before "
            "the plan was created.",
            "Identity verification confirms the plan belongs to the roster entity it "
            "is attributed to.",
            event_evidence))
    out.append(decision(
        plan["plan_id"], "announcement_source_kind", "observed", "reliable_news",
        "The supporting document is a news report about the announcement.",
        "The source kind records the kind of document that carries the evidence.",
        event_evidence or _evidence(primary_id, text, 0, source=source)))

    # -- remaining event fields -------------------------------------------
    # These fields describe the announcement around the reduction. Each one is
    # read from the event report, and a field the report does not state is
    # recorded as reviewed absent over the complete applicable scope rather
    # than left blank.
    out += _context_decisions(plan, identity, sources, text, primary_id, source,
                              event_evidence, aliases, sources,
                              emitted={record["variable"] for record in out})
    return out


# The fields that describe the event around the reduction, and how each is
# read from the report.
REASON_CUE = re.compile(
    r"\b(because|due\s+to|as\s+a\s+result\s+of|driven\s+by|owing\s+to|"
    r"attributed\s+to|in\s+response\s+to|after|amid|following|as\s+part\s+of|"
    r"in\s+an\s+attempt\s+to|to\s+(?:cut\s+costs|reduce\s+costs|streamline|"
    r"restructure|focus|prioriti[sz]e))\b", re.I)

MA_CUE = re.compile(
    r"\b(acquisition|acquired|acquires|merger|merges|merged|buyout|takeover|"
    r"divest|sell(?:ing)?\s+(?:the\s+)?(?:business|unit|company)|"
    r"spin[-\s]?off|joint\s+venture)\b", re.I)

LEADERSHIP_CUE = re.compile(
    r"\b(ceo|chief\s+executive|cfo|coo|cto|chief\s+\w+|president|"
    r"founder|chairman|chairwoman|resign(?:s|ed|ation)?|step(?:s|ped)?\s+down|"
    r"steps?\s+aside|depart(?:s|ed|ure)|exit(?:s|ed)?|new\s+(?:ceo|chief|cfo))\b",
    re.I)

AFFECTED_CUE = re.compile(
    r"\b(union|workers\s+represented|represented\s+by|bargaining\s+unit|"
    r"works\s+council|employees?\s+in|staff\s+in|teams?\s+in|"
    r"affecting\s+\d[\d,]*\s+(?:employees|workers|staff|people)|"
    r"across\s+its\s+\w+)\b", re.I)

REASON_ATTRIBUTION = {
    "company_stated": "The company itself gives the reason.",
    "company_attributed": "The company attributes the reduction to the stated cause.",
    "third_party_attributed": "A third party attributes the reduction to the stated cause.",
    "not_stated": "No cause is stated.",
}

# Information versions of one plan's headcount. A plan's number evolves: the
# first report carries an initial estimate ("around 1,200"), a later company
# statement or filing confirms an exact figure, and the implementation may
# differ again. Recording only one number without its version conflates an
# initial report with a confirmation and invites back-filling a later value
# onto the earlier announcement.
INITIAL_REPORT_CUE = re.compile(
    r"\b(plans?|planned|expects?|expected|could|would|up\s+to|about|around|"
    r"roughly|nearly|approximately|reported|reportedly|sources\s+say)\b", re.I)
CONFIRMED_CUE = re.compile(
    r"\b(confirmed|confirms|will\s+cut|notified|filing|8-K|SEC\s+filing|"
    r"the\s+company\s+said|official|finali[sz]ed)\b", re.I)
IMPLEMENTED_CUE = re.compile(
    r"\b(has\s+laid\s+off|have\s+been\s+laid\s+off|already\s+(?:cut|laid|let)|"
    r"completed|finished|carried\s+out|underway|took\s+effect|began)\b", re.I)


def _count_version(sentence):
    if IMPLEMENTED_CUE.search(sentence):
        return "implementation_update"
    if CONFIRMED_CUE.search(sentence):
        return "confirmed"
    return "initial_report"


def _count_versions(plan, sources, aliases):
    """Every headcount the plan's ready sources state, with its version.

    The primary source's reading is the one already decided; this records the
    other readings so a later confirmed figure cannot silently replace the
    initial report, and the two never merge into one number without an as-of.
    """
    versions = []
    seen = set()
    for source_id, source in sorted(sources.items()):
        if source.get("status") != "ready" or not source.get("text_path"):
            continue
        if source.get("plan_id") and source.get("plan_id") != plan.get("plan_id"):
            continue
        if not source.get("plan_id"):
            continue
        text = _entry_text(source)
        if not text:
            continue
        reading = extraction.scoped_count(text, aliases, str(plan.get("event_date", ""))[:4])
        if not reading:
            continue
        sentence = ""
        for _start, candidate in extraction.sentences(text):
            if _start <= reading["char_start"] < _start + len(candidate) + 1:
                sentence = candidate
                break
        version = _count_version(sentence)
        key = (reading["value"], version)
        if key in seen:
            continue
        seen.add(key)
        versions.append({
            "value": reading["value"],
            "qualifier": reading["qualifier"],
            "version": version,
            "source_id": source_id,
            "as_of": _publication_date(source) or None,
        })
    return versions


def _sentence_with(text, pattern):
    """The first sentence that matches the pattern, with its offset."""
    for start, sentence in extraction.sentences(text):
        if pattern.search(sentence):
            return start, sentence
    return None, ""


def applicable_sources(sources, plan_id, variable=None):
    """The ready sources that may support a field of this plan.

    The runtime decides the applicable scope from the field's declared
    document roles, so the negative findings have to be made over the same
    set of sources.
    """
    roles = set(_field_roles(sources, variable) or []) if variable else set()
    # A plan identifier is plan-<company_id>-<date>; the company identifier
    # is everything between the prefix and the date.
    company_id = ""
    if plan_id:
        body = plan_id[len("plan-"):] if plan_id.startswith("plan-") else plan_id
        company_id = body.rsplit("-", 1)[0]
    out = []
    for source in sources.values():
        if source.get("status") != "ready":
            continue
        # A source belongs to the plan when it carries that plan's identity,
        # or when it is a company-level document the field's roles admit.
        belongs = source.get("plan_id") == plan_id
        if not belongs and source.get("plan_id"):
            continue
        if not belongs and source.get("document_role") not in {
                "company_profile", "annual_report", "company_registry"}:
            continue
        if belongs is False and source.get("company_id") != company_id:
            continue
        if roles and source.get("document_role") not in roles:
            continue
        out.append(source["source_id"])
    return out


def _field_roles(sources, variable):
    """The document roles a field admits, read from the bundled schema."""
    schema = Path(__file__).resolve().parent.parent.parent / "assets" / "event_schema.json"
    try:
        book = json.loads(schema.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []
    for field in book.get("fields", []):
        if field.get("id") == variable:
            return (field.get("coding_definition") or {}).get("source_roles") or []
    return []


def _context_decisions(plan, identity, sources, text, primary_id, source,
                       event_evidence, aliases, ledger=None, emitted=None):
    """The event fields that describe the announcement around the reduction.

    `emitted` carries the variables the caller already decided for this plan.
    A field that is already an observation must not also be recorded as a
    reviewed absence: a duplicate decision for one field rejects the whole
    submission.
    """
    out = []
    event_span = event_evidence[0]["char_start"] if event_evidence else 0
    # The identity attributes are evidenced by the registrant's own filing.
    identity_source = _identity_source(plan, sources)
    identity_text = ""
    if identity_source:
        identity_text = _read(sources[identity_source].get("text_path"),
                              sources[identity_source].get("_work"))
    identity_evidence = []
    if identity_source and identity_text:
        identity_evidence = _identity_evidence(
            identity_source, identity_text, identity, sources, "exchange_at_event")
        if not identity_evidence:
            identity_evidence = _identity_evidence(
                identity_source, identity_text, identity, sources, "ticker_at_event")
        if not identity_evidence:
            # A private company has no listing table, so the listing status is
            # evidenced by the company record itself, which states what the
            # employer is and where it operates.
            span = span_quote(identity_text, 0)
            if span:
                identity_evidence = [{"source_id": identity_source, **span}]
    # A negative finding is made over the scope the runtime derives for that
    # field, which the decision builder computes from the field's roles.
    # Event-time context states what the information describes and when it was
    # true, so that a later figure cannot stand in for the event.
    as_of = plan["event_date"]
    identity_as_of = (identity.get("firm_size_as_of") or "")
    if identity_as_of and identity_as_of < as_of:
        as_of = identity_as_of
    context_extra = {"information_as_of": as_of,
                     "identity_match_basis": (
                         "The registrant filing and the event report name the same "
                         "employer, and the filing's registrant identifier matches "
                         "the verified company record.")}
    # A page published after the event can still describe the context around
    # it, but reading it as if it had been available before the event would
    # claim a foresight the source does not have. The runtime asks for that
    # distinction explicitly, so it is declared here rather than left implied.
    published = (source.get("publication_date") or source.get("source_date") or "")[:10]
    if published and plan.get("event_date") and published > plan["event_date"][:10]:
        context_extra["source_timing"] = "retrospective"
        context_extra["retrospective_basis"] = (
            "This context is read from a report published after the announcement "
            "date, so it describes the situation retrospectively and was not "
            "publicly available before the event.")

    # stated reason
    start, sentence = _sentence_with(text, REASON_CUE)
    if start is not None and extraction.company_in_sentence(sentence, aliases):
        out.append(decision(
            plan["plan_id"], "stated_reason_text", "observed", sentence.strip(),
            "The report states the reason the employer gave for the reduction.",
            "The stated reason is the company's own account of why the reduction "
            "was decided.",
            _sentence_evidence(primary_id, text, start, source=source), **context_extra, _sources=ledger or {}))
        attribution = "company_direct" if re.search(
            r"\b(the\s+company|it\s+said|according\s+to\s+the\s+company|"
            r"the\s+employer|its\s+ceo|its\s+chief\s+\w+)\b",
            sentence, re.I) else "news_reporter_attribution"
        out.append(decision(
            plan["plan_id"], "reason_attribution", "observed", attribution,
            "The report attributes the stated reason to a particular speaker.",
            "Attribution records who made the statement, not whether the reason "
            "is convincing.",
            _sentence_evidence(primary_id, text, start, source=source), **context_extra, _sources=ledger or {}))
    else:
        out.append(decision(
            plan["plan_id"], "stated_reason_text", "reviewed_absent", None,
            "The registered reports were read in full and none of them states a "
            "reason for this reduction.",
            "A reason is recorded only when a source states it.",
            _scope_evidence(primary_id, text, source, event_span),
            **context_extra, _sources=ledger or {}))
        out.append(decision(
            plan["plan_id"], "reason_attribution", "observed", "unclear",
            "No source states a reason, so there is nothing to attribute.",
            "Attribution records who made the statement, not whether the reason "
            "is convincing.",
            _scope_evidence(primary_id, text, source, event_span),
            **context_extra, _sources=ledger or {}))

    # M&A activity
    start, sentence = _sentence_with(text, MA_CUE)
    if start is not None and extraction.company_in_sentence(sentence, aliases):
        out.append(decision(
            plan["plan_id"], "ma_activity", "observed", sentence.strip(),
            "The report describes an acquisition, merger or divestment involving "
            "this employer.",
            "M&A activity records the transaction the employer was involved in.",
            _sentence_evidence(primary_id, text, start, source=source), **context_extra, _sources=ledger or {}))
    else:
        out.append(decision(
            plan["plan_id"], "ma_activity", "reviewed_absent", None,
            "The registered reports were read in full and none of them describes "
            "an acquisition, merger or divestment involving this employer.",
            "M&A activity is recorded only when a source describes the transaction.",
            _scope_evidence(primary_id, text, source, event_span),
            **context_extra, _sources=ledger or {}))

    # leadership transition
    start, sentence = _sentence_with(text, LEADERSHIP_CUE)
    if start is not None and extraction.company_in_sentence(sentence, aliases):
        out.append(decision(
            plan["plan_id"], "leadership_transition", "observed", sentence.strip(),
            "The report describes a change of leadership at this employer.",
            "A leadership transition records the change of office, not the "
            "reduction itself.",
            _sentence_evidence(primary_id, text, start, source=source), **context_extra, _sources=ledger or {}))
    else:
        out.append(decision(
            plan["plan_id"], "leadership_transition", "reviewed_absent", None,
            "The registered reports were read in full and none of them describes "
            "a leadership change at this employer.",
            "A leadership transition is recorded only when a source describes it.",
            _scope_evidence(primary_id, text, source, event_span),
            **context_extra, _sources=ledger or {}))

    # affected parties
    start, sentence = _sentence_with(text, AFFECTED_CUE)
    if start is not None and extraction.company_in_sentence(sentence, aliases):
        out.append(decision(
            plan["plan_id"], "affected_parties", "observed", sentence.strip(),
            "The report names the group of workers the reduction affects.",
            "Affected parties records who the reduction falls on, as the source "
            "states it.",
            _sentence_evidence(primary_id, text, start, source=source), **context_extra, _sources=ledger or {}))
    else:
        out.append(decision(
            plan["plan_id"], "affected_parties", "reviewed_absent", None,
            "The registered reports were read in full and none of them names a "
            "group of workers the reduction falls on.",
            "Affected parties is recorded only when a source names the group.",
            _scope_evidence(primary_id, text, source, event_span),
            **context_extra, _sources=ledger or {}))

    # plan relationship
    out.append(decision(
        plan["plan_id"], "plan_relationship", "observed", "independent",
        "This plan is the only announcement the registered reports describe for "
        "this employer and period.",
        "The relationship records whether two announcements are the same event, "
        "a follow-on round or independent events.",
        event_evidence,
        plan_link_basis="Only one announcement is registered for this employer in this window",
        _sources=ledger or {}, **context_extra))
    out.append(decision(
        plan["plan_id"], "related_plan_id", "reviewed_absent", None,
        "No other registered plan describes the same employer and period, so there "
        "is no related plan to link.",
        "A related plan is named only when another registered plan describes the "
        "same employer and period.",
        _scope_evidence(primary_id, text, source, event_span),
            _sources=ledger or {}, **context_extra))

    # announcement dates and provenance
    # The precision and the raw rendering follow the body's own statement, not
    # a fixed "day": a source that only says "in mid-April" supports month
    # precision, and copying the publication date onto the announcement would
    # manufacture the rest.
    support = plan.get("_date_support")
    published = plan.get("_publication_date") or ""
    precision_map = {"day": "day", "month": "month", "relative": "relative"}
    raw_evidence = event_evidence
    if support:
        raw_evidence = _sentence_evidence(primary_id, text, support["char_start"],
                                          support.get("sentence"), source) or event_evidence
    out.append(decision(
        plan["plan_id"], "announcement_date_raw", "observed", plan["event_date"],
        "The date the plan attributes to the announcement, kept as the raw rendering "
        "for comparison with what the source body states.",
        "The raw date is the source's own rendering of the announcement date.",
        raw_evidence, **context_extra, _sources=ledger or {}))
    out.append(decision(
        plan["plan_id"], "announcement_date_precision", "observed",
        precision_map.get(str((support or {}).get("precision") or ""), "unknown"),
        "Precision records how exactly the source body states the announcement date.",
        "Precision must not exceed what the source states.",
        raw_evidence, **context_extra, _sources=ledger or {}))
    if published:
        out.append(decision(
            plan["plan_id"], "source_publication_date", "observed", published,
            "The publication date recorded in the document's metadata.",
            "The publication date is the date the report appeared; it is a property of "
            "the document, not of the announcement.",
            raw_evidence, date_basis="document_metadata", **context_extra,
            _sources=ledger or {}))
    else:
        out.append(decision(
            plan["plan_id"], "source_publication_date", "unresolved", None,
            "The source metadata carries no publication date, so none is recorded.",
            "The publication date is the date the report appeared; it is a property of "
            "the document, not of the announcement.",
            raw_evidence,
            missing_reason="publication_date_not_in_source_metadata",
            followup={"task": "record the publication date in the source metadata"},
            **context_extra, _sources=ledger or {}))
    out.append(decision(
        plan["plan_id"], "effective_date_start", "reviewed_absent", None,
        "The registered reports do not give a separate date on which the "
        "reduction takes effect.",
        "An effective date is recorded only when a source states it.",
        _scope_evidence(primary_id, text, source, event_span),
            _sources=ledger or {}, **context_extra))
    out.append(decision(
        plan["plan_id"], "effective_date_end", "reviewed_absent", None,
        "The registered reports do not give a separate date on which the "
        "reduction takes effect.",
        "An effective date is recorded only when a source states it.",
        _scope_evidence(primary_id, text, source, event_span),
            _sources=ledger or {}, **context_extra))
    out.append(decision(
        plan["plan_id"], "original_announcement_url", "reviewed_absent", None,
        "The issuer's own announcement page was not separately retrieved in this "
        "pass; the cited report is a news report about the announcement.",
        "The original announcement is the issuer's own notice when it is "
        "available.",
        _scope_evidence(primary_id, text, source, event_span),
            _sources=ledger or {}, **context_extra))
    out.append(decision(
        plan["plan_id"], "original_announcement_status", "observed", "not_checked",
        "The search process did not separately retrieve the issuer's own notice "
        "page in this pass; only news coverage was read.",
        "Search-process metadata records whether the issuer page was fetched, "
        "without implying absence.",
        _scope_evidence(primary_id, text, source, event_span),
            _sources=ledger or {}, **context_extra))

    # listing status: the evidence is the registrant's own filing, because a
    # news report does not carry the listing record.
    listing_evidence = identity_evidence or event_evidence
    if not identity_evidence:
        # No registrant record is registered for this employer, so the listing
        # status has no admissible evidence: the field stays pending rather
        # than borrowing a news source, whose document role cannot support it.
        pass
    elif identity.get("exchange") or identity.get("ticker"):
        out.append(decision(
            plan["plan_id"], "listed_at_event", "observed", 1,
            "The verified company identity record shows the employer listed at the "
            "time of the announcement.",
            "Listing status records whether the employer was listed at the event.",
            listing_evidence,
            listed_at_event_basis="verified listing record",
            _sources=ledger or {}, **context_extra))
    else:
        out.append(decision(
            plan["plan_id"], "listed_at_event", "observed", 0,
            "The verified company identity record shows no listing venue for this "
            "employer at the time of the announcement.",
            "Listing status records whether the employer was listed at the event.",
            listing_evidence,
            listed_at_event_basis="verified listing record",
            _sources=ledger or {}, **context_extra))

    # firm size basis
    if identity.get("firm_size"):
        out.append(decision(
            plan["plan_id"], "firm_size_basis", "observed",
            "Employee count disclosed in the registrant's own filing.",
            "The verified company identity record states the event-time workforce size.",
            "The basis names where the workforce figure comes from.",
            event_evidence, **context_extra, _sources=ledger or {}))
    else:
        out.append(decision(
            plan["plan_id"], "firm_size_basis", "reviewed_absent", None,
            "No applicable source states the workforce size of this employer, so "
            "there is no basis to record.",
            "The basis names where the workforce figure comes from.",
            _scope_evidence(primary_id, text, source, event_span),
            **context_extra, _sources=ledger or {}))

    # percentage bounds
    # A stated range already produced both bounds as observations; emitting a
    # "reviewed absent" here as well would be a duplicate decision for the same
    # field and the whole submission is rejected.
    already = set(emitted or ()) | {record["variable"] for record in out}
    for variable in ("layoff_percentage_lower", "layoff_percentage_upper"):
        if variable in already:
            continue
        out.append(decision(
            plan["plan_id"], variable, "reviewed_absent", None,
            "The report states a single share rather than a bound, so it does "
            "not establish this bound.",
            "A bound is recorded only when the source states one.",
            _scope_evidence(primary_id, text, source, event_span),
            **context_extra, _sources=ledger or {}))
    return out


def _reviewed_scopes(source_ids, sources):
    """The complete read scope of every applicable ready source.

    A negative finding is only valid when the whole applicable source was
    read, so each scope records the full extent of its source.
    """
    scopes = []
    for source_id in sorted(source_ids):
        source = sources.get(source_id, {})
        if source.get("status") != "ready":
            continue
        path = source.get("text_path")
        if not path:
            continue
        base = source.get("_work")
        target = Path(path)
        if not target.is_absolute():
            target = Path(base) / target if base else Path(target)
        try:
            # The runtime measures the decoded text, so the scope must span the
            # same characters rather than the bytes on disk.
            length = len(target.read_bytes().decode("utf-8"))
        except Exception:  # noqa: BLE001
            continue
        scopes.append({"source_id": source_id, "start": 0, "end": length})
    return scopes


def _scope_evidence(source_id, text, source, start):
    """Evidence for a field the sources do not state.

    A negative finding must cite a representative span of the source that was
    read, and the reviewed scope must cover the whole file.
    """
    if not text:
        return []
    # The quote is a slice of the source text, so the runtime can compare it
    # with the text at the recorded offset. It is not stripped or normalised,
    # because any change would break that comparison.
    quote = text[start:start + 200] if start else text[:200]
    if len(quote.strip()) < 10:
        quote = text[:200]
    # An English page often carries a language menu of other scripts near the
    # top. Quoting it would ask the reader to translate a menu, and the export
    # rejects non-English evidence that has no reviewed translation. Cut at the
    # first foreign letter so the quote stays a prefix of the original text.
    language = str((source or {}).get("source_language") or "en").lower()
    if language.startswith("en"):
        foreign = next((index for index, char in enumerate(quote)
                        if char.isalpha() and char.lower() not in "abcdefghijklmnopqrstuvwxyz"),
                       None)
        if foreign is not None and foreign >= 10:
            quote = quote[:foreign].rstrip()
    if len(quote.strip()) < 10:
        return []
    return [{"source_id": source_id, "char_start": start if start else 0,
             "char_end": (start if start else 0) + len(quote), "quote": quote}]


REVIEW_CHECKS = {
    "definition": "The recorded value matches the field definition: what this field "
                  "is required to state about the event.",
    "entity": "The cited evidence names the employer that made the announcement.",
    "period": "The date and the period the value describes are the event's own "
              "period, not another round or a later year.",
    "context_and_negation": "The cited evidence was read for passages that could "
                            "qualify the value differently, and none of them changes "
                            "the reading.",
    "information_available_at_event": "The information was available at the event "
                                      "date, so it describes the employer as it stood "
                                      "when the reduction was announced.",
    "company_attribution_and_causal_link": "The reason is attributed to the company "
                                           "as the source states it, and the causal "
                                           "link is the one the source makes.",
    "count_scope": "The number counts the roles affected in this announcement, not a "
                   "workforce total, a remaining headcount or another employer's figure.",
    "credibility": "The evidence is an exact span of the registered source text.",
    "complete_applicable_scope":
        "Every source the field admits for this plan was read from its beginning "
        "to its end before the finding was made.",
    "negative_counterevidence":
        "The passages in the applicable sources that could have stated this "
        "attribute were looked for and none of them states it; the strongest "
        "candidate passage was read in context and does not qualify.",
}


def _checks_for(record, field_topic=None):
    """The review checks the runtime requires for this decision."""
    checks = {
        "definition": REVIEW_CHECKS["definition"],
        "entity": REVIEW_CHECKS["entity"],
        "period": REVIEW_CHECKS["period"],
        "context_and_negation": REVIEW_CHECKS["context_and_negation"],
    }
    topic = field_topic or ""
    if topic == "context":
        checks["information_available_at_event"] = REVIEW_CHECKS["information_available_at_event"]
    if topic == "event_reason":
        checks["company_attribution_and_causal_link"] = REVIEW_CHECKS["company_attribution_and_causal_link"]
    variable = record.get("variable", "")
    if variable in {"layoff_count", "layoff_count_lower", "layoff_count_upper",
                    "layoff_percentage"}:
        checks["count_scope"] = REVIEW_CHECKS["count_scope"]
    checks["credibility"] = REVIEW_CHECKS["credibility"]
    # A negative finding must show that the whole applicable scope was read
    # and that the strongest passage which could have changed the answer was
    # looked at.
    if record.get("status") in {"reviewed_absent", "not_separate"} or (
            record.get("status") == "observed" and record.get("value") == 0):
        checks["complete_applicable_scope"] = REVIEW_CHECKS["complete_applicable_scope"]
        checks["negative_counterevidence"] = REVIEW_CHECKS["negative_counterevidence"]
    return checks


NUMERIC_VARIABLES = {"layoff_count", "layoff_count_lower", "layoff_count_upper",
                     "layoff_percentage", "layoff_percentage_lower",
                     "layoff_percentage_upper"}

# Risk ordering of second reviews. The review queue is worked highest-risk
# first: a cross-employer clause is the defect that actually shipped a wrong
# percentage in the delivery audit, so it outranks everything else.
RISK_ORDER = ("multi_employer_sentence", "numeric_update", "retrospective_source",
              "mixed_population", "event_relationship")


def _review_risk_flags(record, quote, aliases):
    flags = []
    if quote:
        others = extraction.other_employers_in_sentence(quote, aliases or set())
        if others:
            flags.append("multi_employer_sentence")
        if re.search(r"\b(furlough\w*|temporary\s+layoff)\b", quote, re.I):
            flags.append("mixed_population")
    if record.get("variable") in NUMERIC_VARIABLES:
        flags.append("numeric_update")
    if record.get("source_timing") == "retrospective":
        flags.append("retrospective_source")
    if record.get("variable") in {"plan_relationship", "related_plan_id"}:
        flags.append("event_relationship")
    return flags


def _recompute_numeric(record, text, aliases):
    """The value the scope rules give this employer on re-reading the source."""
    variable = record.get("variable", "")
    if variable.startswith("layoff_count"):
        reading = extraction.scoped_count(text, aliases)
    else:
        reading = extraction.scoped_percentage(text, aliases)
    if not reading:
        return None, "no admissible reading for this employer in this source"
    if variable in {"layoff_count_lower", "layoff_count_upper"}:
        if reading.get("qualifier") not in {"more_than", "at_least", "up_to", "less_than"}:
            return None, ("the re-read reads the figure as a point value, not the bound "
                          "the first decision recorded")
    if variable == "layoff_percentage":
        if reading.get("qualifier") == "range":
            return None, "the re-read reads a range, not the point share recorded"
        return reading.get("value"), None
    if variable == "layoff_percentage_lower":
        return reading.get("lower"), None
    if variable == "layoff_percentage_upper":
        return reading.get("upper"), None
    return reading.get("value"), None


def _value_tokens(value):
    """Text renderings a source may use for a numeric value."""
    if not isinstance(value, (int, float)):
        return [str(value)] if value else []
    if float(value) == int(value):
        return [f"{int(value):,}", str(int(value)), f"{value:g}"]
    return [f"{value:g}"]


def _date_supported(quote, value, precision):
    """True when the quote itself states the recorded date (at its precision)."""
    if not quote or not value:
        return False
    date = str(value)[:10]
    if date in quote:
        return True
    precision_day = extraction._date_precision_and_value(quote)
    if precision == "month":
        month = date[5:7]
        stated = precision_day
        if stated and stated[0] == "month":
            stated_month = stated[1] if isinstance(stated[1], int) \
                else str(stated[1]).split("-")[-1].zfill(2)
            return str(stated_month) == month
        return False
    if precision_day and precision_day[0] == "day":
        return precision_day[1] == date
    return False


def build_second_reviews(first_round, sources, accepted=None, topics=None,
                         aliases_by_company=None):
    """A substantive second review for each first-round decision.

    The review is not a signature: the mechanical checks re-read the bound
    evidence from the registered source, recompute the scoped value with the
    current scope rules, verify that the evidence states the recorded date at
    its recorded precision, and check qualifier coherence. A contradiction
    produces `revise` with a field-specific reason naming both values; an
    unreadable scope produces `abstain`; only a re-read that agrees produces
    `confirm`, and the confirmation text reports what was actually re-checked.

    Reviews are returned in risk order: cross-employer sentences first, then
    numeric fields, retrospective sources, mixed populations and event
    relationships. Each review carries `risk_flags` and `risk_rank` so the
    queue can be worked and audited in that order.

    When the runtime's accepted decisions are supplied, the review binds to
    their hashes, which is what the runtime compares against.
    """
    alias_map = aliases_by_company or {}

    def _aliases_for(entity_id):
        # A plan id is "plan-<company_id>-<suffix>" where company_id itself
        # contains hyphens, so the company key is matched against the known
        # keys instead of being split off by delimiter.
        body = str(entity_id)
        if body.startswith("plan-"):
            body = body[len("plan-"):]
        for company_id in alias_map:
            if body == company_id or body.startswith(company_id + "-"):
                return set(alias_map[company_id] or ())
        return set()

    prepared = []
    for record in first_round:
        variable = record.get("variable", "")
        evidence = record.get("evidence") or []
        quote = str((evidence[0] or {}).get("quote") or "") if evidence else ""
        aliases = _aliases_for(record.get("entity_id", ""))
        flags = _review_risk_flags(record, quote, aliases)
        rank = min((RISK_ORDER.index(flag) for flag in flags
                    if flag in RISK_ORDER), default=len(RISK_ORDER))

        contradictions = []
        cannot_verify = []

        text = ""
        if evidence:
            source = sources.get(evidence[0].get("source_id") or "", {})
            text = _entry_text(source)
        if not evidence:
            cannot_verify.append("the decision carries no bound evidence span")
        elif not text:
            cannot_verify.append("the bound source text could not be read")

        if text and variable in NUMERIC_VARIABLES and aliases:
            recomputed, why = _recompute_numeric(record, text, aliases)
            recorded = record.get("value")
            if recomputed is None:
                if why:
                    contradictions.append(f"re-read disagrees: {why}")
                else:
                    contradictions.append(
                        "re-read found no admissible value for this employer, "
                        f"recorded value {_value_tokens(recorded)[0] if recorded else ''!r} "
                        "has no clause-scoped support")
            elif recorded is None or abs(float(recomputed) - float(recorded)) > 1e-9:
                recorded_text = (_value_tokens(recorded) or [""])[0]
                contradictions.append(
                    f"re-read computes {recomputed:g} for this employer's own clause, "
                    f"not the recorded {recorded_text}; the recorded figure matches "
                    "another clause of a multi-employer sentence" if recorded is not None
                    else f"re-read computes {recomputed:g} but no value was recorded")

        if text and variable == "announcement_date" and record.get("status") == "observed":
            if not _date_supported(quote, record.get("value"),
                                   str(record.get("announcement_date_precision") or "")):
                contradictions.append(
                    "the bound evidence does not state the recorded announcement date at "
                    "its recorded precision; a publication date or page chrome is not "
                    "announcement-date evidence")

        if text and variable in {"layoff_count_qualifier", "layoff_percentage_qualifier"} \
                and record.get("value") == "exact" and quote:
            if re.search(r"\b(about|around|roughly|nearly|approximately|over|more\s+than|"
                         r"at\s+least|up\s+to|almost)\b", quote, re.I):
                contradictions.append(
                    "the evidence qualifies the figure with an approximation or bound "
                    "word, but the recorded qualifier is 'exact'")

        if contradictions:
            outcome = "revise"
        elif cannot_verify:
            outcome = "abstain"
        else:
            outcome = "confirm"

        topic = (topics or {}).get(variable)
        checks = _checks_for(record, topic)
        source_checks = []
        for item in evidence:
            entry = {k: item[k] for k in ("source_id", "char_start", "char_end", "quote")
                     if k in item}
            if "quote_en" in item:
                entry["quote_en"] = item["quote_en"]
            source_checks.append(entry)

        if outcome == "revise":
            criterion = ("The bound evidence was re-read and the mechanical checks "
                         "contradict the recorded value: " + "; ".join(contradictions)
                         + ". The first decision does not stand and must be revised "
                         "against the clause-scoped reading.")
        elif outcome == "abstain":
            criterion = ("The second review cannot re-read the bound evidence: "
                         + "; ".join(cannot_verify)
                         + ". No confirmation is issued on evidence that was not read.")
        else:
            criterion = ("The bound evidence was re-read from the registered source and "
                         "the mechanical checks agree: the clause-scoped re-read of the "
                         "source reproduces the recorded value, the evidence states the "
                         "recorded date at its recorded precision where applicable, and "
                         "no qualifier contradiction was found. The first decision stands "
                         "on its own re-verified evidence, not on a signature.")

        review = {
            "entity_id": record["entity_id"],
            "variable": variable,
            "reviewed_again": True,
            "review_outcome": outcome,
            "criterion_application": criterion,
            "reviewer_id": REVIEWER_ID,
            "reviewer_kind": REVIEWER_KIND,
            "checks": checks,
            "source_checks": source_checks,
            "risk_flags": flags,
            "risk_rank": rank,
        }
        if contradictions:
            review["contradictions"] = contradictions
        if cannot_verify:
            review["cannot_verify_reasons"] = cannot_verify
        key = record["entity_id"] + "|" + variable
        bound = (accepted or {}).get(key)
        if bound:
            review["decision_sha256"] = bound.get("decision_sha256")
            review["definition_sha256"] = bound.get("definition_sha256")
            review["source_bindings"] = bound.get("source_bindings")
        prepared.append((rank, review))

    prepared.sort(key=lambda item: item[0])
    return [review for _rank, review in prepared]


def write_jsonl(path, records):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records),
                    encoding="utf-8")
    return len(records)
