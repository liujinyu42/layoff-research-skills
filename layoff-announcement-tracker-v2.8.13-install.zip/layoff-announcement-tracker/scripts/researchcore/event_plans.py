"""Cluster retrieved pages into layoff plans and emit source-bound decisions.

This module turns the raw corpus (retrieved page text plus company identity
records) into event plans and the field decisions the runtime validates. It
exists because the previous round did this work in throwaway scripts outside
the skill, so the rules that decide which page becomes a plan, which page is
noise, and how a number is read were not reviewable and not reusable.

The rules that matter, each of which answers a defect the audit report found:

* Entity binding. A page is bound to a company only when the company name
  appears in a sentence that also states a workforce reduction, and a company
  whose name is a common English word additionally requires a corporate
  marker. Pages that fail this never become plans; they stay candidates with
  an exclusion reason.
* One plan per announcement. Pages about the same employer within a short
  window collapse into one plan; a second, genuinely separate round gets its
  own plan.
* Number scope. Counts and percentages are read with the scope-safe rules in
  `extraction`, and every value must pass the plausibility gate against the
  event-time firm size.
* Identity backfill. Country, listing venue, ticker and firm size come from
  the verified company identity record, not from the news text, so they are
  populated for every row rather than left empty.
* Window and duplicate control. A plan whose announcement date falls outside
  the requested window is dropped, and two plans for the same employer on the
  same day are merged.
"""
from __future__ import annotations

import collections
import datetime as dt
import hashlib
import json
import re
from pathlib import Path

from . import extraction

WINDOW_MERGE_DAYS = 6


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def _sentences(text):
    return extraction.sentences(text)


def company_aliases(identity):
    names = {identity.get("company") or identity.get("display_name") or ""}
    for item in identity.get("names") or []:
        if isinstance(item, dict) and item.get("name"):
            names.add(item["name"])
    for alias in identity.get("aliases") or []:
        names.add(alias)
    return sorted({n.strip() for n in names if n and n.strip()}, key=len, reverse=True)


def generic_company(name):
    """A roster name that is also an ordinary English word needs care."""
    key = re.sub(r"[^a-z0-9]+", " ", str(name or "").lower()).strip()
    return key in extraction.__dict__.get("_GENERIC", set()) or key in _GENERIC_NAMES


_GENERIC_NAMES = {
    "on", "here", "sea", "box", "plan", "cloud", "surface", "signal", "block",
    "stripe", "notion", "figma", "air", "arm", "base", "beam", "core", "deck",
    "field", "frame", "front", "gate", "grid", "health", "house", "hub", "image",
    "index", "joy", "key", "lead", "level", "light", "line", "link", "list",
    "live", "load", "lock", "main", "map", "mark", "mind", "mode", "moon",
    "north", "open", "orbit", "page", "panel", "peak", "pilot", "point", "press",
    "range", "reach", "realm", "ride", "root", "scale", "scene", "scope", "sense",
    "shift", "shore", "sky", "slate", "snap", "space", "span", "stage", "stamp",
    "state", "stone", "store", "storm", "story", "street", "studio", "survey",
    "switch", "team", "tempo", "thread", "tide", "tile", "timer", "tone", "trace",
    "track", "trail", "trend", "trip", "vault", "vector", "view", "vine", "voice",
    "volume", "wave", "waypoint", "weave", "well", "wheel", "wing", "wire", "wise",
    "world", "yard",
}


def page_binds_to_company(text, aliases, generic):
    """Does this page state that this employer announced a workforce reduction?

    Returns (binds, reason, matched_alias).
    """
    if not text or len(text) < 200:
        return False, "the retrieved page has too little text to read", None
    for _, sentence in _sentences(text):
        alias = extraction.company_in_sentence(sentence, aliases)
        if not alias:
            continue
        if not extraction.REDUCE.search(sentence):
            continue
        # The employer must be the actor performing the reduction. A roundup
        # that lists several employers ("100,000 positions eliminated across
        # major companies like Microsoft, Intel, Google") names the company
        # but attributes no action to it, so it is not this employer's event.
        if not extraction.employer_is_subject(sentence, aliases):
            continue
        if generic and not _corporate_marker(sentence):
            continue
        return True, "", alias
    return False, ("no sentence names this employer as the party announcing a "
                   "workforce reduction"), None


def _corporate_marker(sentence):
    return bool(re.search(
        r"\b(inc|inc\.|corp|corp\.|ltd|ltd\.|llc|l\.l\.c\.|plc|gmbh|holdings|"
        r"group|company|corporation|technologies|labs?|limited)\b", sentence, re.I)) or \
        bool(re.search(r"\b" + re.escape(sentence.split()[0].lower()) + r"'s\b", sentence, re.I))


def _as_day(value):
    if not value:
        return None
    try:
        return dt.date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


# Scope vocabulary. A page that names the departments and places a reduction
# falls on says which plan it describes; two pages that name disjoint groups
# are not the same announcement merely because their dates are close.
DEPARTMENT_TERMS = (
    "engineering", "product", "design", "sales", "marketing", "advertising",
    "human resources", "recruiting", "talent", "finance", "accounting", "legal",
    "operations", "manufacturing", "warehouse", "logistics", "customer service",
    "customer support", "research", "development", "content", "editorial",
    "gaming", "retail", "corporate", "administrative", "maintenance",
    "production", "distribution", "fulfillment", "fulfilment", "support",
)
REGION_TERMS = (
    "united states", "canada", "mexico", "brazil", "united kingdom", "ireland",
    "germany", "france", "spain", "italy", "netherlands", "belgium", "sweden",
    "norway", "denmark", "finland", "poland", "romania", "portugal",
    "switzerland", "austria", "australia", "new zealand", "india", "china",
    "japan", "south korea", "singapore", "malaysia", "indonesia", "vietnam",
    "philippines", "thailand", "israel", "turkey", "south africa", "argentina",
    "chile", "colombia", "europe", "asia", "latin america", "emea", "apac",
    "california", "texas", "new york", "washington", "florida", "illinois",
    "massachusetts", "georgia", "north carolina", "ohio", "pennsylvania",
    "michigan", "arizona", "colorado", "oregon", "virginia", "new jersey",
    "minnesota", "missouri", "utah", "maryland", "tennessee", "nevada",
    "wisconsin", "indiana", "connecticut", "iowa", "kansas", "kentucky",
    "alabama", "oklahoma", "nebraska", "idaho", "hawaii", "new mexico",
    "rhode island", "delaware", "montana", "maine", "new hampshire",
    "west virginia", "mississippi", "arkansas", "south carolina", "louisiana",
)
UPPERCASE_REGIONS = {"us", "u.s.", "uk"}
GLOBAL_TERMS = (
    "globally", "worldwide", "global", "company-wide", "companywide",
    "across the company", "entire workforce", "nationwide", "all offices",
    "across all", "company wide",
)

TITLE_STOPWORDS = {
    "the", "and", "for", "with", "from", "that", "this", "will", "have",
    "has", "are", "was", "were", "its", "their", "about", "after", "over",
    "more", "than", "into", "amid", "news", "report", "reports", "said",
    "says", "company", "employees", "workers", "staff", "jobs", "job",
}


REDUCTION_CUE = re.compile(
    r"\b(lay ?offs?|layl?offs?|redundan\w*|job cuts?|cutting \d|cut \d|eliminat\w+ \d|"
    r"retrench\w*|downsiz\w*|restructur\w*|furlough\w*|terminat\w+ \d|let go|"
    r"closing (?:the|its|a) \w+|shut(?:ting)? down)\b", re.IGNORECASE)


def _scope_terms(text):
    """Departments and places a page says the reduction affects.

    Only sentences that report a workforce reduction are read: a passing
    mention of an office in another country is not the affected scope, and
    treating it as one would split a single plan in two.
    """
    departments, regions = set(), set()
    global_scope = False
    sentences = re.split(r"(?<=[.!?])\s+", text or "")[:400]
    for sentence in sentences:
        if not REDUCTION_CUE.search(sentence):
            continue
        lowered = sentence.lower()
        departments.update(term for term in DEPARTMENT_TERMS
                           if re.search(r"\b" + re.escape(term) + r"\b", lowered))
        regions.update(term for term in REGION_TERMS
                       if re.search(r"\b" + re.escape(term) + r"\b", lowered))
        for term in UPPERCASE_REGIONS:
            if re.search(r"(?<![A-Za-z])" + re.escape(term.upper()) + r"(?![A-Za-z])", sentence):
                regions.add(term)
        if any(term in lowered for term in GLOBAL_TERMS):
            global_scope = True
    return {"departments": departments, "regions": regions, "global": global_scope}


def _title_tokens(title):
    cleaned = re.sub(r"[^a-z0-9 ]+", " ", (title or "").lower())
    return {token for token in cleaned.split()
            if len(token) >= 4 and token not in TITLE_STOPWORDS}


def _same_plan(left, right, merge_days):
    """Decide whether two pages describe one announcement.

    A date is a candidate signal, never a decision: consecutive coverage of one
    employer can span weeks and still be one event, while two announcements on
    the same day can be different regional or departmental plans. Identity,
    affected scope and headcount coverage decide; the date only bounds the
    search and supplies one positive signal.

    Returns ("same" | "different" | "review", reason).
    """
    lid, rid = left.get("plan_id"), right.get("plan_id")
    if lid and rid and lid != rid:
        return "different", "the pages already carry different plan identities"
    distance = abs((left["day"] - right["day"]).days)
    if distance > merge_days:
        return "different", "the pages are %d days apart" % distance
    ls, rs = left["_scope"], right["_scope"]
    if ls["regions"] and rs["regions"] and not (ls["regions"] & rs["regions"]):
        return "different", ("the pages name different affected regions: "
                             + ", ".join(sorted(ls["regions"])) + " / "
                             + ", ".join(sorted(rs["regions"])))
    if ls["departments"] and rs["departments"] and not (ls["departments"] & rs["departments"]):
        return "different", ("the pages name different affected departments: "
                             + ", ".join(sorted(ls["departments"])) + " / "
                             + ", ".join(sorted(rs["departments"])))
    lc, rc = left.get("_count"), right.get("_count")
    lv = (lc or {}).get("value")
    rv = (rc or {}).get("value")
    if lv and rv and lv != rv:
        # A regional figure inside a company-wide total is a sub-plan, not a
        # duplicate of the total; merging them would report one number twice.
        if ls["global"] != rs["global"]:
            return "different", ("one page states a company-wide total and the "
                                 "other a local subset")
        return "review", ("the pages state different headcounts (%s and %s) and "
                          "their coverage relation is unclear" % (lv, rv))
    if (left.get("date_basis") == "effective") != (right.get("date_basis") == "effective"):
        return "review", "one page describes an announcement and the other an implementation date"
    signals = []
    if distance == 0:
        signals.append("same_day")
    if lv and rv and lv == rv:
        signals.append("same_headcount")
    if ls["regions"] & rs["regions"]:
        signals.append("same_region")
    if ls["departments"] & rs["departments"]:
        signals.append("same_department")
    if len(left["_tokens"] & right["_tokens"]) >= 2:
        signals.append("shared_title_terms")
    if not signals:
        return "review", ("the pages share no identity signal beyond the same "
                          "employer, so the plan relationship is unclear")
    return "same", ",".join(signals)


def _brief(record, reason_field, reason):
    """A review record keeps the source mapping but not a second copy of the page."""
    out = {key: value for key, value in record.items() if key != "text"}
    out[reason_field] = reason
    return out


def build_plans(records, identities, window_start, window_end, merge_days=WINDOW_MERGE_DAYS,
                known_plans=None):
    """Group page records into event plans.

    `records` is a list of dicts with keys: company_id, source_id, url, title,
    date, text, and optionally event_date. `identities` maps company_id to its
    verified identity record. `known_plans` maps a source_id to the plan
    identifier the runtime already carries for it.

    Returns (plans, rejected, pending_review). A plan carries
    `needs_review=True` when the pages could plausibly belong to one
    announcement but the available scope information cannot confirm it; such a
    plan is a review record with its source mapping, not a confirmed event.
    A page with no usable date is pending review rather than rejected: a
    retrospective report may describe an in-window event, and discarding it
    would silently shrink coverage.
    """
    known_plans = known_plans or {}
    by_company = collections.defaultdict(list)
    rejected = []
    pending_review = []
    for record in records:
        identity = identities.get(record["company_id"], {})
        aliases = company_aliases(identity)
        generic = any(generic_company(a) for a in aliases)
        if record.get("event_review"):
            binds, reason = True, ""
        else:
            binds, reason, _alias = page_binds_to_company(record.get("text") or "", aliases, generic)
        if not binds:
            rejected.append(_brief(record, "exclusion_reason", reason))
            continue
        event_day = _as_day(record.get("event_date"))
        if not event_day and str(record.get("form") or "").upper() in {"10-K", "10-Q", "20-F", "40-F", "10-K/A", "10-Q/A"}:
            pending_review.append(_brief(record, "review_reason",
                "Periodic filing requires an explicit event date and plan identity; report period and filing date cannot establish a new layoff event"))
            continue
        published = _as_day(record.get("date"))
        day = event_day or published
        if day is None:
            pending_review.append(_brief(
                record, "review_reason",
                "the page states no publication or event date, so its event "
                "window cannot be judged"))
            continue
        if not (dt.date.fromisoformat(window_start) <= day <= dt.date.fromisoformat(window_end)):
            rejected.append(_brief(
                record, "exclusion_reason",
                "the event falls outside the requested event window"))
            continue
        text = record.get("text") or ""
        by_company[record["company_id"]].append({
            **record,
            "day": day,
            "date_basis": "event_date" if event_day else "publication_date",
            "_scope": _scope_terms(text),
            "_tokens": _title_tokens(record.get("title") or ""),
            "_count": extraction.scoped_count(text, aliases, str(day.year)),
            "_aliases": aliases,
        })

    plans = []
    for company_id, items in by_company.items():
        items.sort(key=lambda r: (r["day"], r["source_id"]))
        clusters = []
        for item in items:
            placed = False
            for cluster in clusters:
                decision, reason = _same_plan(cluster["pages"][0], item, merge_days)
                if decision == "different":
                    continue
                if decision == "review":
                    cluster["review"].append(reason)
                    continue
                # The item joins only when it is compatible with every page
                # already in the cluster. Comparing against the last page
                # would chain A-B-C where A and C are different plans.
                if any(_same_plan(member, item, merge_days)[0] == "different"
                       for member in cluster["pages"]):
                    continue
                cluster["pages"].append(item)
                placed = True
                break
            if not placed:
                clusters.append({"pages": [item], "review": []})
        for cluster in clusters:
            pages = cluster["pages"]
            # The candidate that anchors the event is the earliest page that
            # states a workforce action; the rest are corroborating coverage.
            primary = _primary_page(pages)
            aliases = pages[0]["_aliases"]
            year = primary["day"].year
            count = primary.get("_count")
            percentage = extraction.scoped_percentage(primary.get("text") or "", aliases, str(year))
            firm_size = identities.get(company_id, {}).get("firm_size")
            share = percentage["value"] if percentage else None
            if count:
                ok, why = extraction.plausibility(count["value"], firm_size, share)
                if not ok:
                    count = None
                    rejected.append(_brief(primary, "exclusion_reason",
                                           "the stated figure is not plausible for one employer "
                                           "in one event: " + why))
            # The plan identity must be one the runtime already knows, because
            # the runtime builds its entity list from the plan_id recorded on
            # each registered source. Inventing an identifier here would
            # produce decisions the runtime cannot bind to an entity.
            # A cluster usually contains pages the runtime already knows and
            # pages added in this round. Keeping the id of the strongest old
            # page would rename the event whenever a new page becomes the
            # primary, which loses every decision already bound to the old id
            # and shows up as both a lost event and an unrelated new one. The
            # id the cluster already carries is the stable choice.
            known = collections.Counter(r.get("plan_id") for r in pages if r.get("plan_id"))
            if known:
                plan_id = known.most_common(1)[0][0]
            else:
                # The identifier the runtime already carries for this event's
                # pages is the stable one. Without it a plan is named after
                # the day of whichever page happened to be strongest, so the
                # same event changes its name when a new page arrives and
                # every decision bound to the old name is lost.
                carried = collections.Counter(
                    carried_id for carried_id in
                    (known_plans.get(r["source_id"]) for r in pages)
                    if carried_id)
                plan_id = (carried.most_common(1)[0][0] if carried
                           else _plan_id(company_id, primary["day"]))
            plan = {
                "plan_id": plan_id,
                # Only an identity the corpus already carries is authoritative.
                # A date-derived identifier is a fallback, and two same-day
                # clusters that fall back to it are still two plans.
                "id_basis": "registered" if (known or carried) else "date",
                "company_id": company_id,
                "event_date": primary["day"].isoformat(),
                "date_basis": primary.get("date_basis") or "publication_date",
                "publication_date": (primary.get("date") or "")[:10],
                "primary_source_id": primary["source_id"],
                "primary_url": primary["url"],
                "title": primary.get("title", ""),
                **({"event_review": primary["event_review"]} if primary.get("event_review") else {}),
                "sources": [{"source_id": r["source_id"], "url": r["url"],
                             "reported_date": r.get("date") or "",
                             "event_date": r.get("event_date") or "",
                             "title": r.get("title", "")}
                            for r in pages],
                "count": count,
                "percentage": percentage,
                "n_sources": len(pages),
                "scope": {"regions": sorted(pages[0]["_scope"]["regions"]),
                          "departments": sorted(pages[0]["_scope"]["departments"]),
                          "global": pages[0]["_scope"]["global"]},
            }
            if cluster["review"]:
                # A relationship this round could not confirm is a review item
                # with its sources, not a confirmed event.
                plan["needs_review"] = True
                plan["review_reason"] = "; ".join(sorted(set(cluster["review"])))
            plans.append(plan)

    # Two clusters can resolve to the same registered plan when the pages of
    # one announcement carry different publication dates. The registered
    # identity wins and the second cluster merges into it. Two *different*
    # plans that fall back to the same date-derived identifier keep their own
    # identity instead of being folded together.
    by_identity = {}
    unique = []
    for plan in sorted(plans, key=lambda p: (p["company_id"], p["event_date"],
                                             p["primary_source_id"])):
        key = plan["plan_id"]
        if key in by_identity:
            previous = by_identity[key]
            mergeable = (not previous.get("needs_review") and not plan.get("needs_review")
                         and previous["company_id"] == plan["company_id"]
                         and previous.get("id_basis") == "registered"
                         and plan.get("id_basis") == "registered")
            if mergeable:
                previous["n_sources"] += plan["n_sources"]
                for src in plan["sources"]:
                    if src["source_id"] not in {s["source_id"] for s in previous["sources"]}:
                        previous["sources"].append(src)
                if not previous.get("count") and plan.get("count"):
                    previous["count"] = plan["count"]
                if not previous.get("percentage") and plan.get("percentage"):
                    previous["percentage"] = plan["percentage"]
                continue
            suffix = 2
            while "%s-%d" % (key, suffix) in by_identity:
                suffix += 1
            key = "%s-%d" % (key, suffix)
            plan["plan_id"] = key
        by_identity[key] = plan
        unique.append(plan)
    return unique, rejected, pending_review



def _plan_id(company_id, day):
    """Fallback identifier for a plan the runtime does not already know.

    The date is written without separators, which is the form the runtime
    registers on a source: plan-<company_id>-<YYYYMMDD>.
    """
    stamp = day.isoformat().replace("-", "")
    return "plan-%s-%s" % (company_id, stamp)


def _primary_page(cluster):
    """The page that best states the event: earliest, then most informative."""
    def score(record):
        text = record.get("text") or ""
        has_number = bool(extraction.COUNT.search(text))
        has_reduction = bool(extraction.REDUCE.search(text))
        return (not record.get("event_review"), not has_number, not has_reduction, -len(text))
    return sorted(cluster, key=score)[0]


def identity_backfill(plan, identity):
    """Country, venue, ticker and firm size come from the identity record."""
    return {
        "country": identity.get("country"),
        "exchange_at_event": identity.get("exchange"),
        "ticker_at_event": identity.get("ticker"),
        "listed_at_event": identity.get("listed_at_event"),
        "firm_size": identity.get("firm_size"),
        "firm_size_as_of": identity.get("firm_size_as_of"),
        "cik": identity.get("cik"),
    }


def plan_identity_hash(plan, identity):
    return _digest({"plan": plan["plan_id"], "identity": identity_backfill(plan, identity)})
