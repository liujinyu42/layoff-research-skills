"""Shared egress and transport helpers for automated collection.

Two failure modes dominated the previous manual run and both are handled here:

1. The search endpoint refuses the current exit address (HTTP 429/503 with an
   "automated queries" body). Recovery requires either waiting or moving to a
   different exit node, which on this machine is a sing-box Clash-compatible
   control API on 127.0.0.1:9090.
2. A single slow or hanging publisher blocks a worker. Every request therefore
   carries a timeout and the pool treats a refused connection as a normal
   retryable event rather than a crash.

The module is deliberately free of skill-internal imports so it can be used by
the bundled collection scripts and by ad-hoc recovery runs alike.
"""
from __future__ import annotations

import json
import os
import random
import re
import socket
import threading
import time
from pathlib import Path

import requests

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")

CLASH_API = os.environ.get("LAYOFF_EGRESS_API", "http://127.0.0.1:9090")
EGRESS_LOG = Path(os.environ.get("LAYOFF_EGRESS_LOG", "discovery/captures/access/vpn-nodes.json"))

# The sing-box SOCKS5 inbound. Node rotation only changes the exit address if
# the request actually travels through sing-box; a request that only inherits
# the ambient HTTP_PROXY never leaves that proxy, so "rotating" the node
# changes nothing and the same refused address is retried forever.
SOCKS_PROXY = os.environ.get("LAYOFF_EGRESS_SOCKS", "socks5h://127.0.0.1:2334")

# A refused request body, not merely a non-200 status, identifies a blocked exit.
BLOCK_MARKERS = ("automated queries", "unusual traffic", "too many requests")


def default_proxy():
    """Use the sing-box SOCKS5 inbound when it is listening.

    Rotation only changes the exit address if the request travels through
    sing-box. When the ambient `HTTP_PROXY` is set to some other proxy, a
    request inherits it and never reaches the node that was rotated, so the
    rotation is theatre. Detecting the local SOCKS5 inbound keeps the
    transport honest without requiring the operator to set an environment
    variable.
    """
    override = os.environ.get("LAYOFF_EGRESS_PROXY")
    if override:
        return override
    # Strip the scheme before splitting host and port.
    _, _, endpoint = SOCKS_PROXY.rpartition("://")
    host, _, port = endpoint.rpartition(":")
    try:
        with socket.create_connection((host or "127.0.0.1", int(port)), timeout=2):
            return SOCKS_PROXY
    except (OSError, ValueError):
        return None


class _FailedResponse:
    """A response for a request that never reached the endpoint.

    The transport tried every time and raised each time, so there is no
    status and no body. The caller still needs something it can read, and
    it must be able to tell this apart from a refusal, because a request
    that never arrived is not a refusal by the endpoint.
    """

    status_code = 0
    text = ""
    content = b""

    def __init__(self, url=""):
        self.url = url

    def __bool__(self):
        return False


class Egress:
    """Rate-limited HTTP transport with automatic exit-node rotation.

    `interval` is the minimum spacing between requests across all threads. It
    starts at `floor` and backs off when the endpoint refuses, then decays
    toward the floor again once requests succeed. Rotation is attempted after
    repeated refusals so a long run does not stall behind one blocked address.
    """

    def __init__(self, floor=0.05, ceiling=4.0, api=CLASH_API, log=EGRESS_LOG,
                 rotate_after=2, selector=None, proxy=None, probe_url=None):
        self.floor = floor
        self.ceiling = ceiling
        self.api = api
        self.log = Path(log)
        self.rotate_after = rotate_after
        self.allow_rotation = True
        self.selector = selector
        # A rotation is only an escape from a refusal if the new address can
        # actually be used. The probe URL is the address that was refused.
        self.probe_url = probe_url
        # An explicit proxy routes the request through sing-box, which is what
        # makes node rotation observable. `None` keeps the ambient environment.
        self.proxy = proxy if proxy is not None else default_proxy()
        self.interval = floor
        self.next_at = 0.0
        self.blocked = 0
        self.refusals = 0
        self.rotations = 0
        self.current_ip = ""
        # The addresses that were refused and are not to be used again.
        self.refused_ips = set()
        # The nodes whose address was refused. Nodes of one region share one
        # address, so the region is what a later rotation has to leave.
        self.refused_regions = set()
        self._lock = threading.Lock()
        self._local = threading.local()

    # -- transport ---------------------------------------------------------
    def session(self):
        # drop_sessions() sets the slot to None rather than deleting the
        # attribute, so the rebuild has to check for None and not for a
        # missing attribute: returning the None would surface as an
        # AttributeError on the next request after a rotation.
        s = getattr(self._local, "s", None)
        if s is None:
            s = requests.Session()
            if not self.allow_rotation:
                s.trust_env = False
            s.headers.update({"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"})
            if self.proxy:
                s.proxies.update({"http": self.proxy, "https": self.proxy})
            # A pooled connection to a node that has just been replaced keeps
            # failing even though the new node works. The session is dropped
            # when a rotation happens rather than every request closing the
            # tunnel: a `Connection: close` header makes the SOCKS handshake
            # fail on some publishers, which would read as an unreachable
            # site rather than as a transport problem.
            self._local.s = s
        return self._local.s

    def drop_sessions(self):
        """Discard the pooled sessions.

        A session holds a connection to the address that was in use when it
        was opened. Once the exit node has been replaced, that connection no
        longer carries traffic, so the session is dropped and the next request
        opens a fresh tunnel.
        """
        with self._lock:
            session = getattr(self._local, "s", None)
            self._local.s = None
        if session is not None:
            try:
                session.close()
            except Exception:  # noqa: BLE001
                pass

    def probe_session(self):
        """A short-lived session used to read the current exit address.

        It is separate from the request session because a dead node can wedge
        a pooled connection, and the probe must not hang the rotation.
        """
        s = requests.Session()
        if not self.allow_rotation:
            s.trust_env = False
        s.headers.update({"User-Agent": UA, "Connection": "close"})
        if self.proxy:
            s.proxies.update({"http": self.proxy, "https": self.proxy})
        return s

    def proxy_for_control(self):
        """The session used for control-plane calls.

        Rotation talks to the local Clash API, which must not be tunnelled
        through the proxy it is reconfiguring.
        """
        if not hasattr(self._local, "c"):
            c = requests.Session()
            c.headers.update({"User-Agent": UA})
            self._local.c = c
        return self._local.c

    def _wait(self):
        while True:
            with self._lock:
                now = time.time()
                if now >= self.next_at:
                    self.next_at = now + self.interval
                    return
                delay = self.next_at - now
            time.sleep(min(delay, 0.2))

    def request(self, method, url, **kwargs):
        kwargs.setdefault("timeout", 30)
        response = None
        for attempt in range(3):
            self._wait()
            try:
                response = self.session().request(method, url, **kwargs)
            except requests.RequestException:
                time.sleep(1.5)
                continue
            if not self.is_refusal(response):
                self._note_success()
                return response
            self._note_refusal(url=url)
            if attempt < 2:
                # Wait out the refusal before trying again, so the next
                # attempt does not land on the same refused address.
                time.sleep(min(2.0 * (self.blocked + 1), 8.0))
        if response is None:
            # Every attempt raised, so there is no response to describe. The
            # caller is told the request never reached the endpoint instead
            # of being handed nothing to read.
            return _FailedResponse(url)
        return response

    def get(self, url, **kwargs):
        return self.request("GET", url, **kwargs)

    # -- pacing ------------------------------------------------------------
    @staticmethod
    def is_refusal(response):
        """A refusal is a blocked exit, never an empty result set.

        The previous round recorded 2715 zero-result queries as blocked, which
        hid the real cause (the query syntax) behind a network excuse. A feed
        that answered with a well-formed document containing no items is a
        completed search that found nothing; only a refusal status or a
        refusal body means the endpoint refused to answer.
        """
        if response.status_code in (429, 403, 503):
            return True
        if response.status_code >= 500:
            return True
        if response.status_code == 200:
            body = response.text[:2000].lower()
            return any(marker in body for marker in BLOCK_MARKERS)
        return False

    def _note_refusal(self, url=None):
        """Count a refusal and decide whether the exit address must change.

        The refusal count is cumulative and is never reset by a successful
        request. Resetting it made the rotation condition unreachable: with
        several workers, a success between two refusals reset the counter, so
        the modulo test almost never fired and the run kept hammering a
        refused address. The counter now decays slowly instead.
        """
        with self._lock:
            self.blocked += 1
            self.refusals += 1
            self.interval = min(self.ceiling, max(self.interval * 1.6, 0.4))
            self.next_at = max(self.next_at, time.time() + self.interval * 4)
            should_rotate = self.allow_rotation and self.refusals >= self.rotate_after
            if should_rotate:
                self.refusals = 0
        if should_rotate:
            moved = self.rotate(probe_url=url or self.probe_url)
            if not moved:
                # No address could be found that answers. Thrashing the
                # rotation would spend the whole run trying to move, and
                # each attempt takes seconds, so the run waits instead: the
                # provider's own address pool turns over on its own.
                with self._lock:
                    self.next_at = max(self.next_at, time.time() + 90.0)
                    self.interval = self.ceiling

    def _note_success(self):
        with self._lock:
            self.blocked = 0
            # A success is evidence the address works, so the pace relaxes,
            # but the refusal counter only decays, so a flapping endpoint
            # still leads to a rotation.
            self.refusals = max(0, self.refusals - 1)
            self.interval = max(self.floor, self.interval * 0.97)

    # -- exit rotation -----------------------------------------------------
    def exit_ip(self, timeout=12):
        """The address this transport currently leaves from.

        A node that is not reachable makes the lookup time out; that is a
        failed candidate, not a fatal error, so the caller keeps the last
        known address.
        """
        try:
            with self.probe_session() as probe:
                return probe.get("https://api.ipify.org?format=json",
                                 timeout=(4, timeout)).json().get("ip", "")
        except Exception:  # noqa: BLE001
            return self.current_ip

    def _proxies(self):
        try:
            return self.proxy_for_control().get(self.api + "/proxies", timeout=8).json().get("proxies", {})
        except Exception:  # noqa: BLE001
            return {}

    def rotate(self, skip_ips=(), probe_url=None, max_seconds=60.0):
        """Move the active exit node and verify the new address is usable.

        A node group can present several entries that share one egress
        address, so the new address is checked before it is accepted. When the
        node changed but the address did not, the rotation is reported as
        ineffective rather than counted as a change.

        When `probe_url` is given, the new address must also answer that
        address with a real document. An address that changed but is still
        refused is not an escape from the refusal, and reporting it as one
        would let the run keep hammering a blocked address while believing
        it had moved.

        `max_seconds` bounds the whole rotation. A rotation that must try
        many candidates must still finish, because the run is waiting for it.
        """
        proxies = self._proxies()
        selector = self.selector or self._pick_selector(proxies)
        if not selector:
            return None
        deadline = time.time() + max_seconds
        before = self.current_ip or self.exit_ip()
        # The group that measures its own entries is tried first, because it
        # is the one that actually changes the address: the named nodes of a
        # group often all resolve to the same refused address, and moving
        # between them changes nothing.
        moved = self._rotate_to_automatic(proxies, probe_url)
        if moved:
            self.drop_sessions()
            return moved
        tried = tuple(skip_ips)
        # The addresses that were already refused are not tried again, so a
        # rotation reaches past the addresses that are known to be blocked
        # instead of cycling between them.
        with self._lock:
            tried = tried + tuple(self.refused_ips)
        # A node that does not answer leaves the group unusable, so several
        # candidates are tried before the rotation gives up.
        tried_nodes = set()
        for _ in range(10):
            if time.time() > deadline:
                break
            node = self._pick_node(proxies, selector, tried, tried_nodes)
            if not node:
                return None
            tried_nodes.add(node)
            try:
                self.proxy_for_control().put(f"{self.api}/proxies/{selector}",
                                             json={"name": node}, timeout=8)
            except Exception:  # noqa: BLE001
                continue
            time.sleep(2.0)
            # The group state changed, so the next candidate is chosen from
            # the current selection rather than a stale snapshot.
            proxies = self._proxies() or proxies
            ip = self.exit_ip()
            if not ip:
                # The new node does not answer; try another one.
                tried = tried + (before,)
                continue
            changed = bool(ip) and ip != before
            healthy = True
            if probe_url:
                healthy = self._probe_answers(probe_url)
                if not healthy:
                    # The new address is refused as well. It is remembered,
                    # so the next rotation goes further out rather than
                    # returning to it.
                    tried = tried + (ip,)
                    with self._lock:
                        self.refused_ips.add(ip)
                        self.refused_regions.add(self._region_of(node))
                    continue
            with self._lock:
                if changed:
                    self.rotations += 1
                    self.current_ip = ip
                    self.blocked = 0
                    self.interval = self.floor
                self.refused_ips.discard(ip)
            self._record(node, ip, changed)
            return {"node": node, "ip": ip, "changed": changed, "healthy": healthy}
        return None

    def _probe_answers(self, url, confirm=True):
        """Whether the endpoint answers with a document after the rotation.

        The answer is confirmed twice, a few seconds apart. A node that has
        just been selected can still be finishing its handshake, and one
        successful request through it does not mean the address is usable:
        the next request a second later is refused. An address that answers
        twice is one the run can keep using.
        """
        first = self._probe_once(url)
        if not first:
            return False
        if not confirm:
            return True
        time.sleep(4.0)
        return self._probe_once(url)

    def probe_once(self, url):
        """Whether the endpoint answers this address with a document."""
        return self._probe_once(url)

    def _probe_once(self, url):
        try:
            with self.probe_session() as probe:
                response = probe.get(url, timeout=(5, 20))
        except Exception:  # noqa: BLE001
            return False
        if response.status_code != 200:
            return False
        body = response.text[:2000].lower()
        return not any(marker in body for marker in BLOCK_MARKERS)

    @staticmethod
    def _pick_selector(proxies):
        for name, body in proxies.items():
            if body.get("type") == "Selector" and body.get("all"):
                if name in ("节点选择", "Proxy", "GLOBAL"):
                    return name
        for name, body in proxies.items():
            if body.get("type") == "Selector" and body.get("all"):
                return name
        return None

    @staticmethod
    def _automatic_entries(proxies):
        """The groups that choose their own node by measuring it.

        A group that measures its entries and picks the fastest is not
        locked to one upstream. When every named node of the selected group
        resolves to the same refused address, moving the selection to such a
        group is what actually changes the address: the group measures its
        entries again and may settle on a different upstream.
        """
        out = []
        for name, body in proxies.items():
            if body.get("type") in {"URLTest", "Fallback"} and body.get("all"):
                out.append(name)
        return out

    def _rotate_to_automatic(self, proxies, probe_url=None):
        """Move the selection to a group that chooses its own node.

        Returns the node that group settled on, or None.
        """
        selector = self.selector or self._pick_selector(proxies)
        if not selector:
            return None
        for name in self._automatic_entries(proxies):
            try:
                self.proxy_for_control().put(f"{self.api}/proxies/{selector}",
                                             json={"name": name}, timeout=8)
            except Exception:  # noqa: BLE001
                continue
            # The group needs a moment to settle on its entry before the
            # first request goes through it; a probe sent too early meets the
            # address that is being replaced and reads as a refusal.
            time.sleep(6.0)
            body = proxies.get(selector, {})
            # The node that is actually in use is the one the automatic group
            # settled on, not the name of the group itself.
            settled = proxies.get(name, {}).get("now") or body.get("now")
            node = settled
            ip = self.exit_ip()
            if probe_url and not self._probe_answers(probe_url):
                with self._lock:
                    if ip:
                        self.refused_ips.add(ip)
                    self.refused_regions.add(self._region_of(settled))
                continue
            changed = bool(ip) and ip != (self.current_ip or "")
            with self._lock:
                if changed:
                    self.rotations += 1
                    self.current_ip = ip
                    self.blocked = 0
                    self.interval = self.floor
                self.refused_ips.discard(ip)
            self._record(node, ip, changed)
            return {"node": node, "ip": ip, "changed": changed, "healthy": True}
        return None

    def _pick_node(self, proxies, selector, skip_ips, skip_nodes=()):
        """Choose a node that is likely to have a different exit address.

        Nodes of one region usually share one egress address, so preferring a
        single country defeats the purpose of rotating: every candidate
        resolves to the same refused address and the run stalls. The pool
        therefore spans regions, and the node whose address differs from the
        current one wins.
        """
        body = proxies.get(selector, {})
        options = [n for n in (body.get("all") or []) if n != body.get("now")]
        if not options:
            return None
        # The last known address is used here rather than a fresh lookup: this
        # function runs while a node may be unreachable, and a network call in
        # the selection path would hang the rotation.
        current_ip = self.current_ip
        current_node = body.get("now") or ""
        # Nodes of one region share one egress address, so the region in use is
        # excluded from the candidate pool. Without that exclusion every
        # rotation lands on the same address and the refusal repeats.
        current_region = self._region_of(current_node)
        regions = {}
        for name in options:
            region = self._region_of(name)
            regions.setdefault(region, []).append(name)
        ordered = []
        for region in sorted(regions, key=lambda r: (r == current_region, r)):
            if region == current_region and len(regions) > 1:
                continue
            group = regions[region]
            random.shuffle(group)
            ordered.extend(group)
        blocked_ips = set(skip_ips)
        if current_ip:
            blocked_ips.add(current_ip)
        # A node that was already tried and refused is not tried again. The
        # node, not only its address, has to be excluded: several nodes share
        # one address, so excluding only the address lets the rotation return
        # to the same region through a different node.
        tried_nodes = set(skip_nodes)
        for name in ordered:
            if name == body.get("now"):
                continue
            if name in tried_nodes:
                continue
            if self._node_is_refused(name, proxies, blocked_ips):
                continue
            return name
        # Every candidate is either current, already tried, or of a
        # known-refused address. The refused addresses are remembered, so the
        # next rotation reaches past them instead of cycling between them.
        for name in ordered:
            if name != body.get("now") and name not in tried_nodes:
                return name
        return ordered[0] if ordered else None

    def _node_is_refused(self, name, proxies, blocked_ips):
        """Whether this node is known to share a refused exit address.

        Nodes of one region share one address, so the region that produced a
        refusal is treated as refused as well. This is the coarse signal that
        is available without a network call.
        """
        if not blocked_ips:
            return False
        region = self._region_of(name)
        for refused in getattr(self, "refused_regions", ()):  # noqa: B009
            if self._region_of(refused) == region:
                return True
        return False

    @staticmethod
    def _region_of(node):
        """The region prefix of a node name, e.g. `乌克兰1|IEPL|1X` -> `乌克兰1`."""
        return str(node or "").split("|")[0]

    @staticmethod
    def _region_prefix(ip):
        """A coarse bucket for an address, used only to vary the pool."""
        if not ip:
            return ""
        return ".".join(ip.split(".")[:2])

    def _record(self, node, ip, changed=True):
        """Append to the node history.

        The write is serialised and atomic: several workers may rotate at the
        same moment, and an interleaved read-modify-write left the history
        file as invalid JSON, which is exactly the record a reader needs.
        """
        try:
            with self._lock:
                self.log.parent.mkdir(parents=True, exist_ok=True)
                history = []
                if self.log.is_file():
                    try:
                        loaded = json.loads(self.log.read_text())
                        if isinstance(loaded, list):
                            history = loaded
                    except ValueError:
                        # A damaged history is replaced rather than appended to;
                        # the addresses it held are recoverable from the
                        # receipts, which carry the exit address per capture.
                        history = []
                history.append({"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "node": node,
                                "ip": ip, "changed": changed})
                temporary = self.log.with_suffix(".tmp")
                temporary.write_text(json.dumps(history[-200:], ensure_ascii=False, indent=1))
                temporary.replace(self.log)
        except Exception:  # noqa: BLE001
            pass

    def status(self):
        return {"ip": self.current_ip or self.exit_ip(), "interval": round(self.interval, 3),
                "blocked": self.blocked, "rotations": self.rotations, "proxy": self.proxy}


def default_egress(**kwargs):
    return Egress(**kwargs)
