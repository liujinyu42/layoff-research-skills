"""Contract regressions for the 2.8.3 review findings.

Every case pins a generic behaviour; no company is special-cased anywhere in
the implementation, and the fixtures use fictional employers throughout:

* a multi-employer sentence gives each employer the figure in its own clause,
  in either order and under while/whereas/and connectives; a figure never
  crosses employers;
* a property reduction and an employee reduction are recorded separately, and
  a mixed layoff/furlough population keeps its mixed basis;
* the announcement date and the publication date are separate facts; precision
  never exceeds what the source body states, and an unsupported date is
  unresolved instead of manufactured;
* the second review re-reads the bound evidence, recomputes the scoped value,
  and refuses (revise) a record whose figure belongs to another clause of a
  multi-employer sentence; reviews come back in risk order;
* a plan's headcount keeps information versions with an as-of;
* HTML text keeps inline tags inline and block elements apart;
* every relevant seed ends in an auditable closure state;
* a configuration-missing source stays visible instead of disappearing.
"""
import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from researchcore import coding
from researchcore import extraction
from researchcore import seed_sweep
from researchcore import sources as source_module

TWO_EMPLOYERS_WHILE = (
    "Northwind said it would lay off 14% of its workforce, about 1,000 people, "
    "while Solstice will cut nearly 700 employees, or 13% of its staff.")
TWO_EMPLOYERS_SWAPPED = (
    "Solstice will cut nearly 700 employees, or 13% of its staff, while "
    "Northwind said it would lay off 14% of its workforce, about 1,000 people.")
TWO_EMPLOYERS_AND = (
    "Northwind announced cuts of 14% of its staff, about 1,000 people, and "
    "Solstice announced it is laying off nearly 700 employees, or 13% of its "
    "workforce.")
TWO_EMPLOYERS_WHEREAS = (
    "Northwind said it would lay off 14% of its workforce, about 1,000 people, "
    "whereas Solstice is cutting nearly 700 employees, or 13% of its staff.")


class ClauseAttributionTests(unittest.TestCase):
    """The figure a company records is the figure in its own clause."""

    def check(self, text, first, second, year="2022"):
        for company, count_value, pct_value in (*first, *second):
            count = extraction.scoped_count(text, [company], year)
            share = extraction.scoped_percentage(text, [company], year)
            self.assertIsNotNone(count, f"{company}: no count in {text!r}")
            self.assertEqual(count["value"], count_value,
                             f"{company}: count {count['value']} != {count_value}")
            self.assertEqual(share["value"], pct_value,
                             f"{company}: share {share['value']} != {pct_value}")

    def test_while_connective(self):
        self.check(TWO_EMPLOYERS_WHILE,
                   [("Northwind", 1000, 14.0)], [("Solstice", 700, 13.0)])

    def test_swapped_order_gives_the_same_figures(self):
        self.check(TWO_EMPLOYERS_SWAPPED,
                   [("Northwind", 1000, 14.0)], [("Solstice", 700, 13.0)])

    def test_and_connective_between_employer_clauses(self):
        self.check(TWO_EMPLOYERS_AND,
                   [("Northwind", 1000, 14.0)], [("Solstice", 700, 13.0)])

    def test_whereas_connective_between_employer_clauses(self):
        self.check(TWO_EMPLOYERS_WHEREAS,
                   [("Northwind", 1000, 14.0)], [("Solstice", 700, 13.0)])

    def test_qualifier_survives_on_count_and_percentage(self):
        count = extraction.scoped_count(TWO_EMPLOYERS_WHILE, ["Solstice"], "2022")
        self.assertEqual(count["qualifier"], "approximately")
        count = extraction.scoped_count(TWO_EMPLOYERS_WHILE, ["Northwind"], "2022")
        self.assertEqual(count["qualifier"], "approximately")
        share = extraction.scoped_percentage(
            "Northwind will cut nearly 6% of its workforce.", ["Northwind"], "2022")
        self.assertEqual(share["qualifier"], "approximately")

    def test_coordinated_objects_of_one_verb_are_one_clause(self):
        text = "Northwind said it would lay off 1,000 jobs and 500 contractor roles."
        count = extraction.scoped_count(text, ["Northwind"], "2023")
        self.assertIsNotNone(count)
        self.assertEqual(count["value"], 1000)

    def test_count_and_percentage_come_from_the_same_clause(self):
        text = ("Northwind said it would lay off 14% of its workforce, about 1,000 "
                "people, while Solstice is cutting 700 employees, or 13% of its staff.")
        count = extraction.scoped_count(text, ["Solstice"], "2022")
        share = extraction.scoped_percentage(text, ["Solstice"], "2022")
        self.assertEqual(count["value"], 700)
        self.assertEqual(share["value"], 13.0)


class RealEstateAndPopulationTests(unittest.TestCase):
    def test_office_footprint_is_not_a_headcount(self):
        text = "Northwind said it would reduce its office space by 90%."
        self.assertIsNone(extraction.scoped_percentage(text, ["Northwind"], "2025"))

    def test_a_sublease_mention_does_not_erase_a_real_headcount(self):
        text = ("Northwind, which recently subleased part of its headquarters, "
                "said it would lay off 300 employees.")
        count = extraction.scoped_count(text, ["Northwind"], "2025")
        self.assertIsNotNone(count)
        self.assertEqual(count["value"], 300)

    def test_mixed_population_keeps_its_mixed_basis(self):
        text = "Northwind said it would lay off or furlough about 2,800 people."
        count = extraction.scoped_count(text, ["Northwind"], "2020")
        self.assertIsNotNone(count)
        self.assertEqual(count["value"], 2800)
        self.assertIn("mixed population", count["basis"])
        # A furlough-only population is still not a layoff count.
        self.assertIsNone(extraction.scoped_count(
            "Northwind furloughed 2,000 employees during the downturn.",
            ["Northwind"], "2020"))


def plan_for(plan_id, event_date, primary_id="s1", company_id="acme-1"):
    return {"plan_id": plan_id, "company_id": company_id,
            "event_date": event_date, "primary_source_id": primary_id,
            "needs_review": False}


class DateEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)
        self.identity = {"display_name": "Acme Corp", "firm_size": 20000}
        self.aliases = ["Acme"]

    def build(self, body, publication="2020-05-01", event_date="2020-04-13"):
        text_path = self.work / "snapshot.txt"
        text_path.write_text(body, encoding="utf-8")
        source = {"source_id": "s1", "status": "ready",
                  "text_path": text_path.name, "_work": str(self.work),
                  "publication_date": publication, "plan_id": "plan-acme-1"}
        sources = {"s1": source}
        plan = plan_for("plan-acme-1", event_date)
        out = coding.build_plan_decisions(plan, self.identity, sources,
                                          self.aliases, event_date[:4])
        return {record["variable"]: record for record in out}

    def test_a_dated_statement_supports_day_precision(self):
        fields = self.build(
            "On November 4, 2020, Acme Corp said it would lay off 300 people.",
            event_date="2020-11-04")
        announcement = fields["announcement_date"]
        self.assertEqual(announcement["status"], "observed")
        self.assertEqual(announcement["announcement_date_precision"], "day")
        self.assertEqual(announcement["date_basis"],
                         "event_statement_in_source_body")
        self.assertTrue(any("November 4, 2020" in span["quote"]
                            for span in announcement["evidence"]))

    def test_a_month_statement_supports_month_precision_only(self):
        fields = self.build(
            "Acme Corp said in mid-April it would lay off about 2,800 people.")
        announcement = fields["announcement_date"]
        self.assertEqual(announcement["status"], "observed")
        self.assertEqual(announcement["announcement_date_precision"], "month")
        precision = fields["announcement_date_precision"]["value"]
        self.assertEqual(precision, "month")

    def test_a_relative_statement_is_recorded_with_its_anchor(self):
        fields = self.build(
            "Acme Corp said this week it would lay off 300 people.",
            publication="2020-05-01")
        announcement = fields["announcement_date"]
        self.assertEqual(announcement["status"], "observed")
        self.assertEqual(announcement["announcement_date_precision"], "relative")
        self.assertEqual(announcement["date_anchor"], "2020-05-01")

    def test_no_date_statement_is_unresolved_not_manufactured(self):
        fields = self.build(
            "Acme Corp said it would lay off 300 people across its divisions.")
        announcement = fields["announcement_date"]
        self.assertEqual(announcement["status"], "unresolved")
        self.assertIsNone(announcement["value"])
        self.assertEqual(announcement["missing_reason"],
                         "announcement_date_not_stated_in_source_body")
        self.assertEqual(announcement["withdrawn_value"], "2020-04-13")

    def test_a_conflicting_day_statement_is_unresolved(self):
        fields = self.build(
            "On November 6, 2020, Acme Corp said it would lay off 300 people.",
            event_date="2020-11-04")
        announcement = fields["announcement_date"]
        self.assertEqual(announcement["status"], "unresolved")
        self.assertEqual(announcement["missing_reason"],
                         "announcement_date_conflicts_with_source_body")

    def test_publication_date_comes_from_metadata_and_is_separate(self):
        fields = self.build(
            "On April 13, 2020, Acme Corp said it would lay off 300 people.",
            publication="2020-04-14", event_date="2020-04-13")
        publication = fields["source_publication_date"]
        self.assertEqual(publication["status"], "observed")
        self.assertEqual(publication["value"], "2020-04-14")
        self.assertEqual(publication["date_basis"], "document_metadata")
        announcement = fields["announcement_date"]
        self.assertEqual(announcement["value"], "2020-04-13")

    def test_missing_publication_metadata_is_unresolved(self):
        fields = self.build(
            "On April 13, 2020, Acme Corp said it would lay off 300 people.",
            publication="")
        publication = fields["source_publication_date"]
        self.assertEqual(publication["status"], "unresolved")
        self.assertEqual(publication["missing_reason"],
                         "publication_date_not_in_source_metadata")


class DecisionLedger:
    """A source ledger whose bound text lives in a temporary workspace."""

    def __init__(self, work, texts):
        self.work = work
        self.sources = {}
        for source_id, text in texts.items():
            path = work / "text" / source_id / "snapshot.txt"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
            self.sources[source_id] = {
                "source_id": source_id, "status": "ready",
                "text_path": path.relative_to(work).as_posix(),
                "_work": str(work)}


class SecondReviewTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)
        self.aliases = {"acme-1": ["Acme"]}

    def record(self, variable, value, quote, source_id="s1", **extra):
        return {"entity_id": "plan-acme-1", "variable": variable, "status": "observed",
                "value": value, "reason": "the report states it.",
                "criterion": "criterion text",
                "evidence": [{"source_id": source_id, "char_start": 0,
                              "char_end": 10, "quote": quote}], **extra}

    def review(self, records, ledger=None):
        return coding.build_second_reviews(records, ledger.sources if ledger else {},
                                           None, None, aliases_by_company=self.aliases)

    def test_cross_employer_figure_is_rejected(self):
        text = (TWO_EMPLOYERS_WHILE + " " + PAD_TEXT)
        ledger = DecisionLedger(self.work, {"s1": text})
        wrong = self.record("layoff_percentage", 14.0,
                            "Northwind said it would lay off 14% of its workforce, "
                            "about 1,000 people,")
        wrong["evidence"][0]["source_id"] = "s1"
        # The record belongs to Solstice but carries Northwind's clause figure.
        self.aliases = {"acme-1": ["Solstice"]}
        reviews = self.review([wrong], ledger)
        self.assertEqual(reviews[0]["review_outcome"], "revise")
        self.assertIn("14", " ".join(reviews[0]["contradictions"]))
        self.assertIn("multi_employer_sentence", reviews[0]["risk_flags"])

    def test_an_agreeing_record_is_confirmed_on_its_own_reread(self):
        text = ("Solstice will cut nearly 700 employees, or 13% of its staff. "
                + PAD_TEXT)
        ledger = DecisionLedger(self.work, {"s1": text})
        right = self.record("layoff_percentage", 13.0,
                            "Solstice will cut nearly 700 employees, or 13% of its staff.")
        right["evidence"][0]["source_id"] = "s1"
        self.aliases = {"acme-1": ["Solstice"]}
        reviews = self.review([right], ledger)
        self.assertEqual(reviews[0]["review_outcome"], "confirm")
        self.assertIn("re-read", reviews[0]["criterion_application"])
        # A numeric field is reviewed at numeric risk even when it agrees.
        self.assertEqual(reviews[0]["risk_flags"], ["numeric_update"])

    def test_missing_evidence_is_an_abstain_not_a_confirm(self):
        record = self.record("layoff_count", 300, "")
        record["evidence"] = []
        reviews = self.review([record])
        self.assertEqual(reviews[0]["review_outcome"], "abstain")

    def test_a_date_without_statement_evidence_is_revised(self):
        text = ("Acme Corp said it would lay off 300 people. " + PAD_TEXT)
        ledger = DecisionLedger(self.work, {"s1": text})
        record = self.record("announcement_date", "2020-04-13",
                             "Acme Corp said it would lay off 300 people.",
                             announcement_date_precision="day")
        reviews = self.review([record], ledger)
        self.assertEqual(reviews[0]["review_outcome"], "revise")
        self.assertIn("announcement date", " ".join(reviews[0]["contradictions"]))

    def test_a_dated_evidence_supports_the_recorded_date(self):
        text = ("On April 13, 2020, Acme Corp said it would lay off 300 people. "
                + PAD_TEXT)
        ledger = DecisionLedger(self.work, {"s1": text})
        record = self.record("announcement_date", "2020-04-13",
                             "On April 13, 2020, Acme Corp said it would lay off 300 people.",
                             announcement_date_precision="day")
        reviews = self.review([record], ledger)
        self.assertEqual(reviews[0]["review_outcome"], "confirm")

    def test_exact_qualifier_against_an_approximate_quote_is_revised(self):
        text = ("Acme Corp said it would lay off about 1,200 people. " + PAD_TEXT)
        ledger = DecisionLedger(self.work, {"s1": text})
        record = self.record("layoff_count_qualifier", "exact",
                             "Acme Corp said it would lay off about 1,200 people.")
        reviews = self.review([record], ledger)
        self.assertEqual(reviews[0]["review_outcome"], "revise")

    def test_reviews_are_ordered_by_risk(self):
        text = TWO_EMPLOYERS_WHILE + " " + PAD_TEXT
        ledger = DecisionLedger(self.work, {"s1": text})
        wrong = self.record("layoff_percentage", 14.0,
                            "Northwind said it would lay off 14% of its workforce")
        wrong["evidence"][0]["source_id"] = "s1"
        plain = self.record("plan_relationship", "none",
                            "The report describes no other event.")
        plain["evidence"][0]["source_id"] = "missing-source"
        self.aliases = {"acme-1": ["Solstice"]}
        reviews = self.review([plain, wrong], ledger)
        self.assertLess(reviews[0]["risk_rank"], reviews[1]["risk_rank"])
        self.assertEqual(reviews[0]["variable"], "layoff_percentage")


PAD_TEXT = ("The company employs people in many locations. "
            "This paragraph is background about the business and its operations. "
            "It carries no further figure or decision.")


class CountVersionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)
        self.identity = {"display_name": "Acme Corp", "firm_size": 20000}

    def build(self, primary_text, other_text=None):
        sources = {}
        for source_id, (text, day) in {
                "s1": (primary_text, "2020-04-13"),
                "s2": (other_text, "2020-06-01") if other_text else (None, "")}.items():
            if text is None:
                continue
            path = self.work / "text" / source_id / "snapshot.txt"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
            sources[source_id] = {"source_id": source_id, "status": "ready",
                                  "text_path": path.relative_to(self.work).as_posix(),
                                  "_work": str(self.work),
                                  "publication_date": day, "plan_id": "plan-acme-1"}
        plan = plan_for("plan-acme-1", "2020-04-13")
        out = coding.build_plan_decisions(plan, self.identity, sources, ["Acme"], "2020")
        return {record["variable"]: record for record in out}

    def test_initial_estimate_carries_its_version_and_as_of(self):
        fields = self.build(
            "Acme Corp said it plans to lay off about 1,200 people.")
        count = fields["layoff_count"]
        self.assertEqual(count["information_version"], "initial_report")
        self.assertEqual(count["count_as_of"], "2020-04-13")

    def test_a_confirmed_later_figure_is_a_separate_version(self):
        fields = self.build(
            "Acme Corp said it plans to lay off about 1,200 people.",
            other_text="Acme Corp confirmed it will cut 900 employees.")
        count = fields["layoff_count"]
        versions = count["information_versions"]
        self.assertEqual(count["information_version"], "initial_report")
        by_version = {entry["version"]: entry for entry in versions}
        self.assertIn("confirmed", by_version)
        self.assertEqual(by_version["confirmed"]["value"], 900)
        self.assertEqual(by_version["confirmed"]["as_of"], "2020-06-01")
        # The initial report is not silently replaced by the confirmation.
        self.assertEqual(count["value"], 1200)


class HtmlInlineTests(unittest.TestCase):
    def test_inline_links_stay_inline(self):
        html = (b"<html><body><p>Northwind said it will lay off "
                b"<a href=\"https://example.test/x\">2,800</a> people, or 13% "
                b"of its staff.</p></body></html>")
        text, _tables, _links, status = source_module._normalize(html, ".html", "")
        self.assertEqual(status, "ready")
        self.assertIn("lay off 2,800 people", text)

    def test_block_elements_introduce_paragraph_breaks(self):
        html = (b"<html><body><p>First paragraph.</p>"
                b"<p>Second paragraph.</p></body></html>")
        text, _tables, _links, _status = source_module._normalize(html, ".html", "")
        self.assertIn("\n\n", text)
        self.assertNotIn("paragraph.Second", text)


class SeedClosureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)
        (self.work / "qa").mkdir()
        (self.work / "discovery").mkdir()
        rows = [
            {"candidate_id": "c-confirmed", "relevant": "true", "company_id": "acme-1",
             "company": "Acme", "source_url": "https://example.test/a", "title": "A",
             "reported_date": "2025-01-01"},
            {"candidate_id": "c-linked", "relevant": "true", "company_id": "acme-1",
             "company": "Acme", "source_url": "https://example.test/b", "title": "B",
             "reported_date": "2025-01-02"},
            {"candidate_id": "c-excluded", "relevant": "true", "company_id": "beta-1",
             "company": "Beta", "source_url": "https://example.test/c", "title": "C",
             "reported_date": "2025-01-03"},
            {"candidate_id": "c-open", "relevant": "true", "company_id": "beta-1",
             "company": "Beta", "source_url": "https://example.test/d", "title": "D",
             "reported_date": "2025-01-04"},
        ]
        with (self.work / "discovery/seed-inbox.csv").open("w", encoding="utf-8",
                                                           newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        ledger = [
            {"candidate_id": "c-confirmed", "disposition": "included",
             "plan_id": "plan-acme-1-a", "reason": ""},
            {"candidate_id": "c-linked", "disposition": "merged",
             "plan_id": "plan-acme-1-b", "reason": ""},
            {"candidate_id": "c-excluded", "disposition": "excluded",
             "plan_id": "", "reason": "duplicate of a registered source"},
        ]
        with (self.work / "event_candidate_review.csv").open("w", encoding="utf-8",
                                                             newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(ledger[0].keys()))
            writer.writeheader()
            writer.writerows(ledger)
        (self.work / "qa/event-plans.json").write_text(json.dumps({
            "plans": [{"plan_id": "plan-acme-1-a", "needs_review": False},
                      {"plan_id": "plan-acme-1-b", "needs_review": True}]}), encoding="utf-8")

    def test_every_relevant_seed_reaches_a_terminal_state(self):
        summary = seed_sweep.seed_closure(self.work)
        self.assertEqual(summary["relevant_seeds"], 4)
        self.assertEqual(summary["confirmed"], 1)
        self.assertEqual(summary["linked"], 1)
        self.assertEqual(summary["source_supported_exclusion"], 1)
        self.assertEqual(summary["named_unresolved"], 1)
        rows = list(csv.DictReader(
            (self.work / "discovery/seed-closure.csv").open(encoding="utf-8")))
        by_id = {row["candidate_id"]: row for row in rows}
        self.assertEqual(by_id["c-confirmed"]["closure_state"], "confirmed")
        self.assertEqual(by_id["c-linked"]["closure_state"], "linked")
        self.assertEqual(by_id["c-excluded"]["closure_state"], "source_supported_exclusion")
        self.assertEqual(by_id["c-open"]["closure_state"], "named_unresolved")
        self.assertIn("no terminal disposition", by_id["c-open"]["detail"])


class ConfigurationGapTests(unittest.TestCase):
    def test_a_configuration_missing_source_stays_visible(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "sources.json").write_text(json.dumps({"sources": [
                {"source_id": "sec-a", "company_id": "acme-1", "status": "failed",
                 "error_class": "sec_user_agent",
                 "error": "SEC_USER_AGENT is not set",
                 "source_url": "https://www.sec.gov/Archives/x.htm",
                 "document_role": "issuer_filing"}]}), encoding="utf-8")
            gaps = source_module.configuration_gaps(work)
            self.assertEqual(len(gaps), 1)
            self.assertEqual(gaps[0]["status"], "configuration_missing")
            report = json.loads(
                (work / "review/configuration-gaps.json").read_text(encoding="utf-8"))
            self.assertEqual(report["count"], 1)
            self.assertIn("stays active and retryable", report["boundary"])

    def test_a_clean_ledger_writes_no_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            (work / "sources.json").write_text(json.dumps({"sources": [
                {"source_id": "news-a", "company_id": "acme-1", "status": "ready"}]}),
                encoding="utf-8")
            self.assertEqual(source_module.configuration_gaps(work), [])
            self.assertFalse((work / "review/configuration-gaps.json").exists())


class PackageIntegrityTests(unittest.TestCase):
    def test_manifest_records_hashes_and_flags_a_name_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "skill-v282"
            (root / "scripts/researchcore").mkdir(parents=True)
            (root / "scripts/researchcore/__init__.py").write_text(
                'VERSION = "2.8.3"\n', encoding="utf-8")
            (root / "assets").mkdir()
            (root / "assets/event_schema.json").write_text(
                json.dumps({"version": "1.6.0"}), encoding="utf-8")
            (root / "__pycache__").mkdir()
            (root / "__pycache__/junk.pyc").write_bytes(b"cache")
            result = subprocess.run(
                [sys.executable, str(Path(__file__).parent / "package_integrity.py"),
                 "--skill", str(root), "--package-name", "skill-v282"],
                capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            manifest = json.loads(
                (root / "integrity-manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["runtime_version"], "2.8.3")
            self.assertEqual(manifest["schema_version"], "1.6.0")
            self.assertIn("scripts/researchcore/__init__.py", manifest["files"])
            self.assertNotIn("__pycache__/junk.pyc", manifest["files"])
            self.assertTrue(manifest["warnings"])


class RetrospectiveMentionTests(unittest.TestCase):
    def test_recap_mentions_are_itemised_and_marked(self):
        text = ("Northwind had cut 700 people in the first quarter. "
                "Northwind will lay off 50 roles next month.")
        mentions = extraction.retrospective_event_mentions(text, ["Northwind"])
        self.assertEqual(len(mentions), 1)
        self.assertTrue(mentions[0]["recap"])
        self.assertEqual(mentions[0]["count"], 700)
        self.assertTrue(mentions[0]["date_precision"] in {"month", None})

    def test_an_ordinary_forward_sentence_is_not_a_recap_mention(self):
        text = "Northwind said it would lay off 300 people."
        self.assertEqual(extraction.retrospective_event_mentions(text, ["Northwind"]), [])


class RetrospectiveSourceFramingTests(unittest.TestCase):
    def test_a_retrospective_source_marks_its_timing(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            identity = {"display_name": "Acme Corp", "firm_size": 20000}
            path = work / "snapshot.txt"
            path.write_text("Acme Corp said it would lay off 300 people.", encoding="utf-8")
            sources = {"s1": {"source_id": "s1", "status": "ready",
                              "text_path": path.name, "_work": str(work),
                              "publication_date": "2026-01-01",
                              "plan_id": "plan-acme-1"}}
            plan = plan_for("plan-acme-1", "2020-04-13")
            out = coding.build_plan_decisions(plan, identity, sources, ["Acme"], "2020")
            framing = {record["variable"]: record for record in out}
            status = framing["announcement_status"]
            self.assertEqual(status.get("source_timing"), "retrospective")


if __name__ == "__main__":
    unittest.main()
