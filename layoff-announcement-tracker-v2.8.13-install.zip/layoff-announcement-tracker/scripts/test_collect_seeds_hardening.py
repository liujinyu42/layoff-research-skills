"""Hardening tests from the independent review (R-15, R-16, R-17 and the Low items).

Network calls are mocked, sleeps are patched, and workspaces live under tempfile;
nothing is written to the layoff-run output directory.
"""
from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

import collect_seeds
from researchcore import seed_sweep
from test_collect_seeds import CF_403_HTML, FISKER_HTML, WINDOW, board_page

PLAIN_403 = "<html><head><title>403 Forbidden</title></head><body>Forbidden</body></html>"


class PacerTests(unittest.TestCase):
    """R-15: process-wide per-host pacing, backoff and Retry-After, with no proxy."""

    def test_threads_share_one_per_host_interval(self):
        pacer = collect_seeds.HostPacer(floor=0.03)
        stamps, lock = [], threading.Lock()

        def worker():
            for _ in range(4):
                pacer.wait("www.thelayoff.com")
                with lock:
                    stamps.append(time.monotonic())

        threads = [threading.Thread(target=worker) for _ in range(4)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        stamps.sort()
        self.assertEqual(len(stamps), 16)
        gaps = [b - a for a, b in zip(stamps, stamps[1:])]
        # Sixteen requests from four threads are still spaced by the host interval.
        self.assertGreaterEqual(min(gaps), 0.03 * 0.7)

    def test_hosts_are_paced_independently(self):
        slept = []
        now = [100.0]

        def sleep(delay):
            slept.append(delay)
            now[0] += delay

        pacer = collect_seeds.HostPacer(floor=5.0, clock=lambda: now[0], sleeper=sleep)
        pacer.wait("a.example")
        pacer.wait("b.example")
        self.assertEqual(slept, [])
        pacer.wait("a.example")
        self.assertEqual(slept, [5.0])

    def test_refusal_widens_the_interval_and_success_relaxes_it(self):
        pacer = collect_seeds.HostPacer(floor=0.15, ceiling=8.0, clock=lambda: 0.0, sleeper=lambda _: None)
        pacer.note("h", 403)
        first = pacer.interval("h")
        self.assertGreater(first, 0.15)
        pacer.note("h", 503)
        self.assertGreater(pacer.interval("h"), first)
        for _ in range(500):
            pacer.note("h", 403)
        self.assertLessEqual(pacer.interval("h"), 8.0)
        before = pacer.interval("h")
        pacer.note("h", 200)
        self.assertLess(pacer.interval("h"), before)
        # A 404 is a definite answer, not a refusal.
        pacer2 = collect_seeds.HostPacer(floor=0.15, clock=lambda: 0.0, sleeper=lambda _: None)
        pacer2.note("h", 404)
        self.assertEqual(pacer2.interval("h"), 0.15)

    def test_retry_after_is_honoured_on_429_and_503(self):
        now = [1000.0]
        slept = []
        def sleep(delay):
            slept.append(delay)
            now[0] += delay

        pacer = collect_seeds.HostPacer(floor=0.1, clock=lambda: now[0], sleeper=sleep)
        pacer.note("h", 429, retry_after=30.0)
        pacer.wait("h")
        self.assertGreaterEqual(slept[-1], 30.0)
        slept.clear()
        pacer.note("h", 503, retry_after=45.0)
        pacer.wait("h")
        self.assertGreaterEqual(slept[-1], 45.0)
        # Retry-After on a non-throttle status is ignored.
        pacer3 = collect_seeds.HostPacer(floor=0.1, clock=lambda: 0.0, sleeper=slept.append)
        slept.clear()
        pacer3.note("h", 200, retry_after=99.0)
        pacer3.wait("h")
        self.assertEqual(slept, [])

    def test_retry_after_header_parsing(self):
        parse = collect_seeds._retry_after_seconds
        self.assertEqual(parse("7"), 7.0)
        self.assertEqual(parse("100000"), collect_seeds.RETRY_AFTER_CAP)
        self.assertIsNone(parse(""))
        self.assertIsNone(parse(None))
        self.assertIsNone(parse("soon"))
        self.assertEqual(parse("Wed, 21 Oct 2015 07:28:00 GMT"), 0.0)

    def test_plain_get_waits_then_notes_and_sends_no_proxy(self):
        pacer = mock.Mock()
        response = mock.Mock(status_code=429, text="slow down",
                             headers={"Retry-After": "7", "Server": "nginx"})
        with mock.patch.object(collect_seeds, "PACER", pacer), \
                mock.patch("requests.get", return_value=response) as get:
            status, body = collect_seeds._plain_get("https://www.thelayoff.com/acme")
        self.assertEqual((status, body), (429, "slow down"))
        pacer.wait.assert_called_once_with("www.thelayoff.com")
        pacer.note.assert_called_once_with("www.thelayoff.com", 429, 7.0)
        self.assertNotIn("proxies", get.call_args.kwargs)
        self.assertFalse(getattr(body, "cloudflare_headers", False))

    def test_plain_get_notes_transport_failure_without_raising(self):
        import requests
        pacer = mock.Mock()
        with mock.patch.object(collect_seeds, "PACER", pacer), \
                mock.patch("requests.get", side_effect=requests.ConnectionError("down")):
            self.assertEqual(collect_seeds._plain_get("https://www.thelayoff.com/x"), (0, ""))
        pacer.note.assert_called_once_with("www.thelayoff.com", 0)


class CloudflareLabelTests(unittest.TestCase):
    """R-16 and L1/L2: Cloudflare is named only on Cloudflare markers."""

    def test_refusal_kinds(self):
        kind = collect_seeds.refusal_kind
        self.assertEqual(kind(403, PLAIN_403), "http_403")
        self.assertEqual(kind(403, CF_403_HTML), "cloudflare_403")
        self.assertEqual(kind(200, CF_403_HTML), "cloudflare_challenge")
        self.assertEqual(kind(404, ""), "")
        self.assertEqual(kind(200, "<html>ok</html>"), "")
        body = collect_seeds._Body(PLAIN_403)
        body.cloudflare_headers = True
        self.assertEqual(kind(403, body), "cloudflare_403")

    def test_429_503_and_missing_response_are_never_cloudflare_or_host_refusals(self):
        for status in (0, 429, 500, 503):
            with self.subTest(status=status):
                self.assertNotIn(collect_seeds.refusal_kind(status, ""), collect_seeds.HOST_REFUSALS)
                self.assertFalse(collect_seeds.is_cloudflare_403_or_empty(status, ""))
                self.assertFalse(collect_seeds.is_cloudflare_403_or_empty(status, "", rendered=False))
        self.assertTrue(collect_seeds.is_cloudflare_403_or_empty(403, PLAIN_403))

    def test_plain_get_marks_cloudflare_challenge_headers(self):
        response = mock.Mock(status_code=403, text=PLAIN_403,
                             headers={"Server": "cloudflare", "CF-RAY": "abc-LHR"})
        with mock.patch.object(collect_seeds, "PACER", mock.Mock()), \
                mock.patch("requests.get", return_value=response):
            status, body = collect_seeds._plain_get("https://www.trueup.io/co/acme")
        self.assertEqual(status, 403)
        self.assertTrue(body.cloudflare_headers)
        self.assertEqual(collect_seeds.refusal_kind(status, body), "cloudflare_403")
        plain = mock.Mock(status_code=403, text=PLAIN_403, headers={"Server": "nginx"})
        with mock.patch.object(collect_seeds, "PACER", mock.Mock()), \
                mock.patch("requests.get", return_value=plain):
            _, body = collect_seeds._plain_get("https://example.test/")
        self.assertEqual(collect_seeds.refusal_kind(403, body), "http_403")

    def test_host_blocker_reason_and_text_follow_what_was_tried(self):
        plain = collect_seeds.HostBlocker(attempts=3, interval=600, sleeper=lambda _: None,
                                          getter=mock.Mock(return_value=(403, PLAIN_403)))
        self.assertTrue(plain.confirm("h", "https://h/x", first_kind="http_403"))
        self.assertEqual(plain.reason("h"), "http_403_persistent")
        text = plain.describe("h")
        self.assertIn("3 plain HTTP request(s)", text)
        self.assertIn("600s", text)
        self.assertIn("without Cloudflare markers", text)
        self.assertIn("no browser render", text)
        cloudflare = collect_seeds.HostBlocker(attempts=3, interval=600, sleeper=lambda _: None,
                                               getter=mock.Mock(return_value=(403, CF_403_HTML)))
        self.assertTrue(cloudflare.confirm("h", "https://h/x", first_kind="cloudflare_403"))
        self.assertEqual(cloudflare.reason("h"), "cloudflare_403_persistent")
        self.assertIn("Cloudflare markers", cloudflare.describe("h"))
        # A mix is not called Cloudflare.
        mixed = collect_seeds.HostBlocker(attempts=3, interval=0, sleeper=lambda _: None,
                                          getter=mock.Mock(return_value=(403, CF_403_HTML)))
        self.assertTrue(mixed.confirm("h", "https://h/x", first_kind="http_403"))
        self.assertEqual(mixed.reason("h"), "http_403_persistent")

    def test_challenge_needs_a_title_or_two_markers(self):
        ordinary = ("<html><head><title>Acme Layoffs</title></head><body>"
                    "<h2 class='post-title'>Attention required: layoffs at Acme</h2></body></html>")
        self.assertFalse(collect_seeds.is_challenge(ordinary))
        self.assertFalse(collect_seeds.is_challenge(FISKER_HTML))
        self.assertTrue(collect_seeds.is_challenge(CF_403_HTML))
        self.assertTrue(collect_seeds.is_challenge("<html><body>Checking your browser... cf-chl</body></html>"))
        self.assertTrue(collect_seeds.is_challenge("<title>Attention Required! | Cloudflare</title>"))
        self.assertFalse(collect_seeds.is_challenge(""))

    def test_later_page_plain_403_is_http_403_not_cloudflare(self):
        self.assertEqual(collect_seeds.later_page_block_code(403, PLAIN_403),
                         collect_seeds.THELAYOFF_STOP_403)
        self.assertEqual(collect_seeds.later_page_block_code(403, CF_403_HTML),
                         collect_seeds.THELAYOFF_STOP_CF)
        self.assertEqual(collect_seeds.thelayoff_outcome(collect_seeds.THELAYOFF_STOP_403), "blocked")


class LaterPageTests(unittest.TestCase):
    """Later-page behaviour the review listed as untested."""
    start = "https://www.thelayoff.com/acme"

    def sweep(self, pages, later):
        sleeper = mock.Mock()
        calls = []

        def fetch(url):
            calls.append(url)
            item = later[min(len(calls) - 1, len(later) - 1)]
            return item[1], item[0]

        result = collect_seeds.collect_thelayoff_pages(
            "Acme", WINDOW, self.start, pages[1], fetch, sleeper=sleeper, pace=0.15,
            transient_backoff=(5.0, 15.0))
        return result, sleeper, calls

    def pages(self):
        return {1: board_page([("Acme layoffs", "2024-05-01", "/t/a")], next_page=2)}

    def test_later_page_404_is_partial_without_retries(self):
        (hits, reviewed, cond, code, oldest, retries), sleeper, calls = self.sweep(
            self.pages(), [(404, "<html>missing</html>")])
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_PARTIAL)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "partial")
        self.assertEqual(retries, 0)
        self.assertEqual(len(calls), 1)
        self.assertEqual(len(hits), 1)
        sleeper.assert_called_once_with(0.15)

    def test_later_page_429_is_retried_then_partial_and_never_cloudflare(self):
        (hits, reviewed, cond, code, oldest, retries), sleeper, calls = self.sweep(
            self.pages(), [(429, "slow down")])
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_PARTIAL)
        self.assertEqual(retries, 2)
        self.assertEqual(len(calls), 3)
        self.assertEqual([c.args[0] for c in sleeper.call_args_list], [0.15, 5.0, 15.0])
        self.assertNotIn("cloudflare", cond.lower())

    def test_later_page_429_then_success_continues(self):
        pages = self.pages()
        page2 = board_page([("Acme more layoffs", "2024-04-01", "/t/b")], next_page=None)
        (hits, reviewed, cond, code, oldest, retries), sleeper, calls = self.sweep(
            pages, [(429, "slow down"), (200, page2)])
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_NO_NEXT)
        self.assertEqual(retries, 1)
        self.assertEqual(reviewed, 2)
        self.assertEqual(len(hits), 2)

    def test_later_page_with_no_articles_and_a_next_link_is_partial_layout(self):
        pages = self.pages()
        bare = board_page([], next_page=3)
        (hits, reviewed, cond, code, oldest, retries), _, _ = self.sweep(pages, [(200, bare)])
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_LAYOUT)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "partial")
        self.assertEqual(len(hits), 1)
        self.assertIn("layout", cond)

    def test_zero_article_first_page_without_marker_is_partial_and_with_marker_is_completed(self):
        unknown = "<html><body><div id='posts'></div><p>Something changed.</p></body></html>"
        fetch = mock.Mock()
        hits, reviewed, cond, code, oldest, retries = collect_seeds.collect_thelayoff_pages(
            "Acme", WINDOW, self.start, unknown, fetch, sleeper=mock.Mock(), pace=0)
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_LAYOUT)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "partial")
        self.assertEqual(hits, [])
        fetch.assert_not_called()
        empty = ("<html><body><div id='posts'></div>"
                 "<p>There are no posts about Acme yet.  Be the first to comment:</p></body></html>")
        hits, reviewed, cond, code, oldest, retries = collect_seeds.collect_thelayoff_pages(
            "Acme", WINDOW, self.start, empty, fetch, sleeper=mock.Mock(), pace=0)
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_NO_NEXT)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "completed")

    def test_layout_partial_opens_a_seed_partial_gap(self):
        unknown = "<html><body><div id='posts'></div></body></html>"
        hits, reviewed, cond, code, oldest, retries = collect_seeds.collect_thelayoff_pages(
            "Acme", WINDOW, self.start, unknown, mock.Mock(), sleeper=mock.Mock(), pace=0)
        work, cfg, status = import_single_thelayoff(self, hits, reviewed, cond, code, oldest, unknown)
        self.assertEqual([g["reason"] for g in status["gaps"] if g["channel"] == "thelayoff"],
                         ["seed_partial"])


def import_single_thelayoff(case, hits, reviewed, cond, code, oldest, html):
    tmp = tempfile.TemporaryDirectory()
    case.addCleanup(tmp.cleanup)
    work = Path(tmp.name)
    cfg = {"event_start": "2019-01-01", "event_end": "2026-11-13",
           "roster": [{"company_id": "acme", "company": "Acme"}]}
    seed_sweep.plan(work, cfg)
    tasks = json.loads((work / "discovery/seed-plan.json").read_text())["tasks"]
    (work / "cap.html").write_text(html or "x", encoding="utf-8")
    rows = []
    for task in tasks:
        base = {"task_id": task["task_id"], "executed_at": "2026-11-13", "result_path": "cap.html"}
        if task["channel"] == "thelayoff":
            rows.append({**base, "outcome": collect_seeds.thelayoff_outcome(code),
                         "stop_basis": collect_seeds.thelayoff_stop_basis(
                             "https://www.thelayoff.com/acme", hits, reviewed, cond, code, oldest),
                         "hits": hits,
                         **collect_seeds.thelayoff_window_sweep_fields(reviewed, cond, oldest)})
        elif task["channel"] == "issuer_report":
            basis = "No issuer registration is registered, so the filing channel does not apply."
            rows.append({**base, "outcome": "not_applicable", "stop_basis": basis,
                         "applicability_basis": basis, "hits": []})
        else:
            rows.append({**base, "outcome": "completed", "hits": [],
                         "stop_basis": "The tracker was inspected for this employer and nothing more was needed."})
    batch = work / "b.json"
    batch.write_text(json.dumps(rows), encoding="utf-8")
    seed_sweep.import_receipts(work, cfg, batch)
    return work, cfg, seed_sweep.status(work, cfg)


class ExecuteIntegrationTests(unittest.TestCase):
    """Run collect_seeds.main() on a tempfile workspace with every fetch mocked."""

    def run_collect(self, channel, fake_get, roster=(("acme", "Acme"),), extra=(), registry=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        work = Path(tmp.name)
        cfg = {"event_start": "2019-01-01", "event_end": "2026-11-13",
               "roster": [{"company_id": cid, "company": name} for cid, name in roster]}
        seed_sweep.plan(work, cfg)
        if registry:
            (work / "registry").mkdir()
            (work / "registry/entities.json").write_text(json.dumps({"entries": registry}), encoding="utf-8")
        out = work / "batch.json"
        argv = ["collect_seeds.py", "--work", str(work), "--out", str(out),
                "--only-channel", channel, "--workers", "1", "--pace", "0",
                "--host-confirm-interval", "0", "--thelayoff-transient-backoff", "0,0", *extra]
        render = mock.Mock(return_value=None)
        with mock.patch.object(collect_seeds, "_plain_get", side_effect=fake_get) as get, \
                mock.patch.object(collect_seeds.render_table, "render", render), \
                mock.patch.object(collect_seeds.time, "sleep"), \
                mock.patch.object(sys, "argv", argv):
            collect_seeds.main()
        return work, cfg, json.loads(out.read_text(encoding="utf-8")), get, render

    def test_plain_403_host_is_blocked_with_http_403_reason_and_honest_text(self):
        def fake(url):
            return 403, PLAIN_403
        work, cfg, batch, get, render = self.run_collect(
            "trueup", fake, roster=(("acme", "Acme"), ("beta", "Beta")))
        self.assertEqual(len(batch), 2)
        for receipt in batch:
            self.assertEqual(receipt["outcome"], "blocked")
            self.assertEqual(receipt["hits"], [])
            self.assertEqual(receipt["reason"], "http_403_persistent")
            self.assertNotIn("Cloudflare 403", receipt["stop_basis"])
            self.assertNotIn("empty render", receipt["stop_basis"])
            self.assertIn("no browser render", receipt["stop_basis"])
            self.assertIn("http_403_persistent", receipt["stop_basis"])
        self.assertIn("3 plain HTTP request(s)", batch[0]["stop_basis"])
        # First page 403 is never rendered, and the second company does not fetch at all.
        render.assert_not_called()
        self.assertEqual(get.call_count, 3)

    def test_cloudflare_403_host_is_labelled_cloudflare(self):
        def fake(url):
            return 403, CF_403_HTML
        work, cfg, batch, get, render = self.run_collect("trueup", fake)
        self.assertEqual(batch[0]["reason"], "cloudflare_403_persistent")
        self.assertIn("Cloudflare markers", batch[0]["stop_basis"])
        render.assert_not_called()

    def test_reason_survives_seed_import_and_surfaces_in_seed_status(self):
        def fake(url):
            return 403, PLAIN_403
        work, cfg, batch, _, _ = self.run_collect("trueup", fake)
        rows = list(batch)
        tasks = json.loads((work / "discovery/seed-plan.json").read_text())["tasks"]
        for task in tasks:
            if task["channel"] == "trueup":
                continue
            basis = "No issuer registration is registered, so the filing channel does not apply."
            row = {"task_id": task["task_id"], "executed_at": "2026-11-13",
                   "result_path": batch[0]["result_path"], "hits": []}
            if task["channel"] == "issuer_report":
                row.update(outcome="not_applicable", stop_basis=basis, applicability_basis=basis)
            else:
                row.update(outcome="completed",
                           stop_basis="The tracker was inspected for this employer and nothing more was needed.")
            rows.append(row)
        path = work / "all.json"
        path.write_text(json.dumps(rows), encoding="utf-8")
        status = seed_sweep.import_receipts(work, cfg, path)
        stored = json.loads((work / "discovery/seed-receipts.json").read_text())
        trueup = [r for r in stored.values() if r["channel"] == "trueup"][0]
        self.assertEqual(trueup["reason"], "http_403_persistent")
        gap = [g for g in status["gaps"] if g["channel"] == "trueup"][0]
        self.assertEqual(gap["reason"], "seed_blocked")
        self.assertEqual(gap["receipt_reason"], "http_403_persistent")
        # Status re-verifies the receipt digest, so the stored reason is part of the evidence.
        self.assertEqual(seed_sweep.status(work, cfg)["gaps"], status["gaps"])

    def test_import_rejects_free_text_or_misplaced_reason(self):
        def fake(url):
            return 403, PLAIN_403
        work, cfg, batch, _, _ = self.run_collect("trueup", fake)
        for reason, outcome in (("Cloudflare says no!", "blocked"), ("http_403_persistent", "completed")):
            with self.subTest(reason=reason, outcome=outcome):
                row = dict(batch[0], reason=reason, outcome=outcome)
                path = work / "bad.json"
                path.write_text(json.dumps([row]), encoding="utf-8")
                with self.assertRaises(ValueError):
                    seed_sweep.import_receipts(work, cfg, path)

    def test_non_403_failures_are_not_called_cloudflare_or_persistent(self):
        def fake(url):
            return 429, ""
        work, cfg, batch, get, render = self.run_collect("trueup", fake)
        self.assertEqual(batch[0]["outcome"], "blocked")
        self.assertNotIn("reason", batch[0])
        self.assertNotIn("Cloudflare", batch[0]["stop_basis"])
        self.assertIn("HTTP 429", batch[0]["stop_basis"])

    def test_thelayoff_zero_article_board_without_marker_is_partial(self):
        def fake(url):
            return 200, "<html><body><div id='posts'></div></body></html>"
        work, cfg, batch, _, _ = self.run_collect("thelayoff", fake)
        self.assertEqual(batch[0]["outcome"], "partial")
        self.assertIn("layout", batch[0]["stop_basis"])
        self.assertEqual(batch[0]["pages_reviewed"], 1)


class UnparseableDateTests(unittest.TestCase):
    """R-17: an unparseable Layoffs.fyi date no longer crashes seed-import."""

    def test_table_rows_for_hits_pass_seed_sweep_normalisation(self):
        table = {"by_company": {"acme": [
            {"company": "Acme", "date": "soon", "count": "3", "percentage": "",
             "source": "https://example.com/a", "industry": "Tech"},
            {"company": "Acme", "date": "", "count": "", "percentage": "",
             "source": "", "industry": "Tech"},
            {"company": "Acme", "date": "6/1/2024", "count": "9", "percentage": "",
             "source": "https://example.com/b", "industry": "Tech"},
        ]}}
        hits = collect_seeds.table_rows_for(table, "Acme", [], WINDOW)
        task = {"company_id": "acme"}
        normalized = [seed_sweep._normalize_hit(task, hit) for hit in hits]
        self.assertEqual([hit["reported_date"] for hit in hits], ["", "", "2024-06-01"])
        self.assertEqual([n["reported_date"] for n in normalized], [None, None, "2024-06-01"])
        self.assertEqual([hit["exclusion_reason"] for hit in hits],
                         ["unparseable_date", "unparseable_date", ""])
        self.assertFalse(hits[0]["relevant"])
        self.assertTrue(hits[0]["date_unparseable"])
        self.assertEqual(hits[0]["reported_date_raw"], "soon")
        self.assertIn("soon", hits[0]["title"])
        self.assertNotIn("date_unparseable", hits[2])


if __name__ == "__main__":
    unittest.main()
