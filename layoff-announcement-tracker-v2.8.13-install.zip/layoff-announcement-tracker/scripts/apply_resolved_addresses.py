#!/usr/bin/env python3
"""Carry resolved publisher addresses back into the workspace.

A search feed points at a publisher's article through an aggregator's own
redirect, and that redirect cannot be read as an article. The publisher's
address has to be recovered before the page can be fetched and registered as
a source, and the address has to be carried back into two places:

* the discovery inbox, which is where the registrar reads a candidate from;
* the candidate ledger, which records the address the disposition rests on.

Both places record the same document, so both are told where it lives. The
candidate identity does not change: a document does not become a different
document because its address was resolved.

Usage:

    python "$S/scripts/apply_resolved_addresses.py" --work "$W" \
        --resolution "$W/qa/publisher-resolution-bulk3.json" [--dry-run]
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from urllib.parse import urldefrag

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

INBOXES = ("discovery/inbox.csv", "discovery/seed-inbox.csv")
LEDGER = "event_candidate_review.csv"


def read_csv(path: Path):
    if not path.is_file():
        return [], []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def write_csv(path: Path, fields, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def load_resolution(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        items = payload.get("resolved") or []
    else:
        items = payload
    out = {}
    for item in items:
        cid = item.get("candidate_id")
        address = (item.get("resolved_url") or "").strip()
        if cid and address:
            out[cid] = address
    return out


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--resolution", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    work = Path(args.work).resolve()

    resolved = load_resolution(Path(args.resolution))
    print(f"resolved addresses: {len(resolved)}")

    summary = {"inbox": 0, "ledger": 0, "receipts": 0}

    # --- the discovery inbox the registrar reads from ----------------------
    for name in INBOXES:
        path = work / name
        fields, rows = read_csv(path)
        if not fields:
            continue
        moved = 0
        for row in rows:
            address = resolved.get(row.get("candidate_id"))
            if not address:
                continue
            current = urldefrag((row.get("source_url") or "").strip())[0]
            if not current or current == address:
                continue
            row["source_url"] = address
            row["publisher_address_resolved"] = "true"
            moved += 1
        summary["inbox"] += moved
        if moved and not args.dry_run:
            write_csv(path, fields, rows)
        print(f"  {name}: {moved} address(es) moved")

    # --- the candidate ledger the disposition review reads from ------------
    ledger_path = work / LEDGER
    fields, rows = read_csv(ledger_path)
    moved = 0
    for row in rows:
        address = resolved.get(row.get("candidate_id"))
        if not address:
            continue
        current = urldefrag((row.get("evidence_url") or row.get("source_url") or "").strip())[0]
        if current == address:
            continue
        row["evidence_url"] = address
        row["source_url"] = address
        row["publisher_address_resolved"] = "true"
        moved += 1
    summary["ledger"] = moved
    if moved and not args.dry_run:
        write_csv(ledger_path, fields, rows)
    print(f"  {LEDGER}: {moved} address(es) moved")

    # --- the receipts the discovery ledger records --------------------------
    receipts_path = work / "discovery/receipts.json"
    if receipts_path.is_file() and not args.dry_run:
        receipts = json.loads(receipts_path.read_text(encoding="utf-8"))
        for receipt in receipts.values():
            for hit in receipt.get("hits", []):
                address = resolved.get(hit.get("candidate_id"))
                if not address:
                    continue
                current = urldefrag((hit.get("url") or "").strip())[0]
                if not current or current == address:
                    continue
                hit["url"] = address
                hit["publisher_address_resolved"] = True
                summary["receipts"] += 1
        receipts_path.write_text(json.dumps(receipts, ensure_ascii=False),
                                 encoding="utf-8")
        print(f"  discovery/receipts.json: {summary['receipts']} address(es) moved")

    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
