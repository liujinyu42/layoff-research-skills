#!/usr/bin/env python3
"""Integrity manifest for a delivery package of this skill.

A delivery zip used to be trusted by its file name alone: a run logged
"v282" while the packaged runtime still reported 2.8.0, and no manifest
recorded which bytes were actually shipped. This script produces the
integrity manifest that travels with a package:

* the SHA256 of every shipped file (caches and editor state excluded);
* the runtime version read from ``researchcore/__init__.py`` and the schema
  version read from ``assets/event_schema.json``;
* the version token parsed from the package directory or archive name, with
  an explicit warning when it does not match the runtime version.

Usage:

    python scripts/package_integrity.py --skill <skill-root> [--package-name v283]

The manifest is written to ``integrity-manifest.json`` in the skill root and
must be shipped next to the archive it describes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

EXCLUDED_DIRS = {"__pycache__", ".pytest_cache", ".git", ".DS_Store"}
EXCLUDED_FILES = {".DS_Store", "integrity-manifest.json"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def runtime_version(skill_root: Path) -> str:
    init = skill_root / "scripts" / "researchcore" / "__init__.py"
    match = re.search(r'VERSION\s*=\s*"([^"]+)"', init.read_text(encoding="utf-8"))
    return match.group(1) if match else ""


def schema_version(skill_root: Path) -> str:
    schema = skill_root / "assets" / "event_schema.json"
    try:
        return str(json.loads(schema.read_text(encoding="utf-8")).get("version") or "")
    except (OSError, ValueError):
        return ""


def name_version_token(name: str) -> str:
    match = re.search(r"v?(\d+\.\d+\.\d+|v\d{2,}[a-z]?)", name.lower())
    if not match:
        return ""
    return match.group(1)


def compact_token_to_runtime(token: str) -> str:
    """A compact release token ("v283") read as a runtime version ("2.8.3").

    The skill's release series names packages vNNN after the runtime x.y.z;
    a v282 package shipped with a 2.8.3 runtime once passed unnoticed because
    the token was never compared to the runtime. The dotted form is compared
    exactly; a compact token is mapped by its digits (v282 -> 2.8.2).
    """
    digits = token.lstrip("v")
    if token.startswith("v") and digits.isdigit() and len(digits) == 3:
        return f"{digits[0]}.{digits[1]}.{digits[2]}"
    return ""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skill", required=True, help="the skill root to manifest")
    parser.add_argument("--package-name", default="",
                        help="the package directory or archive name for the version check")
    parser.add_argument("--output", default="",
                        help="where to write the manifest (default: <skill>/integrity-manifest.json)")
    args = parser.parse_args()

    skill_root = Path(args.skill).resolve()
    if not skill_root.is_dir():
        print(f"skill root not found: {skill_root}", file=sys.stderr)
        return 2

    files = {}
    for path in sorted(skill_root.rglob("*")):
        if not path.is_file():
            continue
        if any(part in EXCLUDED_DIRS for part in path.parts):
            continue
        if path.name in EXCLUDED_FILES:
            continue
        relative = path.relative_to(skill_root).as_posix()
        files[relative] = {"sha256": sha256(path), "bytes": path.stat().st_size}

    manifest_sha = hashlib.sha256(
        json.dumps(files, sort_keys=True, ensure_ascii=False,
                   separators=(",", ":")).encode()).hexdigest()
    runtime = runtime_version(skill_root)
    schema = schema_version(skill_root)
    token = name_version_token(args.package_name or skill_root.name)

    warnings = []
    claimed = compact_token_to_runtime(token) or token
    if token and runtime and claimed != runtime:
        warnings.append(
            f"package name claims version {claimed!r} but the packaged runtime "
            f"reports {runtime!r}; verify the archive matches the runtime it names")
    if not runtime:
        warnings.append("runtime version could not be read from researchcore/__init__.py")
    if not schema:
        warnings.append("schema version could not be read from assets/event_schema.json")

    manifest = {
        "runtime_version": runtime,
        "schema_version": schema,
        "package_name_version_token": token,
        "package_name": args.package_name or skill_root.name,
        "manifest_sha256": manifest_sha,
        "file_count": len(files),
        "warnings": warnings,
        "files": files,
    }
    target = Path(args.output) if args.output else skill_root / "integrity-manifest.json"
    target.write_text(json.dumps(manifest, indent=2, ensure_ascii=False,
                                 sort_keys=True) + "\n", encoding="utf-8")
    print(f"integrity manifest: {target}")
    print(f"  runtime={runtime} schema={schema} files={len(files)} "
          f"name_token={token or 'none'}")
    for warning in warnings:
        print(f"  WARNING: {warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
