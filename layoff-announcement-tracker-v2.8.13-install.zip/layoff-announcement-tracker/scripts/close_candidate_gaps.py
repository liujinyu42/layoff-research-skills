#!/usr/bin/env python3
"""Turn registered candidate pages into events and close the candidate ledger.

Three things have to happen in this order, and the order is the whole point:

1. **Cluster.** Every readable registered page is clustered into event plans.
   A page that names one employer and states one reduction about it is one
   event; pages about the same announcement regroup by date.
2. **Bind.** Each plan's `plan_id` is written back onto its sources. The
   runtime builds its entity list from the `plan_id` recorded on each
   registered source, so a plan whose sources do not carry the id cannot
   receive any decision.
3. **Account.** Match candidates to registered plans of the same employer.
   Unread or unclassified leads stay open for substantive review.

Usage:

    python "$S/scripts/close_candidate_gaps.py" --work "$W"
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import io
import json
import sys
from pathlib import Path
from urllib.parse import urldefrag

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore import candidate_review, event_plans, sources as source_module  # noqa: E402
from researchcore.discovery import _atomic  # noqa: E402
from researchcore.event_sources import is_event_source  # noqa: E402
from register_candidates import is_aggregator, resolved_publishers  # noqa: E402

EVENT_ROLES = {"layoff_announcement", "event_filing", "news_report", "official_disclosure"}


def read_json(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    # Rejected records carry the parsed publication `date`, which is more useful
    # to a reader than a repr; emit it as ISO text rather than failing the run.
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=1, default=str),
                          encoding="utf-8")


def read_csv(path):
    path = Path(path)
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def ready_sources(work):
    rows = (read_json(Path(work) / "sources.json", {}) or {}).get("sources", [])
    out = {}
    for row in rows:
        if not row.get("active", True) or row.get("status") != "ready":
            continue
        if row.get("document_role") not in EVENT_ROLES:
            continue
        try:
            text = source_module.text_for(Path(work), row)
        except Exception:  # noqa: BLE001
            continue
        if not text or len(text) < 200:
            continue
        out[row["source_id"]] = {**row, "_text": text}
    return out


def reviewed_events(work, sources, cfg):
    """Read source-bound positive reviews for pages the heuristic could not classify."""
    reviews = read_json(Path(work) / "qa/reviewed-event-sources.json", {}) or {}
    for sid, review in reviews.items():
        source = sources.get(sid, {})
        text = source.get("_text", "")
        quote, start = review.get("quote"), review.get("char_start")
        event_date = review.get("event_date") or ""
        if not isinstance(event_date, str) or len(event_date) != 10:
            raise ValueError(f"Invalid event date for {sid}")
        dt.date.fromisoformat(event_date)
        if (not source or review.get("company_id") != source.get("company_id")
                or review.get("text_sha256") != source.get("text_sha256")
                or not cfg["event_start"] <= event_date <= cfg["event_end"]
                or type(start) is not int or start < 0 or not isinstance(quote, str)
                or not quote.strip() or text[start:start + len(quote)] != quote
                or not all(str(review.get(key) or "").strip()
                           for key in ("reviewer_id", "entity_basis", "action_basis", "date_basis"))):
            raise ValueError(f"Invalid or stale event review for {sid}")
    return reviews


def cluster(work, cfg):
    """Cluster every readable event page and return (plans, rejected, pending)."""
    registry = read_json(Path(work) / "registry/entities.json", {}) or {}
    identities = registry.get("entries", registry)
    records = []
    ready = ready_sources(work)
    reviews = reviewed_events(work, ready, cfg)
    for source in ready.values():
        review = reviews.get(source["source_id"])
        records.append({
            "company_id": source.get("company_id"),
            "source_id": source["source_id"],
            "url": source.get("source_url"),
            "title": source.get("title") or "",
            "date": review["event_date"] if review else
                    (source.get("publication_date") or source.get("source_date") or "")[:10],
            "event_review": review,
            "event_date": review["event_date"] if review else "",
            "form": source.get("form") or "",
            "text": source["_text"],
            "text_path": source.get("text_path"),
            "plan_id": source.get("plan_id") or "",
        })
    # The identifier each registered page already carries is the stable one
    # for the event it belongs to, so the clustering inherits it rather than
    # naming the event after whichever page is strongest today.
    known_plans = {record["source_id"]: record.get("plan_id")
                   for record in records if record.get("plan_id")}
    plans, rejected, pending = event_plans.build_plans(
        records, identities, cfg.get("event_start", "2020-01-01"),
        cfg.get("event_end", "2026-09-30"), known_plans=known_plans)
    return plans, rejected, pending


def bind_plans(work, plans):
    """Write each plan's id onto its sources in the manifest, then re-ingest."""
    manifest = Path(work) / "qa/full_manifest.csv"
    rows = read_csv(manifest)
    if not rows:
        if plans:
            raise ValueError("Run register_candidates.py to build qa/full_manifest.csv before binding plans")
        return 0, 0
    plan_of = {}
    for plan in plans:
        if plan.get("needs_review"):
            continue
        for source in plan.get("sources", []):
            plan_of[source["source_id"]] = plan["plan_id"]
    changed = 0
    for row in rows:
        wanted = plan_of.get(row["source_id"], row.get("plan_id") or "")
        if (row.get("plan_id") or "") != wanted:
            row["plan_id"] = wanted
            changed += 1
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)
    _atomic(manifest, output.getvalue())
    # The sources are re-read whenever the manifest's plan assignment is not
    # already the one the sources carry. Comparing the manifest with itself
    # is not enough: a run that was interrupted between writing the manifest
    # and re-reading the sources leaves the manifest correct and the sources
    # stale, and the next run would then find nothing to change and skip the
    # re-read, leaving a plan that the manifest names and the sources do not.
    wanted = {row["source_id"]: row.get("plan_id", "") for row in rows}
    carried = {row.get("source_id"): row.get("plan_id") or ""
               for row in (read_json(Path(work) / "sources.json", {}) or {}).get("sources", [])}
    stale = [source_id for source_id, plan in wanted.items()
             if carried.get(source_id, "") != plan]
    if changed or stale:
        source_module.ingest(Path(work), manifest, new_only=True)
        print(f"  re-read {len(stale)} source(s) whose plan assignment was stale",
              flush=True)
    return changed, len(plan_of)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    args = parser.parse_args()
    work = Path(args.work).resolve()
    run(work)


def run(work):
    cfg = read_json(work / "config.json", {}) or {}

    print("clustering readable pages into events", flush=True)
    plans, rejected, pending = cluster(work, cfg)
    confirmed = [plan for plan in plans if not plan.get("needs_review")]
    review = [plan for plan in plans if plan.get("needs_review")]
    write_json(work / "qa/event-plans.json",
               {"plans": plans, "rejected": rejected, "pending_review": pending})
    write_json(work / "qa/plan-review-queue.json",
               {"plans": review,
                "undated_pages": [{key: value for key, value in item.items() if key != "text"}
                                  for item in pending]})
    print(f"  plans={len(confirmed)} across {len({p['company_id'] for p in confirmed})} companies; "
          f"plans needing review={len(review)}; "
          f"pages needing review={len(rejected) + len(pending)}", flush=True)

    changed, bound = bind_plans(work, plans)
    print(f"  manifest rows updated={changed}; sources bound to a plan={bound}", flush=True)

    live = source_module.read_sources(work)
    candidate_review.prepare(work, cfg, live, write_tasks=False)
    ledger_path = work / "event_candidate_review.csv"
    rows = read_csv(ledger_path)
    companies = {item["company"]: item["company_id"] for item in cfg.get("roster", [])}
    recovered = resolved_publishers(work)
    ready = {}
    for source in live.values():
        if source.get("active", True) and source.get("status") == "ready":
            key = source["company_id"], urldefrag(source.get("source_url") or "")[0]
            ready.setdefault(key, []).append(source)
    rejected_by_source = {item["source_id"]: item["exclusion_reason"] for item in rejected}
    included = {row["plan_id"] for row in rows if row["disposition"] == "included"}
    for row in rows:
        company_id = companies.get(row["company"])
        if not company_id or row["disposition"] != "unresolved":
            continue
        url = urldefrag(row["evidence_url"] or row["source_url"])[0]
        if is_aggregator(url):
            url = recovered.get(url.split("?")[0], {}).get("resolved_url") or url
        matches = ready.get((company_id, url), [])
        if not matches:
            row["reason"] = "Publisher source has not been verified. Check the original or an alternative public source."
            continue
        bound_sources = {s["plan_id"]: s for s in matches if s.get("plan_id") and is_event_source(s)}
        source = next(iter(bound_sources.values()), matches[0])
        row["evidence_url"] = source["source_url"]
        if len(bound_sources) == 1:
            plan_id = source["plan_id"]
            row.update(disposition="merged" if plan_id in included else "included", plan_id=plan_id,
                       reason="The same employer and source URL are bound to this registered plan.")
            included.add(plan_id)
        else:
            reason = ("Source URL is associated with multiple event plans." if bound_sources else
                      rejected_by_source.get(source["source_id"], "Source requires event review."))
            row["reason"] = f"Pending substantive review: {reason}"

    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=candidate_review.FIELDS, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    _atomic(ledger_path, output.getvalue())
    summary = candidate_review.prepare(work, cfg, live)
    print(f"  ledger rows={len(rows)}; disposition reviews queued={summary['tasks']}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
