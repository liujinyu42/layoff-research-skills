#!/usr/bin/env python3
"""Re-judge the relevance of every recorded hit under the current rules.

A hit's relevance is decided when the search runs, and the rules for that
decision improve as the run uncovers cases the first rules got wrong — a
headline whose only company name is the publisher's own byline, or a report
that falls outside the event window. A receipt that was judged under the
earlier rules still carries the earlier judgement, so the recorded results
would not match what a fresh run would produce.

This tool re-applies the current rule to every hit in every receipt and
reports what changed. It never invents a hit and never drops one: a hit that
the current rule rejects keeps its place in the receipt and is marked as
excluded, with the reason, so the record stays complete and the exclusion is
visible.

The receipts are re-signed afterwards, because a receipt whose contents
changed no longer matches the signature it was written with.
"""

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "scripts"))

import collect_discovery  # noqa: E402
from researchcore.discovery import _digest  # noqa: E402


def rejudge(receipt, window_start, window_end):
    """Re-apply the current relevance rule to one receipt."""
    company = receipt.get("company", "")
    aliases = receipt.get("aliases") or ([company] if company else [])
    generic = any(collect_discovery.is_generic(alias) for alias in aliases)
    changed = 0
    for hit in receipt.get("hits", []):
        relevant, reason = collect_discovery.hit_relevant(
            hit.get("title", ""), aliases, generic,
            publisher=hit.get("publisher", ""),
            reported_date=hit.get("reported_date", ""),
            window_start=window_start, window_end=window_end)
        was = bool(hit.get("relevant"))
        if was != relevant:
            hit["relevant"] = relevant
            hit["exclusion_reason"] = "" if relevant else reason
            changed += 1
        elif not relevant and not hit.get("exclusion_reason"):
            hit["exclusion_reason"] = reason
    return changed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--window-start", default="")
    parser.add_argument("--window-end", default="")
    parser.add_argument("--apply", action="store_true",
                        help="write the re-judged receipts back")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    receipts_path = work / "discovery/receipts.json"
    if not receipts_path.is_file():
        print("no discovery receipts found")
        return 0
    receipts = json.loads(receipts_path.read_text(encoding="utf-8"))

    start = args.window_start
    end = args.window_end
    if not (start and end):
        config = json.loads((work / "config.json").read_text(encoding="utf-8"))
        start = start or config.get("event_start", "")
        end = end or config.get("event_end", "")

    changed_hits = 0
    changed_receipts = 0
    for receipt in receipts.values():
        if not receipt.get("company"):
            task = receipt
            receipt["company"] = task.get("company", "")
            receipt["aliases"] = task.get("aliases", [])
        count = rejudge(receipt, start, end)
        if count:
            changed_receipts += 1
            changed_hits += count
            unsigned = {key: value for key, value in receipt.items()
                        if key != "receipt_sha256"}
            receipt["receipt_sha256"] = _digest(unsigned)

    print(f"window: {start} .. {end}")
    print(f"receipts re-judged: {len(receipts)}")
    print(f"receipts changed: {changed_receipts}")
    print(f"hits re-classified: {changed_hits}")
    if args.apply:
        receipts_path.write_text(json.dumps(receipts, ensure_ascii=False, indent=1),
                                 encoding="utf-8")
        print(f"written to {receipts_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
