"""Regression cases derived from observed v2.3.2 production failures."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bing_discovery
from researchcore.delivery_review import measure_gaps
from researchcore.event_sources import verification_url
from researchcore.search_coverage import normalize


def cell(value, quote=None, **extra):
    return {'status': 'observed', 'value': value,
            'evidence': [{'quote': quote}] if quote else [], **extra}


class SemanticRegressionTests(unittest.TestCase):
    entities = {
        'g': {'company_id': 'google', 'company': 'Google'},
        's': {'company_id': 'sap', 'company': 'SAP'},
        'o': {'company_id': 'opentext', 'company': 'OpenText'},
        'r': {'company_id': 'getaround', 'company': 'Getaround'},
        'u': {'company_id': 'unity', 'company': 'Unity'},
        'e': {'company_id': 'example', 'company': 'Example'},
    }
    roster = [{'company_id': 'amazon', 'company': 'Amazon'},
              {'company_id': 'google', 'company': 'Google', 'aliases': 'Alphabet'}]

    def reasons(self, decisions, entities=None):
        return [gap['reason'] for gap in measure_gaps(decisions, entities or self.entities, self.roster)]

    def test_google_newline_does_not_hide_2023_recap(self):
        decisions = {
            'g|announcement_date': cell('2025-01-10', date_basis='news_reported_announcement'),
            'g|layoff_count': cell(12000, 'Google announced a new reduction.\nIn 2023, Google laid off 12,000 employees.'),
        }
        self.assertTrue(any('historical/cumulative' in reason for reason in self.reasons(decisions)))

    def test_sap_cannot_use_amazon_count(self):
        decisions = {'s|layoff_count': cell(18000, 'Amazon laid off 18,000 employees in January 2025.')}
        self.assertTrue(any('target employer' in reason and 'Amazon' in reason
                            for reason in self.reasons(decisions)))

    def test_opentext_year_only_mismatch_is_rejected(self):
        decisions = {
            'o|announcement_date': cell('2026-02-01', date_basis='announcement'),
            'o|layoff_count': cell(1200, 'In 2024, OpenText cut 1,200 jobs.'),
        }
        self.assertTrue(any('historical/cumulative' in reason for reason in self.reasons(decisions)))

    def test_getaround_previous_percentage_is_rejected(self):
        decisions = {
            'r|layoff_percentage': cell(30, 'Getaround had previously announced a 30% reduction.'),
            'r|layoff_percentage_qualifier': cell('exact'),
            'r|layoff_percentage_denominator': cell('Current workforce', 'Getaround had previously announced a 30% reduction.'),
        }
        self.assertTrue(any('historical/cumulative' in reason for reason in self.reasons(decisions)))

    def test_exact_percentage_rejects_zero_zero_bounds(self):
        decisions = {
            'r|layoff_percentage': cell(30, 'Getaround cut 30% of staff.'),
            'r|layoff_percentage_lower': cell(0, 'Getaround cut 30% of staff.'),
            'r|layoff_percentage_upper': cell(0, 'Getaround cut 30% of staff.'),
            'r|layoff_percentage_qualifier': cell('exact'),
            'r|layoff_percentage_denominator': cell('Workforce', 'Getaround cut 30% of staff.'),
        }
        self.assertTrue(any('null lower/upper bounds' in reason for reason in self.reasons(decisions)))

    def test_unity_range_cannot_become_approximate_point(self):
        decisions = {
            'u|layoff_count': cell(400, 'Unity will cut 300 or 400 jobs.'),
            'u|layoff_count_qualifier': cell('approximately'),
        }
        self.assertTrue(any('numeric range' in reason for reason in self.reasons(decisions)))

    def test_publication_date_is_not_announcement_date(self):
        decisions = {'e|announcement_date': cell('2025-01-01', date_basis='publication')}
        self.assertTrue(any('date_basis' in reason for reason in self.reasons(decisions)))

    def test_address_is_not_country(self):
        decisions = {'e|country': cell('100 Main Street, Springfield 94105')}
        self.assertTrue(any('controlled country/jurisdiction' in reason for reason in self.reasons(decisions)))

    def test_valid_alias_and_point_percentage_control(self):
        decisions = {
            'g|announcement_date': cell('2025-01-15', date_basis='company_statement'),
            'g|layoff_count': cell(500, 'Alphabet cut 500 jobs in January 2025.'),
            'g|layoff_count_qualifier': cell('exact'),
            'g|layoff_percentage': cell(10, 'Alphabet cut 10% of staff in January 2025.'),
            'g|layoff_percentage_qualifier': cell('exact'),
            'g|layoff_percentage_denominator': cell('Workforce', 'Alphabet cut 10% of staff in January 2025.'),
            'g|country': cell('United States'),
            'g|plan_relationship': cell('independent', plan_link_basis='Only event in this plan'),
        }
        self.assertEqual(self.reasons(decisions), [])


class SourceAndSearchRegressionTests(unittest.TestCase):
    def test_primary_source_precedes_news_for_verification_url(self):
        news = {'source_id': 'news', 'source_type': 'news', 'document_role': 'news_report',
                'status': 'ready', 'company_id': 'c', 'plan_id': 'p',
                'source_url': 'https://news.example/report'}
        primary = {'source_id': 'primary', 'source_type': 'company_announcement',
                   'document_role': 'layoff_announcement', 'status': 'ready',
                   'company_id': 'c', 'plan_id': 'p', 'source_url': 'https://company.example/notice'}
        decisions = {
            'p|layoff_count': {'evidence': [{'source_id': 'news'}]},
            'p|announcement_date': {'evidence': [{'source_id': 'primary'}]},
        }
        self.assertEqual(verification_url('p', decisions, {'news': news, 'primary': primary}),
                         primary['source_url'])

    def search_row(self, pages):
        return {'company_id': 'c', 'window_start': '2025-01-01', 'window_end': '2025-12-31',
                'channel': 'news_index', 'query': 'Example annual layoffs sweep',
                'executed_at': '2026-01-01', 'outcome': 'found_events', 'events_registered': 'p',
                'search_scope': 'window_sweep', 'pages_reviewed': pages,
                'stop_condition': 'Inspected all returned pages through the end of the requested window.'}

    def test_window_sweep_requires_nonnegative_integer_pages(self):
        contract = {'channels': {'news_index': {}},
                    'outcomes': {'found_events': {'counts_as_covered': True}}}
        cfg = {'roster': [{'company_id': 'c', 'company': 'Example'}],
               'event_start': '2025-01-01', 'event_end': '2025-12-31'}
        ents = {'p': {'company_id': 'c'}}
        for invalid in ('', -1, 1.5, True):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                normalize(contract, self.search_row(invalid), 1, cfg, ents)
        record = normalize(contract, self.search_row('3'), 1, cfg, ents)
        self.assertEqual(record['pages_reviewed'], 3)
        self.assertTrue(record['counts_as_covered'])


class BingDiscoveryRegressionTests(unittest.TestCase):
    def test_all_queries_include_aliases(self):
        row = {'company': 'Example Corp', 'aliases': 'Old Example;Example Brand'}
        queries = bing_discovery.queries_for(row, ['"{c}" layoffs'])
        self.assertEqual(len(queries), 3)
        self.assertTrue(any('Old Example' in query for query in queries))
        self.assertTrue(any('Example Brand' in query for query in queries))

    def test_boundary_buffer_and_url_or_title_deduplication(self):
        xml = b'''<rss><channel>
        <item><title>Example announces cuts</title><link>https://news.example/a</link><pubDate>Tue, 20 Jan 2026 08:00:00 GMT</pubDate></item>
        <item><title>Different headline, same URL</title><link>https://news.example/a</link><pubDate>Tue, 20 Jan 2026 08:00:00 GMT</pubDate></item>
        <item><title>Example   announces cuts</title><link>https://other.example/b</link><pubDate>Tue, 20 Jan 2026 08:00:00 GMT</pubDate></item>
        <item><title>Too late</title><link>https://news.example/c</link><pubDate>Sun, 01 Mar 2026 08:00:00 GMT</pubDate></item>
        </channel></rss>'''
        rows = bing_discovery.parse_rss(xml, '2025-01-01', '2025-12-31')
        self.assertEqual(len(rows), 3)
        unique = bing_discovery.deduplicate(rows)
        self.assertEqual(len(unique), 1)
        self.assertEqual(unique[0]['url'], 'https://news.example/a')

    def test_request_failure_and_empty_completion_have_distinct_receipts(self):
        row = {'company_id': 'c', 'company': 'Example', 'aliases': []}
        failed_session = mock.Mock()
        failed_session.get.side_effect = requests.ConnectionError('network unavailable')
        with mock.patch.object(bing_discovery, 'sess', return_value=failed_session), \
             mock.patch.object(bing_discovery.time, 'sleep'):
            failed = bing_discovery.discover(row, '2025-01-01', '2025-12-31', 0, ['"{c}" layoffs'])
        self.assertEqual(failed['status'], 'failed')
        self.assertEqual(failed['query_receipts'][0]['status'], 'request_error')
        self.assertIn('network unavailable', failed['query_receipts'][0]['error'])

        response = mock.Mock(status_code=200, content=b'<rss><channel></channel></rss>')
        empty_session = mock.Mock()
        empty_session.get.return_value = response
        with mock.patch.object(bing_discovery, 'sess', return_value=empty_session), \
             mock.patch.object(bing_discovery.time, 'sleep'):
            empty = bing_discovery.discover(row, '2025-01-01', '2025-12-31', 0, ['"{c}" layoffs'])
        self.assertEqual(empty['status'], 'completed')
        self.assertEqual(empty['query_receipts'][0]['result_count'], 0)
        self.assertIsNone(empty['query_receipts'][0]['error'])

    def test_resume_requires_completed_payload(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'candidate.json'
            path.write_text(json.dumps({'status': 'partial', 'candidates': [], 'query_receipts': []}))
            self.assertIsNone(bing_discovery.completed_payload(path))
            path.write_text(json.dumps({'status': 'completed', 'candidates': [], 'query_receipts': []}))
            self.assertIsNotNone(bing_discovery.completed_payload(path))


if __name__ == '__main__':
    unittest.main()
