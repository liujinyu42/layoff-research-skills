#!/usr/bin/env python3
"""Rules the publisher-address resolver has to keep.

Every case here was a real failure of the resolver:

* a publisher that puts a whole slug in one path segment was not recognised
  as an article address, so the article was never accepted;
* the text "02" appears inside the name of the December slice, so the slice
  for February was read as the slice for December;
* a publisher that names its own site maps in its robots file was read only
  at the conventional addresses, so the index that lists its dated slices was
  never found;
* the words that carry no meaning were treated as distinctive, so an
  unrelated article matched a title.

Run:

    python "$S/scripts/test_publisher_resolution.py"
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import resolve_publishers as rp  # noqa: E402


class ArticleAddress(unittest.TestCase):
    def test_multi_segment_path_is_an_article(self):
        self.assertTrue(rp.is_article_address(
            "https://techcrunch.com/2024/02/29/fisker-layoffs/"))

    def test_numeric_segment_is_an_article(self):
        self.assertTrue(rp.is_article_address(
            "https://example.com/news/12345"))

    def test_single_hyphenated_slug_is_an_article(self):
        self.assertTrue(rp.is_article_address(
            "https://www.businessinsider.com/tech-layoffs-pagerduty-ceo-"
            "apologizes-martin-luther-king-jr-quote-2023-2"))

    def test_single_bare_word_is_not_an_article(self):
        self.assertFalse(rp.is_article_address("https://example.com/news"))

    def test_home_page_is_not_an_article(self):
        self.assertFalse(rp.is_article_address("https://example.com"))


class DistinctiveWords(unittest.TestCase):
    def test_meaningless_words_are_dropped(self):
        words = rp.slug_words("Intel layoffs 2024 what to know as INTC plans "
                               "to slash thousands of jobs")
        distinctive = rp._distinctive(words)
        self.assertNotIn("what", distinctive)
        self.assertNotIn("know", distinctive)
        self.assertIn("Intel", distinctive)

    def test_company_name_is_kept(self):
        words = rp.slug_words("PagerDuty CEO Apologizes for Martin Luther "
                               "King Jr. Layoff Quote")
        distinctive = rp._distinctive(words)
        self.assertIn("PagerDuty", distinctive)


class DatedSlice(unittest.TestCase):
    def test_month_is_read_as_a_pair_with_the_year(self):
        import re
        text = "https://www.businessinsider.com/sitemap/2023-12.xml"
        stamped = re.search(r"/(\d{4})-(\d{2})\.xml$", text)
        self.assertIsNotNone(stamped)
        self.assertEqual(stamped.group(1), "2023")
        self.assertEqual(stamped.group(2), "12")
        # The loose test would have matched February's slice too.
        self.assertTrue("02" in text)


class SlugWords(unittest.TestCase):
    def test_publisher_suffix_is_dropped(self):
        words = rp.slug_words("Fisker layoffs as cash dwindles - TechCrunch")
        self.assertNotIn("TechCrunch", words)

    def test_empty_title(self):
        self.assertEqual(rp.slug_words(""), [])


class TitleMatch(unittest.TestCase):
    def test_unrelated_page_with_one_shared_word_is_rejected(self):
        # A picture gallery that names the same company is not the report
        # about that company's reduction.
        self.assertFalse(rp.title_matches(
            "Pictures: The Seagate Hotel Spa In Delray Beach",
            ["Seagate", "layoffs", "hotel", "delray", "beach"]))

    def test_the_article_itself_matches(self):
        self.assertTrue(rp.title_matches(
            "Redfin lays off 862 employees and closes home flipping business",
            ["Redfin", "lays", "employees", "closes", "home", "business"]))

    def test_digits_are_not_counted(self):
        self.assertTrue(rp.title_matches(
            "Company cuts 5,000 jobs", ["Company", "cuts", "5,000", "jobs"]))


if __name__ == "__main__":
    unittest.main()
