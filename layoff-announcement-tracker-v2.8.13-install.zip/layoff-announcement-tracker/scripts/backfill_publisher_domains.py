#!/usr/bin/env python3
"""Recover each publisher's own domain from the saved search captures.

The feed's `<source>` element carries the publisher's display name and the
publisher's own domain. The receipt records the display name, but a capture
written before that field existed kept only the name.

This tool reads the saved captures and fills the missing publisher domain
onto the receipts, so an aggregator hit can be resolved to the publisher's
own article page. It changes nothing else: the title, the URL and the
relevance verdict are taken from the receipt, and the domain is read from the
capture the receipt points at.

Usage:

    python "$S/scripts/backfill_publisher_domains.py" --work "$W"
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import xml.etree.ElementTree as ET  # noqa: E402


def read_json(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        return default


def domains_in_capture(path):
    """The publisher domains a capture records, keyed by article id."""
    path = Path(path)
    if not path.is_file():
        return {}
    try:
        body = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {}
    if "<item>" not in body:
        return {}
    try:
        root = ET.fromstring(body)
    except ET.ParseError:
        return {}
    out = {}
    for node in root.iter("item"):
        link = ""
        child = node.find("link")
        if child is not None and child.text:
            link = child.text.strip()
        if not link:
            continue
        source_url = ""
        for src in node.iter("source"):
            if src.get("url"):
                source_url = src.get("url")
            break
        if source_url:
            out[link.split("?")[0]] = source_url
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    args = parser.parse_args()

    work = Path(args.work).resolve()
    receipts = read_json(work / "discovery/receipts.json", {}) or {}
    filled = 0
    scanned = 0

    def backfill(records):
        """Fill the publisher domain onto every hit of every record."""
        changed = 0
        for receipt in records:
            capture = work / str(receipt.get("result_path", ""))
            if not capture.is_file():
                continue
            domains = domains_in_capture(capture)
            if not domains:
                continue
            for hit in receipt.get("hits", []):
                if hit.get("publisher_url"):
                    continue
                domain = domains.get(str(hit.get("url", "")).split("?")[0])
                if domain:
                    hit["publisher_url"] = domain
                    changed += 1
        return changed

    # The batch files are the executor's output; the runtime reads the
    # receipts, so both are updated when both exist.
    for batch_path in sorted((work / "discovery").glob("google-*.json")):
        batch = read_json(batch_path)
        if not isinstance(batch, list):
            continue
        changed = backfill(batch)
        if changed:
            batch_path.write_text(json.dumps(batch, ensure_ascii=False, indent=1),
                                  encoding="utf-8")
            print(f"{batch_path.name}: filled {changed} publisher domain(s)")
            filled += changed

    if receipts:
        scanned = len(receipts)
        filled += backfill(list(receipts.values()))
        (work / "discovery/receipts.json").write_text(
            json.dumps(receipts, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"scanned {scanned} receipt(s); filled {filled} publisher domain(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
