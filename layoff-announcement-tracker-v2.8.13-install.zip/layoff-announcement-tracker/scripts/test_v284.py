import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from researchcore import event_plans
from prepare_followups import prepare

class RegressionTests(unittest.TestCase):
    def test_periodic_date_requires_review(self):
        record = {'company_id':'x','source_id':'s','url':'https://example.com','form':'10-Q','date':'2024-06-30','text':'Example cuts 20 jobs.','title':'Quarterly results'}
        with patch.object(event_plans, 'page_binds_to_company', return_value=(True,'','Example')):
            plans, rejected, pending = event_plans.build_plans([record], {'x':{'company':'Example'}}, '2024-01-01','2024-12-31')
        self.assertEqual(plans, [])
        self.assertEqual(len(pending), 1)
    def test_missing_fields_grouped_per_plan(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'qa').mkdir()
            (p/'config.json').write_text(json.dumps({'roster':[{'company_id':'x','company':'Example'}]}))
            (p/'qa/event-plans.json').write_text(json.dumps({'plans':[{'plan_id':'p','company_id':'x','event_date':'2024-03-01'}]}))
            (p/'decisions.json').write_text(json.dumps({'p|layoff_count':{'status':'observed','value':20}}))
            tasks=prepare(p)
            self.assertEqual(tasks[0]['fields'],['announcement_date','layoff_percentage'])
            self.assertEqual(len(tasks),1)
