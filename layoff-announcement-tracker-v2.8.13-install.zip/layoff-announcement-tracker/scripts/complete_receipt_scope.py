#!/usr/bin/env python3
"""Complete the receipts that were written before the plan carried its scope.

A receipt records the planned query, the scope it answers and the relevance
verdict for every result. The runtime re-derives the company identity check
from the receipt's own scope fields, so a receipt that omits them cannot be
matched against the candidate ledger: every relevant hit reads as a
candidate whose identity does not hold, and the round never passes the
discovery gate.

Earlier receipts were written from a batch format that carried the query and
the company id but not the aliases, the window or the pass depth. The plan
holds all of them, and the plan is the authority on what each task asks, so
the missing scope is copied from it. The signature is recomputed afterwards,
because a receipt whose content changed but whose signature did not is
rejected as altered.

Nothing about an outcome, a result path or a relevance verdict is touched.

Usage:

    python "$S/scripts/complete_receipt_scope.py" --work "$W"
    python "$S/scripts/complete_receipt_scope.py" --work "$W" --dry-run
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore import discovery as discovery_module  # noqa: E402

SCOPE_FIELDS = ("aliases", "window_start", "window_end", "pass")


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def read_json(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    plan = read_json(work / "discovery/plan.json", {}) or {}
    tasks = {task["task_id"]: task for task in plan.get("tasks", [])}
    receipts_path = work / "discovery/receipts.json"
    receipts = read_json(receipts_path, {}) or {}

    completed = 0
    unknown = 0
    for task_id, receipt in receipts.items():
        task = tasks.get(task_id)
        if not task:
            unknown += 1
            continue
        missing = [field for field in SCOPE_FIELDS if field not in receipt]
        if not missing:
            continue
        updated = {**receipt}
        for field in missing:
            updated[field] = task.get(field, "")
        updated.pop("receipt_sha256", None)
        updated["receipt_sha256"] = digest(updated)
        receipts[task_id] = updated
        completed += 1

    report = {"receipts": len(receipts), "completed": completed,
              "unknown_task": unknown}
    if not args.dry_run:
        discovery_module._save(receipts_path, receipts)
        report["saved"] = str(receipts_path)
    print(json.dumps(report, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
