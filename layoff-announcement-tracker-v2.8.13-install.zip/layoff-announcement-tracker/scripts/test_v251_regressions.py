"""Regressions for failures observed in the WorkBuddy v2.5.0-directory run."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest

from researchcore import VERSION, contracts, registry
from researchcore.delivery_review import measure_gaps
from researchcore.workflow import discovery_integrity_errors, main, runtime_check


SKILL = Path(__file__).resolve().parents[1]


def cell(value, quote=None, status="observed", **extra):
    record = {"status": status, "value": value,
              "evidence": [{"quote": quote}] if quote is not None else []}
    record.update(extra)
    return record


def reasons(decisions, company="Example"):
    entities = {"p": {"company_id": "c", "company": company}}
    return [gap["reason"] for gap in measure_gaps(decisions, entities)]


class V251CountRegressionTests(unittest.TestCase):
    def test_fate_remaining_headcount_is_not_layoff_count(self):
        text = "After the reduction, Fate will retain approximately 220 employees in December 2022."
        found = reasons({"p|announcement_date": cell("2022-12-01", date_basis="announcement"),
                         "p|layoff_count": cell(220, text)}, "Fate Therapeutics")
        self.assertTrue(any("remaining headcount" in reason for reason in found), found)

    def test_lyft_furlough_is_not_termination_count(self):
        text = "Lyft furloughed 288 employees and terminated 982 employees in April 2020."
        found = reasons({"p|announcement_date": cell("2020-04-29", date_basis="announcement"),
                         "p|layoff_count": cell(288, text)}, "Lyft")
        self.assertTrue(any("furloughs" in reason for reason in found), found)

    def test_lyft_termination_count_is_not_blocked_by_adjacent_furlough(self):
        text = "Lyft furloughed 288 employees and terminated 982 employees in April 2020."
        found = reasons({"p|announcement_date": cell("2020-04-29", date_basis="announcement"),
                         "p|layoff_count": cell(982, text)}, "Lyft")
        self.assertFalse(any("furloughs" in reason for reason in found), found)

    def test_lyft_open_positions_are_not_laid_off_employees(self):
        text = "Lyft laid off 1,072 employees and eliminated 250 open positions in April 2023."
        found = reasons({"p|announcement_date": cell("2023-04-27", date_basis="announcement"),
                         "p|layoff_count": cell(250, text)}, "Lyft")
        self.assertTrue(any("open/vacant positions" in reason for reason in found), found)

    def test_new_relic_single_geographic_component_requires_complete_review(self):
        text = ("New Relic laid off 155 employees in the United States and 57 employees "
                "internationally in November 2022.")
        decisions = {"p|announcement_date": cell("2022-11-08", date_basis="announcement"),
                     "p|layoff_count": cell(155, text)}
        found = reasons(decisions, "New Relic")
        self.assertTrue(any("geographic workforce components" in reason for reason in found), found)

    def test_complete_geographic_component_review_is_accepted(self):
        text = ("New Relic laid off 155 employees in the United States and 57 employees "
                "internationally in November 2022.")
        review = {"status": "complete", "components": [155, 57],
                  "basis": "Both disjoint geographic components were checked against the complete statement."}
        decisions = {"p|announcement_date": cell("2022-11-08", date_basis="announcement"),
                     "p|layoff_count": cell(155, text, geographic_component_review=review)}
        found = reasons(decisions, "New Relic")
        self.assertFalse(any("geographic workforce components" in reason for reason in found), found)

    def test_more_than_cannot_be_stored_as_upper_bound(self):
        decisions = {
            "p|layoff_count_qualifier": cell("more_than", "Example laid off more than 100 employees."),
            "p|layoff_count_upper": cell(100, "Example laid off more than 100 employees."),
        }
        found = reasons(decisions)
        self.assertTrue(any("requires an observed layoff_count_lower" in reason for reason in found), found)
        self.assertTrue(any("must leave layoff_count_upper null" in reason for reason in found), found)

    def test_valid_exact_count_still_passes(self):
        decisions = {"p|announcement_date": cell("2025-01-15", date_basis="announcement"),
                     "p|layoff_count_qualifier": cell("exact", "Example laid off 500 employees in January 2025."),
                     "p|layoff_count": cell(500, "Example laid off 500 employees in January 2025.")}
        self.assertEqual(reasons(decisions), [])


class V251IdentityAndWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.work = Path(self.temporary.name)
        self.entries = {
            "a": {"company_id": "a", "display_name": "Alpha", "status": "verified",
                  "registrant_cik": "0000000001", "current_registrant_cik": "0000000001",
                  "historical_ciks": [], "parent_company_id": None,
                  "official_website": "https://alpha.example", "business_description": "Software"},
            "b": {"company_id": "b", "display_name": "Beta", "status": "verified",
                  "registrant_cik": "0000000001", "current_registrant_cik": "0000000001",
                  "historical_ciks": [], "parent_company_id": None,
                  "official_website": "https://beta.example", "business_description": "Therapeutics"},
        }
        self.cfg = {"roster": [{"company_id": "a", "company": "Alpha", "cik": "1"},
                               {"company_id": "b", "company": "Beta", "cik": "1"}]}

    def save_registry(self):
        contracts.write_json(self.work / "registry/entities.json", {"entries": self.entries})

    def test_unrelated_companies_cannot_share_registrant_cik(self):
        self.save_registry()
        report = registry.check(SKILL, self.work, self.cfg)
        self.assertFalse(report["pass"])
        self.assertTrue(any("share one registrant CIK" in item["error"] for item in report["errors"]))

    def test_verified_parent_brand_chain_may_share_registrant_cik(self):
        self.entries["b"]["parent_company_id"] = "a"
        self.save_registry()
        report = registry.check(SKILL, self.work, self.cfg)
        self.assertTrue(report["pass"], report["errors"])

    def test_current_cik_conflict_with_collection_cik_is_rejected(self):
        self.entries["a"]["registrant_cik"] = "0000727632"
        self.entries["a"]["current_registrant_cik"] = "0001341439"
        self.entries["b"]["registrant_cik"] = "0000000002"
        self.entries["b"]["current_registrant_cik"] = "0000000002"
        self.cfg["roster"][0]["cik"] = "727632"
        self.cfg["roster"][1]["cik"] = "2"
        self.save_registry()
        report = registry.check(SKILL, self.work, self.cfg)
        self.assertFalse(report["pass"])
        self.assertTrue(any("conflicts with verified current_registrant_cik" in item["error"]
                            for item in report["errors"]))

    def test_runtime_check_reports_actual_v251_and_schema(self):
        report = runtime_check(SKILL)
        self.assertTrue(report["pass"], report)
        # The runtime reports the version the runtime actually carries, so
        # this assertion follows the release rather than pinning a number
        # that a release bump would silently invalidate.
        from researchcore import VERSION
        self.assertEqual(report["runtime_version"], VERSION)
        self.assertEqual(report["schema_version"], "1.6.0")
        self.assertEqual(Path(report["skill_path"]), SKILL)
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = main(SKILL, ["runtime-check"])
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(output.getvalue())["runtime_version"], VERSION)

    def test_stage_two_not_executed_is_integrity_error(self):
        review = {"gaps": [{"reason": "search_not_executed", "task_id": "search-1"}]}
        errors = discovery_integrity_errors(review)
        self.assertEqual(len(errors), 1)
        self.assertIn("--allow-partial cannot bypass", errors[0]["error"])

    def test_real_blocked_search_remains_named_partial_gap(self):
        review = {"gaps": [{"reason": "search_blocked", "task_id": "search-1"}]}
        self.assertEqual(discovery_integrity_errors(review), [])


if __name__ == "__main__":
    unittest.main()
