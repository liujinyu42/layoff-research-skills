"""Unit tests for ingest retry/backoff and Wayback raw-capture fetching.

Requests are mocked and workspaces live under tempfile; nothing is written to
the layoff-run output directory.
"""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import requests

from researchcore import sources as source_module


HTML_OK = b"<!DOCTYPE html><html><head><title>Acme</title></head><body><p>Acme is a company.</p></body></html>"
HTML_WRAPPER = (
    b"<!DOCTYPE html><html><head><title></title>"
    b'<script src="https://web-static.archive.org/_static/js/bundle-playback.js"></script>'
    b"</head><body>"
    b"<p>Keep the news in the Wayback Machine.</p>"
    b"<p>Please Don't Scroll Past This</p>"
    b"</body></html>"
)


class FakeResponse:
    def __init__(self, status, body=b"", url="https://example.test/page", reason=None, content_type="text/html"):
        self.status_code = status
        self._body = body
        self.url = url
        self.reason = reason if reason is not None else {404: "Not Found", 410: "Gone", 500: "Internal Server Error"}.get(status, "Error")
        self.headers = {"Content-Type": content_type}

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def iter_content(self, size):
        yield self._body

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"{self.status_code} Error for url: {self.url}", response=self)


def _work():
    work = Path(tempfile.mkdtemp())
    (work / "config.json").write_text(json.dumps({
        "version": "2.8.0", "mode": "events",
        "roster": [{"company_id": "acme-1", "company": "Acme"}],
        "year_start": 2020, "year_end": 2026,
        "event_start": "2020-01-01", "event_end": "2026-09-30",
        "profile": "proposal-core", "contract_level": "strict",
    }), encoding="utf-8")
    return work


def _manifest(work, rows):
    path = work / "manifest.json"
    path.write_text(json.dumps(rows), encoding="utf-8")
    return path


def _row(source_id="src-1", url="https://example.test/page"):
    return {
        "source_id": source_id,
        "company_id": "acme-1",
        "source_type": "company_profile",
        "source_url": url,
        "document_role": "company_profile",
    }


def _ledger(work):
    payload = json.loads((work / "sources.json").read_text(encoding="utf-8"))
    return {entry["source_id"]: entry for entry in payload["sources"]}


class IngestRetryTests(unittest.TestCase):
    def setUp(self):
        self.work = _work()
        self.sleep = mock.patch.object(source_module.time, "sleep").start()
        self.addCleanup(mock.patch.stopall)
        self.addCleanup(lambda: __import__("shutil").rmtree(self.work, ignore_errors=True))

    def ingest(self, rows, **kwargs):
        return source_module.ingest(self.work, _manifest(self.work, rows), **kwargs)

    def test_404_is_not_intra_retried_and_is_skipped_on_next_ingest(self):
        url = "https://example.test/missing"
        response = FakeResponse(404, url=url)
        with mock.patch("requests.get", return_value=response) as get:
            first = self.ingest([_row(url=url)])
            self.assertEqual(get.call_count, 1)
        entry = first[0]
        self.assertEqual(entry["status"], "failed")
        self.assertEqual(entry["error_class"], "http_404")
        self.assertEqual(entry["failure_count"], 1)
        self.assertTrue(entry.get("last_attempt"))

        with mock.patch("requests.get", return_value=response) as get:
            second = self.ingest([_row(url=url)])
            self.assertEqual(get.call_count, 0)
        skipped = second[0]
        self.assertEqual(skipped["status"], "failed")
        self.assertEqual(skipped["error_class"], "http_404")
        self.assertEqual(skipped["failure_count"], 1)
        self.assertTrue(skipped["from_cache"])
        self.assertEqual(skipped["last_attempt"], entry["last_attempt"])

    def test_500_is_retried_three_times_then_skipped_during_backoff(self):
        url = "https://example.test/flaky"
        response = FakeResponse(500, url=url)
        with mock.patch("requests.get", return_value=response) as get:
            first = self.ingest([_row(url=url)])
            self.assertEqual(get.call_count, 3)
        self.assertGreaterEqual(self.sleep.call_count, 2)
        entry = first[0]
        self.assertEqual(entry["status"], "failed")
        self.assertEqual(entry["error_class"], "http_500")
        self.assertEqual(entry["failure_count"], 1)

        self.sleep.reset_mock()
        with mock.patch("requests.get", return_value=response) as get:
            second = self.ingest([_row(url=url)])
            self.assertEqual(get.call_count, 0)
        skipped = second[0]
        self.assertEqual(skipped["status"], "failed")
        self.assertEqual(skipped["error_class"], "http_500")
        self.assertEqual(skipped["failure_count"], 1)
        self.assertTrue(skipped["from_cache"])

    def test_retry_failed_and_refresh_and_changed_url_reattempt(self):
        missing = "https://example.test/missing"
        ok = "https://example.test/ok"
        with mock.patch("requests.get", return_value=FakeResponse(404, url=missing)) as get:
            self.ingest([_row(url=missing)])
            self.assertEqual(get.call_count, 1)

        with mock.patch("requests.get", return_value=FakeResponse(200, HTML_OK, url=missing)) as get:
            rows = self.ingest([_row(url=missing)], retry_failed=True)
            self.assertEqual(get.call_count, 1)
        self.assertEqual(rows[0]["status"], "ready")

        with mock.patch("requests.get", return_value=FakeResponse(404, url=missing)) as get:
            failed = self.ingest([_row(url=missing)], refresh=True)
            self.assertEqual(get.call_count, 1)
        self.assertEqual(failed[0]["status"], "failed")
        self.assertEqual(failed[0]["error_class"], "http_404")

        with mock.patch("requests.get", return_value=FakeResponse(200, HTML_OK, url=ok)) as get:
            changed = self.ingest([_row(url=ok)])
            self.assertEqual(get.call_count, 1)
            self.assertEqual(get.call_args[0][0], ok)
        self.assertEqual(changed[0]["status"], "ready")
        self.assertEqual(changed[0]["source_url"], ok)


class WaybackFetchTests(unittest.TestCase):
    def setUp(self):
        self.work = _work()
        self.sleep = mock.patch.object(source_module.time, "sleep").start()
        self.addCleanup(mock.patch.stopall)
        self.addCleanup(lambda: __import__("shutil").rmtree(self.work, ignore_errors=True))

    def ingest(self, url, **kwargs):
        return source_module.ingest(
            self.work, _manifest(self.work, [_row(url=url)]), **kwargs
        )

    def test_id_is_inserted_and_existing_modifiers_are_left_alone(self):
        cases = [
            (
                "https://web.archive.org/web/20130919085618/http://example.com/",
                "https://web.archive.org/web/20130919085618id_/http://example.com/",
            ),
            (
                "https://web.archive.org/web/2023/https://example.com/",
                "https://web.archive.org/web/2023id_/https://example.com/",
            ),
        ]
        for original, expected in cases:
            with self.subTest(original=original):
                work = _work()
                try:
                    with mock.patch("requests.get", return_value=FakeResponse(200, HTML_OK, url=expected)) as get:
                        source_module.ingest(work, _manifest(work, [_row(url=original)]))
                    self.assertEqual(get.call_args[0][0], expected)
                    self.assertEqual(_ledger(work)["src-1"]["source_url"], original)
                    self.assertEqual(_ledger(work)["src-1"]["status"], "ready")
                finally:
                    __import__("shutil").rmtree(work, ignore_errors=True)

        for original in (
            "https://web.archive.org/web/20130919085618id_/http://example.com/",
            "https://web.archive.org/web/20130919085618js_/http://example.com/app.js",
            "https://web.archive.org/web/20130919085618cs_/http://example.com/app.css",
            "https://web.archive.org/web/20130919085618im_/http://example.com/logo.png",
            "https://web.archive.org/web/20130919085618if_/http://example.com/",
        ):
            with self.subTest(original=original):
                self.assertEqual(source_module._wayback_identity_url(original), original)

    def test_wrapper_or_donation_body_is_failed_wayback_wrapper(self):
        url = "https://web.archive.org/web/2024/https://www.example.com/"
        expected = "https://web.archive.org/web/2024id_/https://www.example.com/"
        response = FakeResponse(200, HTML_WRAPPER, url=expected)
        with mock.patch("requests.get", return_value=response) as get:
            rows = self.ingest(url)
            # First fetch plus one retry after wrapper detection.
            self.assertEqual(get.call_count, 2)
            self.assertEqual(get.call_args_list[0][0][0], expected)
            self.assertEqual(get.call_args_list[1][0][0], expected)
        entry = rows[0]
        self.assertEqual(entry["status"], "failed")
        self.assertEqual(entry["error_class"], "wayback_wrapper")
        self.assertIn("wrapper", entry["error"].lower())
        self.assertEqual(entry["source_url"], url)
        self.assertFalse((self.work / "text").exists() and any((self.work / "text").rglob("*.txt")))


class ConfigFailureAndBackoffTests(unittest.TestCase):
    """R-13: a config failure is always retried; transient backoff expires on schedule."""

    SEC_URL = "https://www.sec.gov/Archives/edgar/data/1/acme-10k.htm"

    def setUp(self):
        self.work = _work()
        self.sleep = mock.patch.object(source_module.time, "sleep").start()
        self.addCleanup(mock.patch.stopall)
        self.addCleanup(lambda: __import__("shutil").rmtree(self.work, ignore_errors=True))

    def ingest(self, url, **kwargs):
        return source_module.ingest(self.work, _manifest(self.work, [_row(url=url)]), **kwargs)

    def _age_ledger(self, hours, failure_count=None):
        path = self.work / "sources.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        from datetime import datetime, timedelta, timezone
        stamp = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        for entry in payload["sources"]:
            entry["last_attempt"] = stamp
            if failure_count is not None:
                entry["failure_count"] = failure_count
        path.write_text(json.dumps(payload), encoding="utf-8")

    def test_skip_failed_never_skips_a_sec_user_agent_failure(self):
        from datetime import datetime, timezone
        row = _row(url=self.SEC_URL)
        prior = {"status": "failed", "source_url": self.SEC_URL, "error_class": "sec_user_agent",
                 "failure_count": 5, "last_attempt": datetime.now(timezone.utc).isoformat()}
        self.assertFalse(source_module._skip_failed(prior, row, "x", False, False))
        # Same answer when only the old message text is on the row.
        prior = {"status": "failed", "source_url": self.SEC_URL,
                 "error": "SEC_USER_AGENT must contain an actual ASCII contact and email",
                 "last_attempt": datetime.now(timezone.utc).isoformat()}
        self.assertFalse(source_module._skip_failed(prior, row, "x", False, False))
        # A transient class inside its backoff window is still skipped.
        prior = {"status": "failed", "source_url": self.SEC_URL, "error_class": "http_500",
                 "failure_count": 1, "last_attempt": datetime.now(timezone.utc).isoformat()}
        self.assertTrue(source_module._skip_failed(prior, row, "x", False, False))

    def test_missing_then_supplied_sec_user_agent_is_retried_without_flags(self):
        with mock.patch.dict("os.environ", {}, clear=False) as env:
            env.pop("SEC_USER_AGENT", None)
            with mock.patch("requests.get") as get:
                first = self.ingest(self.SEC_URL)
                get.assert_not_called()
            self.assertEqual(first[0]["status"], "failed")
            self.assertEqual(first[0]["error_class"], "sec_user_agent")
            with mock.patch("requests.get") as get:
                second = self.ingest(self.SEC_URL)
                get.assert_not_called()
            # Retried (and failed again for the same config reason), not served from cache.
            self.assertFalse(second[0]["from_cache"])
            self.assertEqual(second[0]["failure_count"], 2)
        with mock.patch.dict("os.environ", {"SEC_USER_AGENT": "Acme Research liujinyu@example.com"}):
            with mock.patch("requests.get", return_value=FakeResponse(200, HTML_OK, url=self.SEC_URL)) as get:
                third = self.ingest(self.SEC_URL)
                self.assertEqual(get.call_count, 1)
                self.assertEqual(get.call_args.kwargs["headers"]["User-Agent"],
                                 "Acme Research liujinyu@example.com")
        self.assertEqual(third[0]["status"], "ready")

    def test_transient_failure_is_skipped_until_the_backoff_expires_and_retry_failed_overrides(self):
        url = "https://example.test/flaky"
        with mock.patch("requests.get", return_value=FakeResponse(500, url=url)):
            self.ingest(url)
        # 30 minutes later: inside the 1 h window, skipped from cache.
        self._age_ledger(0.5)
        with mock.patch("requests.get", return_value=FakeResponse(200, HTML_OK, url=url)) as get:
            rows = self.ingest(url)
            self.assertEqual(get.call_count, 0)
        self.assertTrue(rows[0]["from_cache"])
        # --retry-failed re-attempts inside the window.
        with mock.patch("requests.get", return_value=FakeResponse(500, url=url)) as get:
            rows = self.ingest(url, retry_failed=True)
            self.assertGreaterEqual(get.call_count, 1)
        self.assertEqual(rows[0]["failure_count"], 2)
        # Two failures back off 2 h: 90 minutes is still inside, 3 h is outside.
        self._age_ledger(1.5)
        with mock.patch("requests.get", return_value=FakeResponse(200, HTML_OK, url=url)) as get:
            self.ingest(url)
            self.assertEqual(get.call_count, 0)
        self._age_ledger(3)
        with mock.patch("requests.get", return_value=FakeResponse(200, HTML_OK, url=url)) as get:
            rows = self.ingest(url)
            self.assertEqual(get.call_count, 1)
        self.assertEqual(rows[0]["status"], "ready")

    def test_legitimate_wayback_capture_that_mentions_the_wayback_machine_is_ready(self):
        body = (b"<!DOCTYPE html><html><head><title>Archive notes</title></head><body>"
                b"<p>We saved this page with the Wayback Machine. See _wm. notes for the layoff memo.</p>"
                b"</body></html>")
        url = "https://web.archive.org/web/2024/https://www.example.com/post"
        expected = "https://web.archive.org/web/2024id_/https://www.example.com/post"
        with mock.patch("requests.get", return_value=FakeResponse(200, body, url=expected)) as get:
            rows = source_module.ingest(self.work, _manifest(self.work, [_row(url=url)]))
            self.assertEqual(get.call_count, 1)
        self.assertEqual(rows[0]["status"], "ready")
        self.assertFalse(source_module._is_wayback_wrapper(body))
        self.assertTrue(source_module._is_wayback_wrapper(HTML_WRAPPER))
        self.assertTrue(source_module._is_wayback_wrapper(b"<div id='wm-ipp-base'>toolbar</div>"))


if __name__ == "__main__":
    unittest.main()
