#!/usr/bin/env python3
"""Run the stage-3 steps in the order the payload contracts require.

Every step is a normal skill entry point; this script only sequences them,
passes the workspace explicitly, and appends one line per step to
`qa/stage3-resume.log` so an interrupted round can be resumed at the last
successful step. The skill location is derived from this file, never from a
machine-specific path.

Usage:
  python3 stage3_resume.py --work WORK [--only STEP] [--from STEP]
                           [--skip-export] [--resume] [--python PATH]
"""
import argparse
import datetime
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
SCRIPTS = HERE.parent
SKILL = SCRIPTS.parent


def steps(work):
    """(name, argv) in contract order. Each argv starts with the interpreter."""
    research = str(SCRIPTS / "research.py")
    qa = work / "qa"
    return [
        ("registry-verify", [research, "registry-verify", "--work", str(work),
                            "--file", str(qa / "entity_registry.csv")]),
        ("generate-decisions", [str(SCRIPTS / "generate_decisions.py"), "--work", str(work)]),
        ("apply-decisions", [research, "apply", "--work", str(work),
                             "--decisions", str(qa / "decisions-generated.jsonl")]),
        ("build-search-log", [str(SCRIPTS / "build_search_log.py"), "--work", str(work)]),
        ("search-log-import", [research, "search-log-import", "--work", str(work),
                               "--file", str(qa / "search_log.csv")]),
        ("build-reason-codes", [str(SCRIPTS / "build_reason_codes.py"), "--work", str(work)]),
        ("reason-apply", [research, "reason-apply", "--work", str(work),
                          "--file", str(qa / "reason_codes.jsonl")]),
        ("fill-profile-fields", [str(SCRIPTS / "fill_profile_fields.py"), "--work", str(work)]),
        ("profile-apply", [research, "apply", "--work", str(work),
                           "--decisions", str(qa / "profile-decisions.jsonl")]),
        ("audit", [research, "audit", "--work", str(work)]),
        ("export", [research, "export", "--work", str(work),
                    "--output", str(work / "1_layoff_announcements.xlsx"),
                    "--allow-partial"]),
    ]


def last_success(log_path):
    if not log_path.is_file():
        return None
    for line in reversed(log_path.read_text(encoding="utf-8", errors="replace").splitlines()):
        if line.startswith("=== ") and " OK " in line:
            return line.split(" OK ", 1)[1].strip()
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--only", default="")
    parser.add_argument("--from", dest="start_at", default="")
    parser.add_argument("--skip-export", action="store_true")
    parser.add_argument("--resume", action="store_true",
                        help="skip steps that already succeeded in the log")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--log", default="qa/stage3-resume.log")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    log_path = work / args.log
    log_path.parent.mkdir(parents=True, exist_ok=True)
    planned = steps(work)

    names = [name for name, _ in planned]
    if args.only:
        if args.only not in names:
            raise SystemExit("Unknown step: " + args.only + "; expected one of " + ", ".join(names))
        planned = [item for item in planned if item[0] == args.only]
    elif args.start_at:
        if args.start_at not in names:
            raise SystemExit("Unknown step: " + args.start_at)
        planned = planned[names.index(args.start_at):]
    if args.skip_export:
        planned = [item for item in planned if item[0] != "export"]

    succeeded = last_success(log_path) if args.resume else None
    passed = False

    def log(message):
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write("=== [%s] %s\n" % (
                datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), message))

    for name, argv in planned:
        if succeeded:
            if passed:
                continue
            if name == succeeded:
                passed = True
                continue
        log("STEP " + name)
        command = [args.python] + argv
        completed = subprocess.run(command, capture_output=True, text=True)
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(completed.stdout or "")
            handle.write(completed.stderr or "")
        if completed.returncode != 0:
            log("FAIL " + name)
            print("step failed: " + name, file=sys.stderr)
            return completed.returncode or 1
        log("OK " + name)
    log("STAGE3 RESUME DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
