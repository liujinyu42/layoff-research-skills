"""Optional additive candidate discovery from Bing News RSS.

Writes candidates and explicit per-query receipts only under --out. Discovery is
not evidence: every candidate still passes source registration, reconciliation,
and semantic review in the normal workflow.
"""
import argparse
import concurrent.futures as cf
import csv
import datetime as dt
import json
import re
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path

import requests

UA = ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/124.0 Safari/537.36')
QUERIES = ['"{c}" layoffs', '"{c}" "job cuts"', '"{c}" "lays off"',
           '"{c}" "workforce reduction"']
EXTRA_QUERIES = ['"{c}" layoff', '"{c}" "cuts jobs"', '"{c}" "job losses"',
                 '"{c}" redundancies', '"{c}" "staff cuts"', '"{c}" "cut jobs"']
SITE_QUERIES = ['"{c}" layoffs site:reuters.com', '"{c}" layoffs site:techcrunch.com',
                '"{c}" "job cuts" site:bloomberg.com']
LOCK = threading.Lock()
LOCAL = threading.local()


def company_names(row):
    """Use the canonical roster name and every declared alias in every query set."""
    company = row.get('company') or row.get('Company') or ''
    aliases = row.get('aliases') or []
    if isinstance(aliases, str):
        aliases = aliases.split(';')
    return sorted({str(name).strip() for name in [company, *aliases] if str(name).strip()},
                  key=str.casefold)


def year_queries(start, end):
    """Historical sweeps counter the unextended feed's recency bias."""
    phrases = ('"{c}" layoffs ', '"{c}" "job cuts" ')
    return [phrase + str(year)
            for year in range(int(start[:4]), int(end[:4]) + 1)
            for phrase in phrases]


def queries_for(row, templates):
    return [template.format(c=name) for name in company_names(row) for template in templates]


def boundary_window(start, end, buffer_days=45):
    """Keep later reports whose publication date may follow the announcement."""
    first = dt.date.fromisoformat(start) - dt.timedelta(days=buffer_days)
    last = dt.date.fromisoformat(end) + dt.timedelta(days=buffer_days)
    if buffer_days < 0:
        raise ValueError('boundary_days must be non-negative')
    return first.isoformat(), last.isoformat()


def sess():
    if not hasattr(LOCAL, 's'):
        session = requests.Session()
        session.headers.update({'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9'})
        LOCAL.s = session
    return LOCAL.s


def direct_url(link):
    match = re.search(r'[?&]url=([^&]+)', link or '')
    if match:
        return urllib.parse.unquote(match.group(1))
    return link if (link or '').startswith('http') else ''


def normalize_url(url):
    return urllib.parse.urldefrag(str(url or '').strip())[0].casefold()


def normalize_title(title):
    return re.sub(r'[^\w]+', ' ', str(title or '').casefold(), flags=re.UNICODE).strip()


def deduplicate(rows):
    """A repeated URL OR a repeated normalized title identifies the same lead."""
    seen_urls, seen_titles, unique = set(), set(), []
    for row in rows:
        url, title = normalize_url(row.get('url')), normalize_title(row.get('title'))
        if not url or not title or url in seen_urls or title in seen_titles:
            continue
        seen_urls.add(url)
        seen_titles.add(title)
        unique.append(row)
    return unique


def parse_rss(xml_bytes, start, end, boundary_days=45):
    """Parse direct article leads inside the expanded publication-date boundary."""
    capture_start, capture_end = boundary_window(start, end, boundary_days)
    root = ET.fromstring(xml_bytes)
    out = []
    for item in root.findall('.//item'):
        title = (item.findtext('title') or '').strip()
        url = direct_url(item.findtext('link') or '')
        published = (item.findtext('pubDate') or '').strip()
        try:
            date = time.strftime('%Y-%m-%d', time.strptime(published[5:16], '%d %b %Y'))
        except ValueError:
            date = ''
        if not (title and url and date and capture_start <= date <= capture_end):
            continue
        out.append({'title': title, 'url': url, 'reported_date': date,
                    'publisher': urllib.parse.urlsplit(url).netloc.lower()})
    return out


def discover(row, start, end, delay, templates, boundary_days=45):
    """Return candidates plus one explicit receipt for every attempted query."""
    rows, receipts = [], []
    for query in queries_for(row, templates):
        receipt = {'query': query, 'executed_at': dt.datetime.now(dt.timezone.utc).isoformat(),
                   'status': 'request_error', 'http_code': None, 'result_count': 0, 'error': None}
        try:
            response = sess().get('https://www.bing.com/news/search',
                                  params={'q': query, 'format': 'RSS', 'count': 100}, timeout=25)
            receipt['http_code'] = response.status_code
            if response.status_code != 200:
                receipt['status'] = 'http_error'
                receipt['error'] = 'Bing News RSS returned HTTP ' + str(response.status_code)
            else:
                try:
                    found = parse_rss(response.content, start, end, boundary_days)
                except ET.ParseError as exc:
                    receipt['status'] = 'parse_error'
                    receipt['error'] = str(exc)
                else:
                    rows.extend(found)
                    receipt.update(status='completed', result_count=len(found))
        except requests.RequestException as exc:
            receipt['error'] = str(exc)
        receipts.append(receipt)
        time.sleep(delay)
    unique = deduplicate(rows)
    statuses = {item['status'] for item in receipts}
    status = ('completed' if statuses == {'completed'} else
              'failed' if 'completed' not in statuses else 'partial')
    return {'version': 2, 'status': status, 'company_id': row['company_id'],
            'company': row['company'], 'aliases': company_names(row)[1:],
            'requested_window': [start, end], 'boundary_days': boundary_days,
            'candidates': unique, 'query_receipts': receipts}


def completed_payload(path):
    """Only a fully completed v2 receipt file is safe to resume; legacy lists rerun."""
    try:
        payload = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError, TypeError):
        return None
    if (isinstance(payload, dict) and payload.get('status') == 'completed'
            and isinstance(payload.get('candidates'), list)
            and isinstance(payload.get('query_receipts'), list)):
        return payload
    return None


def run_company(task):
    row, out, start, end, delay, templates, force, boundary_days = task
    path = Path(out) / ('candidates_' + row['company_id'] + '.json')
    if not force:
        prior = completed_payload(path)
        if prior is not None:
            return row['company_id'], len(prior['candidates']), 'resumed'
    payload = discover(row, start, end, delay, templates, boundary_days)
    temporary = path.with_suffix('.json.tmp')
    with LOCK:
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        temporary.replace(path)
    return row['company_id'], len(payload['candidates']), payload['status']


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--roster', required=True)
    parser.add_argument('--out', default='discovery_bing')
    parser.add_argument('--start', default='2019-01-01')
    parser.add_argument('--end', default=time.strftime('%Y-%m-%d'))
    parser.add_argument('--workers', type=int, default=6)
    parser.add_argument('--delay', type=float, default=0.2)
    parser.add_argument('--boundary-days', type=int, default=45)
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--broad', action='store_true', help='add alternate phrasings and news-site queries')
    parser.add_argument('--by-year', action='store_true', help='add explicit calendar-year queries')
    args = parser.parse_args()
    dt.date.fromisoformat(args.start)
    dt.date.fromisoformat(args.end)
    if args.start > args.end or args.boundary_days < 0:
        parser.error('start must precede end and boundary-days must be non-negative')
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    templates = list(QUERIES)
    if args.broad:
        templates += EXTRA_QUERIES + SITE_QUERIES
    if args.by_year:
        templates += year_queries(args.start, args.end)
    with open(args.roster, encoding='utf-8-sig', newline='') as handle:
        roster = list(csv.DictReader(handle))
    tasks = []
    for row in roster:
        company = row.get('Company') or row.get('company') or ''
        cid = row.get('company_id') or re.sub(r'[^a-z0-9]+', '-', company.lower()).strip('-')
        if not cid or not company:
            parser.error('Every roster row requires a company name; company_id is recommended')
        item = dict(row, company_id=cid, company=company)
        tasks.append((item, out, args.start, args.end, args.delay, templates,
                      args.force, args.boundary_days))
    counts = {}
    with cf.ThreadPoolExecutor(max_workers=args.workers) as executor:
        for cid, count, status in executor.map(run_company, tasks):
            counts[cid] = {'candidates': count, 'status': status}
    index = []
    for task in tasks:
        row = task[0]
        path = out / ('candidates_' + row['company_id'] + '.json')
        try:
            payload = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        candidates = payload.get('candidates', []) if isinstance(payload, dict) else payload
        for candidate in candidates:
            index.append({'company_id': row['company_id'], 'company': row['company'], **candidate})
    with (out / 'candidates.csv').open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=['company_id', 'company', 'title', 'url',
                                                    'reported_date', 'publisher'])
        writer.writeheader()
        writer.writerows(index)
    print(json.dumps({'companies': len(tasks), 'new_candidates': sum(v['candidates'] for v in counts.values()),
                      'company_status': counts, 'index_rows': len(index)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
