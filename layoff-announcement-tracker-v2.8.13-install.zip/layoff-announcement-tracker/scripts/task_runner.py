"""Copy this file into a task folder, edit the settings, then run locally."""
import argparse
import fcntl
import hashlib
import json
import os
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

# Edit these settings in the task-local copy.
SKILL = Path(__file__).resolve().parents[1]
WORK = Path('~/Desktop/layoff-task').expanduser().resolve()
COMPANIES = []  # [{"cid": "123", "company": "Example", "slug": "example"}]
START, END = 2019, 2026
LANES = 2

def save(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    os.replace(tmp, path)

def process(company):
    cid = str(company['cid'])
    name = company['company']
    slug = company.get('slug') or re.sub(r'[^\w-]+', '-', name.casefold()).strip('-')
    folder = WORK/'companies'/company.get('route',cid)
    folder.mkdir(parents=True, exist_ok=True)
    config = dict(cid=cid, company=name, slug=slug, start=START, end=END)
    ready = folder/'ready-for-review.json'
    sys.path.insert(0,str(SKILL/'scripts'))
    from review_packet import packet
    with (WORK/'tracker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if ready.exists() and json.loads(ready.read_text())['scope'] == config and (folder/'tracker.json').exists() and (folder/'review-packet.json').exists():
            return
        call = [sys.executable, str(SKILL/'scripts/company_table.py'), '--work', str(WORK),
                '--cid', cid, '--company', name, '--slug', slug, '--start', str(START), '--end', str(END)]
        subprocess.run(call, check=True)
        from urllib.parse import quote
        url = 'https://layoffs.fyi/company/'+quote(slug,safe='')+'/'
        key = hashlib.sha256(url.encode()).hexdigest()[:20]
        receipt = json.loads((WORK/'company-tables'/f'{key}-{cid}.json').read_text())
        save(folder/'tracker.json', receipt)
        save(folder/'review-packet.json', packet(receipt))
        save(ready, dict(scope=config,query=receipt['query'],tracker_status=receipt['status']))
    print('READY',cid,folder,flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['collect','audit','finalize'])
    parser.add_argument('--allow-partial',action='store_true')
    args=parser.parse_args()
    action=args.action
    ids=[c.get('route',str(c['cid'])) for c in COMPANIES]
    if not ids or len(ids)!=len(set(ids)) or not all(re.fullmatch(r'[A-Za-z0-9_-]+',i) for i in ids) or START>END:
        raise ValueError('Check the task-local roster and year range')
    WORK.mkdir(parents=True,exist_ok=True)
    if action=='collect':
        with ThreadPoolExecutor(max_workers=LANES) as pool:
            list(pool.map(process,COMPANIES))
        return
    results=WORK/'results'
    sys.path.insert(0,str(SKILL/'scripts'))
    from discovery_audit import audit, read
    reports={}
    for c,route in zip(COMPANIES,ids):
        reports[route]=audit(WORK/'companies'/route,read(results/(route+'.json'),{}),START,END,c['company'])
    save(WORK/'coverage-audit.json',reports)
    if action=='audit':
        return
    if not args.allow_partial and any(r['pending'] or r['followups'] or r['blocked'] or r['unresolved'] for r in reports.values()):
        raise ValueError('Review coverage-audit.json or finalize explicitly with --allow-partial')
    if {p.stem for p in results.glob('*.json')}!=set(ids):
        raise ValueError('Expected one reviewed result per CID. Include blocked scopes with explicit blockers.')
    for c,route in zip(COMPANIES,ids):
        cid=str(c['cid'])
        receipt=json.loads((WORK/'companies'/route/'ready-for-review.json').read_text())
        data=json.loads((results/(route+'.json')).read_text())
        if (str(data['cid'])!=cid or data['company']!=c['company'] or receipt['scope']['company']!=c['company']
            or (receipt['scope']['start'],receipt['scope']['end'])!=(START,END)
            or not any(q.get('query')==receipt['query'] and q.get('executed_at') for q in data.get('search',[])) and not data.get('blockers')):
            raise ValueError('Missing scope or search receipt for '+cid)
    subprocess.run([sys.executable,str(SKILL/'scripts/export_batch.py'),'--results',str(results),'--out',str(WORK/'export')],check=True)

if __name__=='__main__':
    main()
