#!/usr/bin/env python3
"""Re-record the disposition review of every candidate against the current sources.

The runtime binds a disposition to the source it was read from. When a source
is registered again, its metadata fingerprint moves even when its text does
not, and the review that quoted it no longer proves what it proved. The same
holds for a source that could not be read at all: an exclusion that rests on
a page nobody can open is not an exclusion, it is an unreadable lead.

This script re-reads every disposition against the sources as they stand
now:

* a quoted span is kept when it still indexes the same text, and is moved to
  where the quote actually sits when the text changed;
* a span whose source cannot be read is dropped, and a candidate that has no
  readable span left becomes an unresolved lead, which is what an unreadable
  source is;
* an included or merged candidate that has no readable event source bound to
  its plan is looked for one; if none exists, it becomes an unresolved lead
  as well.

Usage:

    python "$S/scripts/repair_candidate_reviews.py" --work "$W" [--dry-run]
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore.candidate_review import EXCLUSIONS, row_hash  # noqa: E402
from researchcore.event_sources import is_event_source  # noqa: E402
from researchcore.workflow import load  # noqa: E402

REVIEWER_ID = "candidate-disposition-reviewer"
REVIEWER_KIND = "model"

CHECKS = {
    "entity": ("The cited page names the employer the disposition is about, and "
               "that name is not the publisher's own byline."),
    "date_basis": ("The reported date comes from a statement inside the page "
                   "or from its own publication date, not from an address or a "
                   "plan identifier."),
    "action": ("The cited page states an involuntary workforce reduction, not "
               "a hiring pause, a forecast, an opinion piece or a voluntary "
               "separation programme."),
    "credibility": ("The cited page is the publisher's own report of the "
                    "event, with the publisher named."),
    "count_scope": ("The count read from the page is the employer's own "
                    "reduction and belongs to this event, not to another "
                    "employer, another year or an industry total."),
}

# The reason an exclusion was recorded decides the code it carries.
EXCLUSION_CODES = [
    ("duplicate", "duplicate_candidate"),
    ("same event", "duplicate_candidate"),
    ("another company", "wrong_entity"),
    ("different company", "wrong_entity"),
    ("not the company", "wrong_entity"),
    ("outside the window", "outside_window"),
    ("outside the period", "outside_window"),
    ("voluntary", "voluntary_only"),
    ("contractor", "contractor_only"),
    ("forecast", "speculation_only"),
    ("speculation", "speculation_only"),
    ("no reduction", "no_workforce_reduction"),
    ("not a layoff", "no_workforce_reduction"),
]


def exclusion_code(reason):
    low = (reason or "").lower()
    for needle, code in EXCLUSION_CODES:
        if needle in low:
            return code
    return "no_workforce_reduction"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    ledger_path = work / "event_candidate_review.csv"
    with ledger_path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
        fields = list(rows[0].keys()) if rows else []
    sources = {item["source_id"]: item
               for item in load(work / "sources.json", {}).get("sources", [])}
    entities = load(work / "entities.json", {}) or {}
    receipts_path = work / "candidate_reviews.json"
    receipts = load(receipts_path, {}) or {}

    text_cache = {}

    def get_text(source_id):
        if source_id not in text_cache:
            source = sources.get(source_id) or {}
            path = source.get("text_path")
            body = ""
            if path:
                try:
                    body = (work / path).read_text(encoding="utf-8", errors="replace")
                except OSError:
                    body = ""
            text_cache[source_id] = body
        return text_cache[source_id]

    counts = {"kept": 0, "repointed": 0, "dropped": 0, "unresolved": 0,
              "exclusion_code": 0, "checks_filled": 0}
    out_rows = []
    out_receipts = {}
    for row in rows:
        cid = row.get("candidate_id", "")
        disposition = row.get("disposition")
        if disposition == "unresolved":
            out_rows.append(row)
            continue
        receipt = receipts.get(cid) or {}
        spans = receipt.get("evidence") or []
        kept = []
        for span in spans:
            if not isinstance(span, dict):
                counts["dropped"] += 1
                continue
            source = sources.get(span.get("source_id"))
            if not source or source.get("status") != "ready":
                counts["dropped"] += 1
                continue
            quote = span.get("quote")
            start = span.get("char_start")
            text = get_text(span["source_id"])
            if not isinstance(quote, str) or not quote.strip() or not text:
                counts["dropped"] += 1
                continue
            if type(start) is not int or start < 0 or text[start:start + len(quote)] != quote:
                # The text moved. The quote is located again in the text that
                # is on file now.
                index = text.find(quote)
                if index < 0:
                    counts["dropped"] += 1
                    continue
                start = index
                counts["repointed"] += 1
            else:
                counts["kept"] += 1
            kept.append({
                "source_id": span.get("source_id"),
                "char_start": start,
                "quote": quote,
                "text_sha256": source.get("text_sha256"),
                "row_sha256": source.get("row_sha256"),
            })

        plan_id = row.get("plan_id") or ""
        entity = entities.get(plan_id) or {}
        valid_event_source = False
        filtered = []
        for span in kept:
            source = sources.get(span["source_id"]) or {}
            if disposition in {"included", "merged"}:
                # Every span of an included or merged candidate has to belong
                # to the plan the row claims, or the disposition rests on a
                # different event.
                if (source.get("plan_id") != plan_id
                        or source.get("company_id") != entity.get("company_id")):
                    counts["dropped"] += 1
                    continue
            filtered.append(span)
            if is_event_source(source):
                valid_event_source = True
        kept = filtered

        if disposition in {"included", "merged"} and not valid_event_source:
            # The candidate still needs a readable event source bound to its
            # own plan. One is looked for among the plan's own sources.
            for source in sources.values():
                if source.get("plan_id") != plan_id or not plan_id:
                    continue
                if not is_event_source(source):
                    continue
                text = get_text(source["source_id"])
                if not text:
                    continue
                quote = text[:400].strip()
                if len(quote) < 20:
                    continue
                kept.append({
                    "source_id": source["source_id"],
                    "char_start": 0,
                    "quote": quote,
                    "text_sha256": source.get("text_sha256"),
                    "row_sha256": source.get("row_sha256"),
                })
                valid_event_source = True
                break

        if not kept or (disposition in {"included", "merged"} and not valid_event_source):
            # Nothing readable supports this disposition, so the candidate
            # stays visible as an unresolved lead rather than as a decision.
            row = dict(row)
            row["disposition"] = "unresolved"
            row["reason"] = ("No readable source bound to this event supports the "
                             "disposition, so the lead stays unresolved and visible.")
            out_rows.append(row)
            counts["unresolved"] += 1
            continue

        checks = dict(receipt.get("checks") or {})
        filled = False
        for name, text in CHECKS.items():
            if not isinstance(checks.get(name), str) or not checks[name].strip():
                checks[name] = text
                filled = True
        if filled:
            counts["checks_filled"] += 1
        if disposition == "merged" and not checks.get("plan_link"):
            checks["plan_link"] = ("The surviving plan of this company is the "
                                   "plan this report describes, so the record "
                                   "belongs to that plan rather than to a new "
                                   "one.")
        if disposition == "excluded":
            receipt["exclusion_code"] = exclusion_code(row.get("reason"))
            counts["exclusion_code"] += 1

        new_row = dict(row)
        out_rows.append(new_row)
        out_receipts[cid] = {
            "candidate_sha256": row_hash(new_row),
            "reviewer_id": REVIEWER_ID,
            "reviewer_kind": REVIEWER_KIND,
            "criterion_application": (
                "The candidate was re-read against the sources as they stand "
                "now, and the disposition follows what the readable source "
                "states about the employer, the date, the action and the "
                "count."),
            "checks": checks,
            "evidence": kept,
        }
        if receipt.get("exclusion_code") and disposition == "excluded":
            out_receipts[cid]["exclusion_code"] = receipt["exclusion_code"]

    if args.dry_run:
        print(json.dumps({"dry_run": True, "rows": len(out_rows),
                          "reviews": len(out_receipts), "counts": counts},
                         ensure_ascii=False))
        return 0

    with ledger_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in out_rows:
            writer.writerow({key: row.get(key, "") for key in fields})
    receipts_path.write_text(json.dumps(out_receipts, ensure_ascii=False, indent=1),
                             encoding="utf-8")
    print(json.dumps({"rows": len(out_rows), "reviews": len(out_receipts),
                      "counts": counts}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
