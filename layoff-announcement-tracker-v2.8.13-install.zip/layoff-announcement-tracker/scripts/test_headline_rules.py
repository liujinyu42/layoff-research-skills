"""Regression checks for the headline rules the discovery sweep applies.

Each case comes from a defect this collection round measured against its own
output, so this file fails if those defects return.

    python "$S/scripts/test_headline_rules.py"
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import collect_discovery  # noqa: E402

WINDOW_START = "2020-01-01"
WINDOW_END = "2026-09-30"


def relevant(title, aliases, publisher="", date="", generic=False):
    return collect_discovery.hit_relevant(
        title, aliases, generic, publisher=publisher,
        reported_date=date, window_start=WINDOW_START, window_end=WINDOW_END)


def test_publisher_byline_is_not_a_mention():
    """A trailing publisher name must not stand in for the company.

    The measured case: every story TechTarget ran was counted as a story
    about TechTarget, because the feed appends the publisher's name to the
    headline and the name matched the company being looked for.
    """
    ok, _ = relevant("Salesforce layoffs hit Customer Success at end of fiscal year - TechTarget",
                     ["TechTarget"], publisher="TechTarget")
    assert not ok, "the publisher's byline was read as a mention of the company"

    ok, _ = relevant("Stop blaming AI for layoffs - TechTarget",
                     ["TechTarget"], publisher="TechTarget")
    assert not ok, "a headline about layoffs in general was bound to the publisher"

    # The company's own story still counts.
    ok, _ = relevant("TechTarget cuts 40 jobs in restructuring",
                     ["TechTarget"], publisher="TechTarget")
    assert ok, "a genuine report about the company was rejected"

    # A different company's story under the same publisher is not its story.
    ok, _ = relevant("Docker Enterprise spun off to Mirantis, company restructures - TechTarget",
                     ["TechTarget"], publisher="TechTarget")
    assert not ok, "another company's story was bound to the publisher"


def test_byline_is_removed_without_a_known_publisher():
    """The trailing name is a byline even when the feed does not name it."""
    ok, _ = relevant("Acme cuts 200 jobs - Some News Outlet", ["Acme"])
    assert ok, "the company was lost when the byline was unnamed"
    ok, _ = relevant("Acme cuts 200 jobs - Some News Outlet", ["Some News Outlet"])
    assert not ok, "an unnamed byline was read as a company mention"


def test_report_outside_the_window_is_not_a_hit():
    """The sweep asks about a period; a report outside it answers another."""
    ok, why = relevant("IBM layoffs 500 jobs", ["IBM"], date="2016-03-02")
    assert not ok, "a report from 2016 was accepted inside a 2020-2026 window"
    assert "outside the event window" in why, "the exclusion gave no reason"

    ok, _ = relevant("IBM layoffs 500 jobs", ["IBM"], date="2026-10-09")
    assert not ok, "a report after the window closed was accepted"

    ok, _ = relevant("IBM layoffs 500 jobs", ["IBM"], date="2022-06-20")
    assert ok, "a report inside the window was rejected"

    # The window's own edges are inside it.
    ok, _ = relevant("IBM layoffs 500 jobs", ["IBM"], date=WINDOW_START)
    assert ok, "the first day of the window was rejected"
    ok, _ = relevant("IBM layoffs 500 jobs", ["IBM"], date=WINDOW_END)
    assert ok, "the last day of the window was rejected"

    # A hit with no date is judged on its content alone.
    ok, _ = relevant("IBM layoffs 500 jobs", ["IBM"])
    assert ok, "an undated hit was rejected for want of a date"


def test_the_window_only_applies_when_it_is_known():
    """No window means no window, not an empty one that rejects everything."""
    ok, _ = collect_discovery.hit_relevant(
        "Acme cuts 200 jobs", ["Acme"], False,
        reported_date="1999-01-01", window_start="", window_end="")
    assert ok, "a hit was rejected because no window was configured"


def test_reduction_wording_is_still_required():
    """The byline rule must not weaken the requirement for a reduction."""
    ok, why = relevant("Acme reports record quarterly earnings - TechTarget",
                       ["Acme"], publisher="TechTarget")
    assert not ok, "a headline with no reduction was accepted"
    assert "reduction" in why, "the exclusion gave no reason"


def test_generic_names_still_need_a_corporate_marker():
    """The generic-name rule survives the byline change."""
    ok, _ = relevant("Here are the layoffs - TechTarget", ["Here"], generic=True)
    assert not ok, "an ordinary word was read as a company"
    ok, _ = relevant("Here Corporation cuts 200 jobs", ["Here"], generic=True)
    assert ok, "a generic name with a corporate marker was rejected"


def main():
    failures = []
    for name, function in sorted(globals().items()):
        if not name.startswith("test_") or not callable(function):
            continue
        try:
            function()
            print(f"ok   {name}")
        except AssertionError as error:
            failures.append((name, str(error)))
            print(f"FAIL {name}: {error}")
    if failures:
        print(f"\n{len(failures)} check(s) failed")
        return 1
    print("\nall checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
