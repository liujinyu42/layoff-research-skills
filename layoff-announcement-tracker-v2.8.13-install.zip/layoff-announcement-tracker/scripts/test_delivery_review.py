"""Accuracy gates: denominators, recaps, attribution and near-duplicate plans."""
import unittest

from researchcore.delivery_review import measure_gaps


def cell(value, quote, status="observed", **extra):
    record = {"status": status, "value": value,
              "evidence": [{"quote": quote}] if quote is not None else []}
    record.update(extra)
    return record


class DeliveryReviewTests(unittest.TestCase):
    entities = {
        "p": {"company_id": "c", "company": "Jamf"},
        "q": {"company_id": "d", "company": "Meta"},
    }

    def reasons(self, decisions, entities=None):
        return [gap["reason"] for gap in measure_gaps(decisions, entities or self.entities)]

    def test_headcount_denominator_is_rejected(self):
        decisions = {
            "p|layoff_count": cell(2595, "Jamf will lay off 6.4% of its 2,595 employees."),
            "p|layoff_percentage": cell(6.4, "Jamf will lay off 6.4% of its 2,595 employees."),
            "p|layoff_percentage_denominator": cell(2595, "Jamf will lay off 6.4% of its 2,595 employees."),
        }
        self.assertTrue(any("denominator" in reason for reason in self.reasons(decisions)))

    def test_count_equal_to_firm_size_is_rejected(self):
        decisions = {
            "p|layoff_count": cell(100000, "Jamf will lay off some of its nearly 100,000 employees globally."),
            "p|firm_size": cell(100000, "Jamf has nearly 100,000 employees globally."),
        }
        reasons = self.reasons(decisions)
        self.assertTrue(any("equals firm_size" in reason for reason in reasons))

    def test_count_above_firm_size_is_rejected(self):
        decisions = {
            "p|layoff_count": cell(1200, "Jamf will cut 1,200 jobs."),
            "p|firm_size": cell(900, "Jamf has 900 employees."),
        }
        self.assertTrue(any("exceeds firm_size" in reason for reason in self.reasons(decisions)))

    def test_count_sentence_owned_by_another_company_is_rejected(self):
        decisions = {
            "p|layoff_count": cell(11000, "Meta, which laid off 11,000 employees, also froze hiring."),
        }
        self.assertTrue(any("another company" in reason for reason in self.reasons(decisions)))

    def test_relative_clause_owned_by_another_company_is_rejected(self):
        decisions = {
            "p|layoff_count": cell(11000, "Cuts at iRobot are part of a trend, including Meta, which laid off 11,000 employees."),
        }
        entities = {"p": {"company_id": "c", "company": "iRobot"},
                    "q": {"company_id": "d", "company": "Meta"}}
        self.assertTrue(any("relative clause" in reason
                            for reason in self.reasons(decisions, entities)))

    def test_earlier_round_recap_is_rejected(self):
        decisions = {
            "p|announcement_date": cell("2025-01-10", None, date_basis="announcement"),
            "p|layoff_count": cell(862, "Jamf then cut another 862 positions in November 2022."),
        }
        self.assertTrue(any("recap" in reason for reason in self.reasons(decisions)))

    def test_same_month_count_is_not_a_recap(self):
        decisions = {
            "p|announcement_date": cell("2022-11-09", None, date_basis="announcement"),
            "p|layoff_count": cell(862, "Jamf cut 862 positions in November 2022."),
        }
        self.assertFalse(any("recap" in reason for reason in self.reasons(decisions)))

    def test_percentage_in_count_sentence_must_be_recorded(self):
        decisions = {
            "p|layoff_count": cell(1000, "Jamf will lay off 1,000 employees, about 10% of its workforce."),
        }
        self.assertTrue(any("record layoff_percentage" in reason for reason in self.reasons(decisions)))

    def test_percentage_evidence_with_headcount_requires_count(self):
        decisions = {
            "p|layoff_percentage": cell(6.4, "Jamf will lay off 166 employees, or 6.4% of staff."),
            "p|layoff_percentage_denominator": cell(2595, "Jamf will lay off 166 employees, or 6.4% of staff."),
        }
        self.assertTrue(any("record layoff_count" in reason for reason in self.reasons(decisions)))

    def test_near_simultaneous_independent_plans_are_rejected(self):
        decisions = {
            "p|announcement_date": cell("2026-06-03", None, date_basis="announcement"),
            "p|plan_relationship": cell("independent", None),
            "q|announcement_date": cell("2026-06-05", None, date_basis="announcement"),
            "q|plan_relationship": cell("independent", None),
        }
        entities = {"p": {"company_id": "c", "company": "GitLab"},
                    "q": {"company_id": "c", "company": "GitLab"}}
        self.assertTrue(any("within 14 days" in reason
                            for reason in self.reasons(decisions, entities)))

    def test_plan_link_basis_allows_independent_plans(self):
        decisions = {
            "p|announcement_date": cell("2026-06-03", None, date_basis="announcement"),
            "p|plan_relationship": cell("independent", None, plan_link_basis="Different subsidiaries and decision dates"),
            "q|announcement_date": cell("2026-06-05", None, date_basis="announcement"),
            "q|plan_relationship": cell("independent", None),
        }
        entities = {"p": {"company_id": "c", "company": "GitLab"},
                    "q": {"company_id": "c", "company": "GitLab"}}
        self.assertFalse(any("within 14 days" in reason
                             for reason in self.reasons(decisions, entities)))

    def test_country_paragraph_is_rejected(self):
        decisions = {
            "p|country": cell("Salesforce is an American cloud-based software company. It provides CRM software.", None),
        }
        self.assertTrue(any("country must be" in reason for reason in self.reasons(decisions)))

    def test_clean_count_has_no_gaps(self):
        decisions = {
            "p|announcement_date": cell("2025-01-15", None, date_basis="announcement"),
            "p|layoff_count": cell(500, "Jamf laid off 500 employees in January 2025."),
            "p|plan_relationship": cell("independent", None, plan_link_basis="Only plan for this company"),
            "p|country": cell("United States", None),
        }
        self.assertEqual(self.reasons(decisions), [])


if __name__ == "__main__":
    unittest.main()
