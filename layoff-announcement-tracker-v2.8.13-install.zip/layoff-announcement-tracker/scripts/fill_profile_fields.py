#!/usr/bin/env python3
"""Fill the company-profile fields from the verified identity record.

Seven fields describe the company rather than the event: its listing
exchange, its ticker, its CIK, its history, its founding year, what it
sells, and how it makes money. Every registered plan needs them, and the
identity record already holds them — together with the registrant filing
that verified them.

The value is not copied on trust. Each one is written into a decision whose
evidence quotes the filing, and the runtime re-reads that quote from the
bound source bytes. A value that cannot be located in the source is left
undecided rather than asserted.

A field the identity record does not hold is recorded as reviewed-absent only
when the variable's own criterion was searched over the whole applicable
scope and did not match. Otherwise the field is left unresolved: a filing that
discusses the company's business but yields no verbatim statement is a
locating failure, not evidence of absence.

Usage:

    python "$S/scripts/fill_profile_fields.py" --work "$W" [--out "$W/qa/profile-decisions.jsonl"]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

REVIEWER_ID = "identity-record-filler"
REVIEWER_KIND = "model"

# The identity of the employing entity is the one the registrant filings
# verified for that company, so the filing that supports a context field is
# the filing that established the entity.
IDENTITY_BASIS = ("The registrant filing names this registrant, and the "
                  "company identity record was verified against it, so the "
                  "filing is the verified record of this employing entity.")

# The identity record's attribute, the field it fills, and the reason the
# attribute answers that field.
MAPPING = [
    ("exchange", "exchange_at_event", "listing_venue",
     "The verified company identity record states the exchange on which the "
     "employer's securities are listed."),
    ("ticker", "ticker_at_event", "ticker",
     "The verified company identity record states the trading symbol of the "
     "employer's listed securities."),
    ("registrant_cik", "cik", "cik",
     "The verified company identity record states the central index key of "
     "the employing registrant."),
    ("business_description", "business_model", "business_model",
     "The verified company identity record describes what the employer does "
     "and how its business is organised."),
    ("__founding", "founding_year", "founding_year",
     "The registrant filing states when the employer was formed."),
    ("__products", "products_services", "products_services",
     "The registrant filing states what the employer sells."),
    ("__history", "company_history", "company_history",
     "The registrant filing states the employer's formation and what it does."),
]


# The identity record names an exchange the way a market data feed does, and
# a registrant filing names it the way the filing itself does. The two forms
# are the same venue.
EXCHANGE_NAMES = {
    "NYSE": ("New York Stock Exchange", "NYSE", "New York Stock Exch."),
    "NASDAQ": ("Nasdaq Stock Market", "NASDAQ", "Nasdaq Global Select Market",
               "Nasdaq Global Market", "Nasdaq Capital Market"),
    "AMEX": ("NYSE American", "NYSE American", "American Stock Exchange",
             "AMEX"),
    "OTC": ("OTC Markets", "OTC Markets Group", "OTC"),
    "LSE": ("London Stock Exchange", "LSE", "London Stock Exch."),
    "TSX": ("Toronto Stock Exchange", "TSX", "Toronto Stock Exch."),
    "ASX": ("Australian Securities Exchange", "ASX", "ASX Limited"),
    "HKEX": ("Hong Kong Stock Exchange", "HKEX", "The Stock Exchange of Hong Kong"),
    "KRX": ("Korea Exchange", "KRX", "Korea Exchange"),
    "TSE": ("Tokyo Stock Exchange", "TSE", "Tokyo Stock Exch."),
    "XETRA": ("Xetra", "XETRA", "Deutsche Börse"),
    "SSE": ("Shanghai Stock Exchange", "SSE", "Shanghai Stock Exch."),
    "SZSE": ("Shenzhen Stock Exchange", "SZSE", "Shenzhen Stock Exch."),
    "SEDAR": ("SEDAR+", "SEDAR"),
    "BSE": ("Borsa Istanbul", "BISE", "Borsa İstanbul"),
    "EURONEXT": ("Euronext", "EURONEXT"),
    "EPA": ("Euronext Paris", "EPA"),
    "AMS": ("Euronext Amsterdam", "AMS"),
    "BIT": ("Borsa Italiana", "BIT"),
    "SWX": ("SIX Swiss Exchange", "SWX", "SIX"),
}


def find_span(text, value, limit=400):
    """Locate the value in the source text.

    The identity record stores a value, not a span, so the span has to be
    found. A value that occurs once is quoted directly; a value that occurs
    several times is quoted with its first occurrence and the offset, and a
    value that does not occur at all is not quoted at all.

    A registrant's CIK is written with leading zeros in the record and
    without them in the filing, and an exchange is written in upper case in
    one place and in full in another. Both are the same value, so both are
    looked for in the form the filing uses.
    """
    if value in (None, "", []):
        return None
    if not text:
        return None
    needle = str(value).strip()
    if not needle:
        return None

    candidates = [needle]
    if needle.isdigit():
        stripped = needle.lstrip("0") or "0"
        if stripped != needle:
            candidates.append(stripped)
    for name in EXCHANGE_NAMES.get(needle.upper(), ()):
        if name not in candidates:
            candidates.append(name)
    lowered = text.lower()
    for candidate in candidates:
        count = lowered.count(candidate.lower())
        if count == 0:
            continue
        start = lowered.index(candidate.lower())
        # The quote is the value with a little of its surroundings, so that
        # the reader can see what the value is about and the runtime can find
        # the same span again.
        lead = 60
        begin = max(0, start - lead)
        end = min(len(text), start + len(candidate) + lead)
        quote = text[begin:end]
        offset = quote.find(candidate if candidate in quote else candidate.lower())
        if offset < 0:
            begin = start
            quote = text[begin:begin + limit]
        else:
            begin = begin + offset
            quote = text[begin:begin + len(candidate) + lead]
        quote = quote.strip()
        begin = text.index(quote, max(0, begin - 5)) if quote else begin
        return {"quote": quote, "char_start": begin}
    # A multi-word value may be spread across a line break in the filing.
    flat = re.sub(r"\s+", " ", needle)
    if flat != needle:
        probe = re.sub(r"\s+", " ", text)
        index = probe.lower().find(flat.lower())
        if index >= 0:
            return {"quote": flat, "char_start": None}
    return None


def fiscal_date(text):
    """The date the filing's statements are made as of.

    The context of a company is what was true at the date the statements
    describe, and an annual report states the period it covers in its own
    first page. The filing date is not the same thing: a report filed after
    an event describes the company after it.
    """
    if not text:
        return ""
    for pattern in (r"[Ff]or the fiscal year ended\s*([A-Z][a-z]+\s+\d{1,2}\s*,?\s*\d{4})",
                    r"[Ff]iscal year ended\s*:?\s*([A-Z][a-z]+\s+\d{1,2}\s*,?\s*\d{4})",
                    r"[Yy]ear ended\s*:?\s*([A-Z][a-z]+\s+\d{1,2}\s*,?\s*\d{4})"):
        match = re.search(pattern, text)
        if not match:
            continue
        try:
            import datetime as dt
            parsed = dt.datetime.strptime(
                " ".join(match.group(1).split()).replace(" ,", ","),
                "%B %d, %Y")
        except ValueError:
            continue
        return parsed.date().isoformat()
    return ""


def period_start(text):
    """The date the filing's covered period began."""
    if not text:
        return ""
    for pattern in (r"[Ff]or the fiscal year ended\s*([A-Z][a-z]+\s+\d{1,2}\s*,?\s*\d{4})",
                    r"[Ff]iscal year ended\s*:?\s*([A-Z][a-z]+\s+\d{1,2}\s*,?\s*\d{4})"):
        match = re.search(pattern, text)
        if not match:
            continue
        try:
            import datetime as dt
            parsed = dt.datetime.strptime(
                " ".join(match.group(1).split()).replace(" ,", ","),
                "%B %d, %Y").date()
        except ValueError:
            continue
        # The day the covered period began: the day before the same date of
        # the previous year, which is how a fiscal year runs.
        try:
            start = parsed.replace(year=parsed.year - 1)
        except ValueError:
            start = parsed.replace(year=parsed.year - 1, day=28)
        return start.isoformat()
    return ""


def founding_statement(text, limit=520):
    """The sentence that says when the company was formed."""
    if not text:
        return None
    for pattern in (
            r"(?:We|The Company|It|\b[A-Z][A-Za-z&.\- ]{2,40})\s+was incorporated[^.]{0,200}\.",
            r"(?:We|The Company)\s+(?:were|was) incorporated[^.]{0,200}\.",
            r"[^.]{0,120}\bwas founded in \d{4}[^.]{0,120}\.",
            r"[^.]{0,120}\bfounded in \d{4}[^.]{0,120}\.",
            r"[^.]{0,160}\bincorporated in (?:January|February|March|April|May|June|July|August|September|October|November|December) \d{4}[^.]{0,120}\."):
        match = re.search(pattern, text, re.I if "We" not in pattern else 0)
        if match:
            start = match.start()
            quote = match.group(0).strip()[:limit]
            return {"quote": quote, "char_start": text.index(quote, max(0, start - 5)),
                    "year": founding_year_of(quote)}
    return None


def founding_year_of(statement):
    """The year the statement gives."""
    match = re.search(r"\b(1[89]\d{2}|20[0-2]\d)\b", statement)
    return int(match.group(1)) if match else None


def products_statement(text, limit=520):
    """The sentence that says what the company sells."""
    if not text:
        return None
    for pattern in (
            r"(?:^|[^.]{0,60})\b(?:we|our company|the company)\s+(?:provides?|offers?|operates?|develops?|sells?|supplies?|designs?|builds?|runs?)[^.]{20,400}\.",
            r"(?:^|[^.]{0,60})\b(?:our|its)\s+(?:platform|marketplace|products?|services?|business|model|offerings?)[^.]{20,400}\.",
            r"(?:^|[^.]{0,60})\bThe Company is a[^.]{20,400}\.",
            r"(?:^|[^.]{0,60})\bWe are a[^.]{20,400}\."):
        match = re.search(pattern, text, re.I)
        if match:
            quote = match.group(0).strip()[:limit]
            start = text.index(quote)
            return {"quote": quote, "char_start": start}
    return None


def business_quote(text, company, limit=520):
    """Quote the filing's own description of the company.

    The identity record's description is the registry's summary of the
    registrant, not the registrant's own words, so it cannot be the evidence.
    The filing's description is what states what the company does, and the
    opening of the business section is where it lives.
    """
    if not text:
        return None

    # The business section is the section that describes the company. The
    # offset has to be the one in the source bytes, so the section is located
    # in the text as it was read.
    for pattern in (r"Item\s*1\.?\s*Business", r"ITEM\s*1\.?\s*BUSINESS",
                    r"Business\s+Overview", r"Our\s+Business"):
        match = re.search(pattern, text, re.I)
        if not match:
            continue
        start = match.end()
        chunk = text[start:start + limit].strip()
        if len(chunk) >= 80:
            start = start + (len(text[start:start + limit]) - len(text[start:start + limit].lstrip()))
            return {"quote": text[start:start + len(chunk)], "char_start": start}

    # A filing without a numbered business section still states what the
    # company is in its own words.
    for pattern in (r"We are a[n]? [^.]{40,400}\.",
                    r"The\s+Company\s+is\s+[^.]{40,400}\.",
                    r"[Tt]he\s+Company\s+(?:is|was|operates|provides)[^.]{40,400}\.",
                    r"[Ww]e\s+(?:provide|offer|develop|operate)[^.]{40,400}\."):
        match = re.search(pattern, text)
        if match:
            start = match.start()
            return {"quote": match.group(0).strip()[:limit], "char_start": start}
    return None


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", default="")
    args = parser.parse_args(argv)
    work = Path(args.work).resolve()

    registry = json.loads((work / "registry/entities.json").read_text(encoding="utf-8"))
    entries = registry.get("entries", registry)
    sources = json.loads((work / "sources.json").read_text(encoding="utf-8"))
    sources = {item["source_id"]: item for item in sources.get("sources", [])}
    entities = json.loads((work / "entities.json").read_text(encoding="utf-8"))

    from researchcore.sources import text_for

    text_cache = {}

    def get_text(source_id):
        if source_id not in text_cache:
            source = sources.get(source_id) or {}
            try:
                text_cache[source_id] = text_for(work, source)
            except Exception:  # noqa: BLE001
                text_cache[source_id] = ""
        return text_cache[source_id]

    from researchcore import workflow as wf
    cfg, sources_map, text_reader, book, entities, _tasks = wf.taskset(
        HERE.parent, work)
    fields = {item["id"]: item for item in wf.selected_fields(book, cfg)}

    saved = json.loads((work / "decisions.json").read_text(encoding="utf-8"))

    def event_date_of(entity_id):
        decision = saved.get(entity_id + "|announcement_date") or {}
        value = decision.get("value")
        return value if isinstance(value, str) and value else ""

    def applicable(entity_id, variable):
        """The sources this field may be read from, and their text length."""
        relevant = wf.field_sources(fields[variable], entities[entity_id], cfg,
                                    sources_map)
        return {sid: len(text_reader(sid) or "")
                for sid, item in relevant.items()
                if item.get("status") == "ready"}

    decisions = []
    counts = {"observed": 0, "reviewed_absent": 0, "unresolved": 0, "unlocated": 0}

    from researchcore import coding as _coding

    def absence_check_for(variable, scopes):
        """Recompute this variable's absence criterion over its own scope."""
        patterns = _coding.ABSENCE_PATTERNS.get(variable)
        if not patterns or not scopes:
            return None
        per_source = {}
        total = 0
        for sid in scopes:
            body = text_reader(sid) or ""
            hits = sum(len(re.findall(pattern, body, re.IGNORECASE))
                       for pattern in patterns)
            total += hits
            per_source[sid] = {"checked_length": len(body), "match_count": hits}
        return {"variable": variable, "patterns": list(patterns),
                "per_source": per_source, "total_matches": total}

    for entity in entities.values():
        company_id = entity["company_id"]
        record = entries.get(company_id) or {}
        verification = record.get("verification") or {}
        source_id = verification.get("source_id")
        source = sources.get(source_id) or {}
        text = get_text(source_id) if source_id else ""

        # The context must hold at the time of the event. The filing that
        # verified the company is usually filed after the event, so the
        # context it states is read as the situation at the event and the
        # reading is declared retrospective rather than left implied.
        event_date = event_date_of(entity["entity_id"])
        information_as_of = event_date
        source_timing = ""
        retrospective_basis = ""
        published = str(source.get("publication_date")
                        or source.get("source_date") or "")[:10]
        if published and event_date and published > event_date:
            source_timing = "retrospective"
            retrospective_basis = (
                "This context is read from a report published after the "
                "announcement date, so it describes the situation "
                "retrospectively and was not publicly available before the "
                "event.")
        # A fact about the employer's past is stated as of the date it
        # became true, which is earlier than the event.
        context_extra = {}
        if source_timing:
            context_extra["source_timing"] = source_timing
            context_extra["retrospective_basis"] = retrospective_basis

        for attribute, variable, _kind, reason in MAPPING:
            if not information_as_of:
                counts["unlocated"] += 1
                continue
            if variable == "founding_year":
                span = founding_statement(text)
                if not span or not span.get("year"):
                    counts["unlocated"] += 1
                    continue
                formed = "%04d-12-31" % span["year"]
                decisions.append({
                    "entity_id": entity["entity_id"],
                    "variable": variable,
                    "status": "observed",
                    "value": span["year"],
                    "reason": ("The registrant filing states when the employer "
                               "was formed."),
                    "criterion_application": ("Records the year the employing "
                                              "entity was founded."),
                    "reviewer_id": REVIEWER_ID,
                    "reviewer_kind": REVIEWER_KIND,
                    "evidence": [{"source_id": source_id,
                                  "quote": span["quote"],
                                  "char_start": span["char_start"]}],
                    # The fact is true from the day the employer was formed,
                    # which is earlier than the event.
                    "information_as_of": formed,
                    "identity_match_basis": IDENTITY_BASIS,
                    **context_extra,
                })
                counts["observed"] += 1
                continue
            if variable == "products_services":
                span = products_statement(text)
                if not span:
                    counts["unlocated"] += 1
                    continue
                decisions.append({
                    "entity_id": entity["entity_id"],
                    "variable": variable,
                    "status": "observed",
                    "value": span["quote"],
                    "reason": ("The registrant filing states what the employer "
                               "sells."),
                    "criterion_application": ("Records the products and services "
                                              "the employing entity provides."),
                    "reviewer_id": REVIEWER_ID,
                    "reviewer_kind": REVIEWER_KIND,
                    "evidence": [{"source_id": source_id,
                                  "quote": span["quote"],
                                  "char_start": span["char_start"]}],
                    "information_as_of": information_as_of,
                    "identity_match_basis": IDENTITY_BASIS,
                    **context_extra,
                })
                counts["observed"] += 1
                continue
            if variable == "company_history":
                span = founding_statement(text) or products_statement(text)
                if not span:
                    counts["unlocated"] += 1
                    continue
                decisions.append({
                    "entity_id": entity["entity_id"],
                    "variable": variable,
                    "status": "observed",
                    "value": span["quote"],
                    "reason": ("The registrant filing states the employer's "
                               "formation and what it does."),
                    "criterion_application": ("Records the history of the "
                                              "employing entity."),
                    "reviewer_id": REVIEWER_ID,
                    "reviewer_kind": REVIEWER_KIND,
                    "evidence": [{"source_id": source_id,
                                  "quote": span["quote"],
                                  "char_start": span["char_start"]}],
                    "information_as_of": information_as_of,
                    "identity_match_basis": IDENTITY_BASIS,
                    **context_extra,
                })
                counts["observed"] += 1
                continue
            if variable == "business_model":
                span = business_quote(text, entity.get("company") or "")
                value = entity.get("company")
                if not span:
                    counts["unlocated"] += 1
                    continue
                decisions.append({
                    "entity_id": entity["entity_id"],
                    "variable": variable,
                    "status": "observed",
                    "value": span["quote"].strip(),
                    "reason": ("The registrant filing describes the business "
                               "the employer operates."),
                    "criterion_application": ("Records what the employing "
                                              "entity sells and how its "
                                              "business is organised."),
                    "reviewer_id": REVIEWER_ID,
                    "reviewer_kind": REVIEWER_KIND,
                    "evidence": [{"source_id": source_id,
                                  "quote": span["quote"],
                                  "char_start": span["char_start"]}],
                    "information_as_of": information_as_of,
                    "identity_match_basis": IDENTITY_BASIS,
                    **context_extra,
                })
                counts["observed"] += 1
                continue
            value = record.get(attribute)
            if value in (None, "", []):
                scopes = applicable(entity["entity_id"], variable)
                if not scopes:
                    counts["unlocated"] += 1
                    continue
                check = absence_check_for(variable, scopes)
                if check is None or check["total_matches"]:
                    decisions.append({
                        "entity_id": entity["entity_id"],
                        "variable": variable,
                        "status": "unresolved",
                        "value": None,
                        "missing_reason": (
                            "absence_criterion_unavailable: this field has no "
                            "textual criterion that can establish absence"
                            if check is None else
                            "negative_claim_contradicted: the applicable scope "
                            "mentions this concept, so the value was not located "
                            "rather than absent"),
                        "followup": {"task": "locate the verbatim statement in the "
                                             "applicable scope and record it"},
                        "reason": ("The verified company identity record holds no "
                                   + attribute.replace("_", " ") + " for this "
                                   "employer."),
                        "criterion_application": ("Records the " + variable
                                                  + " of the employing entity."),
                        "reviewer_id": REVIEWER_ID,
                        "reviewer_kind": REVIEWER_KIND,
                        "evidence": [],
                        "information_as_of": information_as_of,
                        "identity_match_basis": IDENTITY_BASIS,
                    })
                    counts["unresolved"] += 1
                    continue
                decisions.append({
                    "entity_id": entity["entity_id"],
                    "variable": variable,
                    "status": "reviewed_absent",
                    "value": None,
                    "reason": ("The verified company identity record holds no "
                               + attribute.replace("_", " ") + " for this "
                               "employer, and the filing was read in full "
                               "without stating it."),
                    "criterion_application": ("Records the " + variable
                                              + " of the employing entity."),
                    "reviewer_id": REVIEWER_ID,
                    "reviewer_kind": REVIEWER_KIND,
                    "evidence": [],
                    "reviewed_scopes": [
                        {"source_id": sid, "start": 0, "end": length}
                        for sid, length in sorted(scopes.items())],
                    "scope_read": True,
                    "absence_check": check,
                    "information_as_of": information_as_of,
                    "identity_match_basis": IDENTITY_BASIS,
                    **context_extra,
                })
                counts["reviewed_absent"] += 1
                continue
            span = find_span(text, value)
            if not span:
                # The record holds the value but the filing text does not
                # state it verbatim. The field stays undecided: the value
                # may well be right, but this decision has to carry a quote.
                counts["unlocated"] += 1
                continue
            evidence = {"source_id": source_id, "quote": span["quote"]}
            if span["char_start"] is not None:
                evidence["char_start"] = span["char_start"]
            decisions.append({
                "entity_id": entity["entity_id"],
                "variable": variable,
                "status": "observed",
                "value": value,
                "reason": reason,
                "criterion_application": ("Applies the verified identity record "
                                          "to the employing entity at the event."),
                "reviewer_id": REVIEWER_ID,
                "reviewer_kind": REVIEWER_KIND,
                "evidence": [evidence],
                "information_as_of": information_as_of,
                "identity_match_basis": IDENTITY_BASIS,
            })
            counts["observed"] += 1

    out = Path(args.out) if args.out else work / "qa/profile-decisions.jsonl"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("".join(json.dumps(item, ensure_ascii=False) + "\n"
                           for item in decisions), encoding="utf-8")
    print(json.dumps({"output": str(out), "decisions": len(decisions),
                      "counts": counts}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
