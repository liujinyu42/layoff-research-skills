#!/usr/bin/env python3
"""Build the entity-registry verification input from registered sources.

One row per roster company: company_id, entity_id, name, name_type, source_id,
quote, domains, parent_company_id, brand_of, verification_basis.

The row binds a *legal entity*, not just a name:

* `domains` are the company's own hostnames, taken from the roster when it
  states one. They are what lets a later page be attributed to this entity
  instead of to any company with a similar name.
* `verification_basis` says how the name was bound: `own_source` (a source the
  company itself accounts for), `registry_filing`, or `news_mention` (another
  publisher's page happens to name it). A mention is recorded as
  `news_mention`, which the registry treats as mention-only strength: it cannot
  establish a legal entity, and a name shared with another roster company moves
  the entity to review instead of passing as verified.

Quote rules (registry.verify contract): the source must be registered and
ready, the quote must appear exactly once in that source's normalized text, be
verbatim and at least ten characters long.

Usage:
  python3 build_entity_registry.py --work WORK [--roster roster.csv]
                                   [--out qa/entity_registry.csv]
                                   [--no-mention-fallback]
"""
import argparse
import csv
import io
import json
import re
import sys
from pathlib import Path

SUFFIXES = re.compile(
    r'[,\s]*(inc|inc\.|llc|l\.l\.c\.|corp|corp\.|corporation|ltd|ltd\.|limited|plc|'
    r'co|co\.|company|holdings|holding|group|technologies|technology|s\.a\.|n\.v\.|ag)\s*$',
    re.IGNORECASE)

FIELDS = ['company_id', 'entity_id', 'name', 'name_type', 'valid_from', 'valid_to',
          'source_id', 'quote', 'domains', 'parent_company_id', 'brand_of',
          'country', 'registration_id', 'verification_basis']


def load_roster(work, path):
    roster_path = work / path
    if roster_path.is_file():
        with roster_path.open(encoding='utf-8-sig') as handle:
            rows = list(csv.DictReader(handle))
        return [{'company_id': (row.get('company_id') or '').strip(),
                 'company': (row.get('company') or row.get('name') or '').strip(),
                 'domains': (row.get('domains') or row.get('official_website')
                             or row.get('website') or row.get('domain') or '').strip(),
                 'parent_company_id': (row.get('parent_company_id') or '').strip(),
                 'brand_of': (row.get('brand_of') or '').strip(),
                 'country': (row.get('country') or '').strip()}
                for row in rows if (row.get('company_id') or '').strip()]
    config = work / 'config.json'
    if config.is_file():
        payload = json.loads(config.read_text(encoding='utf-8'))
        return [{'company_id': row['company_id'], 'company': row.get('company', ''),
                 'domains': row.get('official_website') or row.get('website') or '',
                 'parent_company_id': row.get('parent_company_id') or '',
                 'brand_of': row.get('brand_of') or '',
                 'country': row.get('country') or ''}
                for row in payload.get('roster', [])]
    raise SystemExit('No roster found; pass --roster or keep config.json in the workspace')


def load_sources(work):
    path = work / 'sources.json'
    if not path.is_file():
        raise SystemExit('sources.json is missing; run the source ingest first')
    payload = json.loads(path.read_text(encoding='utf-8'))
    ready = [source for source in payload['sources']
             if source.get('status') == 'ready' and source.get('text_path')
             and source.get('active', True)]
    by_company = {}
    for source in ready:
        by_company.setdefault(source['company_id'], []).append(source)
    for group in by_company.values():
        group.sort(key=lambda source: -int(source.get('n_chars') or 0))
    return ready, by_company


def name_variants(name):
    """Full roster name first, then the name without a corporate suffix."""
    variants = [name]
    stripped = SUFFIXES.sub('', name).strip().rstrip(',.')
    if '/' in name:
        for part in name.split('/'):
            part = part.strip()
            if len(part) >= 3 and part not in variants:
                variants.append(part)
    if re.search(r'\sUS$', stripped) and len(stripped) > 4:
        shorter = stripped[:-3].strip()
        if shorter and shorter not in variants:
            variants.append(shorter)
    if len(stripped) >= 3 and stripped.lower() != name.lower():
        variants.append(stripped)
    return variants


def pick_quote(text, name):
    """A verbatim quote that is unique in the text and contains the name."""
    for candidate in name_variants(name):
        pattern = re.compile(r'(?<!\w)' + re.escape(candidate) + r'(?!\w)', re.IGNORECASE)
        matches = list(pattern.finditer(text))
        if not matches:
            continue
        scored = []
        for match in matches:
            start = match.start()
            line_start = text.rfind('\n', 0, start) + 1
            line_end = text.find('\n', start)
            if line_end < 0:
                line_end = len(text)
            scored.append((len(text[line_start:line_end].strip()), line_start, line_end))
        scored.sort(reverse=True)
        for _, line_start, line_end in scored[:12]:
            windows = []
            start, end = line_start, line_end
            for _ in range(6):
                windows.append(text[start:end].strip())
                start = 0 if start == 0 else text.rfind('\n', 0, start - 1) + 1
                nxt = text.find('\n', end + 1)
                end = len(text) if end >= len(text) or nxt < 0 else nxt
                if start == 0 and end >= len(text):
                    break
            for quote in windows:
                if 10 <= len(quote) <= 400 and text.count(quote) == 1 \
                        and pattern.search(quote):
                    return quote
    return None


def _domains(value):
    out = []
    for item in re.split(r'[;,]', str(value or '')):
        host = re.sub(r'^https?://', '', item.strip().lower()).split('/')[0]
        if host and re.fullmatch(r'(?:[a-z0-9-]+\.)+[a-z]{2,}', host):
            out.append(host)
    return ';'.join(sorted(set(out)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--work', required=True)
    parser.add_argument('--roster', default='roster.csv')
    parser.add_argument('--out', default='qa/entity_registry.csv')
    parser.add_argument('--config', default='config.json')
    parser.add_argument('--no-mention-fallback', dest='mention_fallback',
                        action='store_false', default=True,
                        help='only accept a company\'s own source as identity evidence')
    args = parser.parse_args()

    work = Path(args.work).resolve()
    roster = load_roster(work, args.roster)
    sources, by_company = load_sources(work)
    print(f'ready sources: {len(sources)}; companies with own ready sources: '
          f'{len(by_company)}', flush=True)

    rows, missing = [], []
    for index, company in enumerate(roster, 1):
        company_id, name = company['company_id'], company['company']
        quote = source_id = basis = None
        for source in by_company.get(company_id, []):
            text = (work / source['text_path']).read_text(encoding='utf-8', errors='replace')
            quote = pick_quote(text, name)
            if quote:
                source_id, basis = source['source_id'], 'own_source'
                break
        if quote is None and args.mention_fallback:
            for source in sources:
                if source['company_id'] == company_id:
                    continue
                text = (work / source['text_path']).read_text(encoding='utf-8', errors='replace')
                quote = pick_quote(text, name)
                if quote:
                    source_id, basis = source['source_id'], 'news_mention'
                    break
        if quote is None:
            missing.append(company_id)
            print(f'[{index}/{len(roster)}] {company_id}: no identity source found', flush=True)
            continue
        domains = _domains(company['domains'])
        if basis == 'own_source' and not domains:
            # Without a domain the name alone cannot distinguish the legal
            # entity, so the row is recorded at mention strength rather than
            # claiming a primary-source identification it does not have.
            basis = 'news_mention'
        rows.append({
            'company_id': company_id,
            'entity_id': company_id,
            'name': name,
            'name_type': 'legal',
            'valid_from': '',
            'valid_to': '',
            'source_id': source_id,
            'quote': quote,
            'domains': domains,
            'parent_company_id': company['parent_company_id'],
            'brand_of': company['brand_of'],
            'country': company['country'],
            'registration_id': '',
            'verification_basis': basis,
        })
        print(f'[{index}/{len(roster)}] {company_id}: {basis} via {source_id}'
              + (f' ({domains})' if domains else ' (no domain)'), flush=True)

    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=FIELDS)
    writer.writeheader()
    writer.writerows(rows)
    out_path = work / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(buffer.getvalue(), encoding='utf-8')
    print(f'wrote {args.out}: {len(rows)} rows; unresolved: {len(missing)} {missing}',
          flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
