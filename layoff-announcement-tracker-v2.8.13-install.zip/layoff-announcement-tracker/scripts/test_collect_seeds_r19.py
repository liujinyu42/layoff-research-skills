"""R-19 tests: index display names and our names are matched on one normalisation.

All fetches are mocked and workspaces live under tempfile; nothing is written to the
layoff-run output directory. Fixtures only mimic the structure of TheLayoff.com's
/index/<letter> pages; no company-specific alias is hard-coded in the code under test.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import collect_seeds
from researchcore import seed_sweep
from test_collect_seeds import board_page
from test_collect_seeds_r14 import IBM_BOARD, NOT_FOUND, index_page


class KeyTests(unittest.TestCase):
    def test_name_key_strips_corporate_and_web_address_tokens_iteratively(self):
        key = collect_seeds.name_key
        self.assertEqual(key("Salesforce.com Inc."), "salesforce")
        self.assertEqual(key("Salesforce, Inc."), "salesforce")
        self.assertEqual(key("Acme Holdings Group AG"), "acme")
        self.assertEqual(key("Foo Group plc"), "foo")
        self.assertEqual(key("Example.io"), "example")
        self.assertEqual(key("Example.AI Ltd"), "example")
        self.assertEqual(key("Seagate Technology Holdings plc"), "seagate technology")
        self.assertEqual(key("Nordic SA NV"), "nordic")
        self.assertEqual(key("The Home Depot, Inc."), "home depot")
        self.assertEqual(key("AT&T Inc."), "at and t")
        self.assertEqual(key("Hewlett-Packard Co."), "hewlett packard")

    def test_name_key_never_strips_a_name_down_to_nothing(self):
        self.assertEqual(collect_seeds.name_key("Inc"), "inc")
        self.assertEqual(collect_seeds.name_key("Group"), "group")
        self.assertEqual(collect_seeds.name_key("Co Ltd"), "co")
        self.assertEqual(collect_seeds.name_key(""), "")

    def test_board_keys_split_a_parenthetical_into_two_names(self):
        keys = collect_seeds.board_keys
        self.assertEqual(keys("HP (Hewlett-Packard)"), {"hp", "hewlett packard"})
        self.assertEqual(keys("Hewlett Packard Enterprise (HPE)"), {"hewlett packard enterprise", "hpe"})
        self.assertEqual(keys("Salesforce.com Inc."), {"salesforce"})
        self.assertEqual(keys("Meta (Facebook) (Instagram)"), {"meta", "facebook", "instagram"})
        self.assertEqual(keys("()"), set())

    def test_alias_slugs_now_also_strip_web_address_and_group_tokens(self):
        slugs = collect_seeds.alias_slugs(["Salesforce.com, Inc.", "Alarum Group"])
        self.assertIn("salesforce-com", slugs)
        self.assertIn("salesforce", slugs)
        self.assertIn("alarum", slugs)


def letter_fixture(letter, entries, pages=1):
    """A letter split over ``pages`` index pages, following <link rel=next>."""
    out = {}
    per = max(1, -(-len(entries) // pages))
    for n in range(1, pages + 1):
        chunk = entries[(n - 1) * per:n * per]
        nxt = f"/index/{letter}/page-{n + 1}" if n < pages else None
        url = f"https://www.thelayoff.com/index/{letter}" + ("" if n == 1 else f"/page-{n}")
        out[url] = (200, index_page(letter, n, 1, chunk, nxt=nxt))
    return out


def make_index(pages):
    return collect_seeds.TheLayoffIndex(lambda url: pages.get(url, (404, NOT_FOUND)),
                                        base="https://www.thelayoff.com")


class MatchingTests(unittest.TestCase):
    def test_the_three_reported_misses_now_match_exactly(self):
        pages = {}
        pages.update(letter_fixture("s", [("salesforce-com", "Salesforce.com Inc."),
                                          ("salesforce-foundation", "Salesforce Foundation")]))
        pages.update(letter_fixture("h", [("hewlett-packard", "HP (Hewlett-Packard)"),
                                          ("hp-enterprise", "Hewlett Packard Enterprise (HPE)"),
                                          ("hilton", "Hilton")], pages=2))
        index = make_index(pages)
        self.assertEqual(index.lookup(["Salesforce", "Salesforce, Inc."])[0],
                         {"salesforce-com": "Salesforce.com Inc."})
        self.assertEqual(index.lookup(["HP", "HP Inc."])[0],
                         {"hewlett-packard": "HP (Hewlett-Packard)"})
        self.assertEqual(index.lookup(["Hewlett Packard Enterprise"])[0],
                         {"hp-enterprise": "Hewlett Packard Enterprise (HPE)"})
        # The inner parenthetical is a key too, in both directions.
        self.assertEqual(index.lookup(["Hewlett-Packard"])[0],
                         {"hewlett-packard": "HP (Hewlett-Packard)"})
        self.assertEqual(index.lookup(["HPE"])[0], {"hp-enterprise": "Hewlett Packard Enterprise (HPE)"})

    def test_match_is_exact_on_keys_not_a_prefix_or_substring(self):
        index = make_index(letter_fixture("s", [("salesforce-foundation", "Salesforce Foundation"),
                                                ("sales-force", "Sales Force Automation")]))
        matches, _ = index.lookup(["Salesforce"])
        self.assertEqual(matches, {})

    def test_two_boards_with_the_same_key_are_both_reported(self):
        index = make_index(letter_fixture("m", [("mara", "MARA"), ("mara-holdings", "Mara Holdings Inc."),
                                                ("maria", "Maria")]))
        matches, _ = index.lookup(["Mara"])
        self.assertEqual(matches, {"mara": "MARA", "mara-holdings": "Mara Holdings Inc."})

    def test_letters_include_the_first_letter_of_every_key_and_variant(self):
        letters = collect_seeds.TheLayoffIndex.letters_for(["The Home Depot, Inc.", "HP (Hewlett-Packard)"])
        self.assertEqual(letters, ["h", "t"])

    def test_near_candidates_rank_by_overlap_top_three_and_exclude_matches(self):
        entries = [("hp-labs", "HP Labs Research"), ("hp-printing", "HP Printing"),
                   ("printing-fin", "Printing Financial Services"),
                   ("hilton", "Hilton"), ("hp-x", "HP X Y Z Unrelated Words")]
        index = make_index(letter_fixture("h", entries))
        index.lookup(["HP Printing"])
        near = index.near_candidates(["HP Printing"], exclude={"hp-printing"})
        self.assertEqual(len(near), 3)
        self.assertEqual([slug for slug, _, _ in near], ["hp-labs", "printing-fin", "hp-x"])
        self.assertNotIn("hp-printing", [slug for slug, _, _ in near])
        self.assertNotIn("hilton", [slug for slug, _, _ in near])
        self.assertTrue(all(0 < score <= 1 for _, _, score in near))
        self.assertEqual(near, sorted(near, key=lambda item: -item[2]))

    def test_initials_rule_stays_candidate_only_and_reads_parenthetical_keys(self):
        index = make_index(letter_fixture("i", [("international-business-machines-x", "International Business Machines (Corp)"),
                                                ("ibex", "IBEX")]))
        index.lookup(["IBM"])
        self.assertEqual(index.initials_candidates(["IBM"]),
                         {"international-business-machines-x": "International Business Machines (Corp)"})
        self.assertEqual(index.lookup(["IBM"])[0], {})


class CollectHelper:
    """collect_seeds.main() on a tempfile workspace with every fetch mocked."""

    def run_collect(self, urls, roster, extra=(), registry=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        work = Path(tmp.name)
        cfg = {"event_start": "2019-01-01", "event_end": "2026-11-13",
               "roster": [{"company_id": cid, "company": name} for cid, name in roster]}
        seed_sweep.plan(work, cfg)
        if registry:
            (work / "registry").mkdir()
            (work / "registry/entities.json").write_text(json.dumps({"entries": registry}), encoding="utf-8")
        out = work / "batch.json"
        self.last_work = work
        argv = ["collect_seeds.py", "--work", str(work), "--out", str(out), "--only-channel", "thelayoff",
                "--workers", "1", "--pace", "0", "--host-confirm-interval", "0", *extra]
        requested = []

        def fake(url):
            requested.append(url)
            status, body = urls.get(url, (404, NOT_FOUND))
            return status, body

        with mock.patch.object(collect_seeds, "_plain_get", side_effect=fake), \
                mock.patch.object(collect_seeds.render_table, "render", return_value=None), \
                mock.patch.object(collect_seeds.time, "sleep"), \
                mock.patch.object(sys, "argv", argv):
            collect_seeds.main()
        return json.loads(out.read_text(encoding="utf-8")), requested

    def urls(self):
        urls = {}
        urls.update(letter_fixture("s", [("salesforce-com", "Salesforce.com Inc."),
                                         ("salesforce-foundation", "Salesforce Foundation")]))
        urls.update(letter_fixture("h", [("hewlett-packard", "HP (Hewlett-Packard)"),
                                         ("hp-enterprise", "Hewlett Packard Enterprise (HPE)"),
                                         ("hp-labs", "HP Labs")]))
        urls["https://www.thelayoff.com/salesforce-com"] = (200, IBM_BOARD)
        urls["https://www.thelayoff.com/hewlett-packard"] = (200, IBM_BOARD)
        urls["https://www.thelayoff.com/hp-enterprise"] = (200, IBM_BOARD)
        return urls



class ExecuteR19Tests(CollectHelper, unittest.TestCase):
    def test_salesforce_hp_and_hpe_resolve_through_the_index_and_say_how(self):
        batch, requested = self.run_collect(
            self.urls(), roster=(("salesforce", "Salesforce"), ("hp", "HP"),
                                 ("hpe", "Hewlett Packard Enterprise")))
        by_task = {r["task_id"]: r for r in batch}
        self.assertEqual({r["outcome"] for r in batch}, {"completed"})
        text = " ".join(r["stop_basis"] for r in batch)
        for slug in ("/salesforce-com", "/hewlett-packard", "/hp-enterprise"):
            self.assertIn(slug, text)
        self.assertIn("(exact key 'salesforce')", text)
        # "hp" is a 2-letter key: the receipt tells a reader to verify it.
        hp = [r for r in batch if "/hewlett-packard " in r["stop_basis"] or "/hewlett-packard)" in r["stop_basis"]
              or "thelayoff.com/hewlett-packard" in r["stop_basis"]][0]
        self.assertIn("short key 'hp'", hp["stop_basis"])

    def test_unresolved_boards_list_top_three_near_candidates_never_accepted(self):
        urls = {}
        urls.update(letter_fixture("a", [("acme-widgets", "Acme Widgets Division"),
                                         ("acme-labs", "Acme Labs"), ("acme-bank", "Acme Bank"),
                                         ("acme-air", "Acme Air Freight Services"), ("zeta", "Zeta")]))
        batch, requested = self.run_collect(urls, roster=(("acme", "Acme Corp"),))
        receipt = batch[0]
        self.assertEqual(receipt["outcome"], "blocked")
        self.assertEqual(receipt["reason"], "board_unresolved")
        basis = receipt["stop_basis"]
        self.assertIn("Closest index entries by word overlap, not accepted:", basis)
        section = basis.split("Closest index entries by word overlap, not accepted:")[1].split("Recorded as")[0]
        self.assertEqual(section.count("overlap"), 3)
        self.assertNotIn("Zeta", section)
        self.assertFalse(any(url.endswith("/acme-labs") for url in requested), "near candidates are never fetched")

    def test_two_matching_boards_are_listed_and_not_chosen(self):
        urls = letter_fixture("m", [("mara", "MARA"), ("mara-holdings", "Mara Holdings Inc.")])
        batch, requested = self.run_collect(urls, roster=(("mara", "Mara"),))
        basis = batch[0]["stop_basis"]
        self.assertEqual(batch[0]["outcome"], "blocked")
        self.assertIn("several boards and none was chosen", basis)
        self.assertIn("mara-holdings", basis)
        self.assertFalse(any(url.endswith("/mara-holdings") for url in requested))

    def test_one_index_match_whose_board_cannot_be_read_is_reported_honestly(self):
        urls = letter_fixture("s", [("salesforce-com", "Salesforce.com Inc.")])
        urls["https://www.thelayoff.com/salesforce-com"] = (503, "")
        batch, _ = self.run_collect(urls, roster=(("salesforce", "Salesforce"),))
        basis = batch[0]["stop_basis"]
        self.assertEqual(batch[0]["outcome"], "blocked")
        self.assertIn("names exactly one board, Salesforce.com Inc. (salesforce-com)", basis)
        self.assertIn("HTTP 503", basis)
        self.assertNotIn("No index entry matched", basis)

    def test_incomplete_index_still_says_so_with_near_candidates(self):
        urls = {"https://www.thelayoff.com/index/a": (200, index_page("a", 1, 1, [("acme-labs", "Acme Labs")],
                                                                    nxt="/index/a/page-2")),
                "https://www.thelayoff.com/index/a/page-2": (503, "")}
        batch, _ = self.run_collect(urls, roster=(("acme", "Acme"),))
        basis = batch[0]["stop_basis"]
        self.assertIn("INCOMPLETE", basis)
        self.assertIn("error at page 2 (HTTP 503)", basis)
        self.assertIn("Closest index entries by word overlap", basis)


class IndexCaptureTests(unittest.TestCase):
    """R-19: every index page the crawl fetches is saved, with no extra request."""

    def pages(self):
        base = "https://www.thelayoff.com/index/h"
        return {
            base: (200, index_page("h", 1, 1, [("hilton", "Hilton")], nxt="/index/h/page-2")),
            base + "/page-2": (200, index_page("h", 2, 1, [("hewlett-packard", "HP (Hewlett-Packard)")],
                                                nxt=None)),
        }

    def crawl(self, capture_dir, pages=None):
        pages = pages if pages is not None else self.pages()
        calls = []

        def fetch(url):
            calls.append(url)
            return pages.get(url, (404, NOT_FOUND))

        index = collect_seeds.TheLayoffIndex(fetch, base="https://www.thelayoff.com",
                                             capture_dir=capture_dir)
        matches, notes = index.lookup(["HP"])
        return index, calls, matches, notes

    def test_pages_and_manifest_are_written_and_no_extra_fetch_is_made(self):
        import hashlib
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "_index"
            _, calls, matches, _ = self.crawl(target)
            _, plain_calls, plain_matches, _ = self.crawl(None)
            self.assertEqual(calls, plain_calls, "capturing adds no request")
            self.assertEqual(matches, plain_matches)
            self.assertEqual(len(calls), 2)
            page1 = target / "h/page-1.html"
            page2 = target / "h/page-2.html"
            self.assertEqual(page1.read_text(encoding="utf-8"), self.pages()[calls[0]][1])
            self.assertEqual(page2.read_text(encoding="utf-8"), self.pages()[calls[1]][1])
            manifest = json.loads((target / "h/_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["letter"], "h")
            self.assertTrue(manifest["complete"])
            self.assertEqual(manifest["stop"], "no_next_page")
            self.assertEqual([f["url"] for f in manifest["fetches"]], calls)
            self.assertEqual([f["page"] for f in manifest["fetches"]], [1, 2])
            self.assertEqual([f["status"] for f in manifest["fetches"]], [200, 200])
            self.assertEqual([f["path"] for f in manifest["fetches"]], ["h/page-1.html", "h/page-2.html"])
            for record, path in zip(manifest["fetches"], (page1, page2)):
                self.assertEqual(record["sha256"], hashlib.sha256(path.read_bytes()).hexdigest())
                self.assertEqual(record["bytes"], path.stat().st_size)
                self.assertRegex(record["fetched_at"], r"^\d{4}-\d\d-\d\dT")
            self.assertEqual(sorted(p.name for p in (target / "h").iterdir()),
                             ["_manifest.json", "page-1.html", "page-2.html"])

    def test_a_failed_page_is_in_the_manifest_with_its_status(self):
        pages = self.pages()
        pages["https://www.thelayoff.com/index/h/page-2"] = (503, "")
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "_index"
            self.crawl(target, pages)
            manifest = json.loads((target / "h/_manifest.json").read_text(encoding="utf-8"))
            self.assertFalse(manifest["complete"])
            self.assertEqual(manifest["stop"], "page_error")
            self.assertEqual([f["status"] for f in manifest["fetches"]], [200, 503])
            self.assertIsNone(manifest["fetches"][1]["path"])
            self.assertFalse((target / "h/page-2.html").exists())

    def test_a_capture_failure_does_not_break_the_crawl_and_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            blocker = Path(tmp) / "not-a-dir"
            blocker.write_text("x", encoding="utf-8")
            _, calls, matches, notes = self.crawl(blocker / "_index")
            self.assertEqual(matches, {"hewlett-packard": "HP (Hewlett-Packard)"})
            self.assertTrue(any("capture failed" in note for note in notes))

    def test_no_capture_dir_means_nothing_is_written(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(Path, "mkdir") as mkdir:
            self.crawl(None)
            mkdir.assert_not_called()


class IndexCaptureCliTests(CollectHelper, unittest.TestCase):
    """Default and overridden capture locations through collect_seeds.main()."""

    def test_default_location_is_under_work_next_to_the_seed_captures(self):
        batch, _ = self.run_collect(self.urls(), roster=(("salesforce", "Salesforce"),))
        base = self.last_work / "discovery/captures/seed/thelayoff/_index/s"
        self.assertTrue((base / "page-1.html").is_file())
        self.assertTrue((base / "_manifest.json").is_file())

    def test_override_flag_redirects_the_capture_and_leaves_work_untouched(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "staging-index"
            self.run_collect(self.urls(), roster=(("salesforce", "Salesforce"),),
                                        extra=["--thelayoff-index-capture-dir", str(target)])
            self.assertTrue((target / "s/page-1.html").is_file())
            self.assertFalse((self.last_work / "discovery/captures/seed/thelayoff/_index").exists())


class ImpactScriptTests(CollectHelper, unittest.TestCase):
    """scripts/thelayoff_index_impact.py reads the saved pages and prints the impact."""

    def test_offline_report_matches_what_the_collector_decided_and_fetches_nothing(self):
        import thelayoff_index_impact as impact
        urls = {}
        urls.update(letter_fixture("h", [("hewlett-packard", "HP (Hewlett-Packard)"),
                                         ("hp-labs", "HP Labs Research"), ("hilton", "Hilton")]))
        urls.update(letter_fixture("m", [("mara", "MARA"), ("mara-holdings", "Mara Holdings Inc.")]))
        urls.update(letter_fixture("a", [("acme-labs", "Acme Labs"), ("acme-bank", "Acme Bank")]))
        urls["https://www.thelayoff.com/hewlett-packard"] = (200, IBM_BOARD)
        # hp/mara/acme are not found by alias slug; hp resolves by the index in the live run.
        batch, _ = self.run_collect(
            urls, roster=(("hp", "HP"), ("mara", "Mara"), ("acme", "Acme Widgets")))
        work = self.last_work
        receipts = work / "parts.json"
        receipts.write_text(json.dumps(batch), encoding="utf-8")
        capture_dir = work / "discovery/captures/seed/thelayoff/_index"
        before = {p: p.read_bytes() for p in capture_dir.rglob("*") if p.is_file()}
        with mock.patch("requests.get", side_effect=AssertionError("network call")):
            rows, summary = impact.run(work, capture_dir, receipts, include_all=True)
        by_id = {row["company_id"]: row for row in rows}
        self.assertEqual(by_id["hp"]["status"], "resolved")
        self.assertEqual(by_id["hp"]["slug"], "hewlett-packard")
        self.assertTrue(by_id["hp"]["short_key"])
        self.assertEqual(by_id["mara"]["status"], "ambiguous")
        self.assertEqual({m["slug"] for m in by_id["mara"]["matches"]}, {"mara", "mara-holdings"})
        self.assertEqual(by_id["acme"]["status"], "unresolved")
        self.assertEqual([n["slug"] for n in by_id["acme"]["near"]][:2], ["acme-bank", "acme-labs"])
        self.assertEqual(summary["resolved"], 1)
        self.assertEqual(summary["ambiguous"], 1)
        self.assertEqual(summary["unresolved"], 1)
        self.assertEqual(summary["short_key"], 1)
        # The collector's own receipts agree: hp completed, the other two unresolved.
        outcomes = {r["task_id"]: (r["outcome"], r.get("reason")) for r in batch}
        self.assertEqual(sorted(v for v in outcomes.values()),
                         [("blocked", "board_unresolved"), ("blocked", "board_unresolved"), ("completed", None)])
        # Default filter keeps only board_unresolved receipts; the CLI prints text and json.
        rows2, _ = impact.run(work, capture_dir, receipts)
        self.assertEqual({row["company_id"] for row in rows2}, {"mara", "acme"})
        import io, contextlib
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            impact.main(["--work", str(work), "--capture-dir", str(capture_dir),
                         "--receipts", str(receipts), "--all"])
        text = out.getvalue()
        self.assertIn("1 resolved, 1 ambiguous, 1 unresolved", text)
        self.assertIn("hp: resolved -> /hewlett-packard", text)
        self.assertIn("SHORT-KEY", text)
        self.assertIn("near (not accepted)", text)
        after = {p: p.read_bytes() for p in capture_dir.rglob("*") if p.is_file()}
        self.assertEqual(before, after, "the report is read-only")


if __name__ == "__main__":
    unittest.main()
