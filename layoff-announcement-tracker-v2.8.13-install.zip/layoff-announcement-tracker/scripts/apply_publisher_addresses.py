#!/usr/bin/env python3
"""Carry a resolved publisher address back into the receipts that point at it.

The candidate ledger holds the publisher's own address once an aggregate link
has been resolved. A receipt that still carries the aggregate address and a
ledger row that carries the publisher address are the same document, and the
runtime compares the two when it checks candidate identity. The comparison
fails on the address, so the receipt has to be told where the document really
lives.

The candidate identity follows the address. A candidate's id is derived from
the employer's identifier and the address, so an address that moves changes
the identity with it. Every place that names the candidate is told the new
name: the receipt's hits, the ledger row, and the disposition receipt that
records what was decided about it. The receipt signature covers the receipt
content, so it is recomputed.

Usage:

    python "$S/scripts/apply_publisher_addresses.py" --work "$W" [--dry-run]
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from urllib.parse import urldefrag

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore.discovery import _digest, candidate_id  # noqa: E402

LEDGER = "event_candidate_review.csv"


def load_ledger(work: Path) -> dict:
    path = work / LEDGER
    if not path.is_file():
        return {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return {row["candidate_id"]: row for row in csv.DictReader(handle)}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    work = Path(args.work).resolve()

    ledger = load_ledger(work)
    receipts_path = work / "discovery/receipts.json"
    receipts = json.loads(receipts_path.read_text(encoding="utf-8"))
    reviews_path = work / "candidate_reviews.json"
    reviews = (json.loads(reviews_path.read_text(encoding="utf-8"))
               if reviews_path.is_file() else {})

    moved = 0
    renamed = 0
    touched = 0
    for receipt in receipts.values():
        company = receipt.get("company_id") or ""
        for hit in receipt.get("hits", []):
            old_id = hit.get("candidate_id")
            if not old_id:
                continue
            row = ledger.get(old_id)
            if not row:
                continue
            resolved = (row.get("source_url") or "").strip()
            current = (hit.get("url") or "").strip()
            if not resolved or not current:
                continue
            if urldefrag(resolved)[0] == urldefrag(current)[0]:
                continue
            hit["url"] = resolved
            hit["publisher_address_resolved"] = True
            moved += 1
            # The identity of a candidate is derived from the employer's
            # identifier and the address, so the identity moves with the
            # address. The ledger row and the disposition receipt are renamed
            # with it, or the runtime would read the row as a candidate that
            # was never reviewed.
            if company:
                new_id = candidate_id(company, resolved)
                if new_id != old_id:
                    row["candidate_id"] = new_id
                    ledger[new_id] = row
                    ledger.pop(old_id, None)
                    review = reviews.pop(old_id, None)
                    if review is not None:
                        reviews[new_id] = review
                    hit["candidate_id"] = new_id
                    renamed += 1
        touched += 1

    summary = {"receipts": touched, "addresses_moved": moved,
               "candidates_renamed": renamed}
    if args.dry_run:
        print(json.dumps(summary, ensure_ascii=False))
        return 0

    for receipt in receipts.values():
        payload = {key: value for key, value in receipt.items()
                   if key != "receipt_sha256"}
        receipt["receipt_sha256"] = _digest(payload)

    receipts_path.write_text(json.dumps(receipts, ensure_ascii=False),
                              encoding="utf-8")

    if renamed:
        fields = ["candidate_id", "company", "reported_date", "source_url",
                  "affected_scope", "disposition", "plan_id", "evidence_url",
                  "reason"]
        ledger_path = work / LEDGER
        with ledger_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for row in sorted(ledger.values(), key=lambda item: item["candidate_id"]):
                writer.writerow({field: row.get(field, "") for field in fields})
        if reviews_path.is_file():
            reviews_path.write_text(json.dumps(reviews, ensure_ascii=False),
                                    encoding="utf-8")

    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
