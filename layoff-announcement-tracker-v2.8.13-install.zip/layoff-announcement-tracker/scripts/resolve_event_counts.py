#!/usr/bin/env python3
"""Read the number of affected roles from the reports bound to each event.

The runtime reads the number from the report that carries the event. Many
events, though, were registered from a page that announces the reduction
without giving a figure, while another report about the same reduction does
give it. The number belongs to the event either way, so the reading is
repeated over every report bound to the plan, and the first report that
states a figure supplies it.

The scope rules are the runtime's own: the sentence has to name the
employer, the number has to count this employer's own reduction, and a
figure that does not survive the plausibility check is not recorded. Nothing
here decides a value; it only finds the report that states one.

Usage:

    python "$S/scripts/resolve_event_counts.py" --work "$W" [--out "$W/qa/count-decisions.jsonl"]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import researchcore.coding as coding  # noqa: E402
from researchcore import event_plans  # noqa: E402
from researchcore.workflow import load  # noqa: E402

# The numerical family of an event. Everything else about the plan is read
# from the report that carries it and is left alone here.
COUNT_FAMILY = {
    "layoff_count", "layoff_count_qualifier", "layoff_count_lower",
    "layoff_count_upper", "layoff_count_basis", "numerical_claim_raw",
    "layoff_percentage", "layoff_percentage_qualifier",
    "layoff_percentage_lower", "layoff_percentage_upper",
    "layoff_percentage_denominator",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", default="")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    plans = []
    for name in ("qa/event-plans.json", "qa/event-plans.fresh.json"):
        data = load(work / name, None)
        if isinstance(data, dict):
            data = data.get("plans", [])
        if isinstance(data, list) and data:
            plans = data
            break
    registry = load(work / "registry/entities.json", {}) or {}
    identities = registry.get("entries", registry)
    sources = {}
    for row in (load(work / "sources.json", {}) or {}).get("sources", []):
        sources[row["source_id"]] = {**row, "_work": str(work)}
    accepted = load(work / "decisions.json", {}) or {}

    by_plan = {}
    for source in sources.values():
        if source.get("plan_id"):
            by_plan.setdefault(source["plan_id"], []).append(source)

    decisions = []
    counts = {"read": 0, "already_read": 0, "no_figure": 0}
    for plan in plans:
        plan_id = plan["plan_id"]
        identity = identities.get(plan.get("company_id"), {}) or {}
        aliases = event_plans.company_aliases(identity)
        if not aliases:
            continue
        if any(plan_id + "|" + variable in accepted
               for variable in ("layoff_count", "layoff_count_lower",
                                "layoff_count_upper")):
            counts["already_read"] += 1
            continue
        year = str(plan.get("event_date", ""))[:4]
        firm_size = identity.get("firm_size")

        candidates = []
        primary = sources.get(plan.get("primary_source_id"))
        if primary:
            candidates.append(primary)
        for source in by_plan.get(plan_id, []):
            if primary and source["source_id"] == primary["source_id"]:
                continue
            if source.get("status") == "ready" and source.get("text_path"):
                candidates.append(source)

        found = False
        for source in candidates:
            if found:
                break
            if source.get("status") != "ready" or not source.get("text_path"):
                continue
            # The runtime's own builder produces the numerical decisions from
            # the report that carries the event. Pointing it at another report
            # about the same event keeps every scope rule it applies.
            patched = dict(plan)
            patched["primary_source_id"] = source["source_id"]
            produced = coding.build_plan_decisions(
                patched, identity, sources, aliases, year)
            numerical = [item for item in produced
                         if item.get("variable") in COUNT_FAMILY]
            if not any(item.get("variable") in {"layoff_count",
                                                "layoff_count_lower",
                                                "layoff_count_upper"}
                       for item in numerical):
                continue
            # The plausibility check the runtime applies before it keeps a
            # figure is applied here as well, because the builder records the
            # figure before that check runs on the plan's own primary report.
            count = None
            for item in numerical:
                if item.get("variable") == "layoff_count":
                    count = item
                    break
            if count is not None and isinstance(count.get("value"), (int, float)):
                share = None
                for item in numerical:
                    if item.get("variable") == "layoff_percentage":
                        share = item.get("value")
                        break
                ok, _why = coding.extraction.plausibility(
                    count["value"], firm_size, share)
                if not ok:
                    continue
            decisions.extend(numerical)
            counts["read"] += 1
            found = True
        if not found:
            counts["no_figure"] += 1

    out = Path(args.out) if args.out else work / "qa/count-decisions.jsonl"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("".join(json.dumps(item, ensure_ascii=False) + "\n"
                           for item in decisions), encoding="utf-8")
    print(json.dumps({"output": str(out), "decisions": len(decisions),
                      "counts": counts}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
