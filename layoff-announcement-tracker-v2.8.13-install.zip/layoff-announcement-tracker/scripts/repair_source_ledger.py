#!/usr/bin/env python3
"""Repair a source ledger that an incremental ingest left inconsistent.

`ingest()` treats the manifest as the complete list of live sources: every
source it does not carry is written back as `active: false`. That is correct
for a full round and destructive for an incremental one. Registering thirty
new pages through a manifest that lists only those thirty silently retires
the whole existing corpus, and because the entity list is derived from the
active sources, every event entity disappears with it.

Three separate faults travel together here, and each one has to be undone:

1. **Retired corpus.** The manifest lists only the newly registered rows.
   The rest of the corpus is still in the ledger and still has its snapshots.
2. **Duplicate registration.** `source_id_for()` derives the id suffix from
   the company id. A page registered through two code paths produces two
   ids for one document: `news-<digest>-<company>` and `news-<digest>`. The
   pair is one document registered twice, and the second copy inflates every
   applicable-source set that the runtime fingerprints.
3. **Stale plan binding.** A retired plan must not come back as an entity,
   but clearing its binding changes the row hash of a source the runtime
   still lists as active, and every decision bound to that source is then
   reported as stale.

The repair keeps the evidence and rebuilds the bindings:

* Sources the ledger holds but the manifest lost are recovered, with the
  snapshot address, plan binding and row content the ledger recorded.
* A plan the runtime retired keeps its sources — the documents stay readable —
  but loses its plan binding, so it stops producing entities.
* A row's plan binding is left exactly as the manifest had it. The manifest
  is the authority on which plan a source serves; only the snapshot address
  was lost from it.

A decision is never rewritten here. If a decision's fingerprint still drifts
after this repair, the drift is a finding about the decision, not about the
ledger, and it is resolved by re-reading the source and re-submitting the
decision through `apply`.

Usage:

    python "$S/scripts/repair_source_ledger.py" --work "$W"
    python "$S/scripts/repair_source_ledger.py" --work "$W" --dry-run
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore import sources as source_module  # noqa: E402


def read_json(path: Path, default=None):
    if not Path(path).is_file():
        return default
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_manifest_rows(path: Path) -> tuple[list[dict], list[str]]:
    rows = list(csv.DictReader(Path(path).open(encoding="utf-8-sig")))
    if not rows:
        raise ValueError("Manifest is empty: " + str(path))
    return rows, list(rows[0].keys())


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--manifest", default="qa/full_manifest.csv")
    parser.add_argument("--output", default="qa/full_manifest_repaired.csv")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    manifest_path = work / args.manifest
    ledger = read_json(work / "sources.json", {}) or {}
    ledger_rows = ledger.get("sources", []) if isinstance(ledger, dict) else ledger
    if not ledger_rows:
        raise ValueError("Source ledger is empty or unreadable: " + str(work / "sources.json"))

    rows, fields = load_manifest_rows(manifest_path)
    by_id = {row["source_id"]: row for row in rows}

    plans = read_json(work / "qa/event-plans.json", {}) or {}
    live_plans = {plan.get("plan_id") for plan in plans.get("plans", []) if plan.get("plan_id")}
    retired = set(read_json(work / "qa/retired-plans.json", []) or [])

    # The reference ledger. A repair run rewrites sources.json, so a second
    # run must read the state before the first one, not the state it left.
    pristine = read_json(work / "sources.json.pre-repair", {}) or {}
    pristine_rows = pristine.get("sources", []) if isinstance(pristine, dict) else pristine
    original = {row["source_id"]: row for row in pristine_rows} if pristine_rows else {}
    if not original:
        original = {row["source_id"]: row for row in ledger_rows}

    report = {"recovered": 0, "restored_snapshot": 0, "cleared_plan": 0, "rows": len(rows)}

    # 1. Restore the snapshot address the manifest lost. Without it the row
    #    hashes differently and every decision bound to the source is rejected.
    for row in rows:
        prior = original.get(row["source_id"])
        if not prior:
            continue
        if prior.get("local_path") and not row.get("local_path"):
            row["local_path"] = prior["local_path"]
            report["restored_snapshot"] += 1
        # A retired plan must not produce an entity. Its sources stay readable;
        # only the binding that would rebuild the entity is dropped.
        plan = row.get("plan_id") or ""
        if plan and plan not in live_plans:
            row["plan_id"] = ""
            report["cleared_plan"] += 1

    # 2. Recover the sources the manifest no longer carries.
    for source in ledger_rows:
        if source["source_id"] in by_id:
            continue
        prior = original.get(source["source_id"], source)
        plan = prior.get("plan_id") or ""
        if plan and plan not in live_plans:
            # A retired plan keeps its documents but loses its binding, so it
            # stops producing an entity.
            plan = ""
            report["cleared_plan"] += 1
        row = {field: "" for field in fields}
        row.update({
            "source_id": source["source_id"],
            "company_id": source["company_id"],
            "source_type": source["source_type"],
            "source_url": source.get("source_url", ""),
            "local_path": prior.get("local_path") or "",
            "document_role": source.get("document_role", ""),
            "fy": source.get("fy") if source.get("fy") not in (None, "") else "",
            "plan_id": plan,
            "publication_date": source.get("publication_date", ""),
            "source_date": source.get("source_date", ""),
            "exchange": source.get("exchange", ""),
            "form": source.get("form", ""),
            "source_language": source.get("source_language") or "en",
        })
        rows.append(row)
        by_id[row["source_id"]] = row
        report["recovered"] += 1

    output_path = work / args.output
    if not args.dry_run:
        with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                writer.writerow({field: row.get(field, "") for field in fields})
        # Keep the pre-repair ledger so a second run repairs from the same
        # baseline instead of from its own output.
        if not (work / "sources.json.pre-repair").is_file():
            (work / "sources.json.pre-repair").write_text(
                json.dumps(ledger, ensure_ascii=False, indent=1), encoding="utf-8")
        recorded = source_module.ingest(work, output_path, offline=True, refresh=False)
        report["statuses"] = {}
        for entry in recorded:
            status = entry.get("status")
            report["statuses"][status] = report["statuses"].get(status, 0) + 1
        report["active"] = sum(1 for entry in recorded if entry.get("active"))
        report["plans"] = len({entry["plan_id"] for entry in recorded if entry.get("plan_id")})
    report["output"] = str(output_path)
    (work / "qa/ledger-repair-report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
