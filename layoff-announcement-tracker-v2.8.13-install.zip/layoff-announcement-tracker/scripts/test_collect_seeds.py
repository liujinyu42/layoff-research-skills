"""Tests for seed date parsing, TheLayoff board parsing, pagination, and host blocks.

Network calls are mocked and workspaces live under tempfile; nothing is
written to the layoff-run output directory.
"""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import collect_seeds


FISKER_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="generator" content="TLO v1.5.1">
  <script src="https://html-load.com/loader.min.js"></script>
  <title>Fisker Layoffs - TheLayoff.com</title>
</head>
<body>
  <div id="posts">
    <article class="col-12 post topic" id="OP+1sjq1YWm">
      <button><strong>&bull;&bull;&bull;</strong></button>
      <header>
        <h2 class="post-title"><a href="/t/1sjq1YWm" class="thread-link">Fisker Warns Employees Of Mass Layoffs Within Two Months</a></h2>
      </header>
      <div class="post-body">
        <p>Fisker sent a memo to employees warning them that layoffs could start on June 28, 2024.</p>
      </div>
      <footer class="meta">
        <span class="post-timeago" data-datetime="2024-05-01T05:00:34Z">
          <time dateTime="2024-05-01T05:00:34Z">May 1, 2024</time>
        </span>
        by <span class="post-author">Anonymous</span>
        <span class="postIdWrap">Post&nbsp;ID:&nbsp;<span class="postid"><a href="/t/1sjq1YWm">@OP+1sjq1YWm</a></span></span>
      </footer>
    </article>
  </div>
</body>
</html>
"""

CF_403_HTML = """<!DOCTYPE html><html><head><title>Just a moment...</title></head>
<body>Checking your browser before you access trueup.io. cf-chl</body></html>"""

WINDOW = ("2019-01-01", "2026-11-13")


class DateParseTests(unittest.TestCase):
    def test_mdy_iso_and_month_name(self):
        self.assertEqual(collect_seeds.parse_reported_date("7/12/2026"), ("2026-07-12", ""))
        self.assertEqual(collect_seeds.parse_reported_date("11/6/2026"), ("2026-11-06", ""))
        self.assertEqual(collect_seeds.parse_reported_date("2019-01-01"), ("2019-01-01", ""))
        self.assertEqual(collect_seeds.parse_reported_date("2024-05-01T05:00:34Z"), ("2024-05-01", ""))
        self.assertEqual(collect_seeds.parse_reported_date("May 1, 2024"), ("2024-05-01", ""))

    def test_unparseable_dates_are_flagged_not_silently_compared(self):
        self.assertEqual(collect_seeds.parse_reported_date(""), ("", "unparseable_date"))
        self.assertEqual(collect_seeds.parse_reported_date("soon"), ("", "unparseable_date"))
        self.assertEqual(collect_seeds.parse_reported_date("13/40/2024"), ("", "unparseable_date"))

    def test_table_rows_for_parses_us_dates_before_the_window_check(self):
        table = {"by_company": {"acme": [
            {"company": "Acme", "date": "7/12/2026", "count": "12", "percentage": "3%",
             "source": "https://example.com/layoff", "industry": "Tech"},
            {"company": "Acme", "date": "1/1/2018", "count": "1", "percentage": "",
             "source": "https://example.com/old", "industry": "Tech"},
            {"company": "Acme", "date": "not-a-date", "count": "2", "percentage": "",
             "source": "https://example.com/bad", "industry": "Tech"},
            {"company": "Acme", "date": "6/1/2024", "count": "3", "percentage": "",
             "source": "", "industry": "Tech"},
        ]}}
        hits = collect_seeds.table_rows_for(table, "Acme", [], WINDOW)
        self.assertEqual([h["exclusion_reason"] for h in hits],
                         ["", "outside_window", "unparseable_date", "no_source_link"])
        self.assertEqual([h["relevant"] for h in hits], [True, False, False, False])
        self.assertEqual(hits[0]["reported_date"], "2026-07-12")
        # R-17: an unparseable date is an empty reported_date plus a flag, never raw text.
        self.assertEqual(hits[2]["reported_date"], "")
        self.assertTrue(hits[2]["date_unparseable"])
        self.assertEqual(hits[2]["reported_date_raw"], "not-a-date")


class TheLayoffTests(unittest.TestCase):
    def test_html_load_ad_loader_is_not_a_challenge(self):
        self.assertIsNone(collect_seeds.CHALLENGE.search(FISKER_HTML[:6000]))
        self.assertIsNotNone(collect_seeds.CHALLENGE.search(CF_403_HTML[:6000]))

    def test_parse_thelayoff_reads_fisker_may_2024_post(self):
        hits = collect_seeds.parse_thelayoff(FISKER_HTML, "Fisker", WINDOW)
        self.assertEqual(len(hits), 1)
        hit = hits[0]
        self.assertEqual(hit["reported_date"], "2024-05-01")
        self.assertTrue(hit["relevant"])
        self.assertEqual(hit["exclusion_reason"], "")
        self.assertEqual(hit["url"], "https://www.thelayoff.com/t/1sjq1YWm")
        self.assertIn("Mass Layoffs", hit["title"])

    def test_parse_thelayoff_on_copied_fisker_capture_if_present(self):
        path = Path("/tmp/thelayoff-captures/fisker.html")
        if not path.is_file():
            self.skipTest("Fisker capture was not copied into /tmp")
        html = path.read_text(encoding="utf-8")
        self.assertIsNone(collect_seeds.CHALLENGE.search(html[:6000]))
        hits = collect_seeds.parse_thelayoff(html, "Fisker", WINDOW)
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0]["reported_date"], "2024-05-01")
        self.assertTrue(hits[0]["relevant"])
        self.assertIn("1sjq1YWm", hits[0]["url"])


class HostBlockTests(unittest.TestCase):
    def test_three_spaced_403s_block_remaining_companies_without_waiting_per_row(self):
        getter = mock.Mock(return_value=(403, CF_403_HTML))
        sleeper = mock.Mock()
        blocker = collect_seeds.HostBlocker(attempts=3, interval=600, sleeper=sleeper, getter=getter)
        self.assertTrue(blocker.confirm("www.trueup.io", "https://www.trueup.io/co/acme"))
        self.assertTrue(blocker.is_blocked("www.trueup.io"))
        # First failure is the attempt already observed; two more are spaced.
        self.assertEqual(getter.call_count, 2)
        self.assertEqual(sleeper.call_args_list, [mock.call(600), mock.call(600)])
        # A later company does not trigger more HTTP or sleep.
        getter.reset_mock()
        sleeper.reset_mock()
        self.assertTrue(blocker.confirm("www.trueup.io", "https://www.trueup.io/co/beta"))
        getter.assert_not_called()
        sleeper.assert_not_called()

    def test_a_later_success_does_not_mark_the_host_blocked(self):
        getter = mock.Mock(side_effect=[(200, "<html><body>ok</body></html>")])
        blocker = collect_seeds.HostBlocker(
            attempts=3, interval=0, sleeper=lambda _: None, getter=getter)
        self.assertFalse(blocker.confirm("www.trueup.io", "https://www.trueup.io/co/acme"))
        self.assertFalse(blocker.is_blocked("www.trueup.io"))

    def test_blocked_receipt_uses_existing_schema_and_persistent_reason(self):
        receipt = collect_seeds._receipt(
            {"task_id": "seed-1", "channel": "trueup"},
            "2026-11-13", "blocked",
            "TrueUp at https://www.trueup.io/co/acme returned a Cloudflare 403 "
            "or an empty render on 3 spaced attempts; the host is recorded as "
            "cloudflare_403_persistent.",
            "discovery/captures/seed/trueup/acme.html",
            [], {"completed": 0, "blocked": 0, "not_applicable": 0, "relevant": 0},
            __import__("threading").Lock(), [])
        receipt["reason"] = "cloudflare_403_persistent"
        self.assertEqual(receipt["outcome"], "blocked")
        self.assertEqual(receipt["hits"], [])
        self.assertEqual(receipt["reason"], "cloudflare_403_persistent")
        self.assertGreaterEqual(len(receipt["stop_basis"]), 15)

    def test_plain_get_does_not_use_a_proxy_or_rotate(self):
        response = mock.Mock(status_code=403, text=CF_403_HTML)
        with mock.patch("requests.get", return_value=response) as get:
            status, body = collect_seeds._plain_get("https://www.trueup.io/co/acme")
        self.assertEqual(status, 403)
        self.assertIn("Just a moment", body)
        kwargs = get.call_args.kwargs
        self.assertNotIn("proxies", kwargs)
        self.assertNotIn("proxy", kwargs)



def board_page(posts, next_page=None, slug="acme"):
    """Minimal TheLayoff board HTML with optional ul.pager li.next Older topics."""
    articles = []
    for title, reported, href in posts:
        articles.append(
            f'<article class="col-12 post topic">'
            f'<h2 class="post-title"><a href="{href}" class="thread-link">{title}</a></h2>'
            f'<div class="post-body"><p>{title}</p></div>'
            f'<footer class="meta"><span class="post-timeago">'
            f'<time datetime="{reported}T12:00:00Z">{reported}</time></span></footer>'
            f"</article>"
        )
    pager = ""
    if next_page is not None:
        pager = (
            f'<ul class="pager"><li class="next">'
            f'<a href="/{slug}?page={next_page}">Older topics'
            f'<span class="bi bi-chevron-bar-right"></span></a></li></ul>'
        )
    return (
        "<!DOCTYPE html><html><body><div id=\"posts\">"
        + "".join(articles)
        + f"</div>{pager}</body></html>"
    )


class TheLayoffPaginationTests(unittest.TestCase):
    start = "https://www.thelayoff.com/acme"
    pace = 0.15

    def sweep(self, pages, max_pages=None, later_error=None, raise_on=None,
              later_calls=None):
        sleeper = mock.Mock()
        fetched = []
        later_call_count = 0

        def fetch(url):
            nonlocal later_call_count
            fetched.append(url)
            number = 1
            if "page=" in url:
                number = int(url.rsplit("page=", 1)[-1])
            if later_calls is not None and number != 1:
                item = later_calls[later_call_count] if later_call_count < len(later_calls) else later_calls[-1]
                later_call_count += 1
                if item[0] == "raise":
                    raise item[1]
                return item[1], item[2]
            if raise_on is not None and url.endswith(f"page={raise_on}"):
                raise ConnectionError("later page failed")
            if later_error is not None and url.endswith(f"page={later_error[0]}"):
                return later_error[1], later_error[2]
            body = pages[number]
            return body, 200

        first = pages[1]
        kwargs = {}
        if max_pages is not None:
            kwargs["max_pages"] = max_pages
        hits, reviewed, condition, code, oldest, retries = collect_seeds.collect_thelayoff_pages(
            "Acme", WINDOW, self.start, first, fetch,
            sleeper=sleeper, pace=self.pace, **kwargs)
        return hits, reviewed, condition, code, oldest, retries, sleeper, fetched

    def import_thelayoff_status(self, hits, reviewed, condition, code, oldest,
                                capture_html, later_page_retries=0):
        """Real seed-import + seed-status on a tempfile workspace.

        Sibling channels are completed / not_applicable so the only possible
        gap is the thelayoff board under test.
        """
        from researchcore import seed_sweep
        fields = collect_seeds.thelayoff_window_sweep_fields(
            reviewed, condition, oldest, later_page_retries=later_page_retries)
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        work = Path(tmp.name)
        cfg = {
            "event_start": "2019-01-01",
            "event_end": "2026-11-13",
            "roster": [{"company_id": "acme", "company": "Acme"}],
        }
        seed_sweep.plan(work, cfg)
        tasks = json.loads((work / "discovery/seed-plan.json").read_text())["tasks"]
        capture = work / "seed-capture.html"
        capture.write_text(capture_html, encoding="utf-8")
        rows = []
        thelayoff_task = None
        for task in tasks:
            if task["channel"] == "thelayoff":
                thelayoff_task = task
                rows.append({
                    "task_id": task["task_id"],
                    "executed_at": "2026-11-13",
                    "outcome": collect_seeds.thelayoff_outcome(code),
                    "stop_basis": collect_seeds.thelayoff_stop_basis(
                        self.start, hits, reviewed, condition, code, oldest),
                    "result_path": "seed-capture.html",
                    "hits": hits,
                    **fields,
                })
            elif task["channel"] == "issuer_report":
                basis = ("No issuer registration or annual report is registered "
                         "for this company in the workspace, so the filing "
                         "channel does not apply.")
                rows.append({
                    "task_id": task["task_id"],
                    "executed_at": "2026-11-13",
                    "outcome": "not_applicable",
                    "stop_basis": basis,
                    "applicability_basis": basis,
                    "result_path": "seed-capture.html",
                    "hits": [],
                })
            else:
                rows.append({
                    "task_id": task["task_id"],
                    "executed_at": "2026-11-13",
                    "outcome": "completed",
                    "stop_basis": ("The tracker was inspected for this employer "
                                   "and no further board pages were required "
                                   "on this channel."),
                    "result_path": "seed-capture.html",
                    "hits": [],
                })
        batch = work / "seed-batch.json"
        batch.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
        imported = seed_sweep.import_receipts(work, cfg, batch)
        status = seed_sweep.status(work, cfg)
        archived = json.loads((work / "discovery/seed-receipts.json").read_text())
        stored = archived[thelayoff_task["task_id"]]
        return imported, status, stored

    def test_multi_page_follow_dedupes_and_paces(self):
        pages = {
            1: board_page([
                ("Acme announces layoffs in 2024", "2024-06-01", "/t/aaa"),
                ("Office snacks", "2024-05-01", "/t/bbb"),
            ], next_page=2),
            2: board_page([
                ("Office snacks", "2024-05-01", "/t/bbb"),  # overlap with page 1
                ("Acme cuts 50 jobs", "2023-03-15", "/t/ccc"),
            ], next_page=None),
        }
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(pages)
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_NO_NEXT)
        self.assertEqual(reviewed, 2)
        self.assertEqual([h["url"] for h in hits], [
            "https://www.thelayoff.com/t/aaa",
            "https://www.thelayoff.com/t/bbb",
            "https://www.thelayoff.com/t/ccc",
        ])
        self.assertEqual(fetched, ["https://www.thelayoff.com/acme?page=2"])
        sleeper.assert_called_once_with(self.pace)
        self.assertIn("no_next_page", condition)
        self.assertGreaterEqual(len(condition), 15)
        self.assertEqual(collect_seeds.next_thelayoff_url(pages[1], self.start),
                         "https://www.thelayoff.com/acme?page=2")
        self.assertEqual(collect_seeds.next_thelayoff_url(pages[2], self.start + "?page=2"), "")
        self.assertEqual(oldest, "2023-03-15")
        self.assertEqual(retries, 0)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "completed")
        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["outcome"], "completed")
        self.assertEqual(stored["oldest_post_date_reached"], "2023-03-15")
        self.assertEqual(stored["later_page_retries"], 0)
        self.assertEqual(stored["window_sweep"]["later_page_retries"], 0)
        self.assertEqual(stored["window_sweep"]["oldest_post_date_reached"], "2023-03-15")
        self.assertFalse(any(gap["channel"] == "thelayoff" for gap in status["gaps"]))
        self.assertTrue(status["pass"])
        self.assertTrue(imported["pass"])

    def test_stop_at_2019_window_boundary(self):
        pages = {
            1: board_page([
                ("Recent layoffs", "2020-04-30", "/t/r1"),
            ], next_page=2),
            2: board_page([
                ("Still in window", "2019-06-01", "/t/r2"),
                ("Before the window", "2018-12-15", "/t/r3"),
            ], next_page=3),
            3: board_page([
                ("Should not be fetched", "2017-01-01", "/t/r4"),
            ], next_page=None),
        }
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(pages)
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_WINDOW)
        self.assertEqual(reviewed, 2)
        self.assertEqual(fetched, ["https://www.thelayoff.com/acme?page=2"])
        self.assertEqual([h["url"] for h in hits], [
            "https://www.thelayoff.com/t/r1",
            "https://www.thelayoff.com/t/r2",
            "https://www.thelayoff.com/t/r3",
        ])
        self.assertEqual(hits[2]["exclusion_reason"], "outside_window")
        self.assertIn("window_boundary", condition)
        self.assertIn("2018-12-15", condition)
        self.assertIn("2019-01-01", condition)
        sleeper.assert_called_once_with(self.pace)
        self.assertEqual(oldest, "2018-12-15")
        self.assertEqual(retries, 0)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "completed")
        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["outcome"], "completed")
        self.assertEqual(stored["oldest_post_date_reached"], "2018-12-15")
        self.assertFalse(any(gap["channel"] == "thelayoff" for gap in status["gaps"]))
        self.assertTrue(status["pass"])
        self.assertTrue(imported["pass"])

    def test_stop_at_no_next_page(self):
        pages = {1: board_page([
            ("Fisker-style single page", "2024-05-01", "/t/one"),
        ], next_page=None)}
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(pages)
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_NO_NEXT)
        self.assertEqual(reviewed, 1)
        self.assertEqual(len(hits), 1)
        self.assertEqual(fetched, [])
        sleeper.assert_not_called()
        self.assertIn("no_next_page", condition)
        self.assertEqual(oldest, "2024-05-01")
        self.assertEqual(retries, 0)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "completed")
        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["outcome"], "completed")
        self.assertEqual(stored["oldest_post_date_reached"], "2024-05-01")
        self.assertFalse(any(gap["channel"] == "thelayoff" for gap in status["gaps"]))
        self.assertTrue(status["pass"])

    def test_stop_at_page_cap(self):
        pages = {
            1: board_page([("Page one layoffs", "2026-11-01", "/t/p1")], next_page=2),
            2: board_page([("Page two layoffs", "2026-10-01", "/t/p2")], next_page=3),
            3: board_page([("Page three should not load", "2026-09-01", "/t/p3")], next_page=4),
        }
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(pages, max_pages=2)
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_CAP)
        self.assertEqual(reviewed, 2)
        self.assertEqual(fetched, ["https://www.thelayoff.com/acme?page=2"])
        self.assertEqual([h["url"] for h in hits], [
            "https://www.thelayoff.com/t/p1",
            "https://www.thelayoff.com/t/p2",
        ])
        self.assertIn("page_cap", condition)
        self.assertIn("thelayoff-max-pages=2", condition)
        sleeper.assert_called_once_with(self.pace)
        self.assertEqual(oldest, "2026-10-01")
        self.assertGreaterEqual(oldest, "2019-01-01")
        self.assertEqual(retries, 0)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "partial")
        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["outcome"], "partial")
        self.assertEqual(stored["pages_reviewed"], 2)
        self.assertEqual(stored["oldest_post_date_reached"], "2026-10-01")
        self.assertEqual(stored["window_sweep"]["pages_reviewed"], 2)
        self.assertEqual(stored["window_sweep"]["oldest_post_date_reached"], "2026-10-01")
        self.assertIn("page_cap", stored["stop_condition"])
        self.assertFalse(status["pass"])
        self.assertEqual(
            [gap["reason"] for gap in status["gaps"] if gap["channel"] == "thelayoff"],
            ["seed_partial"])
        self.assertFalse(imported["pass"])

    def test_later_page_error_keeps_earlier_hits(self):
        pages = {
            1: board_page([("Kept layoffs from page 1", "2024-05-01", "/t/keep")], next_page=2),
            2: board_page([("Unreachable", "2023-01-01", "/t/lost")], next_page=None),
        }
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(
            pages, later_error=(2, "", 503))
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_PARTIAL)
        self.assertEqual(reviewed, 1)
        self.assertEqual([h["url"] for h in hits], ["https://www.thelayoff.com/t/keep"])
        self.assertEqual(fetched, ["https://www.thelayoff.com/acme?page=2"] * 3)
        self.assertEqual(retries, 2)
        self.assertIn("later_page_error", condition)
        self.assertIn("HTTP 503", condition)
        self.assertIn("kept", condition.lower())
        sleeper.assert_has_calls([mock.call(self.pace), mock.call(5.0), mock.call(15.0)])
        # A raised transport error is retried the same way, then stays partial.
        hits2, reviewed2, condition2, code2, oldest2, retries2, _, fetched2 = self.sweep(pages, raise_on=2)
        self.assertEqual(code2, collect_seeds.THELAYOFF_STOP_PARTIAL)
        self.assertEqual(reviewed2, 1)
        self.assertEqual(len(hits2), 1)
        self.assertEqual(retries2, 2)
        self.assertEqual(fetched2, ["https://www.thelayoff.com/acme?page=2"] * 3)
        self.assertIn("ConnectionError", condition2)
        self.assertEqual(oldest, "2024-05-01")
        self.assertGreaterEqual(oldest, "2019-01-01")
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "partial")
        self.assertEqual(collect_seeds.thelayoff_outcome(code2), "partial")
        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["outcome"], "partial")
        self.assertEqual(len(stored["hits"]), 1)
        self.assertEqual(stored["oldest_post_date_reached"], "2024-05-01")
        self.assertEqual(stored["later_page_retries"], 2)
        self.assertEqual(stored["window_sweep"]["later_page_retries"], 2)
        self.assertFalse(status["pass"])
        self.assertEqual(
            [gap["reason"] for gap in status["gaps"] if gap["channel"] == "thelayoff"],
            ["seed_partial"])
        self.assertFalse(imported["pass"])

    def test_later_page_cloudflare_or_403_is_blocked_with_hits(self):
        pages = {
            1: board_page([("Kept layoffs from page 1", "2024-05-01", "/t/keep")], next_page=2),
            2: board_page([("Unreachable", "2023-01-01", "/t/lost")], next_page=None),
        }
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(
            pages, later_error=(2, CF_403_HTML, 403))
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_CF)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "blocked")
        self.assertEqual(reviewed, 1)
        self.assertEqual(retries, 0)
        self.assertEqual([h["url"] for h in hits], ["https://www.thelayoff.com/t/keep"])
        self.assertEqual(fetched, ["https://www.thelayoff.com/acme?page=2"])
        sleeper.assert_called_once_with(self.pace)
        self.assertIn("cloudflare_403_later_page", condition)
        basis = collect_seeds.thelayoff_stop_basis(
            self.start, hits, reviewed, condition, code, oldest)
        self.assertIn("cloudflare_403_later_page", basis)
        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["outcome"], "blocked")
        self.assertEqual(len(stored["hits"]), 1)
        self.assertTrue(stored["hits"][0]["relevant"])
        self.assertEqual(stored["later_page_retries"], 0)
        self.assertIn("cloudflare_403_later_page", stored["stop_basis"])
        self.assertEqual(stored["oldest_post_date_reached"], "2024-05-01")
        self.assertFalse(status["pass"])
        self.assertEqual(
            [gap["reason"] for gap in status["gaps"] if gap["channel"] == "thelayoff"],
            ["seed_blocked"])
        # A 200 challenge page is the same blocked later-page refusal.
        hits2, reviewed2, condition2, code2, oldest2, retries2, _, fetched2 = self.sweep(
            pages, later_error=(2, CF_403_HTML, 200))
        self.assertEqual(code2, collect_seeds.THELAYOFF_STOP_CF)
        self.assertEqual(collect_seeds.thelayoff_outcome(code2), "blocked")
        self.assertEqual(len(hits2), 1)
        self.assertEqual(retries2, 0)
        self.assertEqual(fetched2, ["https://www.thelayoff.com/acme?page=2"])
        self.assertIn("cloudflare_403_later_page", condition2)

    def test_later_page_5xx_then_success_continues_the_sweep(self):
        pages = {
            1: board_page([("Page one layoffs", "2024-06-01", "/t/p1")], next_page=2),
            2: board_page([("Page two layoffs", "2023-03-15", "/t/p2")], next_page=None),
        }
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(
            pages, later_calls=[("return", "", 503), ("return", pages[2], 200)])
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_NO_NEXT)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "completed")
        self.assertEqual(reviewed, 2)
        self.assertEqual(retries, 1)
        self.assertEqual([h["url"] for h in hits], [
            "https://www.thelayoff.com/t/p1",
            "https://www.thelayoff.com/t/p2",
        ])
        self.assertEqual(fetched, ["https://www.thelayoff.com/acme?page=2"] * 2)
        sleeper.assert_has_calls([mock.call(self.pace), mock.call(5.0)])
        self.assertEqual([c.args[0] for c in sleeper.call_args_list], [self.pace, 5.0])
        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["outcome"], "completed")
        self.assertEqual(stored["later_page_retries"], 1)
        self.assertEqual(stored["window_sweep"]["later_page_retries"], 1)
        self.assertTrue(status["pass"])

    def test_later_page_timeout_x3_ends_partial_with_two_retries(self):
        pages = {
            1: board_page([("Kept layoffs from page 1", "2024-05-01", "/t/keep")], next_page=2),
            2: board_page([("Unreachable", "2023-01-01", "/t/lost")], next_page=None),
        }
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(
            pages, later_calls=[("raise", TimeoutError("timed out"))] * 3)
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_PARTIAL)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "partial")
        self.assertEqual(reviewed, 1)
        self.assertEqual(retries, 2)
        self.assertEqual(len(hits), 1)
        self.assertEqual(fetched, ["https://www.thelayoff.com/acme?page=2"] * 3)
        sleeper.assert_has_calls([mock.call(self.pace), mock.call(5.0), mock.call(15.0)])
        self.assertEqual([c.args[0] for c in sleeper.call_args_list], [self.pace, 5.0, 15.0])
        self.assertIn("TimeoutError", condition)
        self.assertIn("2 retries", condition)
        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["outcome"], "partial")
        self.assertEqual(stored["later_page_retries"], 2)
        self.assertEqual(stored["window_sweep"]["later_page_retries"], 2)
        self.assertEqual(
            [gap["reason"] for gap in status["gaps"] if gap["channel"] == "thelayoff"],
            ["seed_partial"])

    def test_default_cap_is_150(self):
        self.assertEqual(collect_seeds.THELAYOFF_MAX_PAGES, 150)
        self.assertEqual(collect_seeds.parse_thelayoff_backoff(None), (5.0, 15.0))
        pages = {}
        # 151 in-window pages would be needed to hit the default cap.
        def page(number):
            nxt = number + 1 if number < 151 else None
            return board_page(
                [(f"Acme page {number} layoffs", "2026-01-01", f"/t/p{number}")],
                next_page=nxt)
        for number in range(1, 152):
            pages[number] = page(number)
        hits, reviewed, condition, code, oldest, retries, sleeper, fetched = self.sweep(pages)
        self.assertEqual(code, collect_seeds.THELAYOFF_STOP_CAP)
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "partial")
        self.assertEqual(reviewed, 150)
        self.assertEqual(len(hits), 150)
        self.assertEqual(len(fetched), 149)
        self.assertIn("thelayoff-max-pages=150", condition)
        self.assertEqual(retries, 0)

    def test_receipt_window_sweep_fields_validate_with_seed_import(self):
        pages = {1: board_page([
            ("Acme announces mass layoffs", "2024-05-01", "/t/1sjq1YWm"),
        ], next_page=None)}
        hits, reviewed, condition, code, oldest, retries, _, _ = self.sweep(pages)
        fields = collect_seeds.thelayoff_window_sweep_fields(
            reviewed, condition, oldest, later_page_retries=retries)
        self.assertEqual(fields["search_scope"], "window_sweep")
        self.assertEqual(fields["pages_reviewed"], 1)
        self.assertIsInstance(fields["pages_reviewed"], int)
        self.assertGreaterEqual(fields["pages_reviewed"], 0)
        self.assertGreaterEqual(len(fields["stop_condition"]), 15)
        self.assertEqual(fields["oldest_post_date_reached"], "2024-05-01")
        self.assertEqual(fields["later_page_retries"], 0)
        self.assertEqual(fields["window_sweep"]["pages_reviewed"], 1)
        self.assertEqual(fields["window_sweep"]["later_page_retries"], 0)
        self.assertEqual(fields["window_sweep"]["stop_condition"], condition)
        self.assertEqual(fields["window_sweep"]["oldest_post_date_reached"], "2024-05-01")
        self.assertIn("no_next_page", fields["stop_condition"])
        self.assertEqual(collect_seeds.thelayoff_outcome(code), "completed")

        imported, status, stored = self.import_thelayoff_status(
            hits, reviewed, condition, code, oldest, pages[1], later_page_retries=retries)
        self.assertEqual(stored["pages_reviewed"], 1)
        self.assertEqual(stored["later_page_retries"], 0)
        self.assertEqual(stored["search_scope"], "window_sweep")
        self.assertEqual(stored["stop_condition"], condition)
        self.assertEqual(stored["oldest_post_date_reached"], "2024-05-01")
        self.assertEqual(stored["window_sweep"]["pages_reviewed"], 1)
        self.assertEqual(stored["window_sweep"]["stop_condition"], condition)
        self.assertEqual(stored["window_sweep"]["oldest_post_date_reached"], "2024-05-01")
        self.assertEqual(stored["outcome"], "completed")
        self.assertEqual(len(stored["hits"]), 1)
        self.assertIn("receipt_sha256", stored)
        self.assertTrue(imported["pass"])
        self.assertTrue(status["pass"])



class PlainGetHeaderTests(unittest.TestCase):
    def test_plain_get_sends_skill_user_agent(self):
        from researchcore.egress import UA
        fake = mock.Mock(status_code=200, text="ok")
        with mock.patch("requests.get", return_value=fake) as get:
            status, body = collect_seeds._plain_get("https://www.thelayoff.com/google")
        self.assertEqual((status, body), (200, "ok"))
        headers = get.call_args.kwargs["headers"]
        self.assertEqual(headers["User-Agent"], UA)
        self.assertNotIn("python-requests", headers["User-Agent"])


if __name__ == "__main__":
    unittest.main()
