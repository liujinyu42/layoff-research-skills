"""Execute planned Stage-2 searches and emit runtime-compliant receipts.

The runtime plans every company/year query family and every seed-verification
query. This executor runs those planned queries, saves each raw result inside
the workspace, inspects every returned hit, and writes a batch file that
`discovery-import` accepts without hand-editing.

Why this lives in the skill: the previous collection round was driven by
throwaway scripts outside the package, so nothing about the search procedure
was reproducible. This module makes the search step repeatable and keeps the
receipt contract (planned query preserved, raw capture archived, every hit
inspected with a relevance verdict and, when irrelevant, an exclusion reason)
in one auditable place.

Usage:

    python "$S/scripts/collect_discovery.py" --work "$W" --out "$W/discovery/google-batch.json"
    python "$S/scripts/collect_discovery.py" --work "$W" --out ... --engine bing
    python "$S/scripts/collect_discovery.py" --work "$W" --out ... --only-company <id>
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime as dt
import hashlib
import json
import os
import re
import sys
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from researchcore.egress import Egress  # noqa: E402
from researchcore.discovery import candidate_id  # noqa: E402

GNEWS = ("https://news.google.com/rss/search?q={q}&hl=en-US&gl=US&ceid=US:en")
BING = "https://www.bing.com/news/search?q={q}&format=RSS"

# Reduction vocabulary. A hit must combine an employer mention with a
# reduction action; a bare keyword match is the noise source that produced
# "here are the layoffs", "North Sea" and "Sea of Thieves" false positives.
REDUCE = re.compile(
    r"\b(lay(?:ing|s|ed)?[\s-]?offs?|job\s+cuts?|cuts?\s+(?:jobs?|staff|roles?|positions?)|"
    r"workforce\s+reduction(?:s)?|redundan(?:cies|cy|t)|downsiz(?:e|ed|ing)|"
    r"eliminat(?:e|ed|ing)\s+(?:\w+\s+){0,3}(?:positions|jobs|roles)|"
    r"shed(?:ding)?\s+\w+\s+jobs|trim(?:ming)?\s+(?:the\s+)?(?:workforce|headcount|staff)|"
    r"cut(?:s|ting)?\s+\w+\s+(?:jobs|roles|positions)|"
    r"restructur(?:e|ing|al)|headcount\s+reduction|"
    r"slash(?:es|ed|ing)\s+(?:jobs|positions)|"
    r"staff\s+cuts?|job\s+loss(?:es)?|voluntary\s+separation(?:s)?)",
    re.I)

# Common English words that are also company names in a public roster. A hit on
# one of these must contain the full legal or brand form, otherwise it is noise.
GENERIC_NAMES = {
    "on", "here", "sea", "box", "plan", "cloud", "surface", "signal", "block",
    "stripe", "notion", "figma", "quora", "medium", "arc", "meta", "apple",
    "amazon", "google", "air", "arm", "base", "beam", "bit", "bloom", "bright",
    "care", "cash", "cast", "chair", "class", "core", "craft", "deck", "desk",
    "drift", "field", "found", "frame", "front", "gate", "grid", "health",
    "hidden", "hour", "house", "hub", "human", "image", "index", "input",
    "joy", "key", "last", "lead", "level", "light", "line", "link", "list",
    "live", "load", "lock", "loop", "main", "map", "mark", "mind", "mode",
    "model", "moon", "move", "native", "nest", "note", "north", "novel",
    "open", "orbit", "outpost", "page", "panel", "partner", "path", "peak",
    "pilot", "pioneer", "point", "press", "prism", "pro", "quill", "range",
    "reach", "realm", "reel", "render", "ridge", "river", "roam", "root",
    "scale", "scene", "scope", "scribe", "sense", "serve", "shade", "shift",
    "shore", "signal", "sky", "slate", "snap", "solid", "space", "span", "spark",
    "spoke", "stack", "stage", "stamp", "state", "steel", "stone", "store",
    "storm", "story", "street", "strike", "studio", "survey", "switch", "tally",
    "team", "tempo", "thread", "tide", "tile", "timer", "tone", "trace", "track",
    "trail", "trend", "trip", "vault", "vector", "vertex", "vessel", "view",
    "village", "vine", "voice", "volume", "wave", "waypoint", "weave", "well",
    "wheel", "wing", "wire", "wise", "world", "yard", "zen",
}

# A generic name only counts when the article names the company in a form that
# disambiguates it: the full brand plus a corporate marker, or an official
# domain mention.
CORPORATE_MARKER = re.compile(
    r"\b(inc|inc\.|corp|corp\.|ltd|ltd\.|llc|l\.l\.c\.|plc|gmbh|s\.a\.|"
    r"company|corporation|holdings|group|labs?|technologies|limited)\b", re.I)


def normalise_company(name):
    return re.sub(r"[^a-z0-9]+", " ", str(name or "").lower()).strip()


def is_generic(name):
    key = normalise_company(name)
    if key in GENERIC_NAMES:
        return True
    return len(key) <= 2


def strip_publisher_suffix(title, publisher=""):
    """The headline without the publisher's trailing name.

    A feed names the publisher at the end of the headline, separated by a
    dash: "Salesforce layoffs hit Customer Success - TechTarget". When the
    company being looked for is called TechTarget, that trailing name is the
    publisher and not the subject of the article, and reading it as a
    mention turns every story the publisher ran into a story about the
    company.
    """
    text = title or ""
    if publisher:
        stripped = re.sub(r"\s*[\-–—|]\s*" + re.escape(publisher) + r"\s*$", "", text,
                          flags=re.I)
        if stripped.strip():
            return stripped.strip()
    # A trailing name after the last dash is a publisher's name even when
    # the feed does not say who the publisher is.
    parts = re.split(r"\s*[\-–—]\s*", text)
    if len(parts) > 1 and len(parts[-1].split()) <= 4:
        return " - ".join(parts[:-1]).strip()
    return text.strip()


def employer_mentioned(title, aliases, generic, publisher=""):
    """Decide whether a hit really concerns the company, not a common word.

    For a distinctive company name, a plain mention is enough. For a generic
    name the article must carry a corporate marker or the company must appear
    with a possessive/employer construction, otherwise "here are the layoffs"
    and "North Sea" slip through.

    The publisher's trailing name is removed before the company is looked
    for, so a company that shares its name with the publisher is not matched
    by the publisher's own byline.
    """
    text = strip_publisher_suffix(title, publisher)
    low = text.lower()
    hit = None
    for alias in aliases:
        if alias and normalise_company(alias) and normalise_company(alias) in normalise_company(low):
            hit = alias
            break
    if hit is None:
        return False, "company name absent from the headline"
    if not generic:
        return True, ""
    if CORPORATE_MARKER.search(text):
        return True, ""
    if re.search(re.escape(hit.lower()) + r"('s|s')\b", low):
        return True, ""
    return False, "generic company name without a corporate marker in the headline"


def hit_relevant(title, aliases, generic, publisher="", reported_date="",
                 window_start="", window_end=""):
    """A relevant hit names the employer and states a workforce reduction.

    A hit outside the event window is not relevant: the sweep asks about a
    period, and an article about a reduction that happened outside it
    answers a different question.
    """
    if reported_date and window_start and window_end:
        if not (window_start <= reported_date <= window_end):
            return False, "the article was reported outside the event window"
    headline = strip_publisher_suffix(title or "", publisher)
    action = REDUCE.search(headline) or re.search(
        r"\b(?:outsourc\w*|offshor\w*|restructur\w*|redundan\w*|shift\w* (?:some )?roles|clos\w* (?:a |its )?(?:plant|office|facility))\b",
        headline, re.I)
    if not action:
        return False, "no workforce-reduction action stated in the headline"
    # Discovery admission is not employer attribution. Match whole aliases,
    # then resolve ambiguous names and affected workers in the article body.
    if not any(a.strip() and re.search(r"(?<!\w)" + re.escape(a.strip()) + r"(?!\w)", headline, re.I) for a in aliases):
        return False, "company name absent from the headline"
    return True, ""


def parse_rss(xml_text):
    items = []
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return items
    for node in root.iter("item"):
        def field(name):
            child = node.find(name)
            return (child.text or "").strip() if child is not None and child.text else ""
        link = field("link")
        if not link:
            for guid in node.iter("guid"):
                if guid.text and guid.text.startswith("http"):
                    link = guid.text.strip()
                    break
        source = ""
        source_url = ""
        # The source element carries both the publisher's display name and the
        # publisher's own domain. The domain matters: an aggregator link
        # cannot be decoded to the article, but the domain plus the title
        # locates the article on the publisher's site.
        for src in node.iter("source"):
            if src.text:
                source = src.text.strip()
            if src.get("url"):
                source_url = src.get("url")
            break
        pub = field("pubDate")
        items.append({"title": field("title"), "link": link, "source": source,
                      "source_url": source_url, "pub": pub,
                      "description": field("description")})
    return items


def iso_date(pub):
    for fmt in ("%a, %d %b %Y %H:%M:%S %Z", "%a, %d %b %Y %H:%M:%S %z",
                "%d %b %Y %H:%M:%S %Z", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(pub, fmt).date().isoformat()
        except Exception:  # noqa: BLE001
            continue
    return ""


def canonical(url):
    """Resolve a Google News redirect to its publisher URL when possible."""
    if not url:
        return ""
    match = re.search(r"[?&]url=([^&]+)", url)
    if match:
        return urllib.parse.unquote(match.group(1))
    return url


def cache_key(query, engine):
    return hashlib.sha1(f"{engine}\n{query}".encode("utf-8")).hexdigest()


def run_query(egress, query, engine="gnews", timeout_note="", cache_dir=None,
              cache_days=30):
    """Execute one planned query; returns (raw_text, items, engine_used).

    A feed that answered with a well-formed document but no items is a
    completed search that found nothing, and it is reported as such. Only a
    refusal — a non-200 status, a refusal body, or an unreachable endpoint —
    yields no result page at all. Conflating the two once caused 2715
    zero-result queries to be recorded as blocked, which hid a query-syntax
    fault behind a network excuse and left the real coverage gap invisible.

    A successful answer is cached by engine and query. Re-running a sweep after
    a lost receipt, or re-importing a corrected window, reuses the captured
    answer instead of asking the feed the same question again. Refusals are
    never cached.
    """
    engines = [engine] if engine != "auto" else ["gnews", "bing"]
    last = None
    for name in engines:
        path = None
        if cache_dir is not None and cache_days > 0:
            path = Path(cache_dir) / f"{cache_key(query, name)}.xml"
            try:
                age = time.time() - path.stat().st_mtime
                if age <= cache_days * 86400:
                    cached = path.read_text(encoding="utf-8")
                    root = ET.fromstring(cached)
                    if root.tag == "rss" and root.find("channel") is not None:
                        return cached, parse_rss(cached), name
            except (OSError, ET.ParseError):
                pass
        template = GNEWS if name == "gnews" else BING
        url = template.format(q=urllib.parse.quote_plus(query))
        try:
            response = egress.get(url)
        except Exception as exc:  # noqa: BLE001
            last = f"{name}:{type(exc).__name__}"
            continue
        if response is None:
            last = f"{name}:no_response"
            continue
        if response.status_code != 200:
            last = f"{name}:http_{response.status_code}"
            continue
        try:
            root = ET.fromstring(response.text)
        except ET.ParseError:
            last = f"{name}:invalid_rss"
            continue
        if root.tag != "rss" or root.find("channel") is None:
            last = f"{name}:invalid_rss"
            continue
        items = parse_rss(response.text)
        if path is not None:
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(response.text, encoding="utf-8")
            except OSError:
                pass
        # An answered feed is an answer, including an empty one.
        return response.text, items, name
    return None, [], last or "no_engine"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--engine", default="auto", choices=["auto", "gnews", "bing"])
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--pace", type=float, default=0.12)
    parser.add_argument("--only-company", default="")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--resume", action="store_true", default=True)
    parser.add_argument("--no-resume", dest="resume", action="store_false")
    parser.add_argument("--no-resolve", dest="resolve", action="store_false", default=True)
    parser.add_argument("--retry-blocked", action="store_true",
                        help="Re-run tasks whose previous receipt was blocked. A blocked "
                             "receipt records a refusal, not a completed search, so those "
                             "tasks have no result page and are worth retrying once the "
                             "exit address or the query has changed.")
    parser.add_argument("--proxy", default=os.environ.get("LAYOFF_EGRESS_PROXY", ""),
                        help="Route requests through this proxy (for example the sing-box "
                             "SOCKS5 inbound) so that node rotation changes the exit address.")
    parser.add_argument("--block-wait", type=float, default=120.0,
                        help="Seconds to wait after the endpoint refuses before the next "
                             "attempt. A refusal is an exit-level throttle, so the run "
                             "continues on its own instead of failing the round.")
    parser.add_argument("--cache-days", type=float, default=30.0,
                        help="Reuse a captured feed answer for this many days. A cached "
                             "answer is reused only while the capture still parses.")
    parser.add_argument("--no-cache", dest="cache", action="store_false", default=True,
                        help="Ignore and do not write the search-answer cache.")
    parser.add_argument("--direct", action="store_true",
                        help="Use direct connections with pacing and no exit rotation.")
    args = parser.parse_args()
    if args.direct and args.proxy:
        parser.error("--direct cannot be combined with a proxy")

    work = Path(args.work).resolve()
    plan_path = work / "discovery/plan.json"
    if not plan_path.is_file():
        raise SystemExit("Run discovery-plan first; this executor does not invent queries.")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    tasks = plan["tasks"]
    # A query is scoped to one year so that the search engine returns results
    # for that year; the *event* window is global. Judging a hit against the
    # query's own year silently drops a 2024 article returned for a 2019 query,
    # and news feeds routinely ignore the year in the query at all.
    global_window = (str(plan.get("window_start") or ""), str(plan.get("window_end") or ""))
    if args.only_company:
        tasks = [t for t in tasks if t["company_id"] == args.only_company]
    if args.limit:
        tasks = tasks[:args.limit]

    receipts_path = work / "discovery/receipts.json"
    done = {}
    if args.resume and receipts_path.is_file():
        done = json.loads(receipts_path.read_text(encoding="utf-8"))
    checkpoint = []
    if args.resume and Path(args.out).is_file():
        checkpoint = json.loads(Path(args.out).read_text(encoding="utf-8"))
        done.update({r["task_id"]: r for r in checkpoint})
    if args.retry_blocked:
        # Keep the receipt file intact; only the task list changes.
        skipped = [tid for tid, receipt in done.items()
                   if str(receipt.get("outcome")) == "blocked"]
        for tid in skipped:
            done.pop(tid, None)
        if skipped:
            print(f"retrying {len(skipped)} previously blocked task(s)", flush=True)
    tasks = [t for t in tasks if t["task_id"] not in done]
    if not tasks:
        print("nothing to execute; all planned tasks already have receipts")
        return 0

    capture_dir = work / "discovery/captures/search"
    capture_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = work / "discovery/cache/search"
    probe_url = GNEWS.format(q=urllib.parse.quote_plus("layoffs"))
    egress = Egress(floor=args.pace, proxy=args.proxy or None,
                    log=work / "discovery/captures/access/vpn-nodes.json",
                    probe_url=probe_url)
    if args.direct:
        egress.proxy = ""
        egress.allow_rotation = False
    # The exit is checked before the sweep starts. A run that begins on a
    # refused address spends its first minutes discovering that, and every
    # one of those minutes is a minute the sweep does not run.
    if args.direct and not egress.probe_once(probe_url):
        raise SystemExit("The direct Google News probe did not return a readable response.")
    if not args.direct and not egress.probe_once(probe_url):
        print("the exit address does not answer; moving to another one", flush=True)
        egress.rotate(probe_url=probe_url)
    lock = threading.Lock()
    checkpoint_by_id = {r["task_id"]: r for r in checkpoint}
    batch = []
    stats = {"completed": 0, "blocked": 0, "partial": 0, "hits": 0, "relevant": 0}
    blocked_until = [0.0]

    def execute(task):
        query = task["query"]
        # Before the first attempt, honour a cooling period left by an earlier
        # refusal so the whole pool pauses together instead of each worker
        # discovering the refusal on its own.
        cooldown = blocked_until[0] - time.time()
        if cooldown > 0:
            time.sleep(min(cooldown, 900))
        raw, items, engine_used = run_query(
            egress, query, args.engine,
            cache_dir=cache_dir if args.cache else None,
            cache_days=args.cache_days)
        stamp = dt.datetime.now().strftime("%Y%m%dT%H%M%S")
        name = f"{task['task_id']}-{stamp}.xml"
        path = capture_dir / name
        if raw is not None:
            path.write_text(raw, encoding="utf-8")
        else:
            # A blocked query still gets a capture so the receipt records what
            # was actually returned rather than an empty placeholder.
            path.write_text(f"<!-- unavailable: {engine_used} -->\n", encoding="utf-8")
        relative = str(path.relative_to(work))

        hits = []
        seen = set()
        for item in items:
            url = canonical(item["link"])
            if not url or url in seen:
                continue
            seen.add(url)
            aliases = task.get("aliases") or [task["company"]]
            generic = any(is_generic(a) for a in aliases)
            published = item.get("source", "")
            reported = iso_date(item.get("pub", ""))
            relevant, reason = hit_relevant(
                item["title"], aliases, generic, publisher=published,
                reported_date=reported,
                window_start=global_window[0] or task.get("window_start", ""),
                window_end=global_window[1] or task.get("window_end", ""))
            hits.append({
                "url": url,
                "title": item["title"],
                "relevant": bool(relevant),
                "exclusion_reason": "" if relevant else reason,
                "publisher": published,
                "publisher_url": item.get("source_url", ""),
                "reported_date": reported,
                # A year-scoped query is a search device. The receipt records
                # that the hit was judged against the global event window, and
                # keeps the query year so a feed that ignores it is visible.
                "window_basis": "global",
                "query_year": task.get("year", ""),
                # The candidate identity belongs in the receipt itself, so
                # that a receipt written by the executor is as complete as
                # one written by the importer.
                "candidate_id": candidate_id(task["company_id"], url),
            })
        # A year-scoped query assumes the feed respects the year. When most of
        # the dated results fall outside it, the same recent articles would
        # otherwise be counted as coverage of every historical year.
        query_year = str(task.get("year") or "")
        dated = [hit["reported_date"] for hit in hits if hit["reported_date"]]
        time_range_reliable = True
        if query_year and len(dated) >= 3:
            outside = sum(1 for day in dated if day[:4] != query_year)
            time_range_reliable = outside * 5 < len(dated) * 3
        for hit in hits:
            hit["time_range_reliable"] = time_range_reliable
        if raw is None:
            outcome = "blocked"
            stop_basis = (f"The search endpoint refused the request on every attempted engine "
                          f"({engine_used}); no result page was returned for this planned query.")
            # A refusal is an exit-level throttle. Hold every worker until the
            # address cools down instead of burning the remaining tasks against
            # a refused endpoint; the round then continues on its own.
            with lock:
                until = time.time() + args.block_wait
                if until > blocked_until[0]:
                    blocked_until[0] = until
        elif not items:
            outcome = "completed"
            stop_basis = (f"The planned query executed through {engine_used} and the feed answered "
                          f"with a well-formed document containing zero results; a zero-result query "
                          f"is a completed search, not an unexecuted one.")
        else:
            outcome = "completed"
            stop_basis = (f"The planned query executed through {engine_used} and every returned "
                          f"result was inspected for relevance; the feed returned "
                          f"{len(items)} result(s) with no further pages offered.")
            if not time_range_reliable:
                stop_basis += (f" Most dated results fall outside {query_year}, so this receipt "
                               f"does not establish coverage of that year.")
        receipt = {
            "task_id": task["task_id"],
            "query": query,
            # The scope binds the receipt to the plan entry it answers, so a
            # receipt cannot be moved to a different question and still pass.
            "scope_sha256": task.get("scope_sha256", ""),
            "company_id": task.get("company_id", ""),
            "company": task.get("company", ""),
            "family": task.get("family", ""),
            "term": task.get("term", ""),
            "executed_at": dt.date.today().isoformat(),
            "outcome": outcome,
            "stop_basis": stop_basis,
            "query_year": query_year,
            "time_range_reliable": time_range_reliable,
            "result_path": relative,
            "hits": hits,
        }
        with lock:
            batch.append(receipt)
            stats[outcome] = stats.get(outcome, 0) + 1
            stats["hits"] += len(hits)
            stats["relevant"] += sum(1 for h in hits if h["relevant"])
            if len(batch) % 250 == 0:
                checkpoint_by_id.update((r["task_id"], r) for r in batch[-250:])
                _flush(work, args.out, list(checkpoint_by_id.values()))
                print(f"{len(batch)}/{len(tasks)} executed | "
                      f"blocked {stats['blocked']} | relevant hits {stats['relevant']}",
                      flush=True)
        return receipt

    print(f"executing {len(tasks)} planned queries via {args.engine} "
          f"({args.workers} workers, pace {args.pace}s)", flush=True)
    with cf.ThreadPoolExecutor(args.workers) as pool:
        futures = [pool.submit(execute, task) for task in tasks]
        receipts = [future.result() for future in cf.as_completed(futures)]

    # A task that was refused may be answered after the cooling period. Give
    # those tasks one more attempt before they are filed as blocked, so a
    # temporary throttle does not become a permanent coverage gap.
    refused = [r for r in receipts if r.get("outcome") == "blocked"]
    if refused and args.block_wait > 0:
        print(f"{len(refused)} task(s) were refused; waiting {args.block_wait:.0f}s "
              f"and retrying them once", flush=True)
        by_id = {t["task_id"]: t for t in tasks}
        with cf.ThreadPoolExecutor(max(1, min(args.workers, 4))) as pool:
            retried = list(pool.map(lambda r: execute(by_id[r["task_id"]]), refused))
        # The retry supersedes the earlier attempt for the same task.
        newest = {r["task_id"]: r for r in receipts}
        newest.update({r["task_id"]: r for r in retried})
        receipts = list(newest.values())

    # Keep one receipt per task, preferring the newest revision.
    by_task = checkpoint_by_id
    for r in receipts:
        by_task[r["task_id"]] = r
    batch = list(by_task.values())
    _flush(work, args.out, batch)
    final = {"completed": 0, "blocked": 0, "partial": 0, "hits": 0, "relevant": 0}
    for r in batch:
        final[r["outcome"]] = final.get(r["outcome"], 0) + 1
        final["hits"] += len(r.get("hits", []))
        final["relevant"] += sum(1 for h in r.get("hits", []) if h.get("relevant"))
    print(json.dumps(final, ensure_ascii=False))
    if args.direct:
        print("Direct transport; no exit rotation.")
    else:
        print("egress:", json.dumps(egress.status(), ensure_ascii=False))
    return 0


def _flush(work, out, batch):
    path = Path(out)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(batch, ensure_ascii=False, indent=1), encoding="utf-8")
    temporary.replace(path)


if __name__ == "__main__":
    raise SystemExit(main())
