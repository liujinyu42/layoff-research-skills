"""Regressions for the exit rotation that could not leave a refused address.

Nodes of one region share one egress address, so a rotation that only moves
between the named nodes of the selected group keeps hitting the same refused
address. The rotation therefore has to reach past the region that produced
the refusal.

Two defects made that impossible:

* The candidate filter rejected every candidate as soon as any address was
  known to be refused, so the loop always returned nothing and the rotation
  fell back to the first candidate — the region it was already in.
* Nothing recorded which region had produced a refusal, so the region could
  not be excluded from the next candidate pool.
"""
import unittest

from researchcore.egress import Egress


PROXIES = {
    "节点选择": {
        "type": "Selector",
        "now": "香港1|BGP|0.4X",
        "all": ["香港1|BGP|0.4X", "香港2|BGP|0.4X", "台湾1|BGP|0.4X",
                "台湾2|BGP|0.4X", "美国1|BGP|0.4X", "美国2|BGP|0.4X",
                "日本1|BGP|0.4X", "新加坡1|BGP|0.4X"],
    }
}


class RotationRegionTests(unittest.TestCase):
    def test_refused_region_is_left_behind(self):
        egress = Egress()
        egress.current_ip = "46.20.109.167"
        egress.refused_ips = {"46.20.109.167"}
        egress.refused_regions = {"香港1"}
        chosen = egress._pick_node(PROXIES, "节点选择", egress.refused_ips)
        self.assertNotEqual(egress._region_of(chosen), "香港1")

    def test_a_known_refusal_does_not_empty_the_candidate_pool(self):
        """The filter has to reject refused candidates, not all candidates."""
        egress = Egress()
        egress.current_ip = "46.20.109.167"
        egress.refused_ips = {"46.20.109.167"}
        chosen = egress._pick_node(PROXIES, "节点选择", egress.refused_ips)
        self.assertTrue(chosen)
        self.assertNotEqual(chosen, PROXIES["节点选择"]["now"])

    def test_region_prefix_is_the_address_group(self):
        egress = Egress()
        self.assertEqual(egress._region_of("台湾1|BGP|Hinet|0.4X"), "台湾1")
        self.assertEqual(egress._region_of(""), "")

    def test_a_refused_region_is_not_treated_as_refused_when_nothing_was_refused(self):
        egress = Egress()
        self.assertFalse(egress._node_is_refused("香港1|BGP|0.4X", PROXIES, set()))


class DroppedSessionTests(unittest.TestCase):
    """drop_sessions() leaves the thread slot None; session() must rebuild.

    Found during the 2026-11-13 discovery run: after a rotation dropped the
    sessions, the first request in that worker thread raised AttributeError
    ('NoneType' object has no attribute 'get') and collection stalled, because
    session() only rebuilt on a missing attribute, not on a None one.
    """

    def test_session_rebuilds_after_drop(self):
        egress = Egress()
        first = egress.session()
        self.assertIsNotNone(first)
        egress.drop_sessions()
        second = egress.session()
        self.assertIsNotNone(second)
        self.assertIsNot(second, first)


if __name__ == "__main__":
    unittest.main()
