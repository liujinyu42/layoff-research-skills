"""Stage ordering and reconciliation for source-first discovery."""
import json
from pathlib import Path
import tempfile
import unittest

from researchcore import discovery, seed_sweep


class SourceFirstWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.work = Path(self.temporary.name)
        self.cfg = {'event_start': '2024-01-01', 'event_end': '2024-12-31',
                    'roster': [{'company_id': 'c', 'company': 'Example', 'aliases': 'Old Example'}]}
        (self.work / 'seed-capture.json').write_text('{"actual": "saved channel result"}')
        (self.work / 'google-capture.json').write_text('{"actual": "saved Google result"}')
        seed_sweep.plan(self.work, self.cfg)
        self.seed_tasks = json.loads((self.work / 'discovery/seed-plan.json').read_text())['tasks']

    def receipt(self, task, hits=None, outcome='completed'):
        row = {'task_id': task['task_id'], 'executed_at': '2026-11-09', 'outcome': outcome,
               'stop_basis': 'The full planned channel and requested period were inspected.',
               'result_path': 'seed-capture.json', 'hits': hits or []}
        if outcome == 'not_applicable':
            row['applicability_basis'] = 'The verified private issuer has no applicable public annual filing route.'
        return row

    def import_seeds(self, rows):
        path = self.work / 'seed-batch.json'
        path.write_text(json.dumps(rows))
        return seed_sweep.import_receipts(self.work, self.cfg, path)

    def complete_seeds(self, with_hit=False):
        rows = []
        for task in self.seed_tasks:
            hits = []
            if with_hit and task['channel'] == 'layoffs_fyi':
                hits = [{'url': 'https://tracker.example/example-2024', 'title': 'Example cuts 50 roles',
                         'reported_date': '2024-05-10', 'relevant': True}]
            rows.append(self.receipt(task, hits))
        return self.import_seeds(rows)

    def google_payload(self, task):
        return {'task_id': task['task_id'], 'query': task['query'], 'executed_at': '2026-11-09',
                'outcome': 'completed', 'stop_basis': 'All returned results for this planned query were inspected.',
                'result_path': 'google-capture.json', 'hits': []}

    def test_google_plan_is_blocked_before_seed_completion(self):
        self.assertEqual(len(self.seed_tasks), 4)
        self.assertEqual({task['channel'] for task in self.seed_tasks},
                         {'layoffs_fyi', 'trueup', 'thelayoff', 'issuer_report'})
        with self.assertRaisesRegex(ValueError, 'seed sweep is incomplete'):
            discovery.plan(self.work, self.cfg)

    def test_seed_creates_exact_title_verification_plus_annual_gap_tasks(self):
        self.assertTrue(self.complete_seeds(with_hit=True)['pass'])
        discovery.plan(self.work, self.cfg)
        tasks = json.loads((self.work / 'discovery/plan.json').read_text())['tasks']
        verification = [task for task in tasks if task['family'] == 'seed_verification']
        annual = [task for task in tasks if task['family'] != 'seed_verification']
        self.assertEqual(len(verification), 1)
        # One query per term per name per company and year, never a grouped
        # query. The test company is known by two names, and one year and
        # sixteen terms make thirty-two queries.
        self.assertEqual(len(annual), 44)
        for task in annual:
            self.assertNotIn(" OR ", task['query'])
        self.assertIn('"Example cuts 50 roles"', verification[0]['query'])
        self.assertIn('"Old Example"', verification[0]['query'])
        result = discovery.status(self.work, self.cfg, [])
        self.assertTrue(any(gap['reason'] == 'seed_hit_unaccounted' for gap in result['gaps']))

    def test_seed_and_google_candidates_are_reconciled_after_search(self):
        self.complete_seeds(with_hit=True)
        discovery.plan(self.work, self.cfg)
        tasks = json.loads((self.work / 'discovery/plan.json').read_text())['tasks']
        path = self.work / 'google-batch.json'
        path.write_text(json.dumps([self.google_payload(task) for task in tasks]))
        discovery.import_results(self.work, self.cfg, path)
        candidate = {'candidate_id': discovery.candidate_id('c', 'https://tracker.example/example-2024'),
                     'company_id': 'c', 'company': 'Example',
                     'source_url': 'https://tracker.example/example-2024'}
        result = discovery.status(self.work, self.cfg, [candidate])
        self.assertTrue(result['pass'], result['gaps'])
        self.assertEqual(result['seed_verification_tasks'], 1)

    def test_tracker_cannot_be_marked_not_applicable(self):
        task = next(task for task in self.seed_tasks if task['channel'] == 'layoffs_fyi')
        with self.assertRaisesRegex(ValueError, 'only available for issuer_report'):
            self.import_seeds([self.receipt(task, outcome='not_applicable')])

    def test_report_not_applicable_requires_basis(self):
        task = next(task for task in self.seed_tasks if task['channel'] == 'issuer_report')
        row = self.receipt(task, outcome='not_applicable')
        row['applicability_basis'] = ''
        with self.assertRaisesRegex(ValueError, 'applicability_basis'):
            self.import_seeds([row])

    def test_blocked_seed_remains_named_gap_but_does_not_stall_the_round(self):
        """A refused channel is reported, not treated as an unexecuted step.

        `blocked` means the receipt exists, its capture is intact and the
        refusal is named. The audit already accepts that state, so gating the
        next stage on it would let one permanently unreachable tracker stop
        every later round. A missing or altered receipt still stops the run.
        """
        rows = [self.receipt(task) for task in self.seed_tasks]
        rows[0]['outcome'] = 'blocked'
        result = self.import_seeds(rows)
        self.assertFalse(result['pass'])
        self.assertTrue(any(gap['reason'] == 'seed_blocked' for gap in result['gaps']))
        planned = discovery.plan(self.work, self.cfg)
        self.assertIn('google_verification_and_gap_discovery', planned['stage'])

    def test_missing_seed_still_blocks_stage_two(self):
        rows = [self.receipt(task) for task in self.seed_tasks][:-1]
        self.import_seeds(rows)
        with self.assertRaises(ValueError):
            discovery.plan(self.work, self.cfg)

    def test_seed_capture_change_invalidates_receipt(self):
        self.complete_seeds()
        (self.work / 'seed-capture.json').write_text('changed')
        result = seed_sweep.status(self.work, self.cfg)
        self.assertTrue(any(gap['reason'] == 'seed_capture_changed' for gap in result['gaps']))


if __name__ == '__main__':
    unittest.main()
