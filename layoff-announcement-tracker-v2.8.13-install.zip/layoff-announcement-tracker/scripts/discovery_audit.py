"""Persist search results before review and reconcile each company's evidence."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

def read(path, default):
    return json.loads(path.read_text()) if path.exists() else default

def record(folder, receipt):
    required = ('query','executed_at','status','hits')
    if not all(k in receipt for k in required) or not receipt['query'].strip() or not isinstance(receipt['hits'],list):
        raise ValueError('Incomplete search receipt')
    datetime.datetime.fromisoformat(receipt['executed_at'].replace('Z','+00:00'))
    status=receipt['status']
    if status not in ('results','empty','blocked') or (status=='results')!=bool(receipt['hits']) or (status=='blocked' and not receipt.get('reason')):
        raise ValueError('Status must agree with hits and blocker')
    for hit in receipt['hits']:
        if not hit.get('title') or not hit.get('url','').startswith(('https://','http://')):
            raise ValueError('Each displayed hit needs a title and URL')
    body=json.dumps(receipt,sort_keys=True,ensure_ascii=False)
    key=hashlib.sha256(body.encode()).hexdigest()[:20]
    directory=folder/'search-receipts'
    directory.mkdir(parents=True,exist_ok=True)
    path=directory/(key+'.json')
    if not path.exists():
        path.write_text(body)
    return key

def audit(folder, result, start, end, company):
    rows=read(folder/'tracker.json',{}).get('rows',[])
    leads={f'tracker:{i}':r for i,r in enumerate(rows)}
    covered=set()
    searched=set()
    blocked=[]
    for path in sorted((folder/'search-receipts').glob('*.json')):
        r=read(path,{})
        if r['status']=='blocked':
            blocked.append(r['query'])
        elif r.get('target_year'):
            searched.add(int(r['target_year']))
        for i,h in enumerate(r['hits']):
            leads[f'{path.stem}:{i}']=h
            date=str(h.get('date',''))[:4]
            if h.get('independent') is True and date.isdigit():
                covered.add(int(date))
    plans={e['plan_id'] for e in result.get('events',[])}
    decisions=result.get('lead_decisions',{})
    pending=[]
    unresolved=[]
    for key in leads:
        decision=decisions.get(key,{})
        status=decision.get('status')
        if status=='unresolved':
            unresolved.append(key)
        if (status not in ('included','merged','excluded','unresolved') or not decision.get('reason')
            or (status in ('included','merged') and decision.get('plan_id') not in plans)):
            pending.append(key)
    years=set(range(start,min(end,datetime.date.today().year)+1))
    return dict(company=company,lead_count=len(leads),pending=pending,unresolved=unresolved,
                blocked=blocked,followups=[dict(year=y,query=f'"{company}" layoffs job cuts {y}') for y in sorted(years-covered-searched)],
                years_without_independent_hits=sorted(years-covered))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('folder',type=Path)
    p.add_argument('receipt',type=Path)
    a=p.parse_args()
    print(record(a.folder,read(a.receipt,{})))
