"""Regression tests for the audit gates added after the delivery audit.

The delivery audit of the previous collection round recorded a layoff count of
100,000 for Google and 61,000 for the same company in a different month. Both
figures came from sentences about the technology sector as a whole. The audit
must now reject a count that cannot describe one employer in one event, so
these cases lock that behaviour in.
"""
import unittest

from researchcore.delivery_review import measure_gaps


def cell(value, quote=None, **extra):
    record = {"status": "observed", "value": value}
    if quote:
        record["evidence"] = [{"source_id": "s", "quote": quote, "char_start": 0}]
    record.update(extra)
    return record


class MagnitudeGate(unittest.TestCase):
    def reasons(self, decisions, entities=None):
        return [gap["reason"] for gap in measure_gaps(decisions, entities or {}, [])]

    ENTITIES = {"p": {"company_id": "jamf", "company": "Jamf"}}

    def test_industry_aggregate_is_rejected(self):
        decisions = {
            "p|announcement_date": cell("2025-07-04", None, date_basis="news_reported_announcement"),
            "p|layoff_count": cell(100000, "over 100,000 positions eliminated across major companies"),
            "p|firm_size": cell(187000, None),
            "p|layoff_percentage": cell(6.0, None),
            "p|layoff_percentage_qualifier": cell("exact", None),
            "p|layoff_percentage_denominator": cell("workforce", None),
            "p|layoff_count_qualifier": cell("exact", None),
            "p|plan_relationship": cell("independent", None, plan_link_basis="Only plan for this company"),
            "p|country": cell("United States", None),
        }
        self.assertTrue(any("beyond any single announced reduction round" in reason
                            or "more than three times the share implied" in reason
                            for reason in self.reasons(decisions, self.ENTITIES)))

    def test_count_above_firm_size_is_reported_as_a_measure_gap(self):
        """A count above the firm size is a measure gap, not an integrity error.

        The firm size comes from a registrant filing that may describe a
        different year than the event, so the conflict is reported and the
        auditor decides. What blocks export is a count that would remove an
        implausible share of the workforce.
        """
        decisions = {
            "p|announcement_date": cell("2025-01-15", None, date_basis="news_reported_announcement"),
            "p|layoff_count": cell(500000, None),
            "p|firm_size": cell(187000, None),
            "p|layoff_count_qualifier": cell("exact", None),
            "p|plan_relationship": cell("independent", None, plan_link_basis="Only plan for this company"),
            "p|country": cell("United States", None),
        }
        reasons = self.reasons(decisions, self.ENTITIES)
        self.assertTrue(any("beyond any single announced reduction round" in reason
                            for reason in reasons))

    def test_year_to_date_total_is_rejected(self):
        decisions = {
            "p|announcement_date": cell("2026-08-06", None, date_basis="news_reported_announcement"),
            "p|layoff_count": cell(50000, None),
            "p|firm_size": cell(76000, None),
            "p|layoff_count_qualifier": cell("exact", None),
            "p|plan_relationship": cell("independent", None, plan_link_basis="Only plan for this company"),
            "p|country": cell("United States", None),
        }
        self.assertTrue(any("beyond any single announced reduction round" in reason
                            for reason in self.reasons(decisions, self.ENTITIES)))

    def test_ordinary_event_passes(self):
        decisions = {
            "p|announcement_date": cell("2025-01-15", None, date_basis="news_reported_announcement"),
            "p|layoff_count": cell(500, "Jamf laid off 500 employees in January 2025."),
            "p|firm_size": cell(187000, None),
            "p|layoff_count_qualifier": cell("exact", None),
            "p|plan_relationship": cell("independent", None, plan_link_basis="Only plan for this company"),
            "p|country": cell("United States", None),
        }
        self.assertEqual(self.reasons(decisions, self.ENTITIES), [])

    def test_aggregate_evidence_fails_the_employer_binding_rule_first(self):
        """The runtime already rejects a count sentence that names no employer.

        The magnitude gate is the second line of defence: it applies when the
        sentence does name the employer but the figure is implausible for it.
        """
        decisions = {
            "p|announcement_date": cell("2025-07-04", None, date_basis="news_reported_announcement"),
            "p|layoff_count": cell(100000, "over 100,000 positions eliminated across major companies"),
            "p|firm_size": cell(187000, None),
            "p|layoff_count_qualifier": cell("exact", None),
            "p|plan_relationship": cell("independent", None, plan_link_basis="Only plan for this company"),
            "p|country": cell("United States", None),
        }
        reasons = self.reasons(decisions, self.ENTITIES)
        self.assertTrue(any("must name the target employer" in reason for reason in reasons))


if __name__ == "__main__":
    unittest.main()
