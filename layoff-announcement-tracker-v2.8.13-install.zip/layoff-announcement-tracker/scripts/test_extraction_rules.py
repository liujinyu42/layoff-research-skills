"""Regression tests for the scope-safe extraction and entity-binding rules.

Each case comes from a defect the delivery audit reported against the previous
collection round, so this file fails if those defects return.

    python "$S/scripts/test_extraction_rules.py"
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from researchcore import delivery_review, extraction  # noqa: E402

COUNT_CASES = [
    # An industry aggregate is not one employer's event.
    ("The tech industry is experiencing significant job cuts in 2025, with over 100,000 "
     "positions eliminated across major companies like Microsoft, Intel, Google, and Infosys.",
     ["Google"], "2025", None, None),
    # A threshold over a multi-company total is not this employer's count.
    ("Tech layoffs 2025: Over 61,000 jobs cut as Microsoft, Google, Amazon, and CrowdStrike "
     "reshape workforce",
     ["Google"], "2025", None, None),
    # A trend attribution does not displace a valid before/after statement.
    ("Salesforce cut its support team from 9,000 to 5,000 and AI is now blamed for 50,000 "
     "job cuts this year",
     ["Salesforce"], "2026", 4000, "exact"),
    ("Groupon will cut about 500 employees across its operations as the company restructures "
     "its business.",
     ["Groupon"], "2022", 500, "approximately"),
    ("Microsoft said it would lay off 10,000 workers while Google announced no changes.",
     ["Google"], "2025", None, None),
    ("In January 2023, Alphabet had announced plans to cut 12,000 jobs, or 6% of its global "
     "workforce.",
     ["Google"], "2025", None, None),
    ("Google now employs 180,000 people after the cuts.",
     ["Google"], "2025", None, None),
    ("The company furloughed 2,000 employees, which is not a layoff.",
     ["Acme"], "2024", None, None),
    # A comparison clause must not hand this employer the other company's
    # figure. The audit report's largest accuracy complaint was exactly this:
    # SAP was recorded as cutting 12,000 (Google's number) instead of 8,000.
    ("While Google dominated 2023 with its astounding 12,000 job cuts, SAP laid off "
     "8,000 of its employees in January 2024, owing to its restructuring programme for 2024.",
     ["SAP"], "2024", 8000, "exact"),
    # A count followed by "of its employees" is this employer's figure; the
    # count pattern used to require the unit word directly after the number.
    ("SAP laid off 8,000 of its employees in January 2024.", ["SAP"], "2024", 8000, "exact"),
    # A role title and a person's name between the employer and its own verb
    # are not another employer acting.
    ("Twilio CEO Jeff Lawson announced Monday that the company would cut 1,500 jobs, "
     "about 17% of its workforce.", ["Twilio"], "2023", 1500, "exact"),
    # The employer is introduced in a parenthetical and the announcement verb
    # carries the reduction: "Uber Technologies (UBER) has just announced ...".
    ("Uber Technologies (UBER) has just announced a restructuring that will cut about "
     "3,300 jobs, or roughly 10% of its global workforce.", ["Uber"], "2026", 3300,
     "approximately"),
    # A possessive employer followed by a pronoun referring back to it.
    ("Salesforce's India employees have been impacted following the US firm's "
     "announcement that it is laying off about 8,000 people or 10% of its global workforce.",
     ["Salesforce"], "2023", 8000, "approximately"),
]

SUBJECT_CASES = [
    ("Groupon will cut about 500 employees across its operations as the company restructures "
     "its business.", ["Groupon"], True),
    ("Fiverr laid off 30 employees in a cost-cutting move.", ["Fiverr"], True),
    ("Twitter is cutting 500 jobs, the company confirmed on Monday.", ["Twitter"], True),
    ("UiPath said it would cut 350 roles.", ["UiPath"], True),
    ("UiPath to lay off 350 employees as it restructures.", ["UiPath"], True),
    ("Peloton will lay off about 220 people, or 12% of its workforce.", ["Peloton"], True),
    ("Zendesk cut 350 jobs in March.", ["Zendesk"], True),
    ("Google will lay off 100 employees in its ads division.", ["Google"], True),
    ("Intel plans another round of layoffs after reducing 40,000 roles", ["Intel"], True),
    ("The tech industry is experiencing significant job cuts in 2025, with over 100,000 "
     "positions eliminated across major companies like Microsoft, Intel, Google, and Infosys.",
     ["Google"], False),
    ("Microsoft said it would lay off 10,000 workers while Google announced no changes.",
     ["Google"], False),
    # The employer can be identified by the slot it occupies rather than by
    # being the grammatical subject.
    ("'AI-first' push leads to 250 layoffs at Fiverr", ["Fiverr"], True),
    ("Flywire cuts 10% of staff amid $16m in net losses", ["Flywire"], True),
    ("Magna Steyr to cut 500 jobs amid EV startup Fisker's financial woes", ["Fisker"], True),
    ("GitLab and GitHub both move to cut jobs", ["GitLab"], True),
    ("Fiverr CEO: 'We had to downsize. It was the right step to take'", ["Fiverr"], True),
    # A corporate designator, a role title and a person's name are part of one
    # employer's own clause, not competing employers.
    ("Uber Technologies (UBER) has just announced a restructuring that will cut about "
     "3,300 jobs.", ["Uber"], True),
    ("Twilio CEO Jeff Lawson announced Monday that the company would cut 1,500 jobs.",
     ["Twilio"], True),
    ("Salesforce's India employees have been impacted following the US firm's announcement "
     "that it is laying off about 8,000 people.", ["Salesforce"], True),
]

PLAUSIBILITY_CASES = [
    (100000, 187000, 6.0, False, "industry aggregate against firm size"),
    (50000, 76000, None, False, "year-to-date attribution total"),
    (500, 187000, 6.0, True, "ordinary single event"),
    (4000, None, None, True, "before/after difference"),
]


def main():
    failures = []

    for text, aliases, year, expected_value, expected_qualifier in COUNT_CASES:
        got = extraction.scoped_count(text, aliases, year)
        value = got["value"] if got else None
        qualifier = got["qualifier"] if got else None
        if value != expected_value or qualifier != expected_qualifier:
            failures.append(f"count case failed: {text[:60]!r} -> {value}/{qualifier} "
                            f"(expected {expected_value}/{expected_qualifier})")

    for text, aliases, expected in SUBJECT_CASES:
        got = extraction.employer_is_subject(text, aliases)
        if got != expected:
            failures.append(f"subject case failed: {text[:60]!r} -> {got} (expected {expected})")

    for value, size, share, expected, label in PLAUSIBILITY_CASES:
        ok, _why = extraction.plausibility(value, size, share)
        if ok != expected:
            failures.append(f"plausibility case failed: {label}")

    percentage = extraction.scoped_percentage(
        "GitLab is cutting about 14% of its full-time workforce, roughly 350 people.",
        ["GitLab"], "2026")
    if not percentage or percentage["value"] != 14.0 or "workforce" not in percentage["denominator"]:
        failures.append(f"percentage case failed: {percentage}")

    # A decimal point is not a sentence boundary. Splitting "6.4% of its
    # workforce" away from the layoff clause made the share unreadable for a
    # sentence that stated both figures.
    percentage = extraction.scoped_percentage(
        "Google announced on January 20 that it was laying off around 12,000 workers, "
        "or 6.4% of its workforce.", ["Google"], "2023")
    if not percentage or percentage["value"] != 6.4:
        failures.append(f"decimal percentage case failed: {percentage}")

    # A stated range is two bounds. Keeping only the first figure contradicts
    # the source and loses the upper bound.
    percentage = extraction.scoped_percentage(
        "Farfetch confirmed it will lay off between 25% and 30% of its workforce, "
        "affecting an estimated 2,000 employees globally.", ["Farfetch"], "2024")
    if (not percentage or percentage.get("qualifier") != "range"
            or percentage.get("lower") != 25.0 or percentage.get("upper") != 30.0):
        failures.append(f"percentage range case failed: {percentage}")

    # A share stated against the headcount already named in the sentence.
    percentage = extraction.scoped_percentage(
        "Rivian Automotive is laying off 239 workers as part of a cost-cutting measure "
        "to reduce its headcount by 6%.", ["Rivian"], "2023")
    if not percentage or percentage["value"] != 6.0:
        failures.append(f"percentage 'by' case failed: {percentage}")

    # A figure introduced by a growth verb counts hires, not cuts.
    for text, company in (
            ("Talking about the job cuts, a spokesperson said the company plans to "
             "grow its overall headcount this year with over 500 roles.", "Okta"),
            ("Acme will hire 200 engineers and open a new office.", "Acme")):
        if extraction.scoped_count(text, [company], "2024") is not None:
            failures.append(f"hiring clause read as a layoff count: {text[:60]}")

    # A sentence that mixes open positions or a remainder with a reduction is
    # declined rather than guessed: either number could be the wrong one.
    if extraction.scoped_count("Acme has 500 open positions and is laying off 300 people.",
                               ["Acme"], "2024") is not None:
        failures.append("a sentence mixing vacancies with cuts produced a count")

    # "cutting up to 175 employees" states a layoff, not a remaining headcount.
    if delivery_review._v251_count_semantics(
            "x", {}, 175, "Weedmaps is cutting up to 175 employees, or 25% of its workforce."):
        failures.append("'up to N' read as a remaining headcount")
    if not delivery_review._v251_count_semantics(
            "x", {}, 500, "Acme cut its staff to 500 employees."):
        failures.append("'cut its staff to 500' was not read as a remainder")

    if failures:
        print(f"FAILED {len(failures)} of "
              f"{len(COUNT_CASES) + len(SUBJECT_CASES) + len(PLAUSIBILITY_CASES) + 4} cases")
        for line in failures:
            print("  -", line)
        return 1
    total = len(COUNT_CASES) + len(SUBJECT_CASES) + len(PLAUSIBILITY_CASES) + 4
    print(f"OK {total} extraction rules pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
