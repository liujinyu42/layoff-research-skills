"""Execute planned Stage-1 seed tasks and emit runtime-compliant receipts.

Stage 1 is the source-first sweep: before any web search, every roster company
is checked against each tracker channel and against its own issuer filing. The
previous collection round executed this by hand, channel by channel, and the
procedure lived in throwaway scripts. Nothing about it was reproducible, so the
receipts could not be rebuilt when the workspace was cleaned.

This module makes that sweep a single command. It records what actually
happened to each channel rather than what the run hoped would happen:

* a channel that answers and lists the company is ``completed`` with the rows
  it actually returned;
* a channel that answers and lists nothing for the company is ``completed``
  with an empty hit list and a stop basis that says so; a guessed-slug 404 is
  not that: the board is looked up by alias slug and the site index first, and
  if none is found the receipt is ``blocked`` with reason ``board_unresolved``;
* a channel that refuses the request (Cloudflare, 403, a JavaScript shell) is
  ``blocked`` with the reason. A blocked channel is a recorded limitation, not
  a fabricated success;
* an issuer filing is ``completed`` from the filing already registered in the
  workspace, or ``not_applicable`` with an explicit basis when the company is
  not an SEC registrant.

The runtime treats ``blocked`` as a coverage gap rather than an integrity
failure, which is the correct reading: an unreachable tracker is a limitation
of the round, while an unexecuted or altered receipt is a false claim.

Usage:

    python "$S/scripts/collect_seeds.py" --work "$W" --out "$W/discovery/seed-batch.json"
    python "$S/scripts/collect_seeds.py" --work "$W" --out ... --only-channel thelayoff
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import csv
import datetime as dt
import email.utils
import hashlib
import json
import os
import re
import sys
import threading
import time
from collections.abc import Mapping
from datetime import date
from pathlib import Path
from urllib.parse import urljoin, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))

import render_table  # noqa: E402
from bs4 import BeautifulSoup  # noqa: E402
from researchcore import sources  # noqa: E402

MONTHS = {name: index for index, name in enumerate(
    ("january", "february", "march", "april", "may", "june", "july",
     "august", "september", "october", "november", "december"), 1)}

# thelayoff.com dates posts as "August 14, 2024 by ...".
POST_DATE = re.compile(
    r"\b(January|February|March|April|May|June|July|August|September|October|"
    r"November|December)\s+(\d{1,2}),\s+(20\d\d)\s+by", re.I)
POST_ID = re.compile(r"Post\s*ID:\s*@OP\+(\w+)")
POST_SPLIT = "•••"
REDUCTION = re.compile(
    r"\b(lay[\s-]?offs?|laid\s+off|laying\s+off|job\s+cuts?|"
    r"cut(?:s|ting)?\s+(?:jobs|staff|headcount|roles)|reduction\s+in\s+force|\bRIF\b|"
    r"redundan\w*|restructur\w*|severance|let\s+go|downsiz\w*|workforce|headcount|WARN)\b",
    re.I)

# A page that refuses the request still returns HTTP 200 with a challenge shell.
# Match real Cloudflare / browser-challenge markers only. TheLayoff.com injects
# an html-load.com ad loader (and "problem loading the page" copy) on otherwise
# real boards; treating that as a challenge filed ~230 HTTP 200 boards as blocked.
CHALLENGE = re.compile(
    r"(just\s+a\s+moment|cf-browser-verification|checking\s+your\s+browser|"
    r"attention\s+required|cf-chl|cf-challenge|managed[_-]?challenge)", re.I)
# A challenge is recognised from its <title> or from two distinct markers in the
# head of the page. One stray phrase (a post titled "Attention required") on a
# real board is not a challenge.
_CHALLENGE_TITLE = re.compile(
    r"<title[^>]*>\s*(?:just\s+a\s+moment|attention\s+required)", re.I)
_CHALLENGE_PARTS = tuple(re.compile(pattern, re.I) for pattern in (
    r"just\s+a\s+moment", r"cf-browser-verification", r"checking\s+your\s+browser",
    r"attention\s+required", r"cf-chl", r"cf-challenge", r"managed[_-]?challenge"))
# Markers that identify Cloudflare itself. Only these (or a Cloudflare challenge
# header) justify a cloudflare_* reason; a plain 403 is labelled http_403.
CLOUDFLARE_MARKERS = re.compile(
    r"(just\s+a\s+moment|cf-browser-verification|cf-chl|cf-challenge|managed[_-]?challenge|"
    r"challenges\.cloudflare\.com|attention\s+required!?\s*\|\s*cloudflare|"
    r"cloudflare\s+ray\s+id|cf-error-details)", re.I)
# A TheLayoff board that parsed to no posts must carry the site's own empty-board
# sentence; otherwise the parser or the page layout is the suspect, not the board.
EMPTY_BOARD = re.compile(r"there\s+are\s+no\s+(?:posts|topics|threads)\b", re.I)

RETRY_AFTER_CAP = 120.0

# Spaced confirmation of a host that keeps returning Cloudflare 403 / an empty
# render. Defaults cover three attempts over roughly 20 minutes. Tests shrink
# the interval. This path never rotates an exit, sets a proxy, or spoofs a UA.
HOST_CONFIRM_ATTEMPTS = int(os.environ.get("LAYOFF_HOST_CONFIRM_ATTEMPTS", "3"))
HOST_CONFIRM_INTERVAL = float(os.environ.get("LAYOFF_HOST_CONFIRM_INTERVAL", "600"))

# A page whose main table is embedded from a client-side widget. Reading the
# shell and reporting "inspected, no rows" would be a false negative: the rows
# exist inside the embedded view, not in the HTML an unauthenticated fetch gets.
JS_TABLE = re.compile(
    r"(airtable\.com/embed|<iframe[^>]+src=[\"'][^\"']*(?:airtable|sheets|tableau|"
    r"datastudio)|data-app-id)", re.I)


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def slug(name):
    """The company slug a tracker uses in its URL."""
    value = re.sub(r"[^a-z0-9]+", "-", str(name or "").lower()).strip("-")
    return value


def unique_urls(items):
    seen, out = set(), []
    for url, title, date in items:
        if not url or url in seen:
            continue
        seen.add(url)
        out.append((url, title, date))
    return out


def parse_reported_date(value):
    """Parse a tracker date to ISO YYYY-MM-DD.

    Returns (iso, "") when the value is a real calendar date, or
    ("", "unparseable_date") when it is missing or not a known format.
    Unparseable values are never treated as inside or outside the window.
    Layoffs.fyi currently emits US M/D/YYYY; ISO and "Month D, YYYY" are
    accepted as well. Ambiguous day/month values are read as M/D, not D/M.
    """
    text = str(value or "").strip()
    if not text:
        return "", "unparseable_date"
    if re.match(r"^\d{4}-\d{2}-\d{2}", text):
        try:
            return date.fromisoformat(text[:10]).isoformat(), ""
        except ValueError:
            return "", "unparseable_date"
    match = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{2}|\d{4})", text)
    if match:
        month, day, year = (int(match.group(1)), int(match.group(2)), int(match.group(3)))
        if year < 100:
            year += 2000 if year < 70 else 1900
        try:
            return date(year, month, day).isoformat(), ""
        except ValueError:
            return "", "unparseable_date"
    match = re.fullmatch(
        r"(January|February|March|April|May|June|July|August|September|October|"
        r"November|December)\s+(\d{1,2}),\s+(20\d\d)", text, re.I)
    if match:
        try:
            return date(int(match.group(3)), MONTHS[match.group(1).lower()],
                        int(match.group(2))).isoformat(), ""
        except (ValueError, KeyError):
            return "", "unparseable_date"
    return "", "unparseable_date"


def is_challenge(text):
    """True for a browser/Cloudflare challenge page, not for ordinary content."""
    head = (text or "")[:6000]
    if not head:
        return False
    if _CHALLENGE_TITLE.search(head):
        return True
    return sum(1 for part in _CHALLENGE_PARTS if part.search(head)) >= 2


def has_cloudflare_markers(body):
    """True when the body (or a Cloudflare challenge header) identifies Cloudflare."""
    if getattr(body, "cloudflare_headers", False):
        return True
    return bool(body and CLOUDFLARE_MARKERS.search(str(body)[:6000]))


class _Body(str):
    """Response text that remembers whether Cloudflare challenge headers came with it."""
    cloudflare_headers = False


def _retry_after_seconds(value):
    """Seconds a Retry-After header asks for (delta or HTTP date), capped, or None."""
    text = str(value or "").strip() if isinstance(value, (str, int, float)) else ""
    if not text:
        return None
    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        return min(float(text), RETRY_AFTER_CAP)
    try:
        when = email.utils.parsedate_to_datetime(text)
    except (TypeError, ValueError):
        return None
    if when is None:
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=dt.timezone.utc)
    delta = (when - dt.datetime.now(dt.timezone.utc)).total_seconds()
    return max(0.0, min(delta, RETRY_AFTER_CAP))


class HostPacer:
    """Process-wide per-host pacing shared by every worker thread.

    Restores the behaviour of the shipped Egress._wait/_note_refusal/_note_success
    for the plain-GET path, without a proxy or any exit rotation: a minimum
    interval between requests to one host (shared across threads), a wider
    interval after a refusal (403/429/5xx) that relaxes again on success, and
    Retry-After honoured on 429/503.
    """

    def __init__(self, floor=0.15, ceiling=8.0, clock=time.monotonic, sleeper=time.sleep):
        self.floor = float(floor)
        self.ceiling = float(ceiling)
        self._clock = clock
        self._sleep = sleeper
        self._lock = threading.Lock()
        self._hosts = {}

    def configure(self, floor):
        with self._lock:
            self.floor = max(float(floor), 0.0)
            for state in self._hosts.values():
                state["interval"] = max(self.floor, min(state["interval"], self.ceiling))

    def _state(self, host):
        state = self._hosts.get(host)
        if state is None:
            state = {"interval": self.floor, "next_at": 0.0}
            self._hosts[host] = state
        return state

    def interval(self, host):
        with self._lock:
            return self._state(host)["interval"]

    def wait(self, host):
        """Acquire a host slot after sleeping, accounting for concurrent wakeups."""
        if not host:
            return 0.0
        delay_total = 0.0
        while True:
            with self._lock:
                state = self._state(host)
                now = self._clock()
                delay = state["next_at"] - now
                if delay <= 0:
                    state["next_at"] = now + state["interval"]
                    return delay_total
            self._sleep(delay)
            delay_total += delay

    def note(self, host, status, retry_after=None):
        """Record one answer: widen on a refusal, relax on success, honour Retry-After."""
        if not host:
            return
        with self._lock:
            state = self._state(host)
            now = self._clock()
            if status in (403, 429, 503) or status >= 500:
                state["interval"] = min(self.ceiling, max(state["interval"] * 1.6, 0.4))
                state["next_at"] = max(state["next_at"], now + state["interval"] * 4)
                if retry_after is not None and status in (429, 503):
                    state["next_at"] = max(state["next_at"], now + float(retry_after))
            elif status:
                state["interval"] = max(self.floor, state["interval"] * 0.97)


PACER = HostPacer()


def _plain_get(url, timeout=30):
    """HTTP GET with no proxy and no exit rotation, paced per host.

    Every request waits for the process-wide per-host slot (PACER), so several
    workers share one request budget per host. The body is returned as text;
    Cloudflare challenge headers are carried on the returned string.
    """
    import requests
    from researchcore.egress import UA
    headers = {"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"}
    host = (urlparse(url).hostname or "").lower()
    PACER.wait(host)
    try:
        response = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
    except requests.RequestException:
        PACER.note(host, 0)
        return 0, ""
    status = response.status_code
    raw_headers = getattr(response, "headers", None)
    lowered = ({str(k).lower(): str(v) for k, v in raw_headers.items()}
               if isinstance(raw_headers, Mapping) else {})
    PACER.note(host, status, _retry_after_seconds(lowered.get("retry-after")))
    body = _Body(response.text or "")
    body.cloudflare_headers = (
        lowered.get("cf-mitigated", "").lower() == "challenge"
        or (status == 403 and "cloudflare" in lowered.get("server", "").lower()
            and "cf-ray" in lowered))
    return status, body


# What a refusal is called. Only a body/header with Cloudflare markers is
# "cloudflare_*"; a bare 403 is http_403; 429, a missing response and 5xx are
# never labelled Cloudflare.
HOST_REFUSALS = {"cloudflare_403", "http_403", "cloudflare_challenge", "browser_challenge"}


def refusal_kind(status, body):
    """Classify a response as a refusal kind, or "" when it is an answer."""
    if status in (404, 410):
        return ""
    cloudflare = has_cloudflare_markers(body)
    if status == 403:
        return "cloudflare_403" if cloudflare else "http_403"
    if status == 429:
        return "rate_limited"
    if status == 0:
        return "no_response"
    if status >= 500:
        return "server_error"
    if is_challenge(body):
        return "cloudflare_challenge" if cloudflare else "browser_challenge"
    return ""


def is_cloudflare_403_or_empty(status, body, rendered=None):
    """True when a host refused with a 403 or a browser challenge.

    Kept for callers of the earlier name. It is now a refusal test only: 429,
    a missing response and 5xx are not host refusals, and ``rendered`` no longer
    widens the answer. Use ``refusal_kind`` to learn whether Cloudflare is named.
    """
    return refusal_kind(status, body) in HOST_REFUSALS


class HostBlocker:
    """Confirm a persistent Cloudflare 403 on one host, then short-circuit.

    After N spaced failures, remaining companies on that host receive a
    blocked receipt with reason cloudflare_403_persistent (Cloudflare markers
    seen) or http_403_persistent (a plain 403). This does not
    rotate, proxy, or change a stage gate; it records an honest block.
    """

    def __init__(self, attempts=None, interval=None, sleeper=time.sleep, getter=None):
        self.attempts = int(attempts if attempts is not None else HOST_CONFIRM_ATTEMPTS)
        self.interval = float(interval if interval is not None else HOST_CONFIRM_INTERVAL)
        self._sleep = sleeper
        self._get = getter if getter is not None else (lambda url: _plain_get(url))
        self._lock = threading.Lock()
        self._state = {}

    def is_blocked(self, host):
        if not host:
            return False
        with self._lock:
            return (self._state.get(host) or {}).get("status") == "blocked"

    def reason(self, host):
        """cloudflare_403_persistent only when every refusal carried Cloudflare markers."""
        with self._lock:
            kinds = list((self._state.get(host) or {}).get("kinds") or [])
        if kinds and all(kind.startswith("cloudflare") for kind in kinds):
            return "cloudflare_403_persistent"
        return "http_403_persistent"

    def describe(self, host):
        """What was actually tried: the request count, spacing and refusal kinds seen."""
        with self._lock:
            state = self._state.get(host) or {}
            kinds = list(state.get("kinds") or [])
            requests_made = int(state.get("requests") or self.attempts)
        seen = sorted(set(kinds)) or ["unclassified"]
        label = {"cloudflare_403": "HTTP 403 with Cloudflare markers",
                 "http_403": "HTTP 403 without Cloudflare markers",
                 "cloudflare_challenge": "a Cloudflare challenge page",
                 "browser_challenge": "a browser challenge page"}
        names = "; ".join(label.get(kind, kind) for kind in seen)
        return (f"{requests_made} plain HTTP request(s), the later ones spaced "
                f"{self.interval:g}s apart, were refused ({names}); no browser render "
                f"was attempted for a 403")

    def confirm(self, host, url, first_kind=""):
        """Return True if this host is (or becomes) persistently blocked.

        The first observed failure is attempt 1. Remaining attempts wait
        `interval` seconds each. Only one thread confirms a given host.
        `first_kind` is that first refusal's kind (see refusal_kind).
        """
        if not host:
            return False
        with self._lock:
            state = self._state.get(host)
            if state is None:
                state = {"status": "checking", "event": threading.Event(),
                         "kinds": [first_kind] if first_kind else [], "requests": 1}
                self._state[host] = state
                runner = True
            elif state["status"] == "blocked":
                return True
            elif state["status"] == "open":
                return False
            else:
                event = state["event"]
                runner = False
        if not runner:
            event.wait()
            return self.is_blocked(host)
        blocked = True
        try:
            for _ in range(max(self.attempts - 1, 0)):
                self._sleep(self.interval)
                status, body = self._get(url)
                kind = refusal_kind(status, body)
                state["requests"] += 1
                if kind not in HOST_REFUSALS:
                    blocked = False
                    break
                state["kinds"].append(kind)
        finally:
            with self._lock:
                state["status"] = "blocked" if blocked else "open"
            state["event"].set()
        return blocked


# --- R-14: resolve a board before concluding that a tracker has none ---------
#
# A 404 on slug(company) only says the guessed address does not exist. TheLayoff
# files boards under its own slugs ("international-business-machines" for IBM),
# so a guessed-slug 404 must not be recorded as "no board". The collector first
# tries alias slugs built from the roster and registry names, then (for
# TheLayoff, which has no search form) the site's own A-Z company index. If no
# board is found the receipt is NOT completed: it is blocked with the reason
# board_unresolved and the slugs tried, so seed-status opens a named gap.

UNRESOLVED_OUTCOME = "blocked"
UNRESOLVED_REASON = "board_unresolved"
MAX_ALIAS_SLUGS = 8
CORPORATE_SUFFIXES = {
    "inc", "incorporated", "corp", "corporation", "co", "company", "ltd", "limited",
    "llc", "plc", "lp", "llp", "sa", "ag", "nv", "se", "gmbh", "holdings", "holding",
    "group",
}
# A trailing web-address token ("Salesforce.com Inc." is the same board as "Salesforce").
TLD_TOKENS = {"com", "io", "ai", "net", "org"}
NAME_STOPWORDS = {"and", "of", "the"}
NEAR_CANDIDATES = 3
_PARENTHETICAL = re.compile(r"\(([^)]*)\)")
THELAYOFF_INDEX_PAGES_MAX = 300
_INDEX_PAGES_OF = re.compile(r"page\s+\d+\s+of\s+(\d+)", re.I)
_INDEX_SLUG = re.compile(r"^/([a-z0-9][a-z0-9._-]*)$")


def name_tokens(name):
    """Lower-case ASCII word tokens of a company name ("&" reads as "and")."""
    import unicodedata
    text = unicodedata.normalize("NFKD", str(name or "")).encode("ascii", "ignore").decode()
    text = text.lower().replace("&", " and ")
    return [token for token in re.split(r"[^a-z0-9]+", text) if token]


def name_variants(name):
    """The name with trailing corporate words stripped one at a time, longest first."""
    tokens = name_tokens(name)
    variants = []
    while tokens:
        variants.append(" ".join(tokens))
        if len(tokens) > 1 and (tokens[-1] in CORPORATE_SUFFIXES or tokens[-1] in TLD_TOKENS):
            tokens = tokens[:-1]
        else:
            break
    # "The Home Depot" is also listed as "Home Depot".
    for variant in list(variants):
        words = variant.split()
        if len(words) > 1 and words[0] == "the":
            rest = " ".join(words[1:])
            if rest not in variants:
                variants.append(rest)
    return variants


def name_key(name):
    """Canonical matching key: normalised tokens with trailing corporate words and
    web-address tokens stripped iteratively and a leading "the" dropped.

    Index display names and our own names go through this same function, so a
    match is an exact equality of keys, never a fuzzy comparison.
    """
    tokens = name_tokens(name)
    while len(tokens) > 1 and (tokens[-1] in CORPORATE_SUFFIXES or tokens[-1] in TLD_TOKENS):
        tokens = tokens[:-1]
    if len(tokens) > 1 and tokens[0] == "the":
        tokens = tokens[1:]
    return " ".join(tokens)


def board_keys(name):
    """Keys for one name. A parenthetical is a second name for the same board:
    "HP (Hewlett-Packard)" gives {"hp", "hewlett packard"}; "Hewlett Packard
    Enterprise (HPE)" gives {"hewlett packard enterprise", "hpe"}."""
    text = str(name or "")
    parts = [_PARENTHETICAL.sub(" ", text)] + _PARENTHETICAL.findall(text)
    return {key for key in (name_key(part) for part in parts) if key}


def registry_names(entries, company_id):
    """Every name the registry holds for a company (display, English, legal, trading)."""
    entry = (entries or {}).get(company_id) or {}
    names = [entry.get("display_name"), entry.get("company_en")]
    for item in entry.get("names") or []:
        if isinstance(item, dict):
            names.append(item.get("name"))
        elif isinstance(item, str):
            names.append(item)
    return [str(name).strip() for name in names if str(name or "").strip()]


def candidate_names(task, entries):
    """Roster name, planned aliases, then registry names, de-duplicated in order."""
    names, seen = [], set()
    for name in [task.get("company"), *(task.get("aliases") or []),
                 *registry_names(entries, task.get("company_id"))]:
        key = " ".join(name_tokens(name))
        if key and key not in seen:
            seen.add(key)
            names.append(str(name))
    return names


def alias_slugs(names, exclude=()):
    """Alias slugs for the names and their suffix-stripped forms, capped and ordered."""
    out, seen = [], set(exclude)
    for name in names:
        for variant in name_variants(name):
            value = slug(variant)
            if len(value) >= 2 and value not in seen:
                seen.add(value)
                out.append(value)
    return out[:MAX_ALIAS_SLUGS]


class TheLayoffIndex:
    """TheLayoff.com's A-Z company index, crawled lazily one letter at a time.

    The site has no search form; its index (/index/<letter>, /index/<letter>/
    page-N) lists every board by display name with the board's real slug. Each
    letter is fetched once per run through the same paced ``fetch`` and shared
    across threads.

    A letter is crawled by following the page's real next link
    (<link rel="next">, a rel=next anchor, or the "Next" pager button) until
    none is left. The "page N of M" text is only a hint: it said "page 1 of 1"
    on pages that had eleven successors, so it never decides where to stop.
    A letter that stops for any other reason (page cap, an unreadable page, or
    a repeated next link) is "incomplete", and the caller must say so rather
    than present the lookup as a full index miss.
    """

    def __init__(self, fetch, base="https://www.thelayoff.com", max_pages=THELAYOFF_INDEX_PAGES_MAX,
                 capture_dir=None):
        self._fetch = fetch
        self.base = base.rstrip("/")
        self.max_pages = int(max_pages)
        # When set, every page this crawl fetches is saved (and nothing else is
        # fetched): <capture_dir>/<letter>/page-<N>.html plus <letter>/_manifest.json.
        self.capture_dir = Path(capture_dir) if capture_dir else None
        self._guard = threading.Lock()
        self._locks = {}
        self._letters = {}

    @staticmethod
    def letter_for(name):
        tokens = name_tokens(name)
        return tokens[0][0] if tokens else ""

    @staticmethod
    def next_href(soup):
        """The index page's next-page link, or empty when there is none."""
        link = soup.select_one('link[rel~="next"][href]') or soup.select_one('a[rel~="next"][href]')
        if link is None:
            for anchor in soup.select('#content a[href^="/index/"]'):
                if anchor.get_text(" ", strip=True).lower().startswith("next"):
                    link = anchor
                    break
        return (link.get("href") or "").strip() if link is not None else ""

    @staticmethod
    def parse_page(html):
        """(entries, total_hint, next_href): entries are (slug, display name).

        ``total_hint`` is the "page N of M" text (1 when absent) and is only a
        hint; ``next_href`` is the real next link.
        """
        soup = BeautifulSoup(html or "", "html.parser")
        content = soup.select_one("#content") or soup
        entries = []
        for anchor in content.select("a[href]"):
            href = (anchor.get("href") or "").strip()
            match = _INDEX_SLUG.match(href)
            if not match or href.startswith("/index") or href.endswith(".php"):
                continue
            display = anchor.get_text(" ", strip=True)
            if display:
                entries.append((match.group(1), display))
        text = content.get_text(" ", strip=True)
        found = _INDEX_PAGES_OF.search(text)
        return entries, int(found.group(1)) if found else 1, TheLayoffIndex.next_href(soup)

    def _capture_page(self, letter, page, url, status, body, state):
        """Save one already-fetched page and note it for the manifest (no new request)."""
        if self.capture_dir is None:
            return
        record = {"page": page, "url": url, "status": status, "path": None,
                  "sha256": None, "bytes": 0,
                  "fetched_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")}
        try:
            if body:
                raw = str(body).encode("utf-8")
                folder = self.capture_dir / letter
                folder.mkdir(parents=True, exist_ok=True)
                name = f"page-{page}.html"
                tmp = folder / (name + ".tmp")
                tmp.write_bytes(raw)
                os.replace(tmp, folder / name)
                record.update(path=f"{letter}/{name}", sha256=hashlib.sha256(raw).hexdigest(),
                              bytes=len(raw))
        except OSError as exc:
            state["capture_error"] = f"{type(exc).__name__}: {exc}"
        state.setdefault("records", []).append(record)

    def _write_manifest(self, letter, state):
        if self.capture_dir is None or not state.get("records"):
            return
        manifest = {"letter": letter, "base": self.base, "complete": state["complete"],
                    "stop": state["stop"], "note": state["note"],
                    "pages_parsed": state["pages"], "fetches": state["records"]}
        try:
            folder = self.capture_dir / letter
            folder.mkdir(parents=True, exist_ok=True)
            tmp = folder / "_manifest.json.tmp"
            tmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, folder / "_manifest.json")
        except OSError as exc:
            state["capture_error"] = f"{type(exc).__name__}: {exc}"

    def _crawl(self, letter):
        state = {"entries": [], "pages": 0, "hint": 0, "complete": False,
                 "stop": "", "note": "", "page": 0}
        seen_slugs, seen_urls = set(), set()
        url = f"{self.base}/index/{letter}"
        while True:
            page = state["pages"] + 1
            seen_urls.add(url.rstrip("/"))
            status, body = self._fetch(url)
            self._capture_page(letter, page, url, status, body, state)
            if status != 200 or not body or is_challenge(body):
                state.update(stop="page_error", page=page,
                             note=f"error at page {page} (HTTP {status})")
                return state
            entries, hint, nxt = self.parse_page(body)
            for entry in entries:
                if entry[0] not in seen_slugs:
                    seen_slugs.add(entry[0])
                    state["entries"].append(entry)
            state["pages"] = page
            state["hint"] = max(state["hint"], hint)
            if not nxt:
                state.update(complete=True, stop="no_next_page", page=page)
                return state
            nxt_url = urljoin(url, nxt)
            if nxt_url.rstrip("/") in seen_urls:
                state.update(stop="repeated_next_link", page=page,
                             note=f"repeated next link {nxt} at page {page}")
                return state
            if page >= self.max_pages:
                state.update(stop="page_cap", page=page,
                             note=f"cap at page {page} ({self.max_pages}-page cap; a next link remains)")
                return state
            url = nxt_url

    def letter(self, letter):
        with self._guard:
            lock = self._locks.setdefault(letter, threading.Lock())
        with lock:
            if letter not in self._letters:
                state = self._crawl(letter)
                self._write_manifest(letter, state)
                self._letters[letter] = state
            return self._letters[letter]

    def _keyed(self, state):
        """(slug, display, keys) per entry, computed once per letter."""
        if "keyed" not in state:
            state["keyed"] = [(entry_slug, display, board_keys(display))
                              for entry_slug, display in state["entries"]]
        return state["keyed"]

    @staticmethod
    def our_keys(names):
        return {key for name in names for key in board_keys(name)}

    @staticmethod
    def letters_for(names):
        first = {key[0] for key in TheLayoffIndex.our_keys(names) if key[:1].isalnum()}
        first |= {variant[0] for name in names for variant in name_variants(name)
                  if variant[:1].isalnum()}
        return sorted(first)

    def lookup(self, names):
        """Boards whose normalised key equals one of our normalised keys.

        Both sides use ``board_keys``: casefolded, "&" as "and", punctuation
        stripped, trailing corporate words and web-address tokens stripped
        iteratively, and a parenthetical read as a second name. The match must
        be exact; the caller refuses to choose when more than one board matches.

        Returns (matches, notes): matches maps slug -> display name; notes
        describes each letter read and any letter that could not be read fully.
        """
        wanted = self.our_keys(names)
        matches, notes = {}, []
        for letter in self.letters_for(names):
            state = self.letter(letter)
            if state.get("capture_error"):
                notes.append(f"index letter {letter.upper()} capture failed ({state['capture_error']}); "
                             f"the crawl itself was not affected")
            if state["complete"]:
                notes.append(f"index letter {letter.upper()}: {state['pages']} page(s) read "
                             f"until no next link remained")
            else:
                notes.append(f"index letter {letter.upper()} incomplete: {state['note']}; "
                             f"{state['pages']} page(s) read")
            for entry_slug, display, keys in self._keyed(state):
                if wanted & keys:
                    matches[entry_slug] = display
        return matches, notes

    @staticmethod
    def match_key(display, names):
        """The shared key that made ``display`` match one of ``names`` (for the receipt)."""
        shared = sorted(TheLayoffIndex.our_keys(names) & board_keys(display))
        return shared[0] if shared else ""

    def near_candidates(self, names, exclude=(), limit=NEAR_CANDIDATES):
        """The closest index entries by token overlap, for a person to check.

        Score is the best Jaccard overlap between the word sets of one of our
        keys and one of the entry's keys. These are never accepted as the board.
        Only letters already read are used (no extra fetch).
        """
        ours = [set(key.split()) for key in self.our_keys(names)]
        scored = []
        for letter in self.letters_for(names):
            state = self._letters.get(letter)
            if not state:
                continue
            for entry_slug, display, keys in self._keyed(state):
                if entry_slug in exclude:
                    continue
                best, shared = 0.0, 0
                for mine in ours:
                    for key in keys:
                        theirs = set(key.split())
                        common = mine & theirs
                        if not common:
                            continue
                        score = len(common) / len(mine | theirs)
                        if (score, len(common)) > (best, shared):
                            best, shared = score, len(common)
                if best > 0:
                    scored.append((-best, -shared, display.casefold(), entry_slug, display))
        scored.sort()
        return [(entry_slug, display, round(-score, 2))
                for score, _, _, entry_slug, display in scored[:limit]]

    def initials_candidates(self, names):
        """Boards whose name initials spell a short single-word name ("HP").

        Only letters already read are used. These are never accepted as the
        board; they are listed in the receipt so a person can check them.
        """
        out = {}
        skip = NAME_STOPWORDS | CORPORATE_SUFFIXES | TLD_TOKENS
        for name in names:
            tokens = name_tokens(name)
            word = tokens[0] if len(tokens) == 1 else ""
            if not (2 <= len(word) <= 5 and word.isalpha()):
                continue
            state = self._letters.get(word[0])
            if not state:
                continue
            for entry_slug, display, keys in self._keyed(state):
                for key in keys:
                    words = [w for w in key.split() if w not in skip]
                    if len(words) >= 2 and "".join(w[0] for w in words) == word:
                        out[entry_slug] = display
        return out


def resolve_board(channel_label, build_url, task, entries, first_url, fetch, index=None):
    """Find the real board for a company whose guessed slug returned 404.

    ``fetch(url)`` returns (body, status). Returns a dict with ``found`` and
    either the located board (url, body, via) or the evidence that none was
    found: the alias slugs tried, any index result, and candidates when the
    index named several boards.
    """
    names = candidate_names(task, entries)
    first_slug = urlparse(first_url).path.rstrip("/").rsplit("/", 1)[-1]
    tried = [(first_url, 404)]
    slugs = alias_slugs(names, exclude={first_slug})
    for value in slugs:
        url = build_url(value)
        body, status = fetch(url)
        tried.append((url, status))
        if status == 200 and body and not is_challenge(body):
            return {"found": True, "url": url, "body": body, "via": "alias_slug",
                    "tried": tried, "names": names, "notes": []}
        if status != 404:
            break
    notes = []
    candidates = {}
    similar = {}
    near = []
    unreadable = None
    if index is not None and tried[-1][1] == 404:
        matches, notes = index.lookup(names)
        similar = {slug_: shown for slug_, shown in index.initials_candidates(names).items()
                   if slug_ not in matches}
        if len(matches) == 1:
            value, display = next(iter(matches.items()))
            url = build_url(value)
            body, status = fetch(url)
            tried.append((url, status))
            key = index.match_key(display, names) if hasattr(index, "match_key") else ""
            if status == 200 and body and not is_challenge(body):
                warn = (f" (short key {key!r}: verify the board is this employer)"
                        if key and len(key.replace(" ", "")) <= 4 else "")
                return {"found": True, "url": url, "body": body, "via": "site_index",
                        "tried": tried, "names": names,
                        "notes": notes + [f"index entry {display!r} -> {value} "
                                          f"(exact key {key!r}){warn}"]}
            unreadable = (value, display, status)
        else:
            candidates = matches
        near = index.near_candidates(names, exclude=set(matches)) if hasattr(index, "near_candidates") else []
    return {"found": False, "tried": tried, "names": names, "notes": notes,
            "candidates": candidates, "similar": similar if index is not None else {},
            "near": near, "unreadable": unreadable,
            "index_used": index is not None}


def unresolved_board_basis(channel_label, resolution):
    """stop_basis for a board that could not be located; names every slug tried."""
    tried = "; ".join(f"{url} -> HTTP {status}" for url, status in resolution["tried"])
    names = ", ".join(repr(name) for name in resolution["names"])
    parts = [f"{channel_label} returned 404 for the guessed address, so the board could not be "
             f"located and no coverage is claimed for this employer. Names tried: {names}. "
             f"Addresses tried: {tried}."]
    if resolution.get("index_used"):
        parts.append("Site index lookup: " + ("; ".join(resolution["notes"]) or "no letter read") + ".")
        if resolution.get("candidates"):
            listed = ", ".join(f"{display} ({value})" for value, display
                               in sorted(resolution["candidates"].items()))
            parts.append(f"The index named several boards and none was chosen: {listed}.")
        incomplete = [note for note in resolution["notes"] if "incomplete" in note]
        if incomplete:
            parts.append("The index lookup is INCOMPLETE (" + "; ".join(incomplete) + "), so this "
                         "is not a full index miss and the board may exist.")
        elif resolution.get("unreadable"):
            value, display, status = resolution["unreadable"]
            parts.append(f"The index names exactly one board, {display} ({value}), but fetching it "
                         f"returned HTTP {status}, so it could not be read.")
        elif not resolution.get("candidates"):
            parts.append("No index entry matched any of those names.")
        if resolution.get("similar"):
            listed = ", ".join(f"{display} ({value})" for value, display
                               in sorted(resolution["similar"].items()))
            parts.append(f"Boards whose initials match the name but which were not accepted: {listed}.")
        if resolution.get("near"):
            listed = "; ".join(f"{display} ({value}, overlap {score})"
                               for value, display, score in resolution["near"])
            parts.append(f"Closest index entries by word overlap, not accepted: {listed}.")
    else:
        parts.append("This channel has no index to search.")
    parts.append(f"Recorded as {UNRESOLVED_REASON} (blocked), not as 'no board exists'.")
    return " ".join(parts)


class Channel:
    """One tracker or filing source, fetched per company."""

    def __init__(self, name, label, build_url, parse):
        self.name = name
        self.label = label
        self.build_url = build_url
        self.parse = parse


def parse_thelayoff(html, company, window):
    """Rows from a thelayoff.com company board.

    Raw board HTML uses <article class="post topic"> with a <time datetime>
    and h2.post-title. The previous splitter ("•••") was the share-button
    label, and the date regex required "Month D, YYYY by" which does not
    appear as adjacent text in the markup, so a real board (e.g. Fisker)
    parsed as zero posts.
    """
    soup = BeautifulSoup(html or "", "html.parser")
    articles = soup.select("#posts article.post, #posts article, article.post")
    rows, seen = [], set()
    for article in articles:
        title_el = article.select_one("h2.post-title a, h2.post-title")
        if not title_el:
            continue
        title = title_el.get_text(" ", strip=True)[:180]
        href = ""
        if title_el.name == "a":
            href = title_el.get("href") or ""
        if not href:
            link = article.select_one("a.thread-link, a[href^='/t/']")
            href = (link.get("href") if link else "") or ""
        href = href.split("#")[0]
        if href.startswith("/"):
            url = "https://www.thelayoff.com" + href
        elif href.startswith("http"):
            url = href
        else:
            url = "https://www.thelayoff.com/" + slug(company)
        if url in seen:
            continue
        seen.add(url)
        body_el = article.select_one(".post-body")
        body = (body_el.get_text(" ", strip=True) if body_el else "")[:600]
        iso = ""
        time_el = article.select_one("span.post-timeago time[datetime], span.post-timeago time, time[datetime], time")
        if time_el is not None:
            raw = (time_el.get("datetime") or time_el.get("dateTime")
                   or time_el.get_text(" ", strip=True) or "")
            iso, _ = parse_reported_date(raw[:10] if re.match(r"^\d{4}-\d{2}-\d{2}", raw) else raw)
        if not iso:
            match = re.search(
                r"\b(January|February|March|April|May|June|July|August|September|October|"
                r"November|December)\s+(\d{1,2}),\s+(20\d\d)",
                article.get_text(" ", strip=True), re.I)
            if match:
                iso, _ = parse_reported_date(match.group(0))
        if iso:
            inside = window[0] <= iso <= window[1]
            reason = "" if inside else "outside_window"
        else:
            inside = False
            reason = "unparseable_date"
        relevant = bool(inside and REDUCTION.search(f"{title} {body}"))
        if relevant:
            reason = ""
        elif inside:
            reason = "no_reduction_stated"
        rows.append({
            "url": url,
            "title": title or f"Post on the {company} board dated {iso or 'an unknown date'}",
            "reported_date": iso,
            "relevant": relevant,
            "exclusion_reason": reason,
        })
    return rows


THELAYOFF_MAX_PAGES = 150
THELAYOFF_STOP_NO_NEXT = "no_next_page"
THELAYOFF_STOP_WINDOW = "window_boundary"
THELAYOFF_STOP_CAP = "page_cap"
THELAYOFF_STOP_PARTIAL = "later_page_error"
THELAYOFF_STOP_CF = "cloudflare_403_later_page"
THELAYOFF_STOP_403 = "http_403_later_page"
THELAYOFF_STOP_CHALLENGE = "browser_challenge_later_page"
THELAYOFF_STOP_LAYOUT = "layout_unrecognized"
THELAYOFF_TRANSIENT_BACKOFF = (5.0, 15.0)


def next_thelayoff_url(html, current_url):
    """Absolute URL of the board's real next-page link, or empty.

    TheLayoff boards do not use rel=next. Older topics live in
    ``ul.pager li.next a[href="/{slug}?page=N"]``.
    """
    soup = BeautifulSoup(html or "", "html.parser")
    link = (soup.select_one("ul.pager li.next a[href]")
            or soup.select_one("li.next a[href]")
            or soup.select_one('a[rel="next"]'))
    href = (link.get("href") or "").strip() if link else ""
    if not href:
        return ""
    nxt = urljoin(current_url, href)
    if nxt.rstrip("/") == (current_url or "").rstrip("/"):
        return ""
    return nxt


def oldest_thelayoff_date(hits):
    dates = [hit["reported_date"] for hit in hits if hit.get("reported_date")]
    return min(dates) if dates else None


def thelayoff_stop_condition(code, pages_reviewed, detail=""):
    """A specific coverage stop_condition (>=15 chars) naming the stop that fired."""
    text = (f"TheLayoff.com window_sweep stopped at {code} after "
            f"{pages_reviewed} page(s) reviewed")
    if detail:
        text += f": {detail}"
    return text + "."


def thelayoff_window_sweep_fields(pages_reviewed, stop_condition,
                                 oldest_post_date_reached=None,
                                 later_page_retries=0):
    """Receipt fields required for a window_sweep coverage record."""
    try:
        retries = int(later_page_retries or 0)
    except (TypeError, ValueError):
        retries = 0
    if retries < 0:
        retries = 0
    return {
        "search_scope": "window_sweep",
        "pages_reviewed": pages_reviewed,
        "stop_condition": stop_condition,
        "oldest_post_date_reached": oldest_post_date_reached,
        "later_page_retries": retries,
        "window_sweep": {
            "pages_reviewed": pages_reviewed,
            "stop_condition": stop_condition,
            "oldest_post_date_reached": oldest_post_date_reached,
            "later_page_retries": retries,
        },
    }


def thelayoff_outcome(stop_code):
    """Seed outcome for a TheLayoff window_sweep stop.

    ``window_boundary`` and ``no_next_page`` are complete coverage of the
    requested window or of the board. A page cap reached while the board is
    still in-window, or any later-page error other than a Cloudflare/403
    refusal, is truncated collection (``partial``). A Cloudflare challenge
    or HTTP 403 on a later page is a named access limitation (``blocked``),
    which the schema allows to carry the hits already inspected.
    """
    if stop_code in {THELAYOFF_STOP_CF, THELAYOFF_STOP_403, THELAYOFF_STOP_CHALLENGE}:
        return "blocked"
    if stop_code in {THELAYOFF_STOP_CAP, THELAYOFF_STOP_PARTIAL, THELAYOFF_STOP_LAYOUT}:
        return "partial"
    return "completed"


def thelayoff_stop_basis(url, hits, pages_reviewed, stop_condition, stop_code,
                         oldest_post_date_reached=None):
    """stop_basis for a TheLayoff sweep; blocked CF cases include the token."""
    relevant = sum(1 for hit in hits if hit.get("relevant"))
    oldest_note = (
        f" oldest_post_date_reached={oldest_post_date_reached}."
        if oldest_post_date_reached else
        " No dated post was reached."
    )
    if hits:
        basis = (f"TheLayoff.com was fetched at {url} and every post on the "
                 f"{pages_reviewed} reviewed board page(s) was inspected; "
                 f"{relevant} post(s) name this employer with a reduction inside "
                 f"the window. {stop_condition}{oldest_note}")
    else:
        basis = (f"TheLayoff.com was fetched at {url} and the board carries no "
                 f"post for this employer inside the requested window. "
                 f"{stop_condition}{oldest_note}")
    if stop_code in {THELAYOFF_STOP_CF, THELAYOFF_STOP_403, THELAYOFF_STOP_CHALLENGE}:
        basis += " " + stop_code
    if thelayoff_outcome(stop_code) == "partial":
        basis += " The window_sweep is truncated and remains partial."
    return basis


def is_cloudflare_later_page(status, body):
    """True when a later board page is refused: an HTTP 403 or a challenge page.

    The name is kept for existing callers; whether the refusal is Cloudflare is
    decided separately by ``later_page_block_code``.
    """
    if status == 403:
        return True
    return is_challenge(body)


def later_page_block_code(status, body):
    """The stop code for a refused later page; Cloudflare only on its markers."""
    if has_cloudflare_markers(body):
        return THELAYOFF_STOP_CF
    if status == 403:
        return THELAYOFF_STOP_403
    return THELAYOFF_STOP_CHALLENGE


def count_thelayoff_articles(html):
    """Number of post <article> elements on a board page."""
    soup = BeautifulSoup(html or "", "html.parser")
    return len(soup.select("#posts article.post, #posts article, article.post"))


def parse_thelayoff_backoff(value=None):
    """Parse a later-page retry backoff (default two waits: 5s then 15s)."""
    if value is None or value == "":
        return THELAYOFF_TRANSIENT_BACKOFF
    if isinstance(value, (list, tuple)):
        parts = list(value)
    else:
        parts = [part for part in str(value).replace(";", ",").split(",") if part.strip()]
    try:
        delays = tuple(float(part) for part in parts)
    except (TypeError, ValueError) as exc:
        raise ValueError("thelayoff transient backoff must be seconds, e.g. 5,15") from exc
    if not delays or any(delay < 0 for delay in delays):
        raise ValueError("thelayoff transient backoff must be non-negative seconds")
    return delays


def is_transient_later_page_error(status, exc=None):
    """Timeout, connection error, HTTP 429 or 5xx (including _plain_get status 0)."""
    if exc is not None:
        if isinstance(exc, (TimeoutError, ConnectionError, OSError)):
            return True
        name = type(exc).__name__.lower()
        if "timeout" in name or "connection" in name:
            return True
        try:
            import requests
            if isinstance(exc, requests.RequestException):
                return True
        except ImportError:
            pass
        return False
    return status in (0, 429) or status >= 500


def collect_thelayoff_pages(company, window, start_url, first_body, fetch,
                            sleeper=None, pace=0.15, max_pages=THELAYOFF_MAX_PAGES,
                            transient_backoff=None):
    """Parse the first board page, then follow next-page links with the same fetch path.

    Stops when the oldest post on a page is older than window[0] (typically
    2019-01-01), when the page has no next link, when ``max_pages`` is reached,
    or when a later page fails. A later-page Cloudflare challenge or HTTP 403
    is not retried and records ``cloudflare_403_later_page``. Other 4xx are
    not retried. A timeout, connection error, or HTTP 5xx is retried with
    backoff (default 5s then 15s, twice) and, if it still fails, records
    ``later_page_error``. Earlier hits are kept in both cases. Posts are
    deduped by URL across pages. ``fetch(url)`` returns ``(body, status)``.
    """
    sleeper = time.sleep if sleeper is None else sleeper
    try:
        cap = int(max_pages)
    except (TypeError, ValueError):
        cap = THELAYOFF_MAX_PAGES
    cap = max(1, cap)
    try:
        backoff = parse_thelayoff_backoff(transient_backoff)
    except ValueError:
        backoff = THELAYOFF_TRANSIENT_BACKOFF
    hits, seen = [], set()
    later_page_retries = 0
    pages_reviewed = 0
    url, body = start_url, first_body
    stop_code = THELAYOFF_STOP_NO_NEXT
    detail = ""
    while True:
        page_hits = parse_thelayoff(body, company, window)
        if (not page_hits and not count_thelayoff_articles(body)
                and not EMPTY_BOARD.search(body or "")):
            # A 200 page with no posts and without the site's own empty-board
            # sentence is a parser or layout problem, not an empty board.
            pages_reviewed += 1
            stop_code = THELAYOFF_STOP_LAYOUT
            detail = (f"page {pages_reviewed} has no post articles and no empty-board "
                      f"marker, so the page layout was not recognised")
            break
        for hit in page_hits:
            key = hit.get("url") or ""
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            hits.append(hit)
        pages_reviewed += 1
        oldest = oldest_thelayoff_date(page_hits)
        if oldest is not None and oldest < window[0]:
            stop_code = THELAYOFF_STOP_WINDOW
            detail = (f"oldest post on page {pages_reviewed} dated {oldest} "
                      f"is older than {window[0]}")
            break
        nxt = next_thelayoff_url(body, url)
        if not nxt:
            stop_code = THELAYOFF_STOP_NO_NEXT
            detail = f"page {pages_reviewed} has no next-page link"
            break
        if pages_reviewed >= cap:
            stop_code = THELAYOFF_STOP_CAP
            detail = f"reached --thelayoff-max-pages={cap}"
            break
        if pace and pace > 0:
            sleeper(pace)
        next_body, status, page_retries, last_exc = "", 0, 0, None
        while True:
            try:
                next_body, status = fetch(nxt)
                last_exc = None
            except Exception as exc:  # noqa: BLE001 — maybe retry transients
                last_exc = exc
                next_body, status = "", 0
            if last_exc is None and is_cloudflare_later_page(status, next_body):
                break
            if last_exc is None and 400 <= status < 500 and status != 429:
                break
            if (last_exc is None and next_body and status == 200
                    and not is_challenge(next_body)):
                break
            if (is_transient_later_page_error(status, last_exc)
                    and page_retries < len(backoff)):
                sleeper(backoff[page_retries])
                page_retries += 1
                continue
            break
        later_page_retries += page_retries
        if last_exc is None and next_body and status == 200 and not is_challenge(next_body):
            url, body = nxt, next_body
            continue
        if last_exc is not None:
            stop_code = THELAYOFF_STOP_PARTIAL
            detail = (f"page {pages_reviewed + 1} raised {type(last_exc).__name__}"
                      f"{' after ' + str(page_retries) + ' retries' if page_retries else ''}"
                      f"; posts from {pages_reviewed} earlier page(s) were kept")
        elif is_cloudflare_later_page(status, next_body):
            stop_code = later_page_block_code(status, next_body)
            what = ("a Cloudflare challenge or 403 (Cloudflare markers present)"
                    if stop_code == THELAYOFF_STOP_CF else
                    "an HTTP 403 without Cloudflare markers"
                    if stop_code == THELAYOFF_STOP_403 else
                    "a browser challenge page")
            detail = (f"page {pages_reviewed + 1} failed (HTTP {status}) "
                      f"with {what}; posts from "
                      f"{pages_reviewed} earlier page(s) were kept")
        else:
            stop_code = THELAYOFF_STOP_PARTIAL
            detail = (f"page {pages_reviewed + 1} failed (HTTP {status})"
                      f"{' after ' + str(page_retries) + ' retries' if page_retries else ''}"
                      f"; posts from {pages_reviewed} earlier page(s) were kept")
        break
    oldest_reached = oldest_thelayoff_date(hits)
    return (hits, pages_reviewed,
            thelayoff_stop_condition(stop_code, pages_reviewed, detail),
            stop_code, oldest_reached, later_page_retries)


def parse_none(html, company, window):
    """A channel that exposes no per-company rows to an unauthenticated fetch."""
    return []


CHANNELS = {
    "layoffs_fyi": Channel(
        "layoffs_fyi", "Layoffs.fyi",
        lambda company: "https://layoffs.fyi/",
        parse_none),
    "trueup": Channel(
        "trueup", "TrueUp Tech Layoffs Tracker",
        lambda company: "https://www.trueup.io/co/" + slug(company),
        parse_none),
    "thelayoff": Channel(
        "thelayoff", "TheLayoff.com",
        lambda company: "https://www.thelayoff.com/" + slug(company),
        parse_thelayoff),
}


FILING_REDUCTION = re.compile(
    r"\b(?:lay[ -]?offs?|laid off|reduction(?:s)? in force|workforce reductions?|"
    r"reduc(?:e|ed|ing) (?:our |its |the )?workforce|job cuts?|"
    r"severance|redundancy (?:costs?|payments?))\b", re.I)


def filing_hits(work, company_id, window):
    """Screen registered issuer reports and retain coverage for every document."""
    work = Path(work)
    try:
        registered = json.loads((work / "sources.json").read_text(encoding="utf-8"))["sources"]
    except (OSError, ValueError, KeyError, TypeError):
        return "blocked", "The workspace source manifest could not be read.", [], []
    reports = [row for row in registered
               if row.get("company_id") == company_id and row.get("active", True)
               and row.get("document_role") in {"annual_report", "annual_financials"}]
    if not reports:
        return ("not_applicable", "No annual report is registered for this company in "
                "the workspace source inventory.", [], [])

    hits, coverage = [], []
    unreadable = 0
    for report in reports:
        url = report.get("source_url") or ""
        address = urlparse(url)
        publication = (report.get("publication_date") or "")[:10]
        try:
            publication = date.fromisoformat(publication).isoformat()
        except ValueError:
            publication = ""
        fy = report.get("fy")
        record = {"source_id": report["source_id"], "url": url, "fy": fy,
                  "publication_date": publication, "source_status": report["status"],
                  "text_path": report.get("text_path"), "text_sha256": report.get("text_sha256")}
        coverage.append(record)
        if (publication and not window[0] <= publication <= window[1]) or (
                fy is not None and str(fy) < window[0][:4]):
            record["screen"] = "outside_window_or_identity_only"
            continue
        if str(fy) == window[1][:4] and not publication:
            record["screen"] = "publication_date_unverified"
            unreadable += 1
            continue
        if report["status"] != "ready" or address.scheme not in {"http", "https"} or not address.netloc:
            record["screen"] = "unavailable"
            unreadable += 1
            continue
        try:
            normalized = sources.text_for(work, report)
        except (OSError, ValueError, KeyError) as exc:
            record["screen"] = "text_unavailable"
            record["error"] = type(exc).__name__
            unreadable += 1
            continue
        match = FILING_REDUCTION.search(normalized)
        record["screen"] = "reduction_keyword" if match else "no_reduction_keyword"
        if match:
            record["matched_text"] = normalized[max(0, match.start() - 70):match.end() + 100]
        form = report.get("form") or "annual report"
        label = f"FY{fy} {form}" if fy else form
        hits.append({"url": url, "title": f"{label} issuer report",
                     "reported_date": publication, "relevant": bool(match),
                     "exclusion_reason": "" if match else "no_reduction_keyword"})
    stop = (f"Registered issuer reports screened: {len(hits)} readable, {unreadable} "
            f"unavailable, {len(reports) - len(hits) - unreadable} outside the window "
            "or identity-only. Keyword matches are leads requiring source review.")
    return ("blocked" if unreadable else "completed"), stop, hits, coverage


def load_rendered_table(work, channel_name):
    """A tracker table already rendered by render_table.py, keyed by company.

    Layoffs.fyi publishes its table through an embedded Airtable view, so a
    plain fetch returns no rows. `render_table.py` renders it with a browser and
    writes the rows here; this function turns them into per-company candidates.

    The table columns are the ones the site shows: company, HQ, headcount,
    date, percentage, industry, source URL.
    """
    path = Path(work) / "discovery/captures/seed" / channel_name / "_table.json"
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None
    by_company = {}
    for row in payload.get("rows", []):
        cells = row.get("cells") or {}

        def cell(index):
            return str(((cells.get(str(index)) or {}).get("t") or "")).strip()

        name = cell(0)
        if not name:
            continue
        by_company.setdefault(name.casefold(), []).append({
            "company": name,
            "date": cell(3),
            "count": cell(2),
            "percentage": cell(4),
            "source": cell(6),
            "industry": cell(5),
        })
    return {"by_company": by_company, "row_count": len(payload.get("rows", [])),
            "row_count_label": payload.get("row_count_label", "")}


def table_rows_for(table, company, aliases, window):
    """Turn the rendered rows for one employer into seed hits."""
    if not table:
        return None
    names = {str(company).casefold()} | {str(a).casefold() for a in (aliases or []) if a}
    rows = []
    for key in names:
        rows.extend(table["by_company"].get(key, []))
    hits = []
    for row in rows:
        iso, date_error = parse_reported_date(row["date"])
        inside = bool(iso) and window[0] <= iso <= window[1]
        source = row["source"] if row["source"].startswith("http") else ""
        if date_error:
            relevant, reason = False, "unparseable_date"
        elif not inside:
            relevant, reason = False, "outside_window"
        elif not source:
            relevant, reason = False, "no_source_link"
        else:
            relevant, reason = True, ""
        hit = {"url": source or "https://layoffs.fyi/",
               "title": (f"{row['company']} listed on Layoffs.fyi with "
                         f"{row['count'] or 'an unstated number of'} layoff(s)"
                         + (f", {row['percentage']}" if row["percentage"] else "")),
               "reported_date": iso,
               "relevant": relevant,
               "exclusion_reason": reason}
        if date_error:
            # Keep the raw text visible without breaking the ISO-only
            # reported_date contract: the hit is flagged, not dropped.
            hit["date_unparseable"] = True
            hit["reported_date_raw"] = row["date"]
            hit["title"] += f" (date as listed: {row['date'] or 'blank'!r})"
        if row["count"]:
            hit["reported_count"] = row["count"]
        if row["percentage"]:
            hit["reported_pct"] = row["percentage"]
        hits.append(hit)
    return hits


def _render_fallback(work, channel_name, url, company, aliases, window, status):
    """Try a real browser when the plain fetch is refused or returns a shell.

    A tracker that serves a JavaScript grid or a bot challenge is not
    unreadable, it just needs to be rendered the way a reader would see it. This
    is what makes the sweep unattended: the collector escalates to a browser on
    its own instead of leaving the channel blocked for a human to retry.
    """
    rendered = None
    try:
        rendered = render_table.render(url)
    except Exception:  # noqa: BLE001
        return None
    if not rendered or not rendered.get("rows"):
        return None
    path = Path(work) / "discovery/captures/seed" / channel_name
    path.mkdir(parents=True, exist_ok=True)
    if not (path / "_table.json").is_file():
        (path / "_table.json").write_text(
            json.dumps(rendered, ensure_ascii=False), encoding="utf-8")
    table = load_rendered_table(work, channel_name)
    if table is None:
        return None
    hits = table_rows_for(table, company, aliases, window) or []
    return {"hits": hits, "row_count": table["row_count"],
            "row_count_label": table["row_count_label"]}


def capture_path(work, channel, company_id, body):
    """Save the raw payload inside the workspace and return its relative path."""
    folder = Path(work) / "discovery/captures/seed" / channel
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / (company_id + ".html")
    path.write_text(body, encoding="utf-8")
    return str(path.relative_to(Path(work).resolve()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--pace", type=float, default=0.15)
    parser.add_argument("--only-channel", default="")
    parser.add_argument("--rerun-issuer-report", action="store_true",
                        help="Refresh the issuer-report part after syncing new filings.")
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--host-confirm-attempts", type=int,
                        default=HOST_CONFIRM_ATTEMPTS,
                        help="Spaced HTTP attempts before a host is treated as persistently blocked")
    parser.add_argument("--host-confirm-interval", type=float,
                        default=HOST_CONFIRM_INTERVAL,
                        help="Seconds between host-confirmation attempts (default 600, ~20 min for 3 tries)")
    parser.add_argument("--thelayoff-max-pages", type=int,
                        default=THELAYOFF_MAX_PAGES,
                        help="Maximum TheLayoff.com board pages to follow per company (default 150)")
    parser.add_argument("--thelayoff-transient-backoff",
                        default="5,15",
                        help="Seconds to wait before each later-page retry of a "
                             "timeout, connection error, or HTTP 5xx (default 5,15)")
    parser.add_argument("--no-thelayoff-index", dest="thelayoff_index", action="store_false",
                        help="Do not crawl TheLayoff.com's A-Z company index to find a board "
                             "whose guessed slug returned 404")
    parser.add_argument("--thelayoff-index-capture-dir", default="",
                        help="Directory for the TheLayoff index pages this run fetches "
                             "(default: <work>/discovery/captures/seed/thelayoff/_index)")
    parser.add_argument("--thelayoff-index-max-pages", type=int,
                        default=THELAYOFF_INDEX_PAGES_MAX,
                        help="Maximum index pages followed per letter (default 300); a letter that "
                             "reaches it is recorded as incomplete")
    args = parser.parse_args()
    if args.rerun_issuer_report:
        if args.only_channel and args.only_channel != "issuer_report":
            parser.error("--rerun-issuer-report only supports the issuer_report channel")
        args.only_channel = "issuer_report"

    work = Path(args.work).resolve()
    plan_path = work / "discovery/seed-plan.json"
    if not plan_path.is_file():
        raise SystemExit("Run seed-plan first; this executor does not invent tasks.")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    tasks = plan["tasks"]
    if args.only_channel:
        tasks = [t for t in tasks if t["channel"] == args.only_channel]
    if args.limit:
        tasks = tasks[:args.limit]

    receipts_path = work / "discovery/seed-receipts.json"
    done = {}
    if receipts_path.is_file():
        done = json.loads(receipts_path.read_text(encoding="utf-8"))
    if not args.rerun_issuer_report:
        tasks = [t for t in tasks if t["task_id"] not in done]
    if not tasks:
        print("nothing to execute; every planned seed task already has a receipt")
        return 0

    registry_entries = {}
    registry_file = work / "registry/entities.json"
    if registry_file.is_file():
        try:
            payload = json.loads(registry_file.read_text(encoding="utf-8"))
            registry_entries = payload.get("entries", payload)
        except Exception:  # noqa: BLE001
            registry_entries = {}
    thelayoff_index = None
    if args.thelayoff_index:
        def fetch_index_page(page_url):
            status, body = 0, ""
            for attempt in range(3):
                status, body = _plain_get(page_url)
                if status == 200 or status in (403, 404, 410):
                    break
                if attempt < 2:
                    time.sleep(min(max(args.pace, 0), 2.0))
            return status, body
        capture_dir = (Path(args.thelayoff_index_capture_dir) if args.thelayoff_index_capture_dir
                       else work / "discovery/captures/seed/thelayoff/_index")
        thelayoff_index = TheLayoffIndex(fetch_index_page,
                                         max_pages=args.thelayoff_index_max_pages,
                                         capture_dir=capture_dir)

    lock = threading.Lock()
    batch = []
    stats = {"completed": 0, "blocked": 0, "partial": 0, "not_applicable": 0, "relevant": 0}
    PACER.configure(args.pace)
    host_blocker = HostBlocker(attempts=args.host_confirm_attempts,
                               interval=args.host_confirm_interval)

    # One fetch of a whole-tracker page serves every company on that tracker.
    shared = {}
    shared_lock = threading.Lock()
    # A channel whose browser render keeps returning nothing is refusing the
    # whole site, not one board. Continuing to launch a browser per company
    # would spend the rest of the round proving the same point.
    render_failures = {}
    render_lock = threading.Lock()
    render_budget = 6

    def may_render(channel_name):
        with render_lock:
            return render_failures.get(channel_name, 0) < render_budget

    def note_render(channel_name, ok):
        with render_lock:
            if ok:
                render_failures[channel_name] = 0
            else:
                render_failures[channel_name] = render_failures.get(channel_name, 0) + 1

    def fetch_shared(channel_name, url):
        """Fetch a page once per URL, without rotating an exit or waiting 90s.

        A shared tracker URL is memoized. Persistent Cloudflare 403s are
        confirmed by HostBlocker, not by egress rotation.
        """
        with shared_lock:
            if url in shared:
                return shared[url]
        body, status = "", 0
        for attempt in range(4):
            status, body = _plain_get(url)
            if body and status == 200 and not is_challenge(body):
                break
            # A hard block (403/404) is an answer, not a transport failure.
            if status in (403, 404, 410):
                break
            if attempt < 3:
                time.sleep(min(max(args.pace, 0), 2.0))
        with shared_lock:
            shared[url] = (body, status)
        return body, status

    def execute(task):
        channel_name = task["channel"]
        window = (task["window_start"], task["window_end"])
        company = task["company"]
        executed_at = dt.datetime.now().date().isoformat()
        sweep_fields = None

        if channel_name == "issuer_report":
            outcome, stop, hits, coverage = filing_hits(work, task["company_id"], window)
            capture = json.dumps({"stop_basis": stop, "reports": coverage, "hits": hits},
                                 ensure_ascii=False, indent=2)
            filename = task["company_id"] + "-" + hashlib.sha256(
                capture.encode("utf-8")).hexdigest()[:16]
            relative = capture_path(work, channel_name, filename, capture)
            receipt = _receipt(task, executed_at, outcome, stop, relative, hits, stats, lock, batch)
            if outcome == "blocked":
                receipt["reason"] = "issuer_report_unavailable"
            return receipt

        channel = CHANNELS[channel_name]
        url = channel.build_url(company)
        host = (urlparse(url).hostname or "").lower()
        if host_blocker.is_blocked(host):
            outcome = "blocked"
            hits = []
            reason = host_blocker.reason(host)
            stop = (f"{channel.label} was not fetched at {url} because {host} was already "
                    f"confirmed as {reason}: {host_blocker.describe(host)}. Remaining "
                    f"companies on this host are recorded as blocked, not as zero-result "
                    f"completions.")
            relative = capture_path(work, channel_name, task["company_id"], stop)
            receipt = _receipt(task, executed_at, outcome, stop, relative, hits, stats, lock, batch)
            receipt["reason"] = reason
            return receipt
        # A tracker whose table is rendered to JSON is read from that table.
        table = load_rendered_table(work, channel_name)
        if table is not None:
            hits = table_rows_for(table, company, task.get("aliases"), window) or []
            relevant = sum(1 for hit in hits if hit["relevant"])
            outcome = "completed"
            stop = (f"{channel.label} was rendered to {table['row_count']} row(s) "
                    f"(the page reports {table['row_count_label'] or 'an unstated count'}); "
                    f"{len(hits)} row(s) name this employer and {relevant} of them fall inside "
                    f"the window with a source link.")
            relative = capture_path(work, channel_name, task["company_id"],
                                    json.dumps(hits, ensure_ascii=False))
            return _receipt(task, executed_at, outcome, stop, relative, hits, stats, lock, batch)
        body, status = fetch_shared(channel_name, url)
        resolution_note = ""
        resolution = None
        if status == 404:
            # R-14: slug(company) is a guess. Look for the real board before
            # deciding there is none.
            def fetch_slug(candidate_url):
                got_body, got_status = fetch_shared(channel_name, candidate_url)
                return got_body, got_status
            resolution = resolve_board(
                channel.label, lambda value: channel.build_url(value), task,
                registry_entries, url, fetch_slug,
                index=thelayoff_index if channel_name == "thelayoff" else None)
            if resolution["found"]:
                url, body, status = resolution["url"], resolution["body"], 200
                host = (urlparse(url).hostname or host).lower()
                resolution_note = (f"The guessed address returned 404; the board was found at "
                                   f"{url} via {resolution['via']} "
                                   f"({'; '.join(resolution['notes']) or 'alias slug'}).")
        challenge = is_challenge(body)
        reason = ""
        if status == 404:
            # No board was found after alias and index attempts. That is not
            # "no board exists": the receipt is not completed. It is blocked
            # with a named reason, which seed-status surfaces as a seed_blocked
            # gap (a contract gap discovery can pass), with every slug tried.
            outcome = UNRESOLVED_OUTCOME
            hits = []
            reason = UNRESOLVED_REASON
            stop = unresolved_board_basis(channel.label, resolution)
        elif not body or status != 200 or challenge:
            # Escalate to a real browser before declaring the channel blocked:
            # a challenge or a script shell is a rendering problem, not a dead
            # source, and resolving it here is what keeps the sweep unattended.
            # A Cloudflare 403 is already a host-level refusal; do not spend a
            # browser launch per company before the spaced confirmation runs.
            rendered = None
            render_attempted = False
            if status != 403 and may_render(channel_name):
                render_attempted = True
                rendered = (_render_fallback(work, channel_name, url, company,
                                             task.get("aliases"), window, status))
                note_render(channel_name, bool(rendered))
            if rendered:
                outcome = "completed"
                hits = rendered["hits"]
                stop = (f"{channel.label} answered with a script-only page or a challenge at "
                        f"{url}, so it was rendered in a browser: {rendered['row_count']} "
                        f"row(s) were read (the page reports "
                        f"{rendered['row_count_label'] or 'an unstated count'}) and "
                        f"{len(hits)} name this employer.")
            else:
                outcome = "blocked"
                hits = []
                persistent = False
                kind = refusal_kind(status, body)
                if kind in HOST_REFUSALS:
                    persistent = host_blocker.confirm(host, url, first_kind=kind)
                tried = ("a browser render returned no rows" if render_attempted
                         else "no browser render was attempted")
                if persistent:
                    reason = host_blocker.reason(host)
                    stop = (f"{channel.label} at {url} was refused: "
                            f"{host_blocker.describe(host)}; the host is recorded as "
                            f"{reason} and remaining companies on {host} are blocked "
                            f"rather than retried.")
                elif challenge:
                    stop = (f"{channel.label} answered with a browser challenge for {url} and "
                            f"{tried}, so the board could not be read in this round.")
                elif status == 403:
                    stop = (f"{channel.label} answered HTTP 403 for {url} on a plain request "
                            f"and a later spaced request to {host} was not refused; {tried}, "
                            f"so this board could not be read in this round.")
                else:
                    stop = (f"{channel.label} returned no readable body for {url} "
                            f"(HTTP {status}) and {tried}; the board could not be "
                            f"inspected in this round.")
        else:
            hits = channel.parse(body, company, window)
            if not hits and JS_TABLE.search(body):
                # The tracker is a shell around an embedded, client-rendered
                # table. Reporting "completed, nothing found" would be false.
                rendered = (_render_fallback(work, channel_name, url, company,
                                             task.get("aliases"), window, status)
                            if may_render(channel_name) else None)
                note_render(channel_name, bool(rendered))
                if rendered:
                    outcome = "completed"
                    hits = rendered["hits"]
                    stop = (f"{channel.label} serves its table from an embedded client-side "
                            f"view at {url}; a browser render read {rendered['row_count']} "
                            f"row(s) (the page reports "
                            f"{rendered['row_count_label'] or 'an unstated count'}) and "
                            f"{len(hits)} name this employer.")
                else:
                    outcome = "blocked"
                    stop = (f"{channel.label} serves its table from an embedded client-side "
                            f"view at {url}; an unauthenticated fetch receives the page shell "
                            f"and a browser render returned no rows.")
            elif channel_name == "thelayoff":
                def fetch_later_page(page_url):
                    # One attempt via the same _plain_get path. Later-page
                    # transient retries (5s, then 15s) live in
                    # collect_thelayoff_pages so a cached 5xx cannot swallow them.
                    status, payload = _plain_get(page_url)
                    return payload, status
                try:
                    backoff = parse_thelayoff_backoff(args.thelayoff_transient_backoff)
                except ValueError:
                    backoff = THELAYOFF_TRANSIENT_BACKOFF
                hits, pages_reviewed, stop_condition, stop_code, oldest_reached, later_retries = (
                    collect_thelayoff_pages(
                        company, window, url, body,
                        fetch=fetch_later_page,
                        sleeper=time.sleep, pace=args.pace,
                        max_pages=args.thelayoff_max_pages,
                        transient_backoff=backoff))
                sweep_fields = thelayoff_window_sweep_fields(
                    pages_reviewed, stop_condition, oldest_reached,
                    later_page_retries=later_retries)
                outcome = thelayoff_outcome(stop_code)
                stop = thelayoff_stop_basis(
                    url, hits, pages_reviewed, stop_condition, stop_code,
                    oldest_reached)
            else:
                outcome = "completed"
                if hits:
                    stop = (f"{channel.label} was fetched at {url} and every post on the board "
                            f"was inspected; {sum(1 for h in hits if h['relevant'])} post(s) "
                            f"name this employer with a reduction inside the window.")
                else:
                    stop = (f"{channel.label} was fetched at {url} and the board carries no "
                            f"post for this employer inside the requested window.")
        if resolution_note:
            stop = stop + " " + resolution_note
        relative = capture_path(work, channel_name, task["company_id"], body or stop)
        receipt = _receipt(task, executed_at, outcome, stop, relative, hits, stats, lock, batch)
        if sweep_fields:
            receipt.update(sweep_fields)
        if reason:
            receipt["reason"] = reason
        return receipt

    print(f"executing {len(tasks)} seed task(s) across "
          f"{len({t['channel'] for t in tasks})} channel(s)", flush=True)
    with cf.ThreadPoolExecutor(args.workers) as pool:
        list(pool.map(execute, tasks))
    _flush(work, args.out, batch)
    print(json.dumps(stats, ensure_ascii=False))
    return 0


def _receipt(task, executed_at, outcome, stop_basis, relative, hits, stats, lock, batch):
    receipt = {"task_id": task["task_id"], "executed_at": executed_at,
               "outcome": outcome, "stop_basis": stop_basis,
               "result_path": relative, "hits": hits}
    if outcome == "not_applicable":
        receipt["applicability_basis"] = stop_basis
    with lock:
        batch.append(receipt)
        stats[outcome] = stats.get(outcome, 0) + 1
        stats["relevant"] += sum(1 for hit in hits if hit.get("relevant"))
    return receipt


def _flush(work, out, batch):
    path = Path(out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(batch, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
