#!/usr/bin/env python3
"""Read a page the way a reader sees it, through a real browser.

Some pages deliver their content only after JavaScript runs: a search engine
that wraps its result addresses, an aggregator that renders the publisher's
link in place, a tracker that hides a table behind a script. A plain HTTP
fetch receives the shell.

This module renders a page in headless Chrome over the DevTools protocol and
returns the resulting document, so the caller can read the links the reader
would see. It reuses the same protocol client the table renderer uses.

Usage:

    python "$S/scripts/render_page.py" --url "<url>" --out /tmp/page.html
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from render_table import WS, chrome_path  # noqa: E402


def render_html(url, port=9355, profile="/tmp/chrome-page-profile", settle=6.0,
                wait_for=None, timeout=45, proxy=None):
    """Render `url` and return the document's HTML.

    `wait_for` is an optional substring; the page is given extra time until
    it appears, which matters for a page that fills its results in stages.
    """
    binary = chrome_path()
    if not binary:
        raise RuntimeError("No Chrome/Chromium/Edge binary found; cannot render the page")
    subprocess.run(["rm", "-rf", profile], check=False)
    # The browser must leave through the same exit address as the fetches, or
    # a page it cannot reach is a page the run must not record as read.
    proxy_arg = ["--proxy-server=" + proxy] if proxy else []
    process = subprocess.Popen(
        [binary, "--headless=new", "--no-sandbox", "--disable-dev-shm-usage",
         "--disable-gpu", "--window-size=1400,2200",
         f"--remote-debugging-port={port}", f"--user-data-dir={profile}",
         "--no-first-run", "--disable-extensions", "--disable-popup-blocking",
         "--disable-background-timer-throttling",
         "--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
         "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36",
         "about:blank"] + proxy_arg,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        target = None
        for _ in range(80):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/json", timeout=2) as reply:
                    pages = [t for t in json.load(reply) if t.get("type") == "page"]
                if pages:
                    target = pages[0]["webSocketDebuggerUrl"]
                    break
            except Exception:  # noqa: BLE001
                time.sleep(0.5)
        if not target:
            raise RuntimeError("no debuggable page")
        sock = WS(target)
        sock.call("Page.enable")
        sock.call("Runtime.enable")
        sock.call("Network.enable")
        sock.call("Page.navigate", url=url)
        deadline = time.time() + timeout
        body = ""
        while time.time() < deadline:
            time.sleep(1.0)
            result = sock.call("Runtime.evaluate",
                               expression="document.documentElement.outerHTML",
                               returnByValue=True)
            body = ((result or {}).get("result") or {}).get("value") or ""
            if body and (not wait_for or wait_for in body):
                break
        return body
    finally:
        try:
            process.terminate()
            process.wait(timeout=10)
        except Exception:  # noqa: BLE001
            try:
                process.kill()
            except Exception:  # noqa: BLE001
                pass
        subprocess.run(["rm", "-rf", profile], check=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True)
    parser.add_argument("--out", default="")
    parser.add_argument("--wait-for", default="")
    parser.add_argument("--settle", type=float, default=6.0)
    args = parser.parse_args()

    html = render_html(args.url, settle=args.settle, wait_for=args.wait_for or None)
    if args.out:
        Path(args.out).write_text(html, encoding="utf-8")
        print(f"rendered {len(html)} bytes to {args.out}")
    else:
        print(html[:4000])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
