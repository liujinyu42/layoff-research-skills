"""Tests for locating a Chrome binary on Linux and via CHROME_PATH."""
from __future__ import annotations

import os
import unittest
from unittest import mock

import render_table


class ChromePathTests(unittest.TestCase):
    def test_chrome_path_env_wins_when_the_file_exists(self):
        with mock.patch.dict(os.environ, {"CHROME_PATH": "/tmp/custom-chrome"}), \
             mock.patch("os.path.exists", side_effect=lambda p: p == "/tmp/custom-chrome"), \
             mock.patch("shutil.which", return_value=None):
            self.assertEqual(render_table.chrome_path(), "/tmp/custom-chrome")

    def test_linux_names_are_resolved_on_path(self):
        def which(name):
            return "/usr/bin/google-chrome-stable" if name == "google-chrome-stable" else None
        with mock.patch.dict(os.environ, {"CHROME_PATH": ""}, clear=False):
            os.environ.pop("CHROME_PATH", None)
            with mock.patch("os.path.exists", return_value=False), \
                 mock.patch("shutil.which", side_effect=which):
                self.assertEqual(render_table.chrome_path(), "/usr/bin/google-chrome-stable")

    def test_mac_paths_are_still_tried(self):
        mac = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("CHROME_PATH", None)
            with mock.patch("shutil.which", return_value=None), \
                 mock.patch("os.path.exists", side_effect=lambda p: p == mac):
                self.assertEqual(render_table.chrome_path(), mac)

    def test_missing_override_falls_through(self):
        with mock.patch.dict(os.environ, {"CHROME_PATH": "/no/such/chrome"}), \
             mock.patch("os.path.exists", return_value=False), \
             mock.patch("shutil.which", return_value=None):
            self.assertIsNone(render_table.chrome_path())


if __name__ == "__main__":
    unittest.main()
