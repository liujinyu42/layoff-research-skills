#!/usr/bin/env python3
"""Re-judge recorded discovery hits against the global event window.

The executor judges each hit against the *event* window, not the year of the
query that returned it (see collect_discovery). This repair exists for
workspaces written by an earlier release, where a 2024 article returned for a
2019 query was recorded as "outside the event window".

It re-runs the same relevance rules with the global window from the workspace
configuration, flips only the hits that genuinely qualify, records why every
hit was kept or dropped, and can import the corrected batch in one step.

Usage:
  python3 repair_discovery_window.py --work WORK [--batch discovery/google-batch.json]
                                     [--out qa/google-batch-corrected.json] [--import]
"""
import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
SCRIPTS = HERE.parent
SKILL = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

from collect_discovery import hit_relevant, is_generic  # noqa: E402
from researchcore.discovery import _aliases  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--batch", default="discovery/google-batch.json")
    parser.add_argument("--out", default="qa/google-batch-corrected.json")
    parser.add_argument("--import-results", dest="do_import", action="store_true",
                        help="import the corrected batch through the normal entry point")
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    config_path = work / args.config
    if not config_path.is_file():
        raise SystemExit("Workspace configuration is missing: " + str(config_path))
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    roster = {row["company_id"]: row for row in cfg.get("roster", [])}
    window_start = str(cfg.get("event_start") or "")
    window_end = str(cfg.get("event_end") or "")
    if not window_start or not window_end:
        raise SystemExit("event_start/event_end must be set in the workspace configuration")

    batch_path = work / args.batch
    if not batch_path.is_file():
        raise SystemExit("Discovery batch is missing: " + str(batch_path))
    batch = json.loads(batch_path.read_text(encoding="utf-8"))

    flipped = dropped = 0
    per_company = {}
    for item in batch:
        company = roster.get(item.get("company_id"))
        if not company:
            continue
        aliases = _aliases(company)
        generic = any(is_generic(alias) for alias in aliases)
        for hit in item.get("hits") or []:
            relevant, reason = hit_relevant(
                hit.get("title", ""), aliases, generic,
                publisher=hit.get("publisher", ""),
                reported_date=hit.get("reported_date", ""),
                window_start=window_start, window_end=window_end)
            was = bool(hit.get("relevant"))
            if relevant and not was:
                flipped += 1
                per_company[item["company_id"]] = per_company.get(item["company_id"], 0) + 1
            if relevant is False and was:
                dropped += 1
            hit["relevant"] = bool(relevant)
            hit["window_basis"] = "global"
            hit["exclusion_reason"] = "" if relevant else (
                reason or "the hit does not meet the relevance rules")

    out_path = work / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(batch, ensure_ascii=False), encoding="utf-8")
    print(f"window: {window_start}..{window_end}")
    print(f"flipped to relevant: {flipped} (across {len(per_company)} companies)")
    print(f"dropped from relevant: {dropped}")
    print("top gainers:", sorted(per_company.items(), key=lambda kv: -kv[1])[:12])

    if args.do_import:
        sys.path.insert(0, str(SCRIPTS))
        from researchcore.workflow import main as workflow_main  # noqa: PLC0415
        code = workflow_main(SKILL, ["discovery-import", "--work", str(work),
                                     "--file", str(out_path)])
        return code if isinstance(code, int) else 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
