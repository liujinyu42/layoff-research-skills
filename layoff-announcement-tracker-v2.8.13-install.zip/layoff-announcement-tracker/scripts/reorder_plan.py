#!/usr/bin/env python3
"""Reorder the discovery plan so the terms that find events run first.

The sweep asks every company and year about every term. The terms are not
equally productive: "redundancies" finds more than two relevant articles per
query, while "team cuts" finds none at all. Running the plan in term order
therefore spends most of its budget on the terms that never pay, and the
companies with no coverage stay uncovered until the very end.

This tool rewrites the plan order without changing a single query. The
receipt contract is unaffected: every task keeps its identity, its query and
its scope, and only the order in which they are attempted changes. A run
that is interrupted still resumes at the same place.

The order is:

1. the terms with the highest observed yield, so the coverage floor rises
   fastest;
2. the seed verification, once the productive terms have run, because a
   verified seed is what turns a tracker entry into evidence;
3. the low-yield terms last, where they still run but they no longer delay
   the companies that were about to be covered.
"""

import argparse
import json
from pathlib import Path

# Observed relevant articles per completed task, measured on the first pass
# of this run. The order is what matters here, not the exact figure.
YIELD_ORDER = [
    ("broad_news", "redundancies"),
    ("broad_news", "job cuts"),
    ("alternative_news", "restructuring"),
    ("alternative_news", "laid off"),
    ("broad_news", "layoffs"),
    ("alternative_news", "cuts jobs"),
    ("unit_notice", "local layoffs"),
    ("unit_notice", "layoff notice"),
    ("alternative_news", "job losses"),
    ("official_notice", "announcement"),
    ("unit_notice", "WARN"),
    ("official_notice", "notice"),
    ("alternative_news", "staff cuts"),
    ("official_notice", "filing"),
    ("official_notice", "statement"),
    ("unit_notice", "team cuts"),
]

RANK = {key: index for index, key in enumerate(YIELD_ORDER)}
SEED_RANK = len(YIELD_ORDER) + 1


def task_rank(task):
    family = task.get("family", "")
    if family == "seed_verification":
        return (SEED_RANK, 0)
    term = task.get("term", "")
    return (RANK.get((family, term), len(YIELD_ORDER) - 1), 0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    plan_path = work / "discovery/plan.json"
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    tasks = plan["tasks"]

    before = [t["task_id"] for t in tasks]
    ordered = sorted(tasks, key=task_rank)
    after = [t["task_id"] for t in ordered]

    moved = sum(1 for a, b in zip(before, after) if a != b)
    print(f"tasks: {len(tasks)} | reordered positions: {moved}")
    if args.dry_run:
        for task in ordered[:5]:
            print(f"  {task['family']:18s}{task.get('term', ''):16s} {task['query'][:56]}")
        return 0

    if [t["task_id"] for t in tasks] != after:
        plan["tasks"] = ordered
        plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=1),
                             encoding="utf-8")
        print(f"plan written to {plan_path}")
    else:
        print("plan already in yield order")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
