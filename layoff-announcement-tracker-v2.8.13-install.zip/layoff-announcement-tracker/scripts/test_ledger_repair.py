"""Regressions for the source-ledger damage an incremental ingest caused.

Registering newly resolved publisher addresses through a manifest that lists
only those addresses retired the entire existing corpus, because `ingest()`
writes back every source the manifest does not carry as inactive. The entity
list is derived from the active sources, so all 836 event entities vanished
at once and the audit reported an empty workspace instead of a damaged one.

These tests reproduce the damage on a synthetic workspace and check that the
bundled repair restores the corpus, keeps the plan bindings that are still
live, and does not resurrect a plan the runtime retired.
"""
import csv
import json
import shutil
import tempfile
import unittest
from pathlib import Path

from researchcore import sources as source_module
from researchcore import workflow as wf

import repair_source_ledger
import reseal_decisions

SKILL = Path(__file__).resolve().parents[1]

MANIFEST_FIELDS = ["source_id", "company_id", "source_type", "source_url",
                    "local_path", "document_role", "fy", "plan_id",
                    "publication_date", "source_date", "exchange", "form",
                    "source_language"]


def row(source_id, company_id, plan_id="", url=None):
    record = {field: "" for field in MANIFEST_FIELDS}
    record.update({
        "source_id": source_id,
        "company_id": company_id,
        "source_type": "news",
        "source_url": url or f"https://example.test/{source_id}",
        "document_role": "news_report",
        "plan_id": plan_id,
        "source_language": "en",
    })
    return record


class LedgerRepairTests(unittest.TestCase):
    def setUp(self):
        self.work = Path(tempfile.mkdtemp())
        (self.work / "qa").mkdir()
        (self.work / "config.json").write_text(json.dumps({
            "version": "2.6.1", "mode": "events",
            "roster": [{"company_id": "acme-1", "company": "Acme"}],
            "year_start": 2020, "year_end": 2026,
            "event_start": "2020-01-01", "event_end": "2026-09-30",
            "profile": "proposal-core", "contract_level": "strict",
        }), encoding="utf-8")
        (self.work / "qa/event-plans.json").write_text(json.dumps({
            "plans": [{"plan_id": "plan-live-1"}], "rejected": []}), encoding="utf-8")
        (self.work / "qa/retired-plans.json").write_text(
            json.dumps(["plan-retired-1"]), encoding="utf-8")
        self.manifest = self.work / "qa/full_manifest.csv"
        self.write_manifest([row("news-a", "acme-1", "plan-live-1"),
                             row("news-b", "acme-1", "plan-live-1")])

    def tearDown(self):
        shutil.rmtree(self.work, ignore_errors=True)

    def write_manifest(self, rows):
        with self.manifest.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=MANIFEST_FIELDS)
            writer.writeheader()
            for record in rows:
                writer.writerow(record)

    def read_ledger(self):
        payload = json.loads((self.work / "sources.json").read_text(encoding="utf-8"))
        return {entry["source_id"]: entry for entry in payload["sources"]}

    def test_incremental_ingest_keeps_the_existing_corpus(self):
        """The previous behaviour retired it; only a full replacement may."""
        source_module.ingest(self.work, self.manifest, offline=True, refresh=False)
        incremental = self.work / "qa/incremental.csv"
        self.write_manifest([row("news-new", "acme-1", "plan-live-1")])
        shutil.copy(self.manifest, incremental)
        source_module.ingest(self.work, incremental, offline=True, refresh=False)
        ledger = self.read_ledger()
        self.assertTrue(ledger["news-new"]["active"])
        self.assertTrue(ledger["news-a"]["active"])
        self.assertTrue(ledger["news-b"]["active"])
        self.assertEqual(ledger["news-a"]["plan_id"], "plan-live-1")
        # Only an explicit full replacement may retire a source.
        source_module.ingest(self.work, incremental, offline=True, refresh=False,
                             retire_missing=True)
        retired = self.read_ledger()
        self.assertFalse(retired["news-a"]["active"])
        self.assertTrue(retired["news-a"]["retired_from_manifest"])

    def test_repair_recovers_the_retired_corpus(self):
        source_module.ingest(self.work, self.manifest, offline=True, refresh=False)
        # A ledger damaged by the previous release: the incremental manifest
        # listed only the new row and the ledger wrote the rest back as
        # inactive and absent from the manifest.
        damaged = self.read_ledger()
        for source_id in ("news-a", "news-b"):
            damaged[source_id]["active"] = False
            damaged[source_id]["retired_from_manifest"] = True
        (self.work / "sources.json").write_text(
            json.dumps({"version": "1.5.0", "sources": list(damaged.values())}),
            encoding="utf-8")
        self.write_manifest([row("news-new", "acme-1", "plan-live-1")])

        report = self.repair()
        self.assertEqual(report["recovered"], 2)
        ledger = self.read_ledger()
        self.assertTrue(ledger["news-a"]["active"])
        self.assertTrue(ledger["news-b"]["active"])

    def test_repair_does_not_resurrect_a_retired_plan(self):
        rows = [row("news-a", "acme-1", "plan-live-1"),
                row("news-c", "acme-1", "plan-retired-1")]
        self.write_manifest(rows)
        source_module.ingest(self.work, self.manifest, offline=True, refresh=False)
        self.repair()
        ledger = self.read_ledger()
        self.assertEqual(ledger["news-a"]["plan_id"], "plan-live-1")
        self.assertEqual(ledger["news-c"]["plan_id"], "")

    def test_repair_restores_the_snapshot_address(self):
        """A row without its snapshot address hashes differently, and every
        decision bound to that source is then reported as stale."""
        rows = [row("news-a", "acme-1", "plan-live-1")]
        rows[0]["local_path"] = ""
        self.write_manifest(rows)
        source_module.ingest(self.work, self.manifest, offline=True, refresh=False)
        ledger = self.read_ledger()
        ledger["news-a"]["local_path"] = "/workspace/text/news-a/x.txt"
        (self.work / "sources.json").write_text(
            json.dumps({"version": "1.5.0", "sources": list(ledger.values())}),
            encoding="utf-8")

        self.repair()
        repaired = self.read_ledger()
        self.assertEqual(repaired["news-a"]["local_path"], "/workspace/text/news-a/x.txt")

    def repair(self):
        argv = ["--work", str(self.work), "--manifest", "qa/full_manifest.csv",
                "--output", "qa/full_manifest_repaired.csv"]
        import sys
        original = sys.argv
        sys.argv = ["repair_source_ledger.py"] + argv
        try:
            repair_source_ledger.main()
        finally:
            sys.argv = original
        return json.loads((self.work / "qa/ledger-repair-report.json").read_text(encoding="utf-8"))


class StaleDecisionTests(unittest.TestCase):
    def test_reseal_reports_nothing_when_the_ledger_is_unchanged(self):
        work = Path(tempfile.mkdtemp())
        try:
            (work / "qa").mkdir()
            (work / "decisions.json").write_text("{}", encoding="utf-8")
            book = json.loads((SKILL / "assets" / "event_schema.json").read_text(encoding="utf-8"))
            (work / "config.json").write_text(json.dumps({
                "version": "2.6.1", "mode": "events",
                "roster": [{"company_id": "acme-1", "company": "Acme"}],
                "year_start": 2020, "year_end": 2026,
                "event_start": "2020-01-01", "event_end": "2026-09-30",
                "profile": "proposal-core", "contract_level": "strict",
                "schema_sha256": wf.digest(book),
                "presentation_language": book.get("presentation_language"),
            }), encoding="utf-8")
            (work / "sources.json").write_text(json.dumps({
                "version": "1.5.0", "sources": []}), encoding="utf-8")
            import sys
            original = sys.argv
            sys.argv = ["reseal_decisions.py", "--work", str(work), "--dry-run"]
            try:
                reseal_decisions.main()
            finally:
                sys.argv = original
        finally:
            shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
