#!/usr/bin/env python3
"""Resolve aggregator links to the publisher's own article page.

A news aggregator link such as `news.google.com/rss/articles/CBMi...` carries
an opaque, encrypted article id. Fetching it returns a script shell, and the
publisher's address is not recoverable from the response body, so such a hit
cannot be registered as a source: the shell's text is the aggregator's menu,
not the employer's statement.

The link is not a dead end, though. The feed that produced it also records
the publisher's display name and the publisher's own domain, and it records
the article's title. The domain plus the title locates the article on the
publisher's site, and that page is the real evidence.

Three strategies are tried, cheapest first:

1. **The publisher's own search.** WordPress sites answer
   `/wp-json/wp/v2/search?search=<term>&per_page=N` with the article's own
   URL, and most news publishers run WordPress.
2. **The publisher's sitemap.** A site map index points at dated sitemaps
   that list every article URL on the site.
3. **A site-scoped search engine query.** A `site:` query against the
   publisher's domain returns the article URL directly.

The result is recorded with the strategy that produced it, so a reader can
see how the publisher's address was recovered rather than being asked to
trust it.

Usage:

    python "$S/scripts/resolve_publishers.py" --work "$W"
    python "$S/scripts/resolve_publishers.py" --work "$W" --limit 50
"""
from __future__ import annotations

import argparse
import gzip
import concurrent.futures
import csv
import json
import re
import sys
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote_plus, urldefrag, urlparse

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore.egress import Egress  # noqa: E402

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36")

AGGREGATOR_HOST = "news.google.com"


def read_csv(path):
    path = Path(path)
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_json(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=1), encoding="utf-8")


def is_aggregator(url):
    host = (urlparse(url).hostname or "").lower()
    return host == AGGREGATOR_HOST or host.endswith("." + AGGREGATOR_HOST)


def slug_words(title):
    """The distinctive words of a title, without the publisher suffix."""
    text = re.sub(r"\s+-\s+[^-]{2,40}$", "", title or "").strip()
    text = re.sub(r"[^0-9A-Za-z一-鿿 ]+", " ", text)
    words = [w for w in text.split() if len(w) > 2]
    return words[:6]


def title_matches(page_title, wanted):
    """Whether a candidate page carries the article's distinctive words.

    Numbers written with a thousands separator split into fragments that are
    not words ("5,000" -> "000"), so a fragment that is only digits is not
    counted. The comparison is over the words that actually distinguish one
    article from another.
    """
    def normalise(value):
        text = re.sub(r"[^0-9A-Za-z一-鿿 ]+", " ", (value or "").lower())
        return re.sub(r"\s+", " ", text).strip()

    haystack = normalise(page_title)
    # A number written with a thousands separator is not a word: the
    # normalisation splits it into fragments, so counting it would ask the
    # page to carry a fragment that the title never had as a word.
    needle = [w.lower() for w in wanted
              if not re.sub(r"[^0-9]", "", w)]
    if not needle:
        return False
    hits = sum(1 for word in needle if word in haystack)
    # Every distinguishing word has to be present. A search endpoint returns
    # whatever it thinks is close, and a page that carries two of the title's
    # words is often a different article about a different subject: a
    # picture gallery that mentions the same company is not the report about
    # that company's reduction.
    return hits == len(needle)


def wordpress_search(session, domain, words, timeout=(5, 20)):
    """Ask a WordPress site for its own articles.

    Two endpoints answer the same question. A site that serves its REST API
    under `/wp-json/` answers there; a site that only exposes the route
    query form answers `/?rest_route=`. The second form works on hosts where
    the first is refused, so both are tried.
    """
    query = quote_plus(" ".join(words[:4]))
    roots = [domain]
    if domain.startswith("www."):
        roots.append(domain[4:])
    elif not domain.startswith("www."):
        roots.append("www." + domain)
    for root in roots:
        if not root:
            continue
        for template in ("https://{root}/wp-json/wp/v2/search?search={q}&per_page=10",
                         "https://{root}/?rest_route=/wp/v2/search&search={q}&per_page=10"):
            url = template.format(root=root, q=query)
            try:
                response = session.get(url, timeout=timeout)
            except Exception:  # noqa: BLE001
                continue
            if response.status_code != 200:
                continue
            body = response.text.strip()
            if not body.startswith("["):
                continue
            try:
                payload = response.json()
            except ValueError:
                continue
            if not isinstance(payload, list):
                continue
            out = []
            for item in payload:
                if isinstance(item, dict) and item.get("url"):
                    out.append({"url": item["url"], "title": item.get("title", "")})
            if out:
                return out
    return []


def publisher_wordpress(session, domain, words, timeout=(5, 20), endpoint=None):
    """The publisher's own articles that carry the title's words."""
    if endpoint:
        query = quote_plus(" ".join(words[:4]))
        base = endpoint.split("?")[0]
        url = f"{base}?search={query}&per_page=10"
        try:
            response = session.get(url, timeout=timeout)
        except Exception:  # noqa: BLE001
            return
        if response.status_code != 200:
            return
        body = response.text.strip()
        if not body.startswith("["):
            return
        try:
            payload = response.json()
        except ValueError:
            return
        if not isinstance(payload, list):
            return
        for item in payload:
            if isinstance(item, dict) and item.get("url") and is_article_address(item["url"]):
                yield item
        return
    for root in (domain, "www." + domain):
        if not root:
            continue
        for item in wordpress_search(session, root, words, timeout):
            if is_article_address(item["url"]):
                yield item


def is_article_address(url):
    """Whether an address points at an article rather than at a home page.

    A publisher's home page is not the source of an announcement. An address
    that carries no article path — no date, no slug, no identifier — is the
    publisher's front door and must never be recorded as the source.
    """
    text = str(url or "")
    if not text.startswith("http"):
        return False
    tail = text.split("://", 1)[-1].split("/", 1)[-1] if "/" in text.split("://", 1)[-1] else ""
    if not tail:
        return False
    segments = [segment for segment in tail.split("/") if segment]
    if len(segments) == 0:
        return False
    # A dated path, a numeric identifier or a multi-word slug all identify an
    # article. A single bare segment is a section, not an article.
    if any(segment.isdigit() for segment in segments):
        return True
    if len(segments) >= 2:
        return True
    last = segments[-1].lower()
    if last.endswith((".html", ".htm", ".php", ".shtml")):
        return True
    # A publisher that puts the whole slug in one segment still writes an
    # article address: the slug carries several words joined by hyphens.
    # A single bare word is a section, but a single hyphenated phrase with
    # several words in it is an article.
    if "-" in last and len(last.split("-")) >= 3:
        return True
    return False


def sitemap_urls(session, domain, timeout=(4, 12), limit=150):
    """Collect the article URLs a site map index lists.

    The site's own `robots.txt` is read first, because that is where a site
    declares its site maps, and a site that publishes no `/sitemap.xml` still
    usually names its maps there. The walk is bounded: a large publisher can
    publish tens of thousands of articles, and reading all of them to find one
    article costs more than the article is worth.
    """
    seeds = []
    for root in (domain, "www." + domain):
        seeds.append("https://%s/robots.txt" % root)
    for root in (domain, "www." + domain):
        seeds.append("https://%s/sitemap.xml" % root)
        seeds.append("https://%s/sitemap_index.xml" % root)
    queue = list(seeds)
    seen = set()
    urls = []
    while queue and len(urls) < limit:
        target = queue.pop(0)
        if target in seen:
            continue
        seen.add(target)
        try:
            response = session.get(target, timeout=timeout)
        except Exception:  # noqa: BLE001
            continue
        if response.status_code != 200:
            continue
        body = response.text
        if target.endswith("robots.txt"):
            for declared in re.findall(r"^\s*Sitemap:\s*(\S+)", body, re.I | re.M):
                if declared not in seen:
                    queue.append(declared)
            continue
        if "<sitemapindex" in body[:4000].lower():
            for child in re.findall(r"<loc>\s*([^<]+?)\s*</loc>", body):
                if child not in seen:
                    queue.append(child)
            continue
        for loc in re.findall(r"<loc>\s*([^<]+?)\s*</loc>", body):
            if loc.startswith("http"):
                urls.append(loc)
    return urls


def site_search(session, domain, words, timeout=(5, 20)):
    """A site-scoped query against the publisher's domain."""
    query = quote_plus(f'site:{domain} "{" ".join(words[:4])}"')
    url = f"https://www.bing.com/search?q={query}&count=20"
    try:
        response = session.get(url, timeout=timeout)
    except Exception:  # noqa: BLE001
        return []
    if response.status_code != 200:
        return []
    body = response.text
    out = []
    # Bing wraps the target address in a `u=` parameter whose value is the
    # base64url of the real URL.
    for match in re.finditer(r"[?&]u=a1([A-Za-z0-9_\-]+)", body):
        import base64
        import urllib.parse
        raw = urllib.parse.unquote(match.group(1))
        padded = "=" * (-len(raw) % 4)
        try:
            decoded = base64.urlsafe_b64decode(raw + padded).decode("utf-8", "ignore")
        except Exception:  # noqa: BLE001
            continue
        if decoded.startswith("http") and domain in decoded:
            out.append({"url": decoded, "title": ""})
    # Some responses place the address directly in the result markup.
    for match in re.finditer(r'href="(https?://[^"]*' + re.escape(domain) + r'[^"]*)"', body):
        out.append({"url": match.group(1), "title": ""})
    seen = set()
    unique = []
    for item in out:
        if item["url"] in seen:
            continue
        seen.add(item["url"])
        unique.append(item)
    return unique


def normalise_domain(value):
    """A bare host name, with any scheme or path removed."""
    text = str(value or "").strip()
    if not text:
        return ""
    if "//" not in text:
        text = "https://" + text
    host = urlparse(text).hostname or ""
    return host.lower()


def publisher_search(session, domain, title, timeout=(4, 15)):
    """Ask the news index for the publisher's own article.

    A query that names the publisher's domain and the article's own words
    returns that publisher's articles, and the feed records the domain on
    every one of them. That is how the index answers "which article on this
    publisher is this one", and it works for a publisher that has no search
    endpoint of its own.
    """
    words = slug_words(title)
    if not words:
        return []
    query = f'"{domain}" ' + " ".join(words[:4])
    url = ("https://news.google.com/rss/search?q=" + quote_plus(query) +
           "&hl=en-US&gl=US&ceid=US:en")
    try:
        response = session.get(url, timeout=timeout)
    except Exception:  # noqa: BLE001
        return []
    if response.status_code != 200:
        return []
    body = response.text
    if "automated queries" in body[:2000].lower():
        return []
    try:
        root = ET.fromstring(body)
    except ET.ParseError:
        return []
    out = []
    for node in root.iter("item"):
        title_node = node.find("title")
        text = (title_node.text or "") if title_node is not None else ""
        source_url = ""
        for src in node.iter("source"):
            if src.get("url"):
                source_url = src.get("url")
            break
        # The feed's `<source url>` is the publisher's own domain, not the
        # article's address. It can confirm that the index knows this article
        # and this publisher, but it is never the answer itself.
        if source_url and domain in source_url:
            out.append({"url": source_url, "title": text})
    return out


def _document_text(response):
    """The body of a response, decompressed when the publisher sends it so.

    A publisher that publishes tens of thousands of articles serves its site
    map compressed; reading it as text would find no addresses at all.
    """
    data = response.content
    if data[:2] == b"\x1f\x8b":
        try:
            data = gzip.decompress(data)
        except OSError:
            pass
    return data.decode("utf-8", "replace")


class DomainProfile:
    """What one publisher's site looks like, learned once and reused.

    A publisher that appears fifty times in the feed should cost one site
    survey, not fifty. The survey answers the structural questions — is this
    a WordPress site, does it publish a site map, does the site map carry
    modification dates — and every article of that publisher is then located
    against the same answer.
    """

    def __init__(self, session, domain, timeout=(4, 12), budget=20.0):
        self.session = session
        self.domain = domain
        self.timeout = timeout
        self.deadline = time.time() + budget
        self.wordpress = None
        self.entries = []
        self.slices = None
        self.walked = False

    def _expired(self):
        return time.time() > self.deadline

    def _probe_wordpress(self):
        """The publisher's WordPress endpoint, when it has one.

        A site that serves the REST API under `/wp-json/` answers there; a
        site that only exposes the route query form answers
        `/?rest_route=`. The endpoint that answers is remembered, so the
        article search does not have to find it again.
        """
        for root in (self.domain, "www." + self.domain):
            if not root:
                continue
            for template in ("https://{root}/wp-json/wp/v2/search?search=layoffs&per_page=1",
                             "https://{root}/?rest_route=/wp/v2/search&search=layoffs&per_page=1"):
                url = template.format(root=root)
                try:
                    response = self.session.get(url, timeout=self.timeout)
                except Exception:  # noqa: BLE001
                    continue
                if response.status_code != 200:
                    continue
                body = response.text.strip()
                if not body.startswith("["):
                    continue
                try:
                    payload = response.json()
                except ValueError:
                    continue
                if isinstance(payload, list):
                    return url
        return None

    def has_wordpress(self):
        return bool(self.wordpress_endpoint())

    def wordpress_endpoint(self):
        """The publisher's WordPress search endpoint, when it has one."""
        if self.wordpress is None:
            self.wordpress = self._probe_wordpress() or ""
        return self.wordpress or None

    def dated_sitemaps(self, year, month):
        """Site maps that a publisher splits by month.

        A publisher that files thousands of articles a month publishes its
        site map in dated slices, and a slice is named after the month it
        covers. The feed already says which month the article was reported,
        so the slice that could contain it can be asked for directly instead
        of walking the whole index.

        The naming conventions differ, so the publisher's own site map index
        is read first: a publisher that slices by month names that convention
        in the index it publishes, and the wanted slice can then be named
        from the same convention instead of guessed. Guessing costs one
        request per wrong guess, and a wrong guess is the common case.
        """
        if not year or not month:
            return []
        out = []
        seen = set()

        def fetch(url):
            if url in seen:
                return None
            seen.add(url)
            try:
                response = self.session.get(url, timeout=self.timeout)
            except Exception:  # noqa: BLE001
                return None
            if response.status_code != 200:
                return None
            locs = re.findall(r"<loc>\s*([^<]+?)\s*</loc>", _document_text(response))
            return locs or None

        # The publisher's own index names its slices. The slice wanted is the
        # one whose name carries the month and the year, or the month alone
        # when the publisher numbers its slices by month.
        month_names = {"01": "january", "02": "february", "03": "march",
                       "04": "april", "05": "may", "06": "june",
                       "07": "july", "08": "august", "09": "september",
                       "10": "october", "11": "november", "12": "december"}
        word = month_names.get(month, "")
        # The slice that names the year and the month exactly is the one
        # that holds the article. The index lists its slices newest first,
        # so taking the first slice that mentions the month would read the
        # wrong month of the right year. The year and the month are read as
        # a pair from the name rather than looked for as loose text: the
        # text "02" appears inside the name of the December slice too.
        exact = []
        for index_url, locs in self.index_slices():
            for loc in locs:
                stamped = re.search(r"/(\d{4})-(\d{2})\.xml$", loc.lower())
                if not stamped:
                    continue
                if stamped.group(1) == year and stamped.group(2) == month:
                    exact.append(loc)
        for loc in exact:
            found = fetch(loc)
            if found:
                out.append((loc, found))
                return out

        for index_url, locs in self.index_slices():
            for loc in locs:
                lowered = loc.lower()
                if year not in lowered:
                    # A slice named for a month without a year is only usable
                    # when the index itself is dated.
                    if not word or word not in lowered:
                        continue
                    if month not in lowered:
                        continue
                if month not in lowered and word not in lowered:
                    continue
                found = fetch(loc)
                if found:
                    out.append((loc, found))
                    return out

        patterns = [
            "news/archive/{y}/{m}.xml",
            "{y}/{m}/sitemap.xml",
            "sitemap/{y}/{m}.xml",
            "sitemap_{y}{m}.xml",
            "post-sitemap{y}{m}.xml",
            "news-sitemap-{y}-{m}.xml",
            "sitemap-{y}-{m}.xml",
        ]
        for root in (self.domain, "www." + self.domain):
            if not root:
                continue
            for pattern in patterns:
                path = pattern.format(y=year, m=month)
                found = fetch(f"https://{root}/{path.lstrip('/')}")
                if found:
                    out.append((f"https://{root}/{path.lstrip('/')}", found))
                    return out
        return out

    def index_slices(self):
        """The site map files the publisher's own index names."""
        if self.slices is not None:
            return self.slices
        self.slices = []
        seen = set()
        roots = []
        for root in (self.domain, "www." + self.domain):
            if root:
                roots.append(f"https://{root}/robots.txt")
                roots.append(f"https://{root}/sitemap.xml")
                roots.append(f"https://{root}/sitemap_index.xml")
        # A publisher names its own site maps in its robots file, and the
        # index that lists its dated slices is often at an address the
        # publisher chose itself rather than at one of the conventional
        # names above. Every map the robots file names is read, because that
        # is where the slice that holds an older article is listed.
        for root in (self.domain, "www." + self.domain):
            if not root:
                continue
            try:
                response = self.session.get(f"https://{root}/robots.txt",
                                            timeout=self.timeout)
            except Exception:  # noqa: BLE001
                continue
            if response.status_code != 200:
                continue
            for declared in re.findall(r"^\s*Sitemap:\s*(\S+)",
                                       _document_text(response), re.I | re.M):
                if declared not in roots:
                    roots.append(declared)
        for target in roots:
            if target in seen:
                continue
            seen.add(target)
            try:
                response = self.session.get(target, timeout=self.timeout)
            except Exception:  # noqa: BLE001
                continue
            if response.status_code != 200:
                continue
            body = _document_text(response)
            locs = re.findall(r"<loc>\s*([^<]+?)\s*</loc>", body)
            if target.endswith("robots.txt"):
                for declared in re.findall(r"^\s*Sitemap:\s*(\S+)", body, re.I | re.M):
                    self.slices.append((declared, []))
                continue
            if not locs:
                continue
            # A file that lists further files is an index; a file that lists
            # articles is a slice.
            if "<sitemapindex" in body[:4000].lower():
                self.slices.append((target, locs))
            else:
                self.slices.append((target, locs))
        return self.slices

    def site_map_entries(self):
        """The article URLs a site map lists, with their modification dates.

        The map is walked lazily: the caller stops as soon as it has found
        the article it wants, so a publisher with fifty thousand articles
        costs only the reading that was needed to find it. What was read is
        kept, so the publisher's second article starts from there.

        A publisher that publishes no site map at all is identified by its
        own robots file, which every publisher serves and which names the
        maps it has. Reading that one file is therefore the first step, and
        the guessed addresses are tried only when the publisher names no map.
        """
        if self.walked:
            yield from self.entries
            return
        seen = set()
        queue = []
        declared_maps = []
        for root in (self.domain, "www." + self.domain):
            queue.append(f"https://{root}/robots.txt")
        # The guessed addresses are only worth trying when the publisher's
        # own robots file names no map, so they wait until then.
        guessed = [f"https://{root}/sitemap.xml" for root in (self.domain, "www." + self.domain)]
        guessed += [f"https://{root}/sitemap_index.xml" for root in (self.domain, "www." + self.domain)]
        news_first = []
        while queue and len(self.entries) < 4000 and not self._expired():
            target = queue.pop(0)
            if target in seen:
                continue
            seen.add(target)
            try:
                response = self.session.get(target, timeout=self.timeout)
            except Exception:  # noqa: BLE001
                continue
            if response.status_code != 200:
                continue
            body = _document_text(response)
            if target.endswith("robots.txt"):
                for declared in re.findall(r"^\s*Sitemap:\s*(\S+)", body, re.I | re.M):
                    if declared not in seen:
                        declared_maps.append(declared)
                        news = bool(re.search(r"news|latest|article|post", declared, re.I))
                        if news:
                            news_first.append(declared)
                        else:
                            queue.append(declared)
                # A publisher that names its maps has no need of the guessed
                # addresses, and the guesses are the slow part.
                if declared_maps:
                    queue = news_first + queue
                else:
                    queue = news_first + guessed + queue
                continue
            if "<sitemapindex" in body[:4000].lower():
                for child in re.findall(r"<loc>\s*([^<]+?)\s*</loc>", body):
                    if child not in seen:
                        news = bool(re.search(r"news|latest|article|post", child, re.I))
                        if news:
                            news_first.append(child)
                        else:
                            queue.append(child)
                queue = news_first + queue
                continue
            fresh = []
            for block in re.findall(r"<url>(.*?)</url>", body, re.S):
                loc = re.search(r"<loc>\s*([^<]+?)\s*</loc>", block)
                if not loc:
                    continue
                stamp = re.search(r"<lastmod>\s*([^<]+?)\s*</lastmod>", block)
                fresh.append((loc.group(1), stamp.group(1) if stamp else ""))
            # A file that lists addresses without the `<url>` wrapper still
            # names its articles, so it is read as a flat list too.
            if not fresh:
                for loc in re.findall(r"<loc>\s*([^<]+?)\s*</loc>", body):
                    fresh.append((loc, ""))
                if fresh:
                    # A numbered shard holds more articles than the first
                    # one, so the next shard is worth reading.
                    sibling = self._next_shard(target)
                    if sibling and sibling not in seen:
                        queue.append(sibling)
                        seen.add(sibling)
            if fresh:
                self.entries.extend(fresh)
                yield from fresh
        self.walked = True

    @staticmethod
    def _next_shard(url):
        """The numbered shard that follows a shard in a numbered series.

        A publisher that splits its articles across numbered files writes the
        next one by raising the number in the name: `post-sitemap.xml` is
        followed by `post-sitemap2.xml`.
        """
        match = re.search(r"^(.*?)(\d+)(\.xml(?:\.gz)?)$", url)
        if not match:
            return None
        base, number, suffix = match.groups()
        if number == "0":
            return None
        return f"{base}{int(number) + 1}{suffix}"


def _words_in(text, words, minimum=2):
    haystack = " " + re.sub(r"[^0-9a-z一-鿿]+", " ", (text or "").lower()) + " "
    haystack = re.sub(r"\s+", " ", haystack)
    hits = 0
    for word in words:
        if word.lower() in haystack:
            hits += 1
    return hits >= minimum


def _distinctive(words, count=3):
    """The words that distinguish one article from another.

    A publisher's slug drops the words that carry no meaning and renames
    numbers, so a slug rarely reproduces the title word for word. The words
    that survive are the unusual ones: a company name, a place, a verb about
    employment. Those are the words worth matching on.
    """
    common = {"the", "a", "an", "and", "or", "but", "of", "in", "on", "at",
              "to", "for", "with", "by", "from", "as", "is", "are", "was",
              "were", "be", "been", "it", "its", "that", "this", "will",
              "has", "have", "had", "not", "but", "after", "over", "into",
              "says", "said", "new", "more", "than", "amid", "company",
              "employees", "jobs", "job", "layoffs", "layoff", "staff",
              "report", "reports", "reported", "what", "how", "why", "who",
              "when", "where", "know", "need", "here", "now", "year",
              "years", "week", "weeks", "month", "months", "day", "days",
              "here", "first", "last", "best", "top", "why", "does", "did",
              "can", "may", "might", "one", "two", "three", "four", "five",
              "six", "seven", "eight", "nine", "ten", "out", "up", "down",
              "off", "so", "just", "also", "its", "his", "her", "their",
              "you", "your", "we", "our", "they", "he", "she", "all", "some",
              "each", "other", "who", "why", "how", "what", "which"}
    keep = [word for word in words
            if word.lower() not in common and len(word) > 2 and not word.isdigit()]
    if not keep:
        keep = [word for word in words if len(word) > 2]
    return keep[:count] if keep else words[:count]


def _days_apart(first, second):
    """The distance in days between two dates, or a large number if unknown."""
    import datetime
    try:
        a = datetime.date.fromisoformat(first[:10])
        b = datetime.date.fromisoformat(second[:10])
    except (ValueError, TypeError):
        return 999
    return abs((a - b).days)


def resolve(session, domain, title, timeout=(4, 15), budget=30.0, profile=None,
            reported_date=""):
    """Return (url, strategy) for the publisher's article, or (None, reason).

    The strategies are ordered by cost and by how often they succeed. The
    publisher's own search answers in one request and is exact. A site map
    walk may read many files, so it is bounded and it is cached per domain.
    A site-scoped engine query is the last resort because it depends on a
    third party, and the news index is asked last of all because it shares
    its request quota with the sweep that is still running.

    `budget` is the total number of seconds this call may spend. A large
    publisher can publish tens of thousands of articles, and reading all of
    them to find one article costs more than the article is worth.
    """
    domain = normalise_domain(domain)
    if not domain:
        return None, "the feed recorded no publisher domain"
    words = slug_words(title)
    if not words:
        return None, "the title carries no distinctive words"

    deadline = time.time() + budget
    profile = profile or DomainProfile(session, domain, timeout, budget)

    # 0. The dated slice, addressed directly. A publisher that splits its
    #    site map by month names the slice after the month it covers, and
    #    that slice holds the article when the article was reported in that
    #    month. The name is derived from the date the feed recorded, so this
    #    costs one request and reads the right month directly.
    stamp = (reported_date or "").strip()[:10]
    if len(stamp) >= 7:
        slice_name = stamp[:7]
        for template in ("https://{root}/sitemap/{slice}.xml",
                         "https://{root}/sitemap/{slice}/sitemap.xml",
                         "https://{root}/news-sitemap-{slice}.xml",
                         "https://{root}/sitemap-{slice}.xml"):
            for root in (domain, "www." + domain):
                if not root:
                    continue
                url = template.format(root=root, slice=slice_name)
                try:
                    response = session.get(url, timeout=timeout)
                except Exception:  # noqa: BLE001
                    continue
                if response.status_code != 200:
                    continue
                for loc in re.findall(r"<loc>\s*([^<]+?)\s*</loc>",
                                      _document_text(response)):
                    if not is_article_address(loc):
                        continue
                    tail = loc.rstrip("/").rsplit("/", 1)[-1].lower()
                    if not _words_in(tail, _distinctive(words), minimum=2):
                        continue
                    return loc, "publisher_dated_sitemap"
                break

    # 1. The publisher's own WordPress search.
    endpoint = profile.wordpress_endpoint()
    if endpoint:
        for item in publisher_wordpress(session, domain, words, timeout,
                                        endpoint=endpoint):
            if title_matches(item.get("title"), words):
                return item["url"], "publisher_wordpress_search"
    if time.time() > deadline:
        return None, "the publisher's own search did not answer in time"

    # 2. The publisher's own site map. A publisher's map lists its articles
    #    by address, and an address carries the article's own words, so the
    #    article is found by matching the title against the map rather than
    #    by asking a third party where it is. The map may be compressed and
    #    split into numbered shards, both of which are read.
    stamp = (reported_date or "").strip()[:10]
    # A publisher that splits its map by month names the slice that covers
    # the month the article was reported in, and that slice is the one that
    # holds the article. The general walk below reads the publisher's
    # "latest" map first, which only ever holds recent articles, so the
    # dated slice is asked for before the walk begins.
    if stamp and len(stamp) >= 7:
        try:
            year = int(stamp[:4])
            month = stamp[5:7]
        except ValueError:
            year = month = None
        if year and month:
            for slice_url, locs in profile.dated_sitemaps(str(year), str(month)):
                for loc in locs:
                    if not is_article_address(loc):
                        continue
                    tail = loc.rstrip("/").rsplit("/", 1)[-1].lower()
                    if not _words_in(tail, _distinctive(words), minimum=2):
                        continue
                    return loc, "publisher_sitemap"
    for loc, lastmod in profile.site_map_entries():
        if not is_article_address(loc):
            continue
        tail = loc.rstrip("/").rsplit("/", 1)[-1].lower()
        if not _words_in(tail, _distinctive(words), minimum=2):
            continue
        if stamp and lastmod:
            # The feed's day and the site map's day must agree to within a
            # few days; an announcement is filed on the day it is reported.
            if _days_apart(stamp, lastmod) > 4:
                continue
        return loc, "publisher_sitemap"
    if time.time() > deadline:
        return None, "the site map did not answer in time"

    # 3. A site-scoped engine query.
    for item in site_search(session, domain, words, timeout):
        return item["url"], "publisher_site_search"
    if time.time() > deadline:
        return None, "the site-scoped query did not answer in time"

    # The news index is not consulted. It shares its request quota with the
    # search sweep that is still running, and it cannot answer the question
    # on its own: its own address for an article is the publisher's home
    # page. Asking it would spend the sweep's quota to confirm a title, and
    # then still leave the address to be found elsewhere.
    if time.time() > deadline:
        return None, "the publisher's own site did not answer in time"

    return None, "no publisher page could be located for this title"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--pace", type=float, default=0.4)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--budget", type=float, default=30.0)
    parser.add_argument("--out", default="")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    out_path = Path(args.out) if args.out else work / "qa/publisher-resolution.json"

    # The feed's own hits carry the publisher name and domain. Every batch
    # file is read, because the sweep writes its receipts in batches and a
    # batch that has not been imported yet still holds real evidence.
    receipts = {}
    imported = read_json(work / "discovery/receipts.json", {}) or {}
    if isinstance(imported, dict):
        receipts.update(imported)
    for batch_path in sorted((work / "discovery").glob("google-*.json")):
        batch = read_json(batch_path)
        if isinstance(batch, list):
            for row in batch:
                if isinstance(row, dict) and row.get("task_id"):
                    receipts.setdefault(row["task_id"], row)
    hits = []
    seen = set()
    for receipt in receipts.values():
        for hit in receipt.get("hits", []):
            if not hit.get("relevant"):
                continue
            url = urldefrag(hit.get("url") or "")[0]
            if not is_aggregator(url):
                continue
            key = (hit.get("title", ""), hit.get("publisher_url", ""))
            if key in seen:
                continue
            seen.add(key)
            hits.append(hit)
    print(f"aggregator hits needing a publisher address: {len(hits)}", flush=True)

    # The hits are grouped by publisher, because the cost of learning how a
    # publisher's site is organised is paid once for all of its articles.
    by_domain = {}
    for hit in hits:
        domain = normalise_domain(hit.get("publisher_url", ""))
        by_domain.setdefault(domain, []).append(hit)

    egress = Egress(floor=args.pace)
    resolved, unresolved = [], []
    lock = threading.Lock()
    done = [0]
    started = time.time()

    def resolve_group(domain, group):
        session = egress.session()
        # One site survey serves every article of this publisher.
        profile = DomainProfile(session, domain, budget=args.budget * 2)
        for hit in group:
            url, strategy = resolve(session, domain, hit.get("title", ""),
                                    budget=args.budget, profile=profile,
                                    reported_date=hit.get("reported_date", ""))
            record = {"title": hit.get("title", ""), "publisher": hit.get("publisher", ""),
                      "publisher_domain": domain,
                      "aggregator_url": hit.get("url", ""),
                      "resolved_url": url or "", "strategy": strategy,
                      "reported_date": hit.get("reported_date", "")}
            with lock:
                (resolved if url else unresolved).append(record)
                done[0] += 1
                if done[0] % 50 == 0:
                    write_json(out_path, {"resolved": resolved, "unresolved": unresolved})
                    rate = done[0] / max(time.time() - started, 1)
                    print(f"{done[0]}/{len(hits)} | resolved {len(resolved)} | "
                          f"unresolved {len(unresolved)} | {rate:.1f}/s", flush=True)

    groups = list(by_domain.items())
    # The publishers with the most articles are handled first, because their
    # articles are worth the most and their site answers fastest.
    groups.sort(key=lambda item: len(item[1]), reverse=True)
    with concurrent.futures.ThreadPoolExecutor(max(1, args.workers)) as pool:
        list(pool.map(lambda item: resolve_group(item[0], item[1]), groups))

    write_json(out_path, {"resolved": resolved, "unresolved": unresolved})
    print(f"resolved {len(resolved)}; unresolved {len(unresolved)}; written to {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
