#!/usr/bin/env python3
"""Reconcile a fresh clustering with the event set the runtime already knows.

Clustering is not idempotent in the way it first appears. A plan's identity is
derived from its strongest page, so when a newly retrieved page becomes that
page the event is *renamed*. Renaming is not a cosmetic problem: every decision
is keyed by `plan_id`, so a rename silently drops the decisions bound to the
old id and reports the same announcement twice — once as a lost event and once
as a new one.

This script keeps identity stable across rounds. A fresh cluster that covers an
event the runtime already knows adopts that event's id and date; only a cluster
with no counterpart becomes a new plan. An event with no fresh page keeps its
place, because losing it would be a coverage regression rather than a finding.

Usage:

    python "$S/scripts/reconcile_plans.py" --work "$W"
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import sys
from pathlib import Path
from urllib.parse import urldefrag

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from researchcore import sources as source_module  # noqa: E402

MATCH_TITLE_SIMILARITY = 0.5
TITLE_STOPWORDS = {
    "the", "and", "for", "with", "from", "that", "this", "will", "have",
    "has", "are", "was", "were", "its", "their", "about", "after", "over",
    "more", "than", "into", "amid", "news", "report", "reports", "said",
    "says", "company", "employees", "workers", "staff", "jobs", "job",
}


def title_tokens(title):
    cleaned = "".join(char if char.isalnum() else " " for char in (title or "").lower())
    return {token for token in cleaned.split()
            if len(token) >= 4 and token not in TITLE_STOPWORDS}


def title_similarity(left, right):
    a, b = title_tokens(left), title_tokens(right)
    if not a or not b:
        return 0.0
    return len(a & b) / float(len(a | b))


def event_urls(event):
    urls = {(urldefrag(item.get("url") or "")[0]) for item in event.get("sources", [])
            if isinstance(item, dict) and item.get("url")}
    primary = (event.get("primary") or {}).get("url")
    if primary:
        urls.add(urldefrag(primary)[0])
    urls.discard("")
    return urls


def reconcile(old_events, fresh_plans, review_out=None):
    """Return plans whose ids are stable with respect to the existing set.

    Identity is matched on evidence, not on proximity. A date gap of a few days
    is not evidence that two records are one event: sequential coverage of one
    employer and two genuinely separate regional plans both look like that. A
    fresh plan joins an existing event only when it shares a source address, an
    exact event date plus a similar headline, or a registered plan id. The
    historical date is never copied onto the fresh plan; when a shared source
    carries a different date, both dates are recorded as a conflict for review.
    """
    by_company = {}
    for event in old_events:
        by_company.setdefault(event.get("company_id"), []).append(event)
    claimed = set()
    old_by_id = {event.get("plan_id"): event for event in old_events}
    merged = []
    unmatched = []
    conflicts = []
    for plan in fresh_plans:
        if plan.get("needs_review"):
            # A plan whose scope relationship is unresolved stays a review
            # record; it must not be confirmed as an event by reconciliation.
            continue
        # A cluster that already carries a known id is the same event by
        # construction; claiming it keeps it out of the rename search below.
        if plan.get("plan_id") in old_by_id:
            claimed.add(plan["plan_id"])
            merged.append(plan)
            continue
        day = as_day(plan.get("event_date"))
        candidates = []
        urls = {(urldefrag(item.get("url") or "")[0])
                for item in plan.get("sources", []) if item.get("url")}
        urls.discard("")
        for event in by_company.get(plan.get("company_id"), []):
            if event.get("plan_id") in claimed or event.get("plan_id") == plan.get("plan_id"):
                continue
            shared = urls & event_urls(event)
            if shared:
                candidates.append((0, 0.0, event, "shared_source:" + sorted(shared)[0]))
                continue
            if plan.get("event_review"):
                # A reviewed announcement date cannot be replaced by a nearby
                # report date, so only a shared address can identify it.
                continue
            other = as_day(event.get("event_date_hint"))
            if not day or not other or day != other:
                continue
            similarity = title_similarity(plan.get("title"), (event.get("primary") or {}).get("title"))
            if similarity >= MATCH_TITLE_SIMILARITY:
                candidates.append((1, -similarity, event, "same_date_title"))
        if not candidates:
            unmatched.append(plan)
            continue
        _rank, _negative, event, basis = min(candidates, key=lambda item: (item[0], item[1],
                                                                          item[2].get("plan_id")))
        claimed.add(event["plan_id"])
        previous_date = event.get("event_date_hint") or ""
        if previous_date and plan.get("event_date") and previous_date[:10] != plan["event_date"][:10]:
            conflict = {"plan_id": event["plan_id"], "company_id": plan.get("company_id"),
                        "matched_from": plan.get("plan_id"), "match_basis": basis,
                        "fresh_event_date": plan["event_date"],
                        "previous_event_date": previous_date[:10],
                        "primary_url": plan.get("primary_url"),
                        "review_reason": ("the matched records state different event dates; "
                                          "the fresh date is kept and the pair needs review")}
            conflicts.append(conflict)
            plan = {**plan, "event_date_conflict": previous_date[:10]}
        merged.append({**plan, "plan_id": event["plan_id"], "matched_from": plan.get("plan_id"),
                       "match_basis": basis})
    # An event this round produced no fresh page for still happened. Keep it so
    # the dataset does not shrink because a publisher rotated an article.
    preserved = []
    for event in old_events:
        if event.get("plan_id") in claimed:
            continue
        preserved.append({
            "plan_id": event["plan_id"],
            "company_id": event.get("company_id"),
            "event_date": event.get("event_date_hint"),
            "primary_source_id": "",
            "primary_url": (event.get("primary") or {}).get("url", ""),
            "title": (event.get("primary") or {}).get("title", ""),
            "sources": [{"source_id": "", "url": item.get("url"), "reported_date": item.get("reported_date")}
                        for item in event.get("sources", []) if isinstance(item, dict)],
            "count": None,
            "percentage": None,
            "n_sources": len(event.get("sources") or []),
            "preserved": True,
        })
    if review_out is not None:
        review_out.extend(conflicts)
    return merged + unmatched + preserved, len(merged), len(unmatched), len(preserved)


def read_json(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=1, default=str),
                          encoding="utf-8")


def read_csv(path):
    path = Path(path)
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def as_day(text):
    try:
        return dt.date.fromisoformat(str(text)[:10])
    except (TypeError, ValueError):
        return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--no-ingest", action="store_true")
    args = parser.parse_args()
    work = Path(args.work).resolve()

    old_events = read_json(work / "qa/events.json", []) or []
    fresh = read_json(work / "qa/event-plans.json", {}) or {}
    fresh_plans = [plan for plan in fresh.get("plans", []) if not plan.get("needs_review")]
    held_for_review = [plan for plan in fresh.get("plans", []) if plan.get("needs_review")]
    conflicts = []
    plans, matched, fresh_new, preserved = reconcile(old_events, fresh_plans, conflicts)
    print(f"existing={len(old_events)} fresh={len(fresh_plans)} -> "
          f"matched={matched} new={fresh_new} preserved={preserved} total={len(plans)}", flush=True)

    # Resolve source ids for every plan, including the preserved events whose
    # record only carries page addresses. A plan without a bound source cannot
    # carry a decision, because every decision must cite a registered snapshot.
    rows = read_csv(work / "qa/full_manifest.csv")
    # One article can cover several employers, and the same address may be
    # registered once per employer it discusses. Resolving by address alone
    # therefore binds a plan to another company's snapshot — a Lyft registration
    # ended up as the primary source of a Tesla event. Match on both.
    by_url_and_company = {}
    for row in rows:
        key = urldefrag(row.get("source_url") or "")[0]
        if key:
            by_url_and_company[(key, row.get("company_id"))] = row["source_id"]

    def resolve(url, company_id):
        key = urldefrag(url or "")[0]
        return (by_url_and_company.get((key, company_id))
                or by_url_and_company.get((key, None)) or "")

    for plan in plans:
        company_id = plan.get("company_id")
        for item in plan.get("sources", []):
            if not item.get("source_id"):
                item["source_id"] = resolve(item.get("url"), company_id)
        if not plan.get("primary_source_id"):
            plan["primary_source_id"] = resolve(plan.get("primary_url"), company_id)
        plan["sources"] = [item for item in plan.get("sources", []) if item.get("source_id")]
        if not plan.get("primary_source_id") and plan["sources"]:
            plan["primary_source_id"] = plan["sources"][0]["source_id"]
    plans = [plan for plan in plans if plan.get("primary_source_id")]
    print(f"plans with a bound source={len(plans)}", flush=True)
    write_json(work / "qa/event-plans.json",
               {"plans": plans, "rejected": fresh.get("rejected", []),
                "pending_review": fresh.get("pending_review", [])})
    write_json(work / "qa/plan-review-queue.json",
               {"plans": held_for_review,
                "date_conflicts": conflicts,
                "undated_pages": fresh.get("pending_review", [])})
    if held_for_review or conflicts:
        print(f"held for review={len(held_for_review)} plans, "
              f"date conflicts={len(conflicts)}", flush=True)

    # Bind every plan id back onto its sources, so the runtime can build the
    # entity list from the ids recorded on registered sources.
    plan_of_source = {}
    for plan in plans:
        for item in plan.get("sources", []):
            if item.get("source_id"):
                plan_of_source[item["source_id"]] = plan["plan_id"]
    changed = 0
    for row in rows:
        wanted = plan_of_source.get(row["source_id"], row.get("plan_id") or "")
        if (row.get("plan_id") or "") != wanted:
            row["plan_id"] = wanted
            changed += 1
    with (work / "qa/full_manifest.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    print(f"manifest rows updated={changed}", flush=True)
    if changed and not args.no_ingest:
        recorded = source_module.ingest(work, work / "qa/full_manifest.csv", offline=False, refresh=False)
        counts = {}
        for record in recorded:
            counts[record.get("status")] = counts.get(record.get("status"), 0) + 1
        print(f"ingest statuses: {counts}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
