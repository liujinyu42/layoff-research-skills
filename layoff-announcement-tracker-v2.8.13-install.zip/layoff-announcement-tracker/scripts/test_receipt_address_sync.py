#!/usr/bin/env python3
"""Tests for the receipt-side repairs.

Two failures recur in this runtime and both look like something else.

The first: an aggregate address is resolved into the publisher's own address
in the candidate ledger, while the receipt that points at the same document
still carries the aggregate address. The runtime compares the two addresses
when it checks candidate identity, so the comparison fails on a document that
was never in doubt.

The second: the receipt carries the publisher name and domain, but the
imported receipt drops both, because the imported shape keeps only the
fields the runtime reads. The publisher address is exactly the field the
resolver needs, so the resolution cannot start without it.
"""
from __future__ import annotations

import csv
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from urllib.parse import urldefrag

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import apply_publisher_addresses as apa  # noqa: E402
from researchcore.discovery import _digest  # noqa: E402


class ReceiptLedgerTests(unittest.TestCase):
    def setUp(self):
        self.work = Path(tempfile.mkdtemp())
        (self.work / "discovery").mkdir()
        (self.work / "event_candidate_review.csv").write_text(
            "candidate_id,company_id,company,source_url,title\n"
            "hit-a,acme-1,Acme,https://publisher.example/story,Story A\n"
            "hit-b,acme-1,Acme,https://other.example/story,Story B\n",
            encoding="utf-8")
        self.addCleanup(shutil.rmtree, self.work, ignore_errors=True)

    def write_receipts(self, receipts):
        path = self.work / "discovery/receipts.json"
        path.write_text(json.dumps(receipts, ensure_ascii=False),
                        encoding="utf-8")
        return path

    def read_receipts(self):
        return json.loads(
            (self.work / "discovery/receipts.json").read_text(encoding="utf-8"))

    def test_address_is_carried_into_the_receipt(self):
        receipts = {"search-1": {
            "task_id": "search-1",
            "hits": [{"candidate_id": "hit-a",
                      "url": "https://news.google.com/rss/articles/ABC",
                      "relevant": True}],
        }}
        self.write_receipts(receipts)
        argv = ["--work", str(self.work)]
        original = sys.argv
        sys.argv = ["apply_publisher_addresses.py"] + argv
        try:
            apa.main()
        finally:
            sys.argv = original
        hit = self.read_receipts()["search-1"]["hits"][0]
        self.assertEqual(hit["url"], "https://publisher.example/story")

    def test_candidate_identity_does_not_move_with_the_address(self):
        receipts = {"search-1": {
            "task_id": "search-1",
            "hits": [{"candidate_id": "hit-a",
                      "url": "https://news.google.com/rss/articles/ABC",
                      "relevant": True}],
        }}
        self.write_receipts(receipts)
        original = sys.argv
        sys.argv = ["apply_publisher_addresses.py", "--work", str(self.work)]
        try:
            apa.main()
        finally:
            sys.argv = original
        hit = self.read_receipts()["search-1"]["hits"][0]
        self.assertEqual(hit["candidate_id"], "hit-a")

    def test_a_receipt_that_already_agrees_is_left_alone(self):
        receipts = {"search-1": {
            "task_id": "search-1",
            "hits": [{"candidate_id": "hit-a",
                      "url": "https://publisher.example/story",
                      "relevant": True}],
        }}
        self.write_receipts(receipts)
        original = sys.argv
        sys.argv = ["apply_publisher_addresses.py", "--work", str(self.work)]
        try:
            apa.main()
        finally:
            sys.argv = original
        hit = self.read_receipts()["search-1"]["hits"][0]
        self.assertNotIn("publisher_address_resolved", hit)

    def test_the_signature_is_recomputed(self):
        receipts = {"search-1": {
            "task_id": "search-1",
            "hits": [{"candidate_id": "hit-a",
                      "url": "https://news.google.com/rss/articles/ABC",
                      "relevant": True}],
            "receipt_sha256": "stale",
        }}
        self.write_receipts(receipts)
        original = sys.argv
        sys.argv = ["apply_publisher_addresses.py", "--work", str(self.work)]
        try:
            apa.main()
        finally:
            sys.argv = original
        receipt = self.read_receipts()["search-1"]
        payload = {key: value for key, value in receipt.items()
                   if key != "receipt_sha256"}
        self.assertEqual(receipt["receipt_sha256"], _digest(payload))

    def test_dry_run_does_not_write(self):
        receipts = {"search-1": {
            "task_id": "search-1",
            "hits": [{"candidate_id": "hit-a",
                      "url": "https://news.google.com/rss/articles/ABC",
                      "relevant": True}],
        }}
        path = self.write_receipts(receipts)
        before = path.read_text(encoding="utf-8")
        original = sys.argv
        sys.argv = ["apply_publisher_addresses.py", "--work", str(self.work),
                    "--dry-run"]
        try:
            apa.main()
        finally:
            sys.argv = original
        self.assertEqual(path.read_text(encoding="utf-8"), before)


class IdentityCheckTests(unittest.TestCase):
    """The check the runtime performs, on the shapes the repair produces."""

    def ledger_row(self, url):
        return {"company_id": "acme-1", "company": "Acme", "source_url": url}

    def receipt(self, url, aliases=("Acme",)):
        return {"company_id": "acme-1", "aliases": list(aliases),
                "hits": [{"url": url, "relevant": True}]}

    def identity_matches_when_the_address_agrees(self):
        row = self.ledger_row("https://publisher.example/story")
        receipt = self.receipt("https://publisher.example/story")
        self.assertEqual(urldefrag(row["source_url"])[0],
                         urldefrag(receipt["hits"][0]["url"])[0])

    def identity_differs_when_the_receipt_still_holds_the_aggregate(self):
        row = self.ledger_row("https://publisher.example/story")
        receipt = self.receipt("https://news.google.com/rss/articles/ABC")
        self.assertNotEqual(urldefrag(row["source_url"])[0],
                            urldefrag(receipt["hits"][0]["url"])[0])


if __name__ == "__main__":
    unittest.main()
