"""Targeted gap-closing search for companies the main sweep did not cover.

A delivery audit of the previous collection round found that a hundred
companies in the reference set had no row at all, and that several years were
thin. The cause was that the main sweep asked one question per company per
year through one engine, and a single phrasing returns few or no results for
some employers.

This module asks more, differently, for the companies that need it:

* several engines, because one index covers different archives;
* several phrasings, because an employer is described as "lays off", "job
  cuts", "cuts staff", "restructures", and sometimes only in a local
  language;
* a year-scoped sweep, because the default feed is biased toward recent items;
* the employer name, its aliases and its former names.

The output is the same receipt format the main collector produces, so the
runtime imports it without any special handling.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime as dt
import json
import re
import sys
import threading
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from collect_discovery import (BING, GNEWS, canonical, hit_relevant, is_generic,  # noqa: E402
                               iso_date, parse_rss)
from researchcore.egress import Egress  # noqa: E402

# Alternative phrasings. The main sweep already used the generic wording, so
# these deliberately vary the verb, the noun and the framing.
PHRASINGS = [
    '"{name}" layoffs',
    '"{name}" "job cuts"',
    '"{name}" "laid off"',
    '"{name}" "cuts jobs"',
    '"{name}" "cut jobs"',
    '"{name}" "workforce reduction"',
    '"{name}" "restructuring" layoffs',
    '"{name}" "job losses"',
    '"{name}" layoffs announcement',
    '"{name}" WARN layoffs',
    '"{name}" redundancies',
    '"{name}" "staff cuts"',
]

# Verbs that indicate the announcement itself rather than commentary about a
# sector, so the engine can be asked for the employer as the subject.
SUBJECT_HINTS = [
    '"{name}" "will cut" jobs',
    '"{name}" "said it would" cut',
    '"{name}" "announced" layoffs',
]


class EngineGate:
    """Skip an engine for the rest of the run once it starts refusing.

    A blocked engine costs two requests and a backoff per query. Probing it
    once and then leaving it alone for the rest of the round keeps the
    remaining queries fast.
    """

    def __init__(self, egress):
        self.egress = egress
        self.disabled = set()

    def available(self, name):
        return name not in self.disabled

    def disable(self, name):
        if name not in self.disabled:
            self.disabled.add(name)
            print(f"  engine {name} is refusing requests; skipping it for the rest of the round",
                  flush=True)

    def query(self, name, template, query):
        if name in self.disabled:
            return None, []
        url = template.format(q=urllib.parse.quote_plus(query))
        try:
            response = self.egress.get(url)
        except Exception:  # noqa: BLE001
            self.disable(name)
            return None, []
        if response.status_code != 200:
            self.disable(name)
            return None, []
        body = response.text
        if any(marker in body[:2000].lower() for marker in ("automated queries", "unusual traffic")):
            self.disable(name)
            return None, []
        return body, parse_rss(body)


def engines():
    return [("gnews", GNEWS), ("bing", BING)]


def unique_urls(items):
    seen = set()
    out = []
    for item in items:
        url = canonical(item.get("link"))
        if not url or url in seen:
            continue
        seen.add(url)
        out.append((url, item))
    return out


def search_company(egress, company, aliases, years, capture_dir, tag):
    """Run every phrasing for one company and collect the distinct hits."""
    names = []
    for name in [company] + list(aliases or []):
        name = str(name or "").strip()
        if name and name not in names:
            names.append(name)
    queries = []
    for name in names:
        for template in PHRASINGS:
            queries.append(template.format(name=name))
        for template in SUBJECT_HINTS:
            queries.append(template.format(name=name))
    for year in years:
        for name in names:
            queries.append(f'"{name}" layoffs {year}')
            queries.append(f'"{name}" "job cuts" {year}')

    gate = getattr(egress, "gate", None) or EngineGate(egress)
    hits = {}
    blocked = 0
    for index, query in enumerate(queries):
        for engine_name, template in engines():
            raw, items = gate.query(engine_name, template, query)
            if raw is None:
                blocked += 1
                continue
            if engine_name == "gnews" and raw:
                path = capture_dir / f"{tag}-{index:03d}-gnews.xml"
                path.write_text(raw, encoding="utf-8")
            for url, item in unique_urls(items):
                if url in hits:
                    continue
                generic = any(is_generic(name) for name in names)
                relevant, reason = hit_relevant(item.get("title", ""), names, generic)
                hits[url] = {
                    "url": url,
                    "title": item.get("title", ""),
                    "relevant": bool(relevant),
                    "exclusion_reason": "" if relevant else reason,
                    "publisher": item.get("source", ""),
                    "publisher_url": "",
                    "reported_date": iso_date(item.get("pub", "")),
                }
    return hits, blocked, len(queries)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--targets", required=True,
                        help="JSON with a gap_reference_companies or zero_roster_companies map")
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--pace", type=float, default=0.25)
    parser.add_argument("--max-queries-per-company", type=int, default=40)
    args = parser.parse_args()

    work = Path(args.work).resolve()
    capture_dir = work / "discovery/captures/gapsearch"
    capture_dir.mkdir(parents=True, exist_ok=True)
    targets = json.loads(Path(args.targets).read_text(encoding="utf-8"))

    roster = {}
    config = work / "config.json"
    if config.is_file():
        cfg = json.loads(config.read_text(encoding="utf-8"))
        for item in cfg.get("roster", []):
            roster[item.get("company")] = item

    plan = {}
    years = []
    plan_path = work / "discovery/plan.json"
    if plan_path.is_file():
        payload = json.loads(plan_path.read_text(encoding="utf-8"))
        for task in payload.get("tasks", []):
            plan.setdefault(task["company"], task.get("aliases") or [])
        years = sorted({str(t.get("window_start", ""))[:4] for t in payload.get("tasks", [])
                        if t.get("window_start")})
    years = [y for y in years if y.isdigit()]

    companies = []
    for name in targets.get("gap_reference_companies", {}):
        if name not in companies:
            companies.append(name)
    for name in targets.get("zero_roster_companies", {}):
        display = targets["zero_roster_companies"][name] if isinstance(
            targets["zero_roster_companies"], dict) else name
        if display not in companies:
            companies.append(display)

    print(f"gap search for {len(companies)} companies", flush=True)
    egress = Egress(floor=args.pace)
    egress.gate = EngineGate(egress)
    lock = threading.Lock()
    results = []
    stats = {"hits": 0, "relevant": 0, "blocked": 0}

    def work_one(company):
        aliases = plan.get(company) or (roster.get(company, {}).get("aliases") or [])
        tag = re.sub(r"[^a-z0-9]+", "-", company.lower()).strip("-")[:48]
        hits, blocked, _n = search_company(egress, company, aliases, years,
                                           capture_dir, tag)
        with lock:
            stats["hits"] += len(hits)
            stats["relevant"] += sum(1 for h in hits.values() if h["relevant"])
            stats["blocked"] += blocked
            if hits:
                results.append({"company": company, "aliases": aliases, "hits": list(hits.values())})
            if len(results) % 10 == 0:
                print(f"  {len(results)}/{len(companies)} companies searched | "
                      f"relevant hits {stats['relevant']}", flush=True)

    with cf.ThreadPoolExecutor(args.workers) as pool:
        list(pool.map(work_one, companies))

    payload = {
        "companies_searched": len(companies),
        "companies_with_hits": len(results),
        "hits": stats["hits"],
        "relevant_hits": stats["relevant"],
        "blocked_requests": stats["blocked"],
        "results": results,
    }
    Path(args.out).write_text(json.dumps(payload, ensure_ascii=False, indent=1),
                               encoding="utf-8")
    print(json.dumps({k: v for k, v in payload.items() if k != "results"}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
