#!/usr/bin/env python3
"""Build the reason coding from the decisions already made.

The stated-reason decision holds a free-text sentence and the attribution
decision holds who said it. The codebook asks for the same reason in a
structured form: which categories apply, each with its own quotation from
the bound source.

The categories carry positive cues, and a cue has to be found in the quoted
span or the coder has to say why the category still applies. So the coding is
derived from the sentence the decision already records, quoted from the
source the decision already cites. Nothing new is claimed here: the
quotation is located in the source bytes, and the cue is verified against
that span by the runtime.

A reason that no category fits is recorded with a proposed category for
review, not forced into a formal label. A decision that recorded no reason
gets no labels at all.

Usage:

    python "$S/scripts/build_reason_codes.py" --work "$W" [--out "$W/qa/reason_codes.csv"]
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

CODER_ID = "reason_codebook_coder"
CODER_KIND = "model"

# The attribution a decision records, mapped to the codebook's own levels.
# A level that does not count as a company statement cannot carry a label:
# it is a reporter's reading of the event, not the issuer's stated reason.
LEVEL_OF_ATTRIBUTION = {
    "company_direct": "company_direct",
    "company_quote_in_news": "company_quote_in_news",
    "news_reporter_attribution": "reporter_interpretation",
    "tracker_summary": "reporter_interpretation",
}


def load_book(skill):
    return json.loads((Path(skill) / "assets/reason_codebook.json")
                      .read_text(encoding="utf-8"))


def cue_hit(text, cue):
    if not cue:
        return False
    return re.search(r"(?<![a-z0-9])" + re.escape(cue.lower()),
                     text.lower()) is not None


def quote_from(text, sentence, limit=320):
    """Find the decision's own sentence inside the bound source text."""
    if not text:
        return None, None
    needle = sentence.strip()
    if not needle:
        return None, None
    if needle in text:
        start = text.index(needle)
        return needle, start
    # The decision may quote a fragment of a longer article, or normalise the
    # punctuation. The longest leading fragment that still occurs in the
    # source is the honest span.
    words = needle.split()
    for size in range(len(words), 4, -1):
        fragment = " ".join(words[:size])
        if fragment in text:
            start = text.index(fragment)
            return fragment, start
    return None, None


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--skill", default="")
    parser.add_argument("--out", default="")
    args = parser.parse_args(argv)

    work = Path(args.work).resolve()
    skill = Path(args.skill).resolve() if args.skill else HERE.parent
    book = load_book(skill)
    categories = {item["code"]: item for item in book["categories"]}

    decisions = json.loads((work / "decisions.json").read_text(encoding="utf-8"))
    sources = json.loads((work / "sources.json").read_text(encoding="utf-8"))
    sources = {item["source_id"]: item for item in sources.get("sources", [])}
    entities = json.loads((work / "entities.json").read_text(encoding="utf-8"))

    from researchcore.sources import text_for

    text_cache = {}

    def get_text(source_id):
        if source_id not in text_cache:
            try:
                text_cache[source_id] = text_for(work, sources[source_id])
            except Exception:  # noqa: BLE001
                text_cache[source_id] = ""
        return text_cache[source_id]

    rows = []
    counts = {"labelled": 0, "no_reason": 0, "not_a_reason": 0,
              "outside_codebook": 0, "unlocatable": 0}
    for plan_id, entity in entities.items():
        reason = decisions.get(plan_id + "|stated_reason_text") or {}
        attribution = decisions.get(plan_id + "|reason_attribution") or {}
        if reason.get("status") != "observed":
            # The contract asks for one coding record per registered plan. A
            # plan whose reason was reviewed and found absent is a coding
            # result too: it carries no label, and the record says so.
            counts["no_reason"] += 1
            rows.append({
                "plan_id": plan_id,
                "company_id": entity.get("company_id", ""),
                "coder_id": CODER_ID,
                "coder_kind": CODER_KIND,
                "source_id": "",
                "quote": "",
                "char_start": "",
                "labels": [],
                "no_label_status": "",
                "notes": ("The source states no reason for this reduction, so "
                          "the plan carries no stated-reason label."),
            })
            continue
        attribution_value = str(attribution.get("value") or "").strip()
        level = LEVEL_OF_ATTRIBUTION.get(attribution_value, "")
        if level not in ("company_direct", "company_quote_in_news"):
            # A reporter's reading of the event is not the issuer's stated
            # reason. The plan still carries a coding record, and the record
            # says that the basis was the reporter's reading.
            counts["not_a_reason"] += 1
            rows.append({
                "plan_id": plan_id,
                "company_id": entity.get("company_id", ""),
                "coder_id": CODER_ID,
                "coder_kind": CODER_KIND,
                "source_id": "",
                "quote": "",
                "char_start": "",
                "labels": [],
                "no_label_status": "",
                "notes": ("The reason was recorded as a reporter's reading of "
                          "the event rather than a company statement, so it "
                          "carries no stated-reason label."),
            })
            continue

        sentence = str(reason.get("value") or "").strip()
        evidence = reason.get("evidence") or []
        if not evidence:
            counts["unlocatable"] += 1
            continue

        found = None
        for item in evidence:
            source_id = item.get("source_id")
            if not source_id or source_id not in sources:
                continue
            if sources[source_id].get("status") != "ready":
                continue
            quote, start = quote_from(get_text(source_id), sentence)
            if quote:
                found = (source_id, quote, start)
                break
        if not found:
            counts["unlocatable"] += 1
            continue
        source_id, quote, start = found

        span = quote
        labels = []
        matched = []
        for code, item in categories.items():
            cues = [cue for cue in item.get("positive_cues", [])
                    if cue_hit(span, cue)]
            if cues:
                matched.append((code, cues))
        if not matched:
            # The sentence names no category. The codebook asks for a proposed
            # category in that case, not a formal label: a category that fits
            # only loosely would turn a researcher's reading of a sentence into
            # the company's stated reason.
            counts["outside_codebook"] += 1
            rows.append({
                "plan_id": plan_id,
                "company_id": entity.get("company_id", ""),
                "coder_id": CODER_ID,
                "coder_kind": CODER_KIND,
                "source_id": source_id,
                "quote": quote,
                "char_start": start,
                "labels": "[]",
                "no_label_status": "outside_codebook",
                "notes": ("The stated reason names no category in this codebook; "
                          "recorded for review rather than forced into a label."),
            })
            continue
        for code, cues in matched:
            labels.append({
                "code": code,
                "source_id": source_id,
                "quote": quote,
                "char_start": start,
                "label_attribution": level,
                "note": ";".join(cues),
            })
        counts["labelled"] += 1
        rows.append({
            "plan_id": plan_id,
            "company_id": entity.get("company_id", ""),
            "coder_id": CODER_ID,
            "coder_kind": CODER_KIND,
            "source_id": source_id,
            "quote": quote,
            "char_start": start,
            "labels": json.dumps(labels, ensure_ascii=False),
            "no_label_status": "",
            "notes": "",
        })

    out = Path(args.out) if args.out else work / "qa/reason_codes.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    # The submission is written as JSON, not CSV: a label carries a nested
    # list, and a CSV cell would carry it as a string that the runtime reads
    # as a flat code list instead.
    payload = []
    for row in rows:
        record = dict(row)
        raw = record.get("labels")
        if isinstance(raw, str):
            try:
                record["labels"] = json.loads(raw)
            except json.JSONDecodeError:
                record["labels"] = []
        payload.append(record)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=1),
                   encoding="utf-8")

    print(json.dumps({"output": str(out), "rows": len(rows), "counts": counts},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
