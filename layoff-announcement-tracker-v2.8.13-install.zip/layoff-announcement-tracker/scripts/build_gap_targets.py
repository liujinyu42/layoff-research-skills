"""Build the gap-closing target list from the workspace and an optional baseline.

The gap list answers one question: which roster companies have no readable
public announcement, and which events in a reference set were never covered.
Both answers feed `close_gaps.py`, which then searches those companies harder.

Two sources of truth are combined:

* the workspace itself, which knows which companies already have plans and how
  many events each has;
* an optional reference set, which knows which events a benchmark contains.

The reference set is read as CSV or JSON with company, date and URL columns. It
is used only to decide where to search harder; it never supplies a value into
the delivered workbook.
"""
from __future__ import annotations

import argparse
import collections
import csv
import json
import re
import unicodedata
from pathlib import Path

LEGAL = re.compile(
    r"\b(inc|ltd|limited|corp|corporation|co|company|group|holdings?|plc|gmbh|"
    r"technolog\w*|technologies|labs?|systems?|software|solutions?|networks?|"
    r"international|worldwide|enterprises?|industries|studios?|therapeutics|"
    r"pharmaceuticals?|biosciences?)\b", re.I)


def norm_company(name):
    text = unicodedata.normalize("NFKC", str(name or "")).lower()
    text = re.sub(r"[^a-z0-9\s]+", " ", text)
    text = LEGAL.sub(" ", text)
    return re.sub(r"\s+", " ", text).strip()


def read_roster(work):
    config = Path(work) / "config.json"
    if not config.is_file():
        return []
    payload = json.loads(config.read_text(encoding="utf-8"))
    return payload.get("roster", [])


def read_plans(work):
    path = Path(work) / "qa/events.json"
    if not path.is_file():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []
    if isinstance(payload, list):
        return payload
    return payload.get("entries", payload.get("plans", []))


def read_reference(path):
    """Accept a CSV or JSON list with company/date/url columns."""
    if not path:
        return []
    p = Path(path)
    if not p.is_file():
        return []
    if p.suffix.lower() == ".json":
        payload = json.loads(p.read_text(encoding="utf-8"))
        rows = payload if isinstance(payload, list) else payload.get("rows", [])
        out = []
        for row in rows:
            out.append({"company": row.get("company") or row.get("Company") or "",
                        "date": str(row.get("date") or row.get("Date") or "")[:10],
                        "url": row.get("url") or row.get("Source") or ""})
        return out
    with p.open(encoding="utf-8-sig", newline="") as handle:
        out = []
        for row in csv.DictReader(handle):
            out.append({"company": row.get("company") or row.get("Company") or "",
                        "date": str(row.get("date") or row.get("Date") or "")[:10],
                        "url": row.get("url") or row.get("Source") or ""})
        return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--reference", default="",
                        help="optional baseline CSV/JSON of known events")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    work = Path(args.work)
    roster = read_roster(work)
    plans = read_plans(work)

    covered = set()
    per_company = collections.Counter()
    for plan in plans:
        company_id = plan.get("company_id")
        if company_id:
            covered.add(company_id)
            per_company[company_id] += 1

    zero = {}
    for item in roster:
        company_id = item.get("company_id")
        if company_id and company_id not in covered:
            zero[company_id] = item.get("company") or company_id

    reference = read_reference(args.reference)
    ref_by_company = collections.defaultdict(list)
    for row in reference:
        ref_by_company[norm_company(row["company"])].append(row)

    # A reference company with no plan of its own is the hardest gap: the
    # benchmark knows events there that the collection never found.
    plan_companies = {norm_company(item.get("company") or "") for item in roster}
    gap_reference = {}
    for key, rows in ref_by_company.items():
        if key and key not in {norm_company(c) for c in per_company}:
            gap_reference[key] = rows

    payload = {
        "roster_rows": len(roster),
        "companies_with_plans": len(covered),
        "zero_coverage_companies": zero,
        "reference_companies_without_plans": gap_reference,
        "reference_rows": len(reference),
        "per_company_event_counts": dict(per_company),
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({
        "roster_rows": len(roster),
        "companies_with_plans": len(covered),
        "zero_coverage_companies": len(zero),
        "reference_companies_without_plans": len(gap_reference),
        "reference_rows": len(reference),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
