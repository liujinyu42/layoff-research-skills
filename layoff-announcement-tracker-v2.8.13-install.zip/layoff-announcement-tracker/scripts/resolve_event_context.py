#!/usr/bin/env python3
"""Read the company context of an event from evidence that was available then.

A company context field describes the employer around the reduction: how many
people it employed, which exchange and ticker it traded under, what it sold,
how it made money, when it was founded and where it was registered. The
runtime requires each such decision to state the information date, and it
rejects a context date later than the event: an employer described after the
reduction is not the employer the reduction happened to.

The registrant filing that verified the company is usually filed years after
the event, so a context read only from it describes a later employer. The
reports published at the event describe the employer as it stood then, and
they are already registered as the plan's sources. This script therefore
reads the context from the event's own reports first and falls back to the
registrant filing for the facts that do not change over time, declaring that
fallback as retrospective.

Every decision it writes quotes the exact span it read, so the runtime can
re-read the same bytes from the bound source.

Usage:

    python "$S/scripts/resolve_event_context.py" --work "$W" [--out "$W/qa/context-decisions.jsonl"]
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from fill_profile_fields import find_span, fiscal_date  # noqa: E402

REVIEWER_ID = "event-context-reader"
REVIEWER_KIND = "model"

IDENTITY_BASIS = ("The registrant filing names this registrant, and the company "
                  "identity record was verified against it, so the filing is the "
                  "verified record of this employing entity.")

# A report published after the event describes the employer retrospectively.
RETROSPECTIVE_BASIS = ("This context is read from a report published after the "
                        "announcement date, so it describes the situation "
                        "retrospectively and was not publicly available before "
                        "the event.")

# An absolute workforce statement. The number has to be the employer's own
# workforce, so the sentence that states it is checked for the employer.
WORKFORCE = [
    re.compile(r"employ(?:s|ed|ing)?\s+(?:approximately\s+|about\s+|around\s+|"
               r"nearly\s+|over\s+|more\s+than\s+|some\s+)?([\d,]{2,7})\s+"
               r"(?:full[-\s]?time\s+)?(?:employees|people|staff|workers)", re.I),
    re.compile(r"(?:has|had)\s+(?:more\s+than\s+|about\s+|around\s+|roughly\s+|"
               r"nearly\s+|over\s+|approximately\s+|some\s+)?([\d,]{2,7})\s+"
               r"(?:full[-\s]?time\s+)?(?:employees|people|staff|workers)", re.I),
    re.compile(r"(?:workforce|headcount|team|staff)\s+(?:of\s+|was\s+|is\s+|"
               r"stood\s+at\s+)?(?:approximately\s+|about\s+|around\s+|roughly\s+|"
               r"nearly\s+|over\s+|more\s+than\s+)?([\d,]{2,7})", re.I),
    re.compile(r"([\d,]{2,7})\s+(?:full[-\s]?time\s+)?(?:employees|people|staff|"
               r"workers)\s+(?:worldwide|globally|internationally|across\s+the\s+"
               r"world|in\s+total)", re.I),
]

# A workforce that only ever existed on paper is not a workforce. The verb
# itself sits outside the matched number, so the guard looks for the stem
# that introduces it.
HYPOTHETICAL = re.compile(
    r"\b(would\s+have|would|plans?\s+to|expected\s+to|could\s+have|"
    r"aims?\s+to|set\s+to)\b", re.I)

# The period the workforce statement refers to.
AS_OF = [
    re.compile(r"as\s+of\s+([A-Z][a-z]+\s+\d{1,2},\s*\d{4})"),
    re.compile(r"(?:at\s+the\s+end\s+of|end\s+of)\s+([A-Z][a-z]+\s+\d{4})"),
    re.compile(r"(?:at\s+the\s+end\s+of|end\s+of)\s+((?:19|20)\d{2})"),
    re.compile(r"as\s+of\s+([A-Z][a-z]+\.?\s+\d{1,2},\s*\d{4})"),
    re.compile(r"as\s+of\s+([A-Z][a-z]+\.?\s+\d{4})"),
    re.compile(r"in\s+([A-Z][a-z]+\s+\d{4})"),
    re.compile(r"at\s+year[-\s]end\s+(\d{4})"),
]

# A listing statement: the venue and, when the sentence carries it, the ticker.
LISTING = [
    re.compile(r"\(?\b(NYSE\s+American|New\s+York\s+Stock\s+Exchange|Nasdaq|"
               r"NASDAQ|NYSE|OTC|TSE|LSE|Euronext|SIX\s+Swiss\s+Exchange|"
               r"TSX|ASX)\s*[:\-]\s*([A-Z]{1,6})\b"),
    re.compile(r"\b(Nasdaq|NASDAQ|New\s+York\s+Stock\s+Exchange|NYSE)"
               r"[-‑ ]listed\b", re.I),
    re.compile(r"\btrading\s+under\s+the\s+ticker\s+(?:symbol\s+)?"
               r"[\"']?([A-Z]{1,6})", re.I),
    re.compile(r"\bticker\s+symbol\s+[\"']?([A-Z]{1,6})", re.I),
]

VENUE_NAMES = {
    "new york stock exchange": "NYSE", "nyse": "NYSE",
    "nasdaq": "NASDAQ", "otc": "OTC",
    "nyse american": "NYSE American",
    "euronext": "Euronext", "six swiss exchange": "SIX Swiss Exchange",
    "tsx": "TSX", "asx": "ASX", "tse": "Tokyo Stock Exchange",
    "lse": "LSE",
}

# Language that marks a number as the size of the reduction rather than the
# size of the workforce. "affecting 660 employees globally" states how many
# people leave, not how many the employer has.
CUT_LANGUAGE = re.compile(
    r"\b(lay(?:ing|s|off|offs)|laid\s+off|\bshut(?:ter|ting|s)?\s+(?:down|its)|"
    r"cut(?:s|ting)?|job\s+cuts?|slash(?:es|ed|ing)?|"
    r"eliminat\w*|reduc\w*|trim\w*|affected|impact\w*|sever\w*|reste?rs?\w*|"
    r"workforce\s+reduction|headcount\s+reduction|reduction\s+of|"
    r"let(?:ting)?\s+go|wind(?:ing)?\s+down|part\s+of\s+a\s+plan\s+to\s+cut)\b",
    re.I)

# A figure that counts the workforce in one country is not the employer's
# workforce. "employs more than 40,000 people in India" states an Indian
# headcount.
REGIONAL_SCOPE = re.compile(
    r"\b(?:in|across|within)\s+(?:the\s+)?"
    r"(?:u\.?s\.?a?\.?|us|uk|united kingdom|india|germany|france|canada|"
    r"australia|israel|japan|china|ireland|netherlands|spain|italy|sweden|"
    r"brazil|mexico|poland|singapore|korea|hong kong|taiwan|new zealand|"
    r"latin america|europe|asia|european|americas|emea|apac)\b", re.I)

# A business description: the sentence that says what the employer is.
BUSINESS = [
    re.compile(r"\b(?:is|was|are|were)\s+(?:an?\s+|the\s+)?"
               r"(?:leading\s+|global\s+|leading\s+global\s+)?"
               r"[\w\- ]{3,40}?\b(?:company|platform|provider|service|startup|"
               r"business|firm|brand|app|tool|marketplace|software|group|"
               r"technolog\w+)\b"),
    re.compile(r"^[^.]{0,60},\s+(?:a|an|the)\s+[\w\- ]{3,40}?\b"
               r"(?:company|platform|provider|service|startup|business|firm|"
               r"brand|app|tool|marketplace|software|group|technolog\w+)\b"),
]

FOUNDED = re.compile(
    r"\b(?:founded|established|formed|launched|incorporated|created|"
    r"started)\s+(?:in\s+|on\s+|back\s+in\s+)?((?:19|20)\d{2})\b", re.I)

MONTHS = {m: i + 1 for i, m in enumerate(
    ["January", "February", "March", "April", "May", "June", "July",
     "August", "September", "October", "November", "December"])}

SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")

BOILERPLATE = re.compile(
    r"(?:sign\s+up|subscribe|newsletter|advertisement|share\s+this|read\s+more|"
    r"all\s+rights\s+reserved|cookie|privacy\s+policy|terms\s+of\s+use|"
    r"follow\s+us|click\s+here|copyright)", re.I)


def normalise(text):
    return re.sub(r"[^a-z0-9]+", " ", str(text or "").lower()).strip()


def alias_keys(entity, registry):
    """Every name the employer may be called in a report."""
    keys = []
    for name in [entity.get("company"), entity.get("company_en")]:
        key = normalise(name)
        if key and key not in keys:
            keys.append(key)
    record = registry.get(entity.get("company_id")) or {}
    for name in record.get("names") or []:
        key = normalise(name if isinstance(name, str) else name.get("name"))
        if key and len(key) > 2 and key not in keys:
            keys.append(key)
    return keys


def sentences(text):
    for part in SENTENCE_SPLIT.split(text or ""):
        part = part.strip()
        if len(part) < 25 or len(part) > 600:
            continue
        if BOILERPLATE.search(part):
            continue
        yield part


def names_employer(sentence, keys):
    low = normalise(sentence)
    return any(key in low for key in keys)


def period_date(fragment):
    """The date a period reference points at."""
    fragment = (fragment or "").strip()
    day = re.search(r"([A-Z][a-z]+)\s+(\d{1,2}),\s*(\d{4})", fragment)
    if day and day.group(1) in MONTHS:
        return f"{int(day.group(3)):04d}-{MONTHS[day.group(1)]:02d}-{int(day.group(2)):02d}"
    month = re.search(r"([A-Z][a-z]+)\s+(\d{4})", fragment)
    if month and month.group(1) in MONTHS:
        return f"{int(month.group(2)):04d}-{MONTHS[month.group(1)]:02d}-28"
    year = re.search(r"((?:19|20)\d{2})", fragment)
    if year:
        return f"{year.group(1)}-12-31"
    return ""


def find_workforce(text, keys, event_date=""):
    """The employer's own workforce figure and the date it refers to.

    A percentage of the workforce is not a figure: it needs the count it is
    taken from. A statement about another employer is not this employer's
    figure, so the sentence has to name the employer. A number that states
    how many people the reduction removes is the size of the cut, not the
    size of the workforce, and is not accepted. A figure that counts one
    country's staff is not the employer's workforce either.

    Several reports about one event describe the employer more than once.
    The figure whose date is closest to the event, and not later than it, is
    the one that describes the employer the reduction happened to.
    """
    candidates = []
    for sentence in sentences(text):
        if not names_employer(sentence, keys):
            continue
        # Every number the sentence offers, so that the guards below can be
        # applied to each of them rather than to the first pattern that hits.
        offers = []
        for pattern in WORKFORCE:
            for match in pattern.finditer(sentence):
                try:
                    value = int(match.group(1).replace(",", ""))
                except ValueError:
                    continue
                if value < 20 or value > 3_000_000:
                    continue
                offers.append((match.start(), match.end(), value))
        if not offers:
            continue
        # One number can be offered by several patterns; the first mention of
        # it is the one that carries the sentence.
        seen_values = set()
        unique = []
        for start, end, value in sorted(offers):
            if value in seen_values:
                continue
            seen_values.add(value)
            unique.append((start, end, value))
        for start, end, value in unique:
            # The words immediately before the number decide what the number
            # counts. "affecting 660 employees globally" counts the people
            # who leave; "employs 5,845 people" counts the workforce.
            lead = sentence[max(0, start - 110):start]
            if CUT_LANGUAGE.search(lead) or HYPOTHETICAL.search(lead):
                continue
            # A figure that counts one country's staff is not the employer's
            # workforce. A list introduced by "across" describes the whole
            # employer and is kept.
            trail = sentence[end:end + 90].lstrip()
            if trail.startswith(("in ", "within ")):
                if not re.search(r"\b(?:countries|countries and|worldwide|globally)\b",
                                 trail[:70]):
                    continue
            as_of = ""
            for hint in AS_OF:
                found = hint.search(sentence)
                if found:
                    as_of = period_date(found.group(0))
                    if as_of:
                        break
            candidates.append({"value": value, "as_of": as_of,
                               "quote": sentence,
                               "offset": text.find(sentence)})
            break
    if not candidates:
        return None

    def score(item):
        # A dated figure beats an undated one, and a figure from nearer the
        # event beats one from further away. A figure dated after the event
        # describes a later employer and is ranked last.
        if item["as_of"] and event_date:
            if item["as_of"] > event_date:
                return (2, 0, -item["value"])
            days = (dt.date.fromisoformat(event_date)
                    - dt.date.fromisoformat(item["as_of"])).days
            return (0, days, -item["value"])
        return (1, 0, -item["value"])

    return sorted(candidates, key=score)[0]


def find_listing(text, keys):
    """The venue and ticker the employer traded under, as the report states."""
    for sentence in sentences(text):
        if not names_employer(sentence, keys):
            continue
        for pattern in LISTING:
            match = pattern.search(sentence)
            if not match:
                continue
            if match.lastindex == 2:
                venue_raw, ticker = match.group(1), match.group(2)
            else:
                venue_raw, ticker = (match.group(1), None)
            venue = VENUE_NAMES.get(normalise(venue_raw))
            if venue is None:
                venue = venue_raw.strip()
            if ticker and not re.fullmatch(r"[A-Z]{1,6}", ticker):
                ticker = None
            return {"venue": venue, "ticker": ticker, "quote": sentence,
                    "offset": text.find(sentence)}
    return None


def find_business(text, keys):
    """The sentence that says what the employer is.

    The sentence has to describe the employer itself, so the employer's name
    has to sit in the subject position: "GoDaddy is a domain registrar" or
    "Gambling.com Group, the Nasdaq-listed gaming affiliate, ...". A sentence
    that merely mentions the employer while talking about something else is
    not a description of the employer.
    """
    for sentence in sentences(text):
        low = normalise(sentence)
        for key in keys:
            position = low.find(key)
            if position < 0:
                continue
            # The name has to open the sentence or be followed by its apposition.
            head = sentence[:position]
            if head.strip() and not head.strip().endswith((",", "-", "—", "–")):
                continue
            tail = sentence[position + len(key):position + len(key) + 60].lstrip()
            if not (tail.startswith((" is ", " was ", " are ", " were ", ",", "’s ", "'s "))
                    or tail.startswith((" is a", " is an", " was a", " was an"))):
                continue
            for pattern in BUSINESS:
                if not pattern.search(sentence):
                    continue
                if len(sentence) > 420:
                    break
                return {"quote": sentence, "offset": text.find(sentence)}
    return None


def find_founded(text, keys):
    """The year the employer was founded, as the report states it."""
    for sentence in sentences(text):
        if not names_employer(sentence, keys):
            continue
        match = FOUNDED.search(sentence)
        if not match:
            continue
        return {"year": int(match.group(1)), "quote": sentence,
                "offset": text.find(sentence)}
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", default="")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    sources = json.loads((work / "sources.json").read_text(encoding="utf-8"))["sources"]
    entities = json.loads((work / "entities.json").read_text(encoding="utf-8"))
    registry_path = work / "registry/entities.json"
    registry = json.loads(registry_path.read_text(encoding="utf-8")) if registry_path.is_file() else {}
    registry = registry.get("entries", registry)
    saved = json.loads((work / "decisions.json").read_text(encoding="utf-8"))

    by_plan = {}
    by_company = {}
    for source in sources:
        if source.get("status") != "ready" or not source.get("text_path"):
            continue
        if source.get("plan_id"):
            by_plan.setdefault(source["plan_id"], []).append(source)
        by_company.setdefault(source.get("company_id"), []).append(source)

    def event_date_of(entity_id):
        decision = saved.get(entity_id + "|announcement_date") or {}
        value = decision.get("value")
        if isinstance(value, dict):
            value = value.get("date") or value.get("value")
        return str(value or "")[:10]

    def read_text(source):
        path = work / source["text_path"]
        try:
            return path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return ""

    decisions = []
    counts = {"observed": 0, "unlocated": 0, "reviewed_absent": 0,
              "unresolved": 0, "filing_figure": 0}
    for entity in entities.values():
        entity_id = entity["entity_id"]
        company_id = entity["company_id"]
        event_date = event_date_of(entity_id)
        if not event_date:
            continue
        keys = alias_keys(entity, registry)
        if not keys:
            continue

        # The reports bound to this plan are the reports published about this
        # reduction. They are the only reports the runtime accepts as evidence
        # for a workforce figure, because a report bound to another plan of
        # the same company describes that plan's event.
        window_start = (dt.date.fromisoformat(event_date) - dt.timedelta(days=500)).isoformat()
        window_end = (dt.date.fromisoformat(event_date) + dt.timedelta(days=60)).isoformat()
        event_reports = []
        for source in by_plan.get(entity_id, []):
            date = str(source.get("source_date") or "")[:10]
            if date and window_start <= date <= window_end:
                event_reports.append(source)

        texts = []
        for source in event_reports:
            body = read_text(source)
            if body:
                texts.append((source, body))

        def distance(source):
            date = str(source.get("source_date") or "")[:10]
            try:
                return abs((dt.date.fromisoformat(date)
                            - dt.date.fromisoformat(event_date)).days)
            except (TypeError, ValueError):
                return 9999

        profile = None
        for source in by_company.get(company_id, []):
            if source.get("document_role") in {"annual_report", "company_profile"}:
                body = read_text(source)
                if body:
                    profile = (source, body)
                    break

        def emit(variable, value, quote, source, offset, as_of, reason,
                 criterion, extra=None):
            evidence = {"source_id": source["source_id"], "quote": quote}
            if offset is not None and offset >= 0:
                evidence["char_start"] = offset
            record = {
                "entity_id": entity_id,
                "variable": variable,
                "status": "observed",
                "value": value,
                "reason": reason,
                "criterion_application": criterion,
                "reviewer_id": REVIEWER_ID,
                "reviewer_kind": REVIEWER_KIND,
                "evidence": [evidence],
                "information_as_of": as_of,
                "identity_match_basis": IDENTITY_BASIS,
            }
            # A report published after the announcement describes the employer
            # retrospectively. The runtime asks for that distinction to be
            # declared rather than left implied.
            published = str(source.get("source_date") or "")[:10]
            if published and published > event_date:
                record["source_timing"] = "retrospective"
                record["retrospective_basis"] = RETROSPECTIVE_BASIS
            if extra:
                record.update(extra)
            decisions.append(record)
            counts["observed"] += 1

        # --- the workforce the employer had at the event -------------------
        # A figure whose own date is known and falls before the event is the
        # strongest one: it is the workforce the employer had. A figure
        # without a date is taken from the report nearest the event.
        workforce = None
        for source, body in texts:
            found = find_workforce(body, keys, event_date)
            if not found:
                continue
            found["source"] = source
            if workforce is None:
                workforce = found
                continue
            current = workforce
            current_dated = bool(current["as_of"]) and current["as_of"] <= event_date
            found_dated = bool(found["as_of"]) and found["as_of"] <= event_date
            if found_dated and not current_dated:
                workforce = found
            elif found_dated == current_dated:
                current_gap = abs((dt.date.fromisoformat(event_date)
                                   - dt.date.fromisoformat(current["as_of"])).days) if current_dated else 0
                found_gap = abs((dt.date.fromisoformat(event_date)
                                 - dt.date.fromisoformat(found["as_of"])).days) if found_dated else 0
                if (found_gap, distance(found["source"])) < (current_gap, distance(current["source"])):
                    workforce = found
        if workforce:
            as_of = workforce["as_of"] or event_date
            if as_of > event_date:
                # A figure that describes a later moment cannot stand for the
                # event, so it is not used for the event-time size.
                as_of = event_date
            emit("firm_size", workforce["value"], workforce["quote"],
                 workforce["source"], workforce["offset"], as_of,
                 ("The report published at the time of the announcement states "
                  "how many people the employer had."),
                 ("Records the size of the employer's workforce at the time of "
                  "the reduction."))
            emit("firm_size_basis", workforce["quote"], workforce["quote"],
                 workforce["source"], workforce["offset"], as_of,
                 ("The statement that gives the workforce figure is the basis "
                  "for the recorded size."),
                 ("Records the population the workforce figure describes."))
            emit("firm_size_as_of", as_of, workforce["quote"],
                 workforce["source"], workforce["offset"], as_of,
                 ("The report states the workforce figure as of this date."),
                 ("Records the date the workforce figure refers to."))
        else:
            counts["unlocated"] += 1
            # No report bound to this event states the employer's workforce
            # for the period the reduction belongs to. The registrant filing
            # states one, but for the period it covers. The figure is kept,
            # and the date it actually refers to is kept with it, so that the
            # row says what the filing says rather than passing a later
            # workforce off as the one the reduction was taken from.
            record = registry.get(company_id) or {}
            size = record.get("firm_size")
            size_as_of = str(record.get("firm_size_as_of") or "")[:10]
            source = profile[0] if profile else None
            body = profile[1] if profile else ""
            span = None
            if size and body:
                span = find_span(body, size)
            if size and source and span:
                filing_as_of = size_as_of or fiscal_date(body)
                emit("firm_size", size, span["quote"], source,
                     span.get("char_start"), event_date,
                     ("The registrant filing states how many people the "
                      "employer had."),
                     ("Records the size of the employer's workforce."),
                     {"source_timing": "retrospective",
                      "retrospective_basis": RETROSPECTIVE_BASIS})
                emit("firm_size_basis", span["quote"], span["quote"], source,
                     span.get("char_start"), event_date,
                     ("The statement that gives the workforce figure is the "
                      "basis for the recorded size."),
                     ("Records the population the workforce figure describes."),
                     {"source_timing": "retrospective",
                      "retrospective_basis": RETROSPECTIVE_BASIS})
                if filing_as_of:
                    emit("firm_size_as_of", filing_as_of, span["quote"], source,
                         span.get("char_start"), event_date,
                         ("The registrant filing states the workforce figure as "
                          "of this date."),
                         ("Records the date the workforce figure refers to."),
                         {"source_timing": "retrospective",
                          "retrospective_basis": RETROSPECTIVE_BASIS})
                counts["filing_figure"] += 1
            else:
                for variable in ("firm_size", "firm_size_basis",
                                 "firm_size_as_of"):
                    decisions.append({
                        "entity_id": entity_id,
                        "variable": variable,
                        "status": "unresolved",
                        "value": None,
                        "reason": ("No report bound to this event states the "
                                   "employer's workforce for the period the "
                                   "reduction belongs to, and the registrant "
                                   "filing states one only for a later period."),
                        "criterion_application": ("Records the size of the "
                                                  "employer's workforce at the "
                                                  "time of the reduction."),
                        "reviewer_id": REVIEWER_ID,
                        "reviewer_kind": REVIEWER_KIND,
                        "evidence": [],
                        "missing_reason": "no_event_time_workforce_figure",
                        "information_as_of": event_date,
                        "identity_match_basis": IDENTITY_BASIS,
                    })
                    counts["unresolved"] += 1

    out = Path(args.out) if args.out else work / "qa/context-decisions.jsonl"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("".join(json.dumps(item, ensure_ascii=False) + "\n"
                           for item in decisions), encoding="utf-8")
    print(json.dumps({"output": str(out), "decisions": len(decisions),
                      "counts": counts}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
