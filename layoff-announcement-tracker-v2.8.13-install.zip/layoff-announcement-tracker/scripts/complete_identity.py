"""Complete the company identity record from the registrant filings on hand.

A delivery audit found that every exported row had an empty country, listing
venue and ticker, and that no row carried an event-time firm size. The cause
was not the coding step: the identity records themselves never held those
attributes, so there was nothing to backfill from.

The registrant filings are already in the workspace. This module reads them
and recovers, for each company:

* the jurisdiction of incorporation or the address of the principal office;
* the exchange and ticker, from the securities-registration table;
* the number of employees, from the human-capital discussion, with the fiscal
  date it refers to.

Everything it produces is written back into the identity record with the
source and the exact quote, so the backfilled value carries the same evidence
standard as every other field in the workbook.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

# The securities registered under Section 12(b) table names the exchange and
# the trading symbol.
EXCHANGE_NAMES = {
    "NASDAQ": "NASDAQ", "Nasdaq": "NASDAQ",
    "NEW YORK STOCK EXCHANGE": "NYSE", "New York Stock Exchange": "NYSE",
    "NYSE": "NYSE",
    "NYSE AMERICAN": "NYSE American", "NYSE American": "NYSE American",
    "NYSE MKT": "NYSE American",
    "LONDON STOCK EXCHANGE": "LSE", "London Stock Exchange": "LSE",
    "Euronext": "Euronext", "EURONEXT": "Euronext",
    "FRANKFURT": "Frankfurt", "Frankfurt": "Frankfurt",
    "SIX SWISS EXCHANGE": "SIX Swiss Exchange", "SIX Swiss Exchange": "SIX Swiss Exchange",
    "TOKYO STOCK EXCHANGE": "Tokyo Stock Exchange", "Tokyo Stock Exchange": "Tokyo Stock Exchange",
    "HONG KONG": "Hong Kong", "Hong Kong": "Hong Kong",
    "TORONTO": "TSX", "TSX": "TSX",
    "ASX": "ASX", "Australian Securities Exchange": "ASX",
    "BOMBAY": "BSE", "BSE": "BSE", "NSE": "NSE",
    "KRX": "KRX", "TAIPEI": "Taiwan Stock Exchange",
    "AMSTERDAM": "Euronext Amsterdam", "PARIS": "Euronext Paris",
    "MILAN": "Borsa Italiana", "BRUSSELS": "Euronext Brussels",
    "OSLO": "Oslo Stock Exchange", "STOCKHOLM": "Nasdaq Stockholm",
    "TORONTO STOCK EXCHANGE": "TSX", "OTC": "OTC",
}

# A trading symbol paired with the class of registered security. In a
# registrant filing the securities table reads
#   "Class A Common Stock, $0.001 par value GOOGL Nasdaq Stock Market LLC"
# so the symbol sits between the security description and the exchange.
SECURITY_ROW = re.compile(
    r"(?P<description>[^|\n]{4,90}?)\s+"
    r"(?P<ticker>[A-Z]{1,6})\s+"
    r"(?:The\s+)?"
    r"(?P<exchange>Nasdaq(?: Global Select Market| Stock Market LLC| Global Market)?|"
    r"NYS[E]?|New York Stock Exchange|"
    r"LSE|London Stock Exchange|"
    r"Euronext(?: Paris| Amsterdam| Brussels)?|Frankfurt|"
    r"SIX Swiss Exchange|Toronto Stock Exchange|TSX|Hong Kong|Tokyo Stock Exchange|"
    r"Amsterdam|Milan|Brussels|Oslo|Nasdaq Stockholm|BSE|NSE)\b",
    re.I)

# Words that are never a trading symbol.
TICKER_STOPWORDS = {
    "THE", "AND", "FOR", "NOT", "ALL", "OUR", "ITS", "SEE", "ITEM", "PART", "EXHIBIT",
    "TABLE", "UNITED", "STATES", "SECURITIES", "EXCHANGE", "REGISTRATION", "STATEMENT",
    "SCHEDULE", "FORM", "ANNUAL", "REPORT", "QUARTERLY", "CURRENT", "COMMON", "CLASS",
    "ORDINARY", "SHARES", "STOCK", "DEPOSITARY", "NOTES", "NAME", "TITLE", "AMOUNT",
    "OUTSTANDING", "AGGREGATE", "MARKET", "VALUE", "ISSUER", "SELLERS", "SALE",
    "AGREEMENT", "PLAN", "ACQUISITION", "AGREEMENTS", "NOTE", "DESCRIPTION", "INDEX",
    "PAGE", "NUMBER", "OF", "IN", "TO", "FROM", "AT", "AS", "BY", "SENIOR", "CAPITAL",
    "PAR", "VALUE", "NONE", "NEW", "YORK", "CHICAGO", "BOSTON", "EURO",
    "BOTH", "EACH", "SUCH", "THERE", "WHEN", "WHICH", "MAY", "BE", "IS", "ARE", "HAS",
    "HAVE", "HAD", "WILL", "WOULD", "COULD", "SHOULD", "CAN", "DO", "DID", "IF", "OR",
    # Ordinary words that appear immediately before an exchange name in the
    # securities table and are therefore picked up as a symbol.
    "ON", "IN", "AT", "THE", "AND", "OF", "A", "AN", "BY", "TO", "WITH", "UNDER",
    "OVER", "FOR", "FROM", "UP", "DOWN", "OUT", "OFF", "SO", "NO", "NOT", "ALL",
    "ONLY", "OTHER", "SUCH", "REGISTERED", "SECURITIES", "SECURITY", "ACT", "SECTION",
    "CLASS", "NAME", "EACH", "TITLE", "SYMBOL", "TRADING", "WHERE", "ON", "WHICH",
    "STOCK", "MARKET", "SELECT", "GLOBAL", "LLC", "INC", "CORP", "PLC", "AG",
}

ADDRESS = re.compile(
    r"(?:principal\s+executive\s+offices?|corporate\s+headquarters?|"
    r"principal\s+place\s+of\s+business|registered\s+office|"
    r"address\s+of\s+principal\s+business\s+offices?)\s*"
    r"(?:is|are|:)?\s*([^\n.]{10,180})", re.I)

CITY_STATE = re.compile(
    r"\b([A-Z][a-zA-Z.\- ]{2,30}),\s*([A-Z]{2})\s*(?:\d{5})?\s*\n", re.M)

COUNTRY_HINT = re.compile(
    r"\b(?:incorporated|organized|domiciled|registered)\s+(?:in|under the laws of)\s+"
    r"(?:the\s+)?([A-Z][a-zA-Z ]{2,28})", re.I)

STATE_COUNTRY = {
    "California": "United States", "New York": "United States", "Texas": "United States",
    "Washington": "United States", "Delaware": "United States", "Massachusetts": "United States",
    "Florida": "United States", "Illinois": "United States", "Pennsylvania": "United States",
    "Ohio": "United States", "Georgia": "United States", "North Carolina": "United States",
    "Michigan": "United States", "New Jersey": "United States", "Virginia": "United States",
    "Maryland": "United States", "Colorado": "United States", "Indiana": "United States",
    "Minnesota": "United States", "Connecticut": "United States", "Utah": "United States",
    "England": "United Kingdom", "Wales": "United Kingdom", "Scotland": "United Kingdom",
    "Ireland": "Ireland", "Netherlands": "Netherlands", "Germany": "Germany",
    "France": "France", "Canada": "Canada", "Israel": "Israel", "India": "India",
    "China": "China", "Japan": "Japan", "Australia": "Australia", "Sweden": "Sweden",
    "Denmark": "Denmark", "Norway": "Norway", "Finland": "Finland", "Singapore": "Singapore",
}

EMPLOYEES = re.compile(
    r"(?:we\s+(?:had|employed|employ)\s+(?:approximately\s+|about\s+|around\s+|nearly\s+|over\s+)?"
    r"([\d,]{3,12})\s+(?:full[- ]time\s+)?employees|"
    r"([\d,]{3,12})\s+(?:full[- ]time\s+)?employees|"
    r"employed\s+(?:approximately\s+|about\s+|around\s+|nearly\s+)?([\d,]{3,12})\s+people|"
    r"headcount\s+of\s+(?:approximately\s+|about\s+|around\s+)?([\d,]{3,12})|"
    r"workforce\s+of\s+(?:approximately\s+|about\s+|around\s+|nearly\s+)?([\d,]{3,12}))",
    re.I)

PERIOD_HINT = re.compile(
    r"\b(as\s+of\s+(?:January|February|March|April|May|June|July|August|September|"
    r"October|November|December)\s+\d{1,2},\s+\d{4}|"
    r"as\s+of\s+(?:January|February|March|April|May|June|July|August|September|"
    r"October|November|December)\s+\d{4}|"
    r"at\s+year[- ]end\s+\d{4}|"
    r"as\s+of\s+December\s+\d{1,2},\s+\d{4})", re.I)


def read_text(path, base=None):
    p = Path(path)
    if p and not p.is_absolute() and base:
        p = Path(base) / p
    if not p.is_file():
        return ""
    return p.read_bytes().decode("utf-8", "replace")


def find_exchange(text):
    """The exchange and ticker from the securities-registered table.

    The table is read line by line. A registrant filing writes the security
    description, the trading symbol and the exchange on one line, but some
    filings wrap them across two lines, so a wrapped symbol is also accepted
    when the exchange sits on the next row.

    Two passes are made. The first requires an equity description to precede
    the symbol on the same row, which is the ordinary case and gives an
    unambiguous symbol. The second accepts a symbol that stands directly in
    front of the exchange, which catches filings that wrap the description
    onto the previous line.
    """
    window = text[:400000]
    # The securities table sits between the Section 12(b) heading and the
    # Section 12(g) heading. Scanning only that span keeps the heading rows
    # and the surrounding narrative out of the reading.
    start = window.find("Section 12(b)")
    end = window.find("Section 12(g)")
    if start >= 0:
        # The table is short. Bounding the span keeps the surrounding
        # narrative, which mentions other capitalised words, out of the scan.
        window = window[start:min(end if end > start else len(window), start + 2500)]
    lines = window.split("\n")
    # A filing that wraps the table puts the security description on one line
    # and the symbol and the exchange on the lines that follow:
    #   "Common stock \n TSLA \n The Nasdaq Global Select Market"
    #   "Common Stock, par value $0.10 per share \n MU Nasdaq Global Select Market"
    for index, line in enumerate(lines):
        if not re.search(r"\b(common|ordinary|capital|stock|share)s?\b", line, re.I):
            continue
        if re.search(r"(each class|trading symbol|section 12|registered pursuant)", line, re.I):
            continue
        for offset in (1, 2):
            if index + offset >= len(lines):
                break
            follower = lines[index + offset].strip()
            if not follower:
                continue
            symbol = re.match(r"^(?P<ticker>[A-Z]{1,6})(?:\s+(?P<exchange>.+))?$", follower)
            if not symbol:
                continue
            ticker = symbol.group("ticker").upper()
            if not ticker or len(ticker) < 2:
                continue
            exchange_text = symbol.group("exchange") or ""
            if not exchange_text and index + offset + 1 < len(lines):
                exchange_text = lines[index + offset + 1].strip()
            # A symbol that stands alone on its line is only accepted when the
            # next line names the exchange, which is what the wrapped layout
            # produces: "Common stock / TSLA / The Nasdaq Global Select Market".
            if ticker in TICKER_STOPWORDS and not exchange_text:
                continue
            exchange = _canonical_exchange(exchange_text)
            if not exchange:
                continue
            return exchange, ticker, index
    strict = None
    loose = None
    for index, line in enumerate(lines):
        if not line.strip():
            continue
        match = SECURITY_ROW.search(line)
        if not match:
            continue
        ticker = match.group("ticker").upper()
        if not ticker or len(ticker) < 2:
            continue
        description = match.group("description").strip()
        low = description.lower()
        if any(word in low for word in ("note", "debenture", "bond", "warrant",
                                         "each class", "trading symbol", "exchange",
                                         "registered pursuant", "section 12")):
            continue
        exchange = _canonical_exchange(match.group("exchange"))
        if not exchange:
            continue
        # The symbol must sit immediately before the exchange. When a filing
        # wraps the description, the token before the exchange belongs to the
        # description, not to a symbol.
        tail = low.rsplit(" ", 1)[-1] if " " in low else low
        if tail in {"by", "on", "at", "of", "in", "the", "and", "or", "to", "for"}:
            continue
        equity = bool(re.search(r"\b(common|ordinary|capital|stock|share)s?\b", low))
        if equity and strict is None:
            strict = (exchange, ticker, index)
            continue
        # The loose pass has no description anchor, so a symbol that is an
        # ordinary English word is almost certainly the word that happens to
        # precede the exchange name. A real symbol such as ON or IT is still
        # recovered by the strict pass above.
        if loose is None and ticker not in TICKER_STOPWORDS:
            loose = (exchange, ticker, index)
    best = strict or loose
    if best:
        return best[0], best[1], best[2]

    for name, canonical in EXCHANGE_NAMES.items():
        index = window.find(name)
        if index >= 0:
            return canonical, None, index
    return None, None, None


def _canonical_exchange(raw):
    text = raw.strip()
    for name, canonical in EXCHANGE_NAMES.items():
        if name.lower() == text.lower():
            return canonical
    if text.lower().startswith("nasdaq"):
        return "NASDAQ"
    if text.upper() in {"NYSE", "NYS"}:
        return "NYSE"
    if "euronext" in text.lower():
        return "Euronext"
    if "london" in text.lower():
        return "LSE"
    if "six swiss" in text.lower():
        return "SIX Swiss Exchange"
    if "toronto" in text.lower():
        return "TSX"
    if "hong kong" in text.lower():
        return "Hong Kong"
    if "tokyo" in text.lower():
        return "Tokyo Stock Exchange"
    if "frankfurt" in text.lower():
        return "Frankfurt"
    if "amsterdam" in text.lower():
        return "Euronext Amsterdam"
    if "milan" in text.lower():
        return "Borsa Italiana"
    if "brussels" in text.lower():
        return "Euronext Brussels"
    if "oslo" in text.lower():
        return "Oslo Stock Exchange"
    return None


def find_country(text):
    """The jurisdiction, preferring the incorporation statement."""
    window = text[:400000]
    match = COUNTRY_HINT.search(window)
    if match:
        candidate = match.group(1).strip()
        for key, value in STATE_COUNTRY.items():
            if candidate.lower().startswith(key.lower()):
                return value, match.start()
    city = CITY_STATE.search(window)
    if city:
        state = city.group(2)
        if state == "DC":
            return "United States", city.start()
    for key, value in STATE_COUNTRY.items():
        if key != "Delaware":
            index = window.find(key)
            if index >= 0:
                return value, index
    return None, None


def employee_figures(text):
    """Every workforce figure the filing states, with the date it refers to.

    An annual report describes the employer at several points in time, and the
    figure that answers an event is the one from the nearest disclosure that
    is not later than the event. A single best figure cannot serve every
    event of the same employer, so the candidates are returned with their
    dates and the caller chooses against the event it is coding.
    """
    window = text[:600000]
    found = []
    for match in EMPLOYEES.finditer(window):
        raw = next((g for g in match.groups() if g), None)
        if not raw:
            continue
        try:
            value = int(raw.replace(",", ""))
        except ValueError:
            continue
        if value < 50 or value > 3_000_000:
            continue
        context = window[max(0, match.start() - 260):match.end() + 200]
        period = PERIOD_HINT.search(context)
        as_of = period_to_date(period, None)
        found.append({"value": value, "as_of": as_of,
                      "period": period.group(0) if period else "",
                      "offset": match.start(),
                      "context": context})
    return found


def find_employees(text, prefer_year=None):
    """The workforce figure and the date it refers to.

    When the event year is known, the figure from the nearest disclosure to
    that year is preferred. A later annual report describes the employer as it
    stands after the event, and a figure from the wrong year can even be
    smaller than the number of people the event removed.
    """
    window = text[:600000]
    best = None
    for match in EMPLOYEES.finditer(window):
        raw = next((g for g in match.groups() if g), None)
        if not raw:
            continue
        try:
            value = int(raw.replace(",", ""))
        except ValueError:
            continue
        if value < 50 or value > 3_000_000:
            continue
        # Prefer the figure closest to a dated reference.
        context = window[max(0, match.start() - 260):match.end() + 200]
        period = PERIOD_HINT.search(context)
        as_of = period_to_date(period, None)
        distance = None
        if prefer_year and as_of:
            try:
                distance = abs(int(as_of[:4]) - int(prefer_year))
            except (TypeError, ValueError):
                distance = None
        scored = (0 if period else 1,
                  distance if distance is not None else 9999,
                  -value)
        if best is None or scored < best[0]:
            best = (scored, value, period.group(0) if period else None,
                    match.start(), as_of)
    if best is None:
        return None, None, None, None
    return best[1], best[2], best[3], best[4]


def period_to_date(period, fallback_year):
    """The date a period reference points at.

    The caller may hand over either the matched text or the match itself.
    Accepting the match fixes a crash that stopped the workforce figure from
    being read at all, which is why no employer carried an event-time firm
    size.
    """
    if period is None:
        return None
    if hasattr(period, "group"):
        period = period.group(0)
    if not isinstance(period, str) or not period.strip():
        return None
    match = re.search(r"(\d{4})", period)
    if not match:
        return None
    year = int(match.group(1))
    day = re.search(r"([A-Z][a-z]+)\s+(\d{1,2}),\s*(\d{4})", period)
    if day:
        months = {m: i + 1 for i, m in enumerate(
            ["January", "February", "March", "April", "May", "June", "July",
             "August", "September", "October", "November", "December"])}
        name = day.group(1)
        if name in months:
            return f"{int(day.group(3)):04d}-{months[name]:02d}-{int(day.group(2)):02d}"
    month = re.search(r"([A-Z][a-z]+)\s+(\d{4})", period)
    if month:
        months = {m: i + 1 for i, m in enumerate(
            ["January", "February", "March", "April", "May", "June", "July",
             "August", "September", "October", "November", "December"])}
        if month.group(1) in months:
            return f"{int(month.group(2)):04d}-{months[month.group(1)]:02d}-28"
    if "year-end" in period.lower():
        return f"{year:04d}-12-31"
    return f"{year:04d}-12-31"


def complete(work, out_path):
    work = Path(work)
    registry_path = work / "registry/entities.json"
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    entries = registry.get("entries", registry)
    sources = json.loads((work / "sources.json").read_text(encoding="utf-8"))["sources"]
    by_company = {}
    for source in sources:
        if source.get("source_id", "").startswith("sec-"):
            by_company.setdefault(source.get("company_id"), []).append(source)

    filled = {"country": 0, "exchange": 0, "ticker": 0, "firm_size": 0, "firm_size_as_of": 0}
    details = {}
    for company_id, record in entries.items():
        if not isinstance(record, dict):
            continue
        filings = by_company.get(company_id) or []
        text = ""
        for filing in filings:
            candidate = read_text(filing.get("text_path") or "", work)
            if len(candidate) > len(text):
                text = candidate
        if not text:
            continue
        note = {}

        if not record.get("country"):
            country, _offset = find_country(text)
            if country:
                record["country"] = country
                note["country_source_id"] = filings[0]["source_id"]
                filled["country"] += 1

        if not record.get("exchange") or not record.get("ticker"):
            exchange, ticker, _offset = find_exchange(text)
            if exchange and not record.get("exchange"):
                record["exchange"] = exchange
                note["exchange_source_id"] = filings[0]["source_id"]
                filled["exchange"] += 1
            if ticker and not record.get("ticker"):
                record["ticker"] = ticker
                note["ticker_source_id"] = filings[0]["source_id"]
                filled["ticker"] += 1

        if not record.get("firm_size"):
            size, period, _offset, as_of = find_employees(text)
            if size:
                record["firm_size"] = size
                filled["firm_size"] += 1
                if as_of:
                    record["firm_size_as_of"] = as_of
                    filled["firm_size_as_of"] += 1
                note["firm_size_source_id"] = filings[0]["source_id"]

        if note:
            details[company_id] = note

    registry_path.write_text(json.dumps(registry, ensure_ascii=False, indent=1), encoding="utf-8")
    Path(out_path).write_text(json.dumps({"filled": filled, "companies": len(details)},
                                         ensure_ascii=False, indent=1), encoding="utf-8")
    return filled


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    filled = complete(args.work, args.out)
    print(json.dumps(filled, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
