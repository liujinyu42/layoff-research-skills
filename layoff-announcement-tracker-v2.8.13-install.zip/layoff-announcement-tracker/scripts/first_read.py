"""Fetch one selected public article locally and print a small first-read view."""
import argparse
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlsplit
from bs4 import BeautifulSoup
from review_packet import canonical, excerpts

def summarize(body, terms):
    spans = excerpts(body, terms)
    return [{'start':a,'end':min(b,a+600),'quote':body[a:min(b,a+600)]} for a,b in spans[:3]]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--work',type=Path,required=True)
    p.add_argument('--url',required=True)
    p.add_argument('--term',action='append',default=[])
    a=p.parse_args()
    if urlsplit(a.url).scheme not in ('http','https'):
        p.error('Provide a publisher HTTP or HTTPS URL')
    base=a.work/'publisher-pages'/hashlib.sha256(canonical(a.url).encode()).hexdigest()
    base.mkdir(parents=True,exist_ok=True)
    path=base/'source.txt'
    if not path.exists():
        try:
            with urlopen(Request(a.url,headers={'User-Agent':'Layoff research reader/2.8.12'}),timeout=25) as response:
                mime=response.headers.get_content_type()
                if mime not in ('text/html','application/xhtml+xml','text/plain'):
                    raise ValueError('Use the browser or document reader for '+mime)
                raw=response.read(5000001)
                if len(raw)>5000000:
                    raise ValueError('Use document reader for large source')
                (base/'source.raw').write_bytes(raw)
                soup=BeautifulSoup(raw,'html.parser')
                for tag in soup.select('script,style,nav,footer,header,aside'): tag.decompose()
                node=soup.find('article') or soup.find('main') or soup
                body=node.get_text(' ',strip=True)
                path.write_text(body)
        except Exception as error:
            print(json.dumps({'status':'needs_browser','reason':str(error),'url':a.url}))
            return
    body=path.read_text()
    quotes=summarize(body,a.term)
    print(json.dumps({'url':a.url,'source':str(path),'status':'review' if quotes else 'inspect_source','excerpts':quotes},ensure_ascii=False))
if __name__=='__main__':
    main()
