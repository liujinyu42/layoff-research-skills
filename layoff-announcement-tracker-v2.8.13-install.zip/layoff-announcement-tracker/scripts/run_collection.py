"""Run the receipt-backed sweep and queue candidates for substantive review."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from researchcore import coding, event_plans  # noqa: E402
from researchcore import sources as source_module  # noqa: E402

def log(message):
    print(f"[{dt.datetime.now().strftime('%H:%M:%S')}] {message}", flush=True)


def run(cmd, cwd=None, check=True):
    """Run a bundled runtime command and surface its output."""
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if check and result.returncode != 0:
        raise RuntimeError(f"command failed: {' '.join(cmd)}\n{result.stdout}\n{result.stderr}")
    return result


def skill_root():
    return Path(__file__).resolve().parent.parent


def read_json(path, default=None):
    p = Path(path)
    if not p.is_file():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return default


def stage1_seeds(work, workers=8, pace=0.15, only_channel=""):
    """Run the planned Stage-1 channel sweep and import the receipts.

    Stage 1 is the source-first pass: every roster company is checked against
    each tracker channel and its own issuer filing before any web search is
    planned. The previous round executed this by hand in throwaway scripts, so
    the step is captured here as part of the same resumable run.
    """
    plan_path = Path(work) / "discovery/seed-plan.json"
    if not plan_path.is_file():
        log("stage 1: planning the channel sweep")
        run([sys.executable, str(skill_root() / "scripts/research.py"),
             "seed-plan", "--work", str(work)], check=False)
    plan = read_json(plan_path, {}) or {}
    tasks = plan.get("tasks", [])
    if not tasks:
        log("stage 1: no planned tasks")
        return {}
    receipts = read_json(Path(work) / "discovery/seed-receipts.json", {}) or {}
    outstanding = [t for t in tasks if t["task_id"] not in receipts]
    if outstanding:
        log(f"stage 1: executing {len(outstanding)} of {len(tasks)} channel task(s)")
        out = Path(work) / "discovery/seed-batch.json"
        cmd = [sys.executable, str(skill_root() / "scripts/collect_seeds.py"),
               "--work", str(work), "--out", str(out),
               "--workers", str(workers), "--pace", str(pace)]
        if only_channel:
            cmd += ["--only-channel", only_channel]
        result = run(cmd, check=False)
        if result.returncode != 0:
            log("stage 1: collector failed\n" + (result.stderr or "")[-800:])
        if out.is_file():
            log("stage 1: importing receipts")
            run([sys.executable, str(skill_root() / "scripts/research.py"),
                 "seed-import", "--work", str(work), "--file", str(out)], check=False)
    status = read_json(Path(work) / "review/seed-next.json", {}) or {}
    pending = len(status.get("pending") or [])
    log(f"stage 1: pending={pending} gaps={len(status.get('gaps') or [])}")
    return status


def stage2_search(work, engine="auto", workers=12, pace=0.12, only_company=""):
    """Run the planned Stage-2 searches and import the receipts."""
    plan = read_json(Path(work) / "discovery/plan.json")
    if not plan:
        raise RuntimeError("discovery/plan.json is missing; run discovery-plan first")
    tasks = plan["tasks"]
    if only_company:
        tasks = [t for t in tasks if t["company_id"] == only_company]
    receipts = read_json(Path(work) / "discovery/receipts.json", {}) or {}
    outstanding = [t for t in tasks if t["task_id"] not in receipts]
    if outstanding:
        log(f"stage 2: executing {len(outstanding)} of {len(tasks)} planned queries")
        out = Path(work) / "discovery/google-batch.json"
        cmd = [sys.executable, str(skill_root() / "scripts/collect_discovery.py"),
               "--work", str(work), "--out", str(out), "--engine", engine,
               "--workers", str(workers), "--pace", str(pace)]
        if only_company:
            cmd += ["--only-company", only_company]
        result = run(cmd, check=False)
        if result.returncode != 0:
            log("stage 2: collector failed\n" + result.stderr[-800:])
        if out.is_file():
            log("stage 2: importing receipts")
            run([sys.executable, str(skill_root() / "scripts/research.py"),
                 "discovery-import", "--work", str(work), "--file", str(out)], check=False)
    status = read_json(Path(work) / "qa/discovery-status.json", {}) or {}
    log(f"stage 2: pass={status.get('pass')} pending={status.get('pending_tasks')} "
        f"relevant_hits={status.get('unique_relevant_hits')}")
    return status


def load_identities(work):
    """Verified company identities, keyed by company_id."""
    registry = read_json(Path(work) / "registry/entities.json", {}) or {}
    entries = registry.get("entries", registry)
    out = {}
    for company_id, record in entries.items():
        if not isinstance(record, dict):
            continue
        identity = {
            "company_id": company_id,
            "display_name": record.get("display_name") or record.get("company"),
            "names": record.get("names") or [],
            "aliases": record.get("aliases") or [],
            "country": record.get("country"),
            "exchange": record.get("exchange"),
            "ticker": record.get("ticker"),
            "listed_at_event": record.get("listed_at_event"),
            "firm_size": record.get("firm_size"),
            "firm_size_as_of": record.get("firm_size_as_of"),
            "cik": record.get("registrant_cik") or record.get("cik"),
        }
        out[company_id] = identity
    return out


def _field_topics(skill_root):
    """The topic of each field, which decides the extra review checks."""
    import json as _json
    path = Path(skill_root) / "assets" / "event_schema.json"
    try:
        book = _json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}
    return {f.get("id"): f.get("topic") or "" for f in book.get("fields", [])}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", required=True)
    parser.add_argument("--engine", default="auto", choices=["auto", "gnews", "bing"])
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--pace", type=float, default=0.12)
    parser.add_argument("--only-company", default="")
    parser.add_argument("--only-channel", default="")
    parser.add_argument("--seed-workers", type=int, default=8)
    parser.add_argument("--skip-search", action="store_true")
    parser.add_argument("--skip-retrieve", action="store_true")
    parser.add_argument("--resolve-publishers", action="store_true",
                        help="attempt direct publisher URL resolution before registration")
    parser.add_argument("--candidates-only", action="store_true",
                        help="stop after registering events and preparing candidate reviews")
    parser.add_argument("--export", action="store_true", default=True)
    parser.add_argument("--no-export", dest="export", action="store_false")
    parser.add_argument("--reset-decisions", action="store_true", default=False,
                        help="replace the previous run's decisions with this run's")
    parser.add_argument("--keep-decisions", dest="reset_decisions",
                        action="store_false")
    args = parser.parse_args()

    work = Path(args.work).resolve()
    work.mkdir(parents=True, exist_ok=True)

    log("checking the installed runtime")
    result = run([sys.executable, str(skill_root() / "scripts/research.py"), "runtime-check"],
                 check=False)
    print(result.stdout[-800:])
    if result.returncode or not json.loads(result.stdout).get("pass"):
        raise SystemExit("runtime-check did not pass; the installed runtime is not usable")

    if not (work / "config.json").is_file():
        parser.error("Initialize the event workspace with research.py init before collection")

    if not args.skip_search:
        registry = run([sys.executable, str(skill_root() / "scripts/research.py"),
                        "registry-check", "--work", str(work)])
        if json.loads(registry.stdout).get("unverified"):
            raise SystemExit("Verify the remaining roster identities before running the sweep.")
        stage1_seeds(work, args.seed_workers, args.pace, args.only_channel)
        result = run([sys.executable, str(skill_root() / "scripts/research.py"),
                      "discovery-plan", "--work", str(work)], check=False)
        if not (work / "discovery/plan.json").is_file() or not json.loads(result.stdout).get("tasks"):
            raise SystemExit(result.stdout or result.stderr or "Discovery planning did not produce tasks.")
        stage2_search(work, args.engine, args.workers, args.pace, args.only_company)

    if not args.skip_retrieve:
        command = [sys.executable, str(skill_root() / "scripts/register_candidates.py"),
                   "--work", str(work)]
        if args.resolve_publishers:
            command.append("--resolve")
        run(command)
    from close_candidate_gaps import run as reconcile_candidates
    reconcile_candidates(work)
    if args.candidates_only:
        return
    identities = load_identities(work)
    plans = read_json(work / "qa/event-plans.json", {})["plans"]

    log("generating source-bound decisions")
    sources = {}
    for row in (read_json(work / "sources.json", {}) or {}).get("sources", []):
        # The recorded text path is relative to the workspace.
        sources[row["source_id"]] = {**row, "_work": str(work)}
    # Sources blocked by operator configuration stay visible: a missing
    # credential must delete no source from the plan, and the delivery review
    # must see exactly which filings the round could not fetch.
    config_gaps = source_module.configuration_gaps(work)
    if config_gaps:
        log(f"configuration gaps: {len(config_gaps)} source(s) blocked on operator "
            "configuration; see review/configuration-gaps.json")
    existing = {} if args.reset_decisions else read_json(work / "decisions.json", {}) or {}
    first_round = []
    aliases_by_company = {}
    for plan in plans:
        if plan.get("event_review"):
            # Reviewed events need field decisions with their actual quoted
            # date and scope. The automatic coder uses a publication-date proxy.
            continue
        identity = identities.get(plan["company_id"], {})
        aliases = event_plans.company_aliases(identity)
        if not aliases:
            continue
        aliases_by_company[plan["company_id"]] = list(aliases)
        first_round += coding.build_plan_decisions(
            plan, identity, sources, aliases, plan["event_date"][:4])
    first_round = [item for item in first_round
                   if item["entity_id"] + "|" + item["variable"] not in existing]
    log(f"first-round decisions: {len(first_round)}")
    coding.write_jsonl(work / "qa/decisions-generated.jsonl", first_round)

    if not first_round and args.reset_decisions:
        parser.error("No automatic decisions were generated. Retain existing decisions.")
    log("submitting decisions")
    # The current run defines the decision set. Decisions left over from an
    # earlier run describe plans this run did not find, and keeping them
    # makes the audit see two readings of the same field.
    if args.reset_decisions:
        stale = work / "decisions.json"
        if stale.is_file():
            archive = work / "history"
            archive.mkdir(parents=True, exist_ok=True)
            shutil.copy2(stale, archive / ("decisions-previous-" + str(int(time.time())) + ".json"))
            stale.unlink()
        log("cleared the decisions from the previous run")
    run([sys.executable, str(skill_root() / "scripts/research.py"), "apply",
         "--work", str(work), "--decisions", str(work / "qa/decisions-generated.jsonl")],
        check=False)
    preflight = read_json(work / "qa/apply-preflight.json", {}) or {}
    if not preflight.get("pass"):
        log(f"decision submission rejected: {len(preflight.get('errors', []))} errors")

    # The second review binds to the decisions the runtime accepted, so it is
    # built from the applied decisions rather than from the submitted ones.
    applied = read_json(work / "decisions.json", {}) or {}
    topics = _field_topics(skill_root())
    second = coding.build_second_reviews(first_round, sources, applied, topics,
                                         aliases_by_company=aliases_by_company)
    coding.write_jsonl(work / "qa/second-generated.jsonl", second)
    log(f"second reviews: {len(second)}")
    run([sys.executable, str(skill_root() / "scripts/research.py"), "apply-second",
         "--work", str(work), "--decisions", str(work / "qa/second-generated.jsonl")],
        check=False)

    from prepare_followups import prepare
    log(f"measurement followups: {len(prepare(work))}")

    log("auditing")
    run([sys.executable, str(skill_root() / "scripts/research.py"), "audit", "--work", str(work)],
        check=False)
    audit = read_json(work / "qa/audit.json", {}) or {}
    log(f"audit: integrity_pass={audit.get('integrity_pass')} errors={len(audit.get('errors', []))}")

    if args.export:
        log("exporting")
        export = run([sys.executable, str(skill_root() / "scripts/research.py"), "export",
                      "--work", str(work), "--output", str(work / "1_layoff_announcements.xlsx"),
                      "--allow-partial"], check=False)
        if export.returncode:
            raise SystemExit(export.stdout or export.stderr or "Export failed. See qa/audit.json.")
    log("done")


if __name__ == "__main__":
    main()
