# v1.5.7-rc4
Fixed an event audit import-order error. Internal technology measures require internal use. New event workspaces default to plan grain and fold implementation waves into their parent plans. Extensions require separate evidence review. Missing or invalid contracts produce explicit errors.

The rc3 contract path was correct. This release retains it and adds a test that loads the bundled asset.

Historical rc4 validation passed 37 regression tests, including corrected expectations for two internal adoption tests. An existing Kimi event workspace audited as PARTIAL with its original blockers. The historical run used existing sources and retained the rc3 schemas and contracts.
