import sys,hashlib,unittest,copy,json
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'skills/listed-filing-extractor/scripts'))
from researchcore.semantic_receipts import review_gaps
from researchcore.review_delivery import coverage
class Gates(unittest.TestCase):
 def test_zero_bounds(self):
  self.assertEqual(coverage({'x|v_disclosed':{'variable':'v_disclosed','status':'observed','value':0}})['v_disclosed']['negative'],1)
 def test_unresolved_not_negative(self):
  self.assertEqual(coverage({'x|v_disclosed':{'variable':'v_disclosed','status':'unresolved','value':None}})['v_disclosed']['unknown'],1)
 def negative(self):
  t='Compensation assessment: no AI performance criterion.'
  d={'variable':'ai_exec_comp_disclosed','status':'observed','value':0,'reviewed_scopes':[{'source_id':'s'}],'negative_review':{'sections':[{'source_id':'s','start':0,'end':len(t),'section':'CD&A','section_sha256':hashlib.sha256(t.encode()).hexdigest(),'finding':'No qualifying linkage.'}],'near_misses':[],'no_candidate_basis':'No AI performance criterion in this synthetic section.'}}
  return d,{'s':t}
 def test_negative_missing_receipt(self):
  d,t=self.negative();d.pop('negative_review');self.assertTrue(review_gaps({'x':d},t))
 def test_negative_valid(self):
  d,t=self.negative();self.assertEqual(review_gaps({'x':d},t),[])
 def test_stale_negative(self):
  d,t=self.negative();t['s']+=' changed';d['negative_review']['sections'][0]['end']+=8;self.assertTrue(review_gaps({'x':d},t))
 def test_candidate_exclusion_required(self):
  d,t=self.negative();d['negative_review']['near_misses']=[{'source_id':'s','quote':'AI'}];self.assertTrue(review_gaps({'x':d},t))
 def test_future_internal_use(self):
  d={'variable':'ai_integration','status':'observed','value':'Will use','evidence':[{'quote':'will use'}],'operational_use':{'use_context':'internal_operations','stage':'planned','process':'support','evidence_indices':[0]}}
  self.assertTrue(review_gaps({'x':d},{}))
 def test_customer_product_deployed_rejected(self):
  d={'variable':'new_tech_adoption','status':'observed','value':'Shipped','evidence':[{}],'operational_use':{'use_context':'customer_product','stage':'deployed_customer','process':'customer analytics suite','evidence_indices':[0]}}
  self.assertTrue(review_gaps({'x':d},{}))
 def test_internal_use_valid(self):
  d={'variable':'ai_integration','status':'observed','value':'Use','evidence':[{}],'operational_use':{'use_context':'internal_operations','stage':'deployed_internal','process':'fraud detection','evidence_indices':[0]}}
  self.assertEqual(review_gaps({'x':d},{}),[])
 def test_legacy_aliases_still_valid(self):
  d={'variable':'ai_integration','status':'observed','value':'Use','evidence':[{}],'operational_use':{'use_context':'internal','stage':'established_use','process':'fraud detection','evidence_indices':[0]}}
  self.assertEqual(review_gaps({'x':d},{}),[])
 def test_contract_vocab_compliant_records(self):
  payload=json.loads((root/'skills/listed-filing-extractor/assets/tech_evidence_contract.json').read_text())
  contexts=set(payload['vocabularies']['use_context']);stages=set(payload['vocabularies']['adoption_stage'])
  self.assertIn('internal_operations',contexts);self.assertIn('deployed_both',stages)
  for context,stage in [('internal_operations','deployed_internal'),('both','deployed_both'),('internal_operations','pilot')]:
   d={'variable':'ai_integration','status':'observed','value':'Use','evidence':[{}],'operational_use':{'use_context':context,'stage':stage,'process':'documented process','evidence_indices':[0]}}
   self.assertEqual(review_gaps({'x':d},{}),[],msg=context+'/'+stage)
 def test_unspecified_context_never_qualifies(self):
  d={'variable':'ai_integration','status':'observed','value':'Use','evidence':[{}],'operational_use':{'use_context':'unspecified','stage':'deployed_internal','process':'fraud detection','evidence_indices':[0]}}
  self.assertTrue(review_gaps({'x':d},{}))
 def test_unknown_stage_never_qualifies(self):
  d={'variable':'ai_integration','status':'observed','value':'Use','evidence':[{}],'operational_use':{'use_context':'internal_operations','stage':'unknown','process':'fraud detection','evidence_indices':[0]}}
  self.assertTrue(review_gaps({'x':d},{}))
 def test_not_separate_needs_receipt(self):
  d,t=self.negative();d['status']='not_separate';d['value']=None;d.pop('negative_review')
  self.assertTrue(review_gaps({'x':d},t))
 def test_not_separate_valid_with_receipt(self):
  d,t=self.negative();d['status']='not_separate';d['value']=None
  self.assertEqual(review_gaps({'x':d},t),[])
 def test_mixed_bonus_valid(self):
  d={'variable':'ai_exec_comp','status':'observed','value':'AI among bonus criteria','ai_pay_link':{'link_type':'mixed_bonus_factor','recipient':'participating NEOs','award_basis':'annual cash bonus'}}
  self.assertEqual(review_gaps({'x':d},{}),[])
 def test_total_needs_perimeter(self):
  self.assertTrue(review_gaps({'x':{'variable':'restructuring_charges','status':'observed','value':3933000000}},{}))
 def test_total_valid(self):
  d={'variable':'restructuring_charges','status':'observed','value':100,'charge_perimeter':{'included':['severance','facilities'],'other_charge_review':'Reviewed adjacent notes; none excluded.','total_basis':'Issuer total.'}}
  self.assertEqual(review_gaps({'x':d},{}),[])

class PlanAndSourceRegressions(unittest.TestCase):
 def test_cycle_is_fatal(self):
  from researchcore.delivery_quality import canonical_view
  entities={p:{'company_id':'issuer'} for p in ['a','b']}
  decisions={'a|plan_relationship':{'value':'same_plan_update'},'a|related_plan_id':{'value':'b'},
             'b|plan_relationship':{'value':'same_plan_update'},'b|related_plan_id':{'value':'a'}}
  _,_,issues=canonical_view(entities,decisions)
  self.assertTrue(any(i.get('fatal') for i in issues))
 def test_earlier_update_cannot_disappear(self):
  from researchcore.delivery_quality import canonical_view
  entities={p:{'company_id':'issuer'} for p in ['a','b']}
  decisions={'b|plan_relationship':{'value':'same_plan_update'},'b|related_plan_id':{'value':'a'},
             'a|announcement_date':{'value':'2024-03-01'},'b|announcement_date':{'value':'2024-01-01'}}
  _,_,issues=canonical_view(entities,decisions)
  self.assertTrue(any(i.get('fatal') for i in issues))
 def test_unknown_relationship_is_preserved(self):
  from researchcore.delivery_quality import canonical_view
  entities={'a':{'company_id':'issuer'}}
  decisions={'a|plan_relationship':{'value':'unresolved','status':'observed'}}
  _,mapping,issues=canonical_view(entities,decisions)
  self.assertEqual(mapping,{'a':'a'})
  self.assertTrue(issues)
 def test_implementation_folded_only_at_plan_granularity(self):
  from researchcore.delivery_quality import canonical_view,plan_count_by_relation
  entities={p:{'company_id':'issuer'} for p in ['a','b']}
  decisions={'a|plan_relationship':{'value':'independent'},
             'b|plan_relationship':{'value':'implementation_of'},'b|related_plan_id':{'value':'a'}}
  _,mapping,_=canonical_view(entities,decisions,'announcement')
  self.assertEqual(mapping,{'a':'a','b':'b'})
  _,mapping,_=canonical_view(entities,decisions,'plan')
  self.assertEqual(mapping,{'a':'a','b':'a'})
  self.assertEqual(plan_count_by_relation(entities,decisions),{'independent':1,'implementation_of':1})
 def test_compressed_html_cannot_be_ready(self):
  import gzip
  from researchcore.sources import _normalize
  with self.assertRaises(ValueError):
   _normalize(gzip.compress(b'<html><body>Source content</body></html>'),'.html','text/html')
 def test_plain_html_still_normalizes(self):
  from researchcore.sources import _normalize
  text,_,_,status=_normalize(b'<html><body>Source content</body></html>','.html','text/html')
  self.assertEqual((text,status),('Source content','ready'))
class AuditRegressions(unittest.TestCase):
 def test_boolean_attestation_rejected(self):
  d,t=Gates().negative();d['negative_review']['no_candidate_basis']=True
  self.assertTrue(review_gaps({'x':d},t))
 def test_zero_charge_requires_perimeter(self):
  self.assertTrue(review_gaps({'x':{'variable':'restructuring_charges','status':'observed','value':0}},{}))
 def test_zero_charge_with_review(self):
  d={'variable':'restructuring_charges','status':'observed','value':0,'charge_perimeter':{'included':['all issuer restructuring'],'other_charge_review':'adjacent notes reviewed','total_basis':'explicit issuer total'}}
  self.assertEqual(review_gaps({'x':d},{}),[])
class EventMeasureGates(unittest.TestCase):
 def test_one_sided_threshold_needs_its_bound(self):
  from researchcore.delivery_quality import event_measure_gates
  accepted={'p|layoff_count_qualifier':{'value':'up_to'}}
  self.assertTrue(any('upper bound' in e for e in event_measure_gates('p',accepted)))
  accepted['p|layoff_count_upper']={'value':1000,'explicit_bound_basis':'announcement states up to 1000'}
  self.assertEqual(event_measure_gates('p',accepted),[])
 def test_more_than_needs_lower_bound(self):
  from researchcore.delivery_quality import event_measure_gates
  accepted={'p|layoff_percentage_qualifier':{'value':'more_than'}}
  self.assertTrue(any('lower bound' in e for e in event_measure_gates('p',accepted)))
  accepted['p|layoff_percentage_lower']={'value':5,'explicit_bound_basis':'announcement states more than 5%'}
  self.assertEqual(event_measure_gates('p',accepted),[])
 def test_one_sided_threshold_cannot_be_point(self):
  from researchcore.delivery_quality import event_measure_gates
  accepted={'p|layoff_count_qualifier':{'value':'up_to'},'p|layoff_count':{'value':1000}}
  self.assertTrue(any('point estimate' in e for e in event_measure_gates('p',accepted)))
 def test_bound_needs_explicit_basis(self):
  from researchcore.delivery_quality import event_measure_gates
  accepted={'p|layoff_count_upper':{'value':1000}}
  self.assertTrue(any('explicit bound evidence' in e for e in event_measure_gates('p',accepted)))
 def test_reversed_bounds(self):
  from researchcore.delivery_quality import event_measure_gates
  accepted={'p|layoff_count_lower':{'value':100,'explicit_bound_basis':'x'},'p|layoff_count_upper':{'value':50,'explicit_bound_basis':'y'}}
  self.assertTrue(any('reversed' in e for e in event_measure_gates('p',accepted)))
 def test_raw_claim_contradicts_absent_quantities(self):
  from researchcore.delivery_quality import event_measure_gates
  accepted={'p|numerical_claim_raw':{'status':'observed','value':'up to 10000 jobs'}}
  for field in ['layoff_count','layoff_count_lower','layoff_count_upper','layoff_percentage','layoff_percentage_lower','layoff_percentage_upper']:
   accepted['p|'+field]={'status':'reviewed_absent','value':None}
  self.assertTrue(any('numerical_claim_raw' in e for e in event_measure_gates('p',accepted)))
  accepted['p|layoff_count_upper']={'status':'observed','value':10000,'explicit_bound_basis':'raw claim preserved'}
  self.assertEqual(event_measure_gates('p',accepted),[])
 def test_absent_raw_claim_cannot_carry_value(self):
  from researchcore.delivery_quality import event_measure_gates
  accepted={'p|numerical_claim_raw':{'status':'reviewed_absent','value':'up to 10000 jobs'}}
  self.assertTrue(any('coexist' in e for e in event_measure_gates('p',accepted)))
class Rc4(unittest.TestCase):
 def test_customer_only_rejected(self):
  d={'variable':'ai_integration','status':'observed','value':'Customer product','evidence':[{}],'operational_use':{'use_context':'customer_product','stage':'deployed_customer','process':'customer service offering','evidence_indices':[0]}}
  self.assertTrue(review_gaps({'x':d},{}))
 def test_extension_not_automatically_folded(self):
  from researchcore.delivery_quality import plan_groups
  e={'a':{'company_id':'x'},'b':{'company_id':'x'}}
  d={'b|plan_relationship':{'value':'extension_of'},'b|related_plan_id':{'value':'a'}}
  self.assertEqual(plan_groups(e,d,'plan')[0],{'a':'a','b':'b'})
 def test_actual_contract_loaded(self):
  from researchcore import semantic_receipts as sr
  sr._contract_cache=None
  actual=json.loads((root/'skills/listed-filing-extractor/assets/tech_evidence_contract.json').read_text())
  self.assertEqual(sr._contract_vocab()['contract_version'],actual['version'])
if __name__=='__main__':unittest.main()
