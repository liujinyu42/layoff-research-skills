---
name: listed-filing-extractor
description: Collect HR, AI/new-technology and financial disclosures for any identified company from public annual, financial, compensation and issuer reports, using SEC when applicable or official local/company sources otherwise, with evidence-linked company-year output, typed technology evidence by adoption stage, market document contracts and two-denominator missingness accounting.
---

# Company HR, AI/technology and financial disclosures

This is the reusable collection capability in proposal Part 2. The historical skill identifier is retained for installation compatibility; the primary population is listed issuers in the researcher's layoff dataset, including U.S. and separately collected non-U.S. markets. A U.S. ticker or CIK is not required for non-U.S. issuers. Explicitly requested private/delisted extensions must be labeled separately. The researcher's historical corpus is not supplied or required. Use the companies and years requested, default FY2019–2025.

Read [workflow.md](references/workflow.md) for execution, [filing-sources.md](references/filing-sources.md) for company/market routing, [filing-variables.md](references/filing-variables.md) for measurement. The entire codebook, output template, source/roster templates and [first-use prompt](references/first-run.md) are included; no chat memory or external template is needed.

## Fixed variable scope

The 41 business fields cover only:
- HR: workforce size; training/development costs (text and amount); layoff disclosure; labor/talent and hiring-competition risks; MD&A HR discussion and restructuring/cost-saving narratives.
- AI/new technology: products/initiatives, internal integration, actual AI/new-tech adoption, AI risks, AI investment text/amounts, technology/infrastructure operating-cost text/amounts, R&D expense, capitalized software text/amount.
- Financial: revenue, operating income, restructuring expense, total employee compensation and explicitly AI-linked compensation (including executive awards).

Each of 15 text constructs has a nullable 0/1 disclosure companion; 11 numeric fields remain numeric. Identity/status/evidence add six base columns, yielding 47 before lossless continuation columns. Both proposal-core and full select this same set. No balance sheet, cash-flow, leverage, CEO total/pay ratio, five AI-risk subtype columns or other retired extensions appear, even as empty columns.

## Measurement contracts

Seven versioned contracts decide what may be *claimed* from those same 47 columns, without adding one. `strict` (default) enforces them; `baseline` preserves pre-1.5 behaviour for historical workspaces.

- [Technology evidence](references/technology-evidence.md): six technology classes and seven adoption stages, so cloud is not AI and a plan is not a capability.
- [Missingness](references/missingness.md): review coverage and value availability are two ratios with two denominators, never one completion percentage.
- [Pre-event linkage](references/pre-event-linkage.md): a fiscal year earlier than a layoff announcement is not evidence that was public before it.
- [Human validation](references/human-validation.md): blind annotation of a held-out split is the only route to a reliability claim.
- [Market routes and registry](references/market-routes-and-registry.md): which documents a market publishes, which legal entity a row is, and whether two years may be divided.

```bash
python "$S/scripts/research.py" contracts-status    --work "$W"
python "$S/scripts/research.py" contracts-scorecard --work "$W"
python "$S/scripts/research.py" readiness           --work "$W"
python "$S/scripts/research.py" next-actions        --work "$W"
```

`readiness` answers five named comparisons rather than one composite score: `reason_description`, `financial_contrast`, `pre_event_capability`, `longitudinal_performance` and `job_skill_pairing`. Each is `measurable`, `partially_measurable` or `not_measurable` with its own sample size and blockers; a contract that is present but has no usable units cannot make a comparison measurable.

`next-actions` turns every open gap into an ordered work list: deterministic repairs first (they settle what is missing, never what a value is), then the semantic comparisons that need reading and judgment. Use it instead of deciding by hand which of seven contracts to run next.

`audit` reports `measurement_contracts_pass`, `contract_gaps`, `research_readiness` (RQ1–RQ3), `comparisons` and `weakest_link` separately from evidence integrity, and COMPLETE now requires no contract gap. Sidecars are content-addressed against the contract asset, the schema version and the upstream files they were derived from, so editing a contract — or a decision the codes were read from — invalidates existing records with a named `stale_record` instead of leaving a stale claim.

## Run to completion

With S=this folder and W=a dedicated v1.5 workspace:

```bash
python "$S/scripts/research.py" init --work "$W" --company "Company name" --years 2019:2025
python "$S/scripts/research.py" source-plan --work "$W"
```

Verify the legal entity and official sources. With a verified CIK use sec-prepare; otherwise find official issuer/local reports and sync their real URLs/files. Nonlisted or delisted companies remain eligible when public material exists. An unavailable report leaves a specific null dependency, not an invented amount or zero. Preserve native fiscal years, language, accounting basis and currency.

Follow next → actual source reading → actual decisions → apply → source supplementation/conflict resolution → next-second → actual self-review → audit/export. The host model performs judgments; scripts validate/store them. Do not treat dispatched tasks as results or send intermediate coding work to the user. Keep financial amounts, disclosure 0/1 and text separate. Financial/AI compensation values must identify period, recipient and scope; general R&D, data-center spending, SBC or CEO total cannot stand in for AI amounts or total compensation. Actual availability varies by company and industry.

Export 2_listed_company_filings.xlsx, one company/year row and one Results sheet, with only the fixed fields and basic trace metadata. No fixed sample-size quota, human-reliability claim, regression or synthetic macro data is part of this task.

## English presentation

All worksheet names, company display names, values, summaries, reasons, missing-data explanations and review metadata must be English. The only worksheet is `Results`. Read [English output and semantic checks](references/english-and-measurement.md) before writing decisions. A non-English company input is allowed: verify an English name or transliteration and set `company_en` in the roster, retaining the original legal name in the source archive. Use stable ASCII IDs. Non-English exact source quotations stay unchanged in the canonical archive; provide separately reviewed English translations for the workbook. Never label a translation as a verbatim original. The exporter rejects non-Latin authored/output strings; the reader must also check actual English meaning because this guard is not a language classifier.

Read [measurement maintenance](references/review-v152.md) when upgrading or interpreting research outputs.

Before coding and final delivery, read [source review closure](references/review-closure.md). Export also writes a review queue and sidecar index; include both with the evidence archive.

## Cross-model reproducibility and proposal scope

Read [reproducible extraction](references/reproducible-extraction.md) before coding or comparing runs. Audit enforces evidence-bound negative-review sections and structured receipts for internal adoption, AI-linked pay and restructuring totals. Existing exports need re-audit; do not relabel them as upgraded.

Before delivery, validate the saved workbook with `python scripts/audit_deliverables.py FILE --expected-rows N` (use the contracted company-year count where known). Review the focused semantic checks in references/reproducible-extraction.md.
