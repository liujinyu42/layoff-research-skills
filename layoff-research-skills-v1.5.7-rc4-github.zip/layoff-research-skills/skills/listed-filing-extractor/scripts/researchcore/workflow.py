"""Two proposal workflows. Metadata binding never substitutes for substantive reading."""
from pathlib import Path
import argparse,csv,json,hashlib,math,datetime,sys,os,subprocess
from .semantic_receipts import NEGATIVE_STATUSES
csv.field_size_limit(max(csv.field_size_limit(),2**31-1))

def digest(obj):return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def load(path,default=None):return json.loads(Path(path).read_text())if Path(path).is_file()else default
def save(path,obj):
 from .contracts import mkdir as _mkdir
 p=Path(path);_mkdir(p.parent);temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');temp.replace(p)
def rows(path):
 p=Path(path)
 if p.suffix=='.csv':
  with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
 text=p.read_text(encoding='utf-8-sig');return json.loads(text)if text.lstrip().startswith('[')else[json.loads(l)for l in text.splitlines()if l.strip()]
def schema(skill):return load(skill/'assets'/('event_schema.json'if skill.name=='layoff-announcement-tracker'else'filing_schema.json'))
def mode(skill):return 'events'if skill.name=='layoff-announcement-tracker'else'filings'
def context(work):
 from .sources import read_sources,text_for
 w=Path(work);cfg=load(w/'config.json');sources={k:v for k,v in read_sources(w).items()if v.get('active',True)};texts={}
 def text(sid):
  if sid not in sources:raise ValueError('Unknown/retired source '+sid)
  if sid not in texts:texts[sid]=text_for(w,sources[sid])
  return texts[sid]
 return cfg,sources,text

def entities(cfg,sources):
 roster={r['company_id']:r for r in cfg['roster']}
 if cfg['mode']=='filings':return {c+':'+str(y):{'entity_id':c+':'+str(y),'company_id':c,'company':r['company'],'company_en':r.get('company_en'),'fy':y,'exchange':r.get('exchange',''),'listing_status':r.get('listing_status','unknown')}for c,r in roster.items()for y in range(cfg['year_start'],cfg['year_end']+1)}
 out={}
 for src in sources.values():
  plan=src.get('plan_id');cid=src['company_id']
  if not plan:continue
  if plan in out and out[plan]['company_id']!=cid:raise ValueError('plan_id assigned to different companies')
  out[plan]={'entity_id':plan,'plan_id':plan,'company_id':cid,'company':roster[cid]['company'],'company_en':roster[cid].get('company_en')}
 return out

def suitable(src,entity,cfg):
 if src['company_id']!=entity['company_id']:return False
 if cfg['mode']=='filings':return str(src.get('fy',''))==str(entity['fy'])
 if src.get('plan_id'):return src['plan_id']==entity['plan_id']
 return src.get('document_role')in {'company_profile','annual_report','company_registry'}

def selected_fields(book,cfg):
 profiles=book.get('profiles')
 if not profiles:return book['fields']
 name=cfg.get('profile','proposal-core')
 if name not in profiles:raise ValueError('Unknown extraction profile '+name)
 ids=set(profiles[name]);return [f for f in book['fields']if f['id']in ids]

def field_sources(field,entity,cfg,sources):
 roles=field.get('source_roles')
 return {sid:src for sid,src in sources.items()if suitable(src,entity,cfg)and(not roles or src.get('document_role')in roles)}

def applicable_fingerprint(relevant):
 return digest({sid:{k:src.get(k)for k in ['text_sha256','row_sha256','status']}for sid,src in relevant.items()})

def init(skill,work,companies,years,start,end,profile='proposal-core',contract_level='strict',plan_granularity=None):
 w=Path(work);roster=[dict(r)for r in companies]if isinstance(companies,list)else rows(companies)
 if not roster:raise ValueError('Explicit nonempty company roster required; proposal sample counts are not input data')
 seen=set()
 for r in roster:
  if not r.get('company_id')or not r.get('company'):raise ValueError('company_id/company required')
  if r['company_id']in seen:raise ValueError('Duplicate company_id')
  seen.add(r['company_id'])
  if r.get('cik'):
   r['cik']=str(r['cik'])
   if not r['cik'].isdigit()or len(r['cik'])>10:raise ValueError('Invalid CIK')
   r['cik']=r['cik'].zfill(10)
 m=mode(skill);lo,hi=map(int,years.split(':'))
 if lo>hi:raise ValueError('Reversed fiscal years')
 datetime.date.fromisoformat(start);datetime.date.fromisoformat(end)
 if start>end:raise ValueError('Reversed announcement dates')
 from .contracts import LEVELS
 if contract_level not in LEVELS:raise ValueError('contract_level must be one of '+', '.join(LEVELS))
 if plan_granularity is not None and plan_granularity not in {'announcement','plan'}:raise ValueError('plan_granularity must be announcement or plan')
 cfg={'version':'1.5.7-rc4','mode':m,'roster':roster,'year_start':lo,'year_end':hi,'event_start':start,'event_end':end,'profile':profile,'contract_level':contract_level,'schema_sha256':digest(schema(skill)),'presentation_language':schema(skill).get('presentation_language')}
 if m=='events':cfg['plan_granularity']=plan_granularity or 'plan'
 selected_fields(schema(skill),cfg)
 prior=load(w/'config.json')
 if prior and prior!=cfg:raise ValueError('Scope/schema changed: use a new workspace or explicitly reconcile before changing config')
 save(w/'config.json',cfg)
 from . import contracts as _contracts
 armed=sorted(_contracts.active(skill,cfg))
 return {'companies':len(roster),'mode':m,'status':'initialized','schedule_started':False,'contract_level':contract_level,'contracts_armed':armed,'measurement_contracts_note':'Armed contracts decide what may be claimed from the fixed 41/43 fields. They never add a column. Run contracts-status for the current gate state.'}

def taskset(skill,work):
 cfg,sources,text=context(work);book=schema(skill)
 if cfg['schema_sha256']!=digest(book):raise ValueError('Schema changed; explicitly migrate or use a new workspace')
 ents=entities(cfg,sources)
 if cfg['mode']=='events':
  prior=load(Path(work)/'entities.json',{})
  for eid,en in prior.items():
   if eid in ents and ents[eid]['company_id']!=en['company_id']:raise ValueError('Plan identity changed')
  prior.update(ents);ents=prior;save(Path(work)/'entities.json',ents)
 tasks=[]
 for eid,entity in ents.items():
  for field in selected_fields(book,cfg):
   candidates=list(field_sources(field,entity,cfg,sources))
   tasks.append({'entity_id':eid,'company_id':entity['company_id'],'fy':entity.get('fy'),'variable':field['id'],'topic':field.get('topic','general'),'definition_sha256':digest(field),'source_ids':candidates,'source_roles':field.get('source_roles',[])})
 return cfg,sources,text,book,ents,tasks

def normalize(d,cfg,sources,text,fields,ents):
 eid=d['entity_id'];var=d['variable'];entity=ents[eid];field=fields[var];status=d.get('status');v=d.get('value')
 if status not in {'observed','reviewed_absent','not_separate','not_applicable','unresolved'}:raise ValueError('Invalid status')
 relevant=field_sources(field,entity,cfg,sources)
 if status=='not_separate'and field['type']not in {'number','integer'}:raise ValueError('not_separate is for a quantity not separately quantified; retain qualifying text as observed')
 if not d.get('reason')or not d.get('criterion_application')or d.get('reviewer_kind')not in {'human','model'}or not d.get('reviewer_id'):raise ValueError('Specific reason/criterion/reviewer required')
 if cfg.get('presentation_language')=='en':
  from .presentation import check_generated_english
  check_generated_english(d)
 if status=='observed':
  if v is None:raise ValueError('Observed needs value')
  typ=field['type']
  if typ=='binary'and(type(v)is not int or v not in [0,1]):raise ValueError('Binary is integer0/1; missing is null')
  if typ in {'number','integer'}and(type(v)not in [int,float]or not math.isfinite(v)):raise ValueError('Finite numeric value required')
  if (typ=='integer'or field.get('unit')=='persons')and int(v)!=v:raise ValueError('Integer required')
  if typ in {'text','date'}and not isinstance(v,str):raise ValueError('String required')
  if typ=='date':datetime.date.fromisoformat(v)
  if field.get('codes')and v not in field['codes']:raise ValueError('Value outside declared codes')
  if field.get('unit')=='percent'and not 0<=v<=100:raise ValueError('Percent must be0:100, preserve denominator')
  if typ in {'number','integer'}and(field.get('unit')in {'persons_or_roles','persons_or_fte','persons','calendar_year'})and v<0:raise ValueError('Negative count/year')
  if field.get('unit')in {'fraction','ratio_0_1'}and not 0<=v<=1:raise ValueError('Rate must be fraction0:1')
  if field.get('unit')=='currency_base':
   amount=d.get('amount')or{}
   if not isinstance(amount.get('raw_value'),(int,float))or not isinstance(amount.get('scale'),(int,float))or amount['scale']<=0:raise ValueError('Money needs numeric raw_value and positive scale from source')
   import re
   if not re.fullmatch('[A-Z]{3}',amount.get('currency',''))or amount['currency']in {'UNK','XXX','XTS'}:raise ValueError('Explicit ISO currency required; no assumed USD')
   expected=amount['raw_value']*amount['scale']
   if not math.isclose(v,expected,rel_tol=1e-12,abs_tol=1e-8):raise ValueError('Base currency amount != raw_value * scale')
   if not amount.get('unit_quote'):raise ValueError('Exact header/sentence unit_quote required')
   if field.get('measure_kind')=='annual_flow'and d.get('measurement_scope')!='company_total':raise ValueError('Annual flow must identify company_total; component/mixed/plan amounts remain separate or unresolved')
  if cfg['mode']=='filings'and field.get('measure_kind')=='executive_compensation':
   if not d.get('executive_name')or not d.get('compensation_basis'):raise ValueError('Executive amount requires identified name and SCT/CAP/NEO basis')
  if cfg['mode']=='filings'and field.get('measure_kind')=='ai_compensation':
   if d.get('recipient_scope')not in {'executive','employee_group','company_total'}or not d.get('compensation_basis'):raise ValueError('AI-linked compensation needs recipient_scope and explicit compensation_basis')
   if d['recipient_scope']=='executive'and not d.get('executive_name'):raise ValueError('AI executive compensation requires executive_name')
   if not d.get('ai_link_basis'):raise ValueError('Explicit AI-to-compensation link required; ordinary total compensation is not an AI amount')
  if cfg['mode']=='filings'and field.get('measure_kind')=='stock'and not d.get('period_end'):raise ValueError('Stock requires actual fiscal period_end')
  if cfg['mode']=='filings'and typ in {'number','integer'}and int(d.get('period_fy',-1))!=entity['fy']:raise ValueError('Numeric period_fy must match target fiscal year')
 elif v is not None:raise ValueError('Missing/unresolved value must be null, never0')
 for date_field in ['period_end','information_as_of']:
  if d.get(date_field):datetime.date.fromisoformat(d[date_field])
 evidence=[];bindings={};scopes=[]
 for e in d.get('evidence',[]):
  sid=e['source_id'];src=sources[sid]
  if sid not in relevant:raise ValueError('Evidence outside field company/year/plan/source role')
  tx=text(sid);q=e['quote'];start=e.get('char_start')
  if not isinstance(q,str)or len(q.strip())<10:raise ValueError('Actual source quotation required')
  if start is None:
   if tx.count(q)!=1:raise ValueError('Quote missing/ambiguous: provide exact char_start')
   start=tx.index(q)
  if type(start)is not int or tx[start:start+len(q)]!=q:raise ValueError('Quote/absolute offset mismatch')
  if status=='observed'and field.get('unit')=='currency_base'and(d.get('amount')or{}).get('unit_quote')not in tx:raise ValueError('Unit quote does not occur in evidence source')
  bindings[sid]={'text_sha256':src['text_sha256'],'row_sha256':src['row_sha256']};evidence.append({**e,'quote_language':e.get('quote_language')or src.get('source_language')or'en','char_start':start,'char_end':start+len(q),'text_sha256':src['text_sha256'],'content_sha256':src['content_sha256'],'source_url':src.get('source_url','')})
 negative=status in NEGATIVE_STATUSES or(status=='observed'and field['type']=='binary'and v==0)
 for scope in d.get('reviewed_scopes',[]):
  sid=scope['source_id'];tx=text(sid)
  if sid not in relevant:raise ValueError('Negative scope outside field source roles')
  lo,hi=scope['start'],scope['end']
  if lo!=0 or hi!=len(tx):raise ValueError('Absence requires complete registered source; snippets cannot establish0')
  scopes.append({'source_id':sid,'start':lo,'end':hi,'scope_sha256':hashlib.sha256(tx.encode()).hexdigest()});bindings[sid]={'text_sha256':sources[sid]['text_sha256'],'row_sha256':sources[sid]['row_sha256']}
 if negative:
  if any(src.get('status')!='ready'for src in relevant.values()):raise ValueError('Incomplete applicable sources cannot establish an absence or0')
  expected={sid for sid,src in relevant.items()if src.get('status')=='ready'}
  if not expected or {s['source_id']for s in scopes}!=expected or d.get('scope_read')is not True:raise ValueError('Actual full reading of all applicable field sources required for negative/missing finding')
 if status in {'observed','not_applicable'}and not negative and not evidence:raise ValueError('Observed/applicability finding needs source evidence')
 if status=='not_applicable'and not d.get('applicability_basis'):raise ValueError('not_applicable requires a source-supported applicability_basis')
 if status=='unresolved'and not d.get('missing_reason'):d={**d,'missing_reason':'unresolved_after_review'}
 if field.get('raw_evidence_required')and status=='observed'and field.get('unit')=='currency_base':
  from .validation import check_raw_amount
  check_raw_amount(d,evidence,text)
 if cfg['mode']=='events'and field.get('topic')=='context'and status=='observed'and not d.get('information_as_of'):raise ValueError('Event-time company context requires information_as_of')
 out={**d,'evidence':evidence,'reviewed_scopes':scopes,'source_bindings':bindings,'applicable_source_fingerprint':applicable_fingerprint(relevant),'definition_sha256':digest(field)};out.pop('decision_sha256',None);out['decision_sha256']=digest(out);return out

def _cached_decision(d,cfg,sources,fields,ents):
 """Queue cache validates bindings; final audit/read still hashes original bytes."""
 unsigned={k:v for k,v in d.items()if k!='decision_sha256'}
 if digest(unsigned)!=d.get('decision_sha256'):raise ValueError('Decision content changed since submission')
 field=fields[d['variable']];entity=ents[d['entity_id']]
 if d.get('definition_sha256')!=digest(field):raise ValueError('Definition changed since submission')
 relevant=field_sources(field,entity,cfg,sources)
 if d.get('applicable_source_fingerprint')!=applicable_fingerprint(relevant):raise ValueError('Applicable source set/content changed since submission; requeue affected fields including positive observations')
 for sid,binding in d.get('source_bindings',{}).items():
  if sid not in relevant or binding!={k:relevant[sid][k]for k in ['text_sha256','row_sha256']}:raise ValueError('Decision/source/definition changed since submission')
 negative=d['status']in NEGATIVE_STATUSES or d['status']=='observed'and field['type']=='binary'and d.get('value')==0
 if negative:
  if any(s.get('status')!='ready'for s in relevant.values()):raise ValueError('Applicable source incomplete')
  if not relevant or set(relevant)!={s['source_id']for s in d['reviewed_scopes']}:raise ValueError('Applicable source set changed; rereview affected absence')
 return d

def check_decisions(skill,work,submitted=None,verify_content=True):
 cfg,sources,text,book,ents,tasks=taskset(skill,work);fields={f['id']:f for f in selected_fields(book,cfg)};accepted={};errors=[]
 existing=load(Path(work)/'decisions.json',{});items=list(existing.values())if submitted is None else submitted
 for i,d in enumerate(items,1):
  try:
   key=d['entity_id']+'|'+d['variable']
   if d['variable'] not in fields:raise ValueError('Variable is not in this book\'s selected scope: '+str(d['variable']))
   if key in accepted:raise ValueError('Duplicate field decision')
   out=normalize(d,cfg,sources,text,fields,ents)if submitted is not None or verify_content else _cached_decision(d,cfg,sources,fields,ents)
   if submitted is None and d.get('decision_sha256')!=out['decision_sha256']:raise ValueError('Decision/source/definition changed since submission')
   accepted[key]=out
  except (ValueError,KeyError,TypeError,OSError)as ex:errors.append({'row':i,'entity_id':d.get('entity_id'),'variable':d.get('variable'),'error':str(ex)})
 return accepted,errors,(cfg,sources,book,ents,tasks)

def prepare(skill,work):
 accepted,errors,(cfg,sources,book,ents,tasks)=check_decisions(skill,work,verify_content=False);w=Path(work);folder=w/'review'
 from .contracts import mkdir as _mkdir
 _mkdir(folder)
 unresolved=[t for t in tasks if t['entity_id']+'|'+t['variable']not in accepted or accepted[t['entity_id']+'|'+t['variable']]['status']=='unresolved']
 (folder/'tasks.jsonl').write_text(''.join(json.dumps(t,ensure_ascii=False)+'\n'for t in unresolved));save(folder/'definitions.json',{f['id']:f for f in book['fields']})
 groups=[]
 for eid,entity in ents.items():
  for topic in sorted({t['topic']for t in unresolved if t['entity_id']==eid}):
   group_tasks=[t for t in unresolved if t['entity_id']==eid and t['topic']==topic];sids={sid for t in group_tasks for sid in t['source_ids']}
   group=[sources[sid]for sid in sorted(sids)];groups.append({'entity_id':eid,'topic':topic,'fields':[t['variable']for t in group_tasks],'sources':[{k:s.get(k)for k in ['source_id','source_type','document_role','text_path','text_sha256','n_chars','status']}for s in group]})
 save(folder/'reading_groups.json',groups);save(folder/'decision-example.json',{'entity_id':'company-id:2023'if cfg['mode']=='filings'else'plan-id','variable':'headcount'if cfg['mode']=='filings'else'stated_reason_text','status':'observed','value':None,'reason':'Write actual source-based reason','criterion_application':'Apply definition to actual context','reviewer_id':'A','reviewer_kind':'model','evidence':[{'source_id':'id','quote':'Copy exact original text'}]})
 from .batches import supplement_tasks
 supplements=supplement_tasks(tasks,sources,accepted);save(folder/'supplement-tasks.json',supplements)
 inventory=load(w/'qa/sec-source-inventory.json',{})
 if inventory.get('unmapped_filings'):save(folder/'source-targeting-tasks.json',inventory['unmapped_filings'])
 return {'entities':len(ents),'profile':cfg.get('profile'),'tasks':len(tasks),'remaining':len(unresolved),'invalid_saved_decisions':len(errors),'reading_groups':str(folder/'reading_groups.json'),'supplement_tasks':len(supplements),'next':'next --limit 10; read applicable original sources, decide each selected field, apply JSONL, repeat until reviewed. prepare/dispatch alone does not complete extraction.'}

def apply(skill,work,path):
 incoming=rows(path);accepted,errors,_=check_decisions(skill,work,incoming);w=Path(work);report={'pass':not errors,'errors':errors,'validated':len(accepted),'accepted':0 if errors else len(accepted),'applied':0 if errors else len(accepted),'semantic_judgments_generated':False};save(w/'qa/apply-preflight.json',report)
 if errors:return report
 prior=load(w/'decisions.json',{})
 if prior:save(w/'history'/('decisions-'+digest(prior)+'.json'),prior)
 prior.update(accepted);save(w/'decisions.json',prior);return report

def second_tasks(skill,work):
 accepted,errors,(cfg,sources,book,ents,first_tasks)=check_decisions(skill,work,verify_content=False)
 if errors:raise ValueError('Repair invalid decisions before second reading')
 from .validation import required_review_checks
 fields={f['id']:f for f in book['fields']};prior=load(Path(work)/'second.json',{})
 tasks=[]
 for key,r in accepted.items():
  if r['status']=='unresolved':continue
  current=prior.get(key,{})
  unsigned={k:v for k,v in current.items()if k!='second_review_sha256'}
  if current.get('decision_sha256')==r['decision_sha256'] and current.get('reviewed_again')is True and current.get('second_review_sha256')==digest(unsigned):
   try:
    from .validation import check_second_review
    check_second_review(current,fields[r['variable']],r,cfg['mode']);continue
   except (ValueError,KeyError,TypeError):pass
  tasks.append({'entity_id':r['entity_id'],'variable':r['variable'],'decision_sha256':r['decision_sha256'],'definition_sha256':r['definition_sha256'],'source_bindings':r['source_bindings'],'required_checks':required_review_checks(fields[r['variable']],r,cfg['mode']),'evidence_to_reread':r['evidence'],'applicable_scope_to_reread':r['reviewed_scopes'],'first_decision':{k:r.get(k)for k in ['status','value','period_fy','reason','criterion_application','amount','measurement_scope','information_as_of']}})
  from .semantic_hints import hints_for
  tasks[-1]['counterevidence_to_inspect']=[hint for sid in r['source_bindings']for hint in hints_for(work,sources[sid],r['variable'])]
 save(Path(work)/'review/second-tasks.json',tasks)
 if tasks:
  first=tasks[0];save(Path(work)/'review/second-template.json',{k:first[k]for k in ['entity_id','variable','decision_sha256','definition_sha256','source_bindings']}|{'reviewed_again':False,'review_outcome':None,'criterion_application':'','reviewer_id':'','reviewer_kind':'model','checks':{name:''for name in first['required_checks']},'source_checks':[]})
 return {'tasks':len(tasks),'path':str(Path(work)/'review/second-tasks.json'),'next':'Read original context again. Submit bindings, reviewed_again:true, review_outcome:confirm, checks with specific explanations, source_checks copied from re-read bound evidence, reviewer and criterion. Revise first decision if wrong; same-model review is not human reliability.'}

def apply_second(skill,work,path):
 accepted,errors,(cfg,sources,book,ents,tasks)=check_decisions(skill,work,verify_content=False);result={};seen=set();fields={f['id']:f for f in book['fields']}
 from .validation import check_second_review
 get_text=context(work)[2]
 for n,r in enumerate(rows(path),1):
  try:
   if cfg.get('presentation_language')=='en':
    from .presentation import check_generated_english
    check_generated_english(r)
   k=r['entity_id']+'|'+r['variable'];d=accepted[k]
   if k in seen:raise ValueError('Duplicate second judgment')
   seen.add(k)
   if r.get('reviewed_again')is not True or not r.get('criterion_application')or not r.get('reviewer_id')or r.get('reviewer_kind')not in {'human','model'}:raise ValueError('Actual second source reading and specific criterion required')
   for name in ['decision_sha256','definition_sha256','source_bindings']:
    if r.get(name)!=d[name]:raise ValueError('Second-review binding changed: '+name)
   check_second_review(r,fields[d['variable']],d,cfg['mode'],get_text)
   out=dict(r);out.pop('second_review_sha256',None);out['second_review_sha256']=digest(out);result[k]=out
  except(KeyError,ValueError,TypeError)as e:errors.append({'row':n,'error':str(e)})
 report={'pass':not errors,'errors':errors,'second_reviews':len(result)};save(Path(work)/'qa/second-preflight.json',report)
 if not errors:
  prior=load(Path(work)/'second.json',{});prior.update(result);save(Path(work)/'second.json',prior)
 return report

def audit(skill,work):
 from .delivery_quality import event_measure_gates
 accepted,errors,(cfg,sources,book,ents,tasks)=check_decisions(skill,work);second=load(Path(work)/'second.json',{});pending=[];needs_second=[];coverage=[]
 from .sources import text_for
 from .validation import check_second_review
 source_texts={}
 fields={f['id']:f for f in book['fields']};selected={t['variable']for t in tasks};not_reviewed=[];unresolved=[];source_gaps=set()
 for src in sources.values():
  if src.get('status')=='ready':
   try:source_texts[src['source_id']]=text_for(Path(work),src)
   except (ValueError,OSError)as e:errors.append({'source_id':src['source_id'],'error':str(e)})
 for pf in ['apply-preflight.json','second-preflight.json']:
  pr=load(Path(work)/'qa'/pf,{})
  if pr.get('pass')is False:errors.append({'error':'Latest submission failed: '+pf})
 for t in tasks:
  k=t['entity_id']+'|'+t['variable'];d=accepted.get(k)
  if not any(sources[sid].get('status')=='ready'for sid in t['source_ids']):
   gap=(t['entity_id'],t['topic'],tuple(t['source_roles']))
   if gap not in source_gaps:source_gaps.add(gap);coverage.append({'entity_id':t['entity_id'],'topic':t['topic'],'required_source_roles':t['source_roles'],'reason':'No ready source appropriate for selected field'})
  if not d:pending.append(k);not_reviewed.append(k);continue
  if d['status']=='unresolved':pending.append(k);unresolved.append(k);continue
  sr=second.get(k,{})
  if sr:
   unsigned={name:value for name,value in sr.items()if name!='second_review_sha256'}
   if sr.get('second_review_sha256')!=digest(unsigned)or not sr.get('criterion_application')or not sr.get('reviewer_id')or sr.get('reviewer_kind')not in {'human','model'}:errors.append({'entity_id':t['entity_id'],'variable':t['variable'],'error':'Second-review content changed or substantive review fields missing'})
   try:check_second_review(sr,fields[t['variable']],d,cfg['mode'],lambda sid:source_texts[sid])
   except (ValueError,KeyError,TypeError)as ex:errors.append({'entity_id':t['entity_id'],'variable':t['variable'],'error':str(ex)})
  if any(sr.get(x)!=d[x]for x in ['decision_sha256','definition_sha256','source_bindings'])or sr.get('reviewed_again')is not True:needs_second.append(k)
 for eid,en in ents.items():
  if cfg['mode']=='filings':
   for f in book['fields']:
    if not f['id'].endswith('_disclosed'):continue
    base=accepted.get(eid+'|'+f['id'].removesuffix('_disclosed'));code=accepted.get(eid+'|'+f['id'])
    if base and code and code.get('status')=='observed':
     conflict=code['value']==0 and base['status']=='observed'and base['value']not in [None,'']or code['value']==1 and base['status']in {'reviewed_absent','not_separate','not_applicable'}
     if conflict:errors.append({'entity_id':eid,'variable':f['id'],'error':'Text disclosure and binary code contradict each other'})
  ready=[s for s in sources.values()if suitable(s,en,cfg)and s.get('status')=='ready']
  valid=any(s.get('document_role')in {'annual_report','annual_financials','company_report','financial_statements'}and s.get('source_type')in {'sec_filing','exchange_filing','company_annual_report','company_disclosure'}for s in ready)if cfg['mode']=='filings'else any(s.get('source_type')in {'company_announcement','sec_filing','exchange_filing'}and s.get('document_role')in {'layoff_announcement','event_filing'}for s in ready)
  if not valid:coverage.append({'entity_id':eid,'reason':'annual/original announcement source missing; news/tracker is not original'})
 if cfg['mode']=='events':
  represented={en['company_id']for en in ents.values()}
  coverage.extend({'company_id':r['company_id'],'reason':'no registered plan; cannot conclude no layoffs'}for r in cfg['roster']if r['company_id']not in represented)
  for eid,en in ents.items():
   date=accepted.get(eid+'|announcement_date',{}).get('value')
   if not date or not cfg['event_start']<=date<=cfg['event_end']:coverage.append({'entity_id':eid,'reason':'announcement_date missing/outside requested window'})
 if cfg['mode']=='events':
  for eid,en in ents.items():
   vals={v:accepted.get(eid+'|'+v,{}).get('value')for v in [f['id']for f in book['fields']]}
   if vals.get('plan_identity_verified')!=1:coverage.append({'entity_id':eid,'reason':'plan identity has not been verified'})
   relationship=accepted.get(eid+'|plan_relationship',{})
   if cfg.get('contract_level')=='strict' and 'plan_relationship' in vals and vals.get('plan_identity_verified')==1:
    if relationship.get('status') not in {'observed','reviewed_absent','not_applicable'}:
     coverage.append({'entity_id':eid,'reason':'plan identity asserted without a resolved plan relationship review'})
   for err in event_measure_gates(eid,accepted):errors.append({'entity_id':eid,'error':err})
   if any(vals.get(v)==1 for v in vals if v.startswith('reason_')and v!='reason_attribution')and vals.get('reason_attribution')not in {'company_direct','company_quote_in_news'}:errors.append({'entity_id':eid,'error':'Reason codes require company attribution'})
   link=vals.get('related_plan_id')
   if link and(link==eid or link not in ents or ents[link]['company_id']!=en['company_id']):errors.append({'entity_id':eid,'error':'Related plan must identify another registered plan of this company'})
   if vals.get('plan_relationship')in {'implementation_of','revision_of','same_plan_as','same_plan_update','extension_of'}and not link:errors.append({'entity_id':eid,'error':'Linked plan relationship requires related_plan_id'})
   event_date=vals.get('announcement_date')
   for var,field in fields.items():
    d=accepted.get(eid+'|'+var,{})
    if field.get('topic')!='context'or d.get('status')!='observed':continue
    asof=d.get('information_as_of')
    if event_date and asof and asof>event_date:errors.append({'entity_id':eid,'variable':var,'error':'Company context refers to a future information_as_of'})
    late=event_date and any((sources[e['source_id']].get('publication_date')or'')>event_date for e in d.get('evidence',[]))
    if late and not(d.get('source_timing')=='retrospective'and d.get('retrospective_basis')):errors.append({'entity_id':eid,'variable':var,'error':'Later source requires explicit retrospective basis; do not imply pre-event public availability'})
 inventory=load(Path(work)/'qa/sec-source-inventory.json',{})
 targeting=[r for r in inventory.get('unmapped_filings',[])if not any(src.get('accession')==r['accession']and src.get('fy')is not None and src.get('target_fy_basis')for src in sources.values())]
 coverage.extend({'company_id':r['company_id'],'reason':'SEC filing fiscal-year target unresolved','accession':r['accession']}for r in targeting)
 bad=[s['source_id']for s in sources.values()if s.get('status')!='ready']
 core_ids={f['id']for f in book['fields']if f.get('core',True)};core_tasks=[t for t in tasks if t['variable']in core_ids];core_pending=[t['entity_id']+'|'+t['variable']for t in core_tasks if t['entity_id']+'|'+t['variable']in pending]
 represented={en['company_id']for en in ents.values()};sample_pass=all(r['company_id']in represented for r in cfg['roster'])
 book_version=book['version']
 from . import readiness as _readiness
 measurement=_readiness.report(skill,Path(work),cfg,book,accepted,ents,sources,tasks,book_version)
 contract_gaps=list(measurement['contracts']['gaps'])
 for gate in _measurement_gates(skill,work,cfg,book_version,accepted,ents,sources,tasks):
  gaps,gate_errors=gate;contract_gaps.extend(gaps);errors.extend(gate_errors)
 from .delivery_quality import review_gaps,event_measure_gates,plan_count_by_relation
 contract_gaps.extend(review_gaps(accepted))
 from .semantic_receipts import review_gaps as semantic_receipt_gaps
 contract_gaps.extend(semantic_receipt_gaps(accepted,source_texts,fields))
 plan_granularity=cfg.get('plan_granularity','plan');plan_mapping={}
 if cfg['mode']=='events':
  from .delivery_quality import canonical_view
  _,plan_mapping,relation_issues=canonical_view(ents,accepted,plan_granularity)
  errors.extend({'entity_id':item.get('entity_id'),'error':item['reason']} for item in relation_issues if item.get('fatal'))
  coverage.extend(relation_issues)
 report={'version':'1.5.7-rc4','runtime_version':'1.5.7-rc4','schema_version':book_version,'profile':cfg.get('profile'),'contract_level':cfg.get('contract_level','strict'),'integrity_pass':not errors,'sample_coverage_pass':sample_pass,'sample_coverage_basis':'Declared roster and fiscal-year grid/registered plans; not proof that every public event has been discovered','source_coverage_pass':not(coverage or bad),'coding_complete':not pending,'semantic_review_complete':not(pending or needs_second),'measurement_contracts_pass':not contract_gaps,'complete':not(errors or pending or needs_second or coverage or bad or contract_gaps),'entities':len(ents),'fields_per_entity':len(selected_fields(book,cfg)),'output_fields_per_entity':len(book['fields']),'positions':len(tasks),'core_positions':len(core_tasks),'core_pending':len(core_pending),'pending':len(pending),'not_reviewed':len(not_reviewed),'unresolved':len(unresolved),'second_pending':len(needs_second),'coverage_gaps':coverage,'source_failures':bad,'source_targeting_pending':len(targeting),'candidate_warnings':len(inventory.get('candidate_issues',[])),'measurement_contracts':measurement['contracts']['contracts'],'contract_gaps':contract_gaps,'research_readiness':measurement['research_questions'],'comparisons':{name:{'status':table['status'],'n':table['n'],'blockers':table['blockers']}for name,table in measurement['comparisons'].items()},'weakest_link':measurement['weakest_link'],'human_validation':measurement['human_validation'],'capability_inventory':measurement['capability_inventory'],'never_claimed':measurement['never_claimed'],'errors':errors,'pending_positions':pending,'second_pending_positions':needs_second,'reliability':None,'plan_granularity':plan_granularity,'plan_count_by_relation':plan_count_by_relation(ents,accepted)if cfg['mode']=='events' else None,'plan_rows':len(ents)if cfg['mode']=='events' else None,'canonical_plan_count':len({plan_mapping.get(eid,eid)for eid in ents})if cfg['mode']=='events' else None,'plan_count_note':'Results rows are announcements, not plans: row count != plan count. plan_granularity=plan additionally folds implementation_of/extension_of links into the canonical plan group.','note':'Evidence integrity, source coverage, coding completion, measurement contracts and semantic self-review are separate. Same-model self-review is not independent human agreement.'};save(Path(work)/'qa/audit.json',report);return report


def _measurement_gates(skill,work,cfg,book_version,accepted,ents,sources,tasks):
 """Mode-specific contract gates; a broken contract surfaces as an error, never as silence."""
 from . import codebook,tech_evidence,search_coverage,missingness,linkage,routes_contract,human_validation
 from . import contracts as cl
 gates=[]
 validators={'reason_codebook':codebook,'tech_evidence':tech_evidence,'linkage':linkage,'missingness':missingness,
             'search_coverage':search_coverage,'market_routes':routes_contract,'human_validation':human_validation}
 broken=set()
 for name in cl.active(skill,cfg):
  try:validators[name].load(skill)
  except (ValueError,KeyError,TypeError,OSError)as ex:broken.add(name);gates.append(([],[{'contract':name,'error':'Contract '+name+' failed: '+str(ex)}]))
 def safe(name,fn):
  if name in broken:return
  try:gates.append(fn())
  except (ValueError,KeyError,TypeError,OSError)as ex:gates.append(([],[{'error':'Contract '+name+' failed: '+str(ex)}]))
 safe('market_routes',lambda:routes_contract.gate(skill,work,cfg,book_version))
 safe('linkage',lambda:linkage.gate(skill,work,cfg,book_version))
 if cfg['mode']=='events':
  safe('reason_codebook',lambda:codebook.gate(skill,work,cfg,ents,book_version))
  safe('search_coverage',lambda:search_coverage.gate(skill,work,cfg,ents,book_version))
 else:
  safe('tech_evidence',lambda:tech_evidence.gate(skill,work,cfg,accepted,ents,book_version))
  safe('missingness',lambda:missingness.gate(skill,work,cfg,book_version,tasks))
 return gates

def export(skill,work,output,partial=False):
 report=audit(skill,work)
 if not report['integrity_pass']:raise ValueError('Invalid source/decision blocks export; see qa/audit.json')
 if not report['complete']and not partial:raise ValueError('Incomplete work; resolve tasks or explicitly export --allow-partial')
 accepted,_,(cfg,sources,book,ents,tasks)=check_decisions(skill,work,verify_content=False);fields=[f['id']for f in book['fields']];columns=['company_id','company','fy']if cfg['mode']=='filings'else['plan_id','company_id','company']
 english=book.get('presentation_language')=='en';sheet_name=book.get('worksheet','结果')
 if english:
  from .presentation import english_evidence_view,ensure_english_output
 columns+=fields+['delivery_status','field_status_json','evidence_json'];data=[]
 plan_mapping={}
 display_decisions=accepted
 if cfg['mode']=='events':
  from .delivery_quality import canonical_view
  display_decisions,plan_mapping,_=canonical_view(ents,accepted,cfg.get('plan_granularity','plan'))
 for eid,en in ents.items():
  if plan_mapping.get(eid,eid)!=eid:
   continue
  rr={k:en.get(k)for k in columns[:3]};rr['company']=en.get('company_en')or en['company'];proof={};statuses={}
  for var in fields:
   d=display_decisions.get(eid+'|'+var);rr[var]=d['value']if d else None;statuses[var]=d['status']if d else('not_reviewed'if var in {f['id']for f in selected_fields(book,cfg)}else'not_requested')
   if d:proof[var]=english_evidence_view(d)if english else d
  rr.update(delivery_status='COMPLETE'if report['complete']else'PARTIAL',field_status_json=json.dumps(statuses,ensure_ascii=False),evidence_json=json.dumps(proof,ensure_ascii=False));data.append(rr)
  if english:ensure_english_output(rr)
 # Long strings continue horizontally; never silently truncate or add company-year rows.
 for col in list(columns):
  extra=1
  for rr in data:
   if not isinstance(rr.get(col),str):continue
   chunks=[];chunk='';size=0
   for ch in rr[col]:
    width=len(ch.encode('utf-16-le'))//2
    if size+width>30000:chunks.append(chunk);chunk='';size=0
    chunk+=ch;size+=width
   chunks.append(chunk);rr[col]=chunks[0];extra=max(extra,len(chunks))
   for n,value in enumerate(chunks[1:],2):rr[col+'__part'+str(n)]=value
  columns += [col+'__part'+str(n)for n in range(2,extra+1)]
 from openpyxl import Workbook,load_workbook
 from openpyxl.styles import Font,PatternFill,Alignment
 from openpyxl.utils import get_column_letter
 template=skill/'assets/output_template.xlsx';contract=load(skill/'assets/output_contract.json')
 if template.is_file():
  if not contract or contract['template_sha256']!=hashlib.sha256(template.read_bytes()).hexdigest()or contract['schema_sha256']!=digest(book):raise ValueError('Built-in template/schema binding changed')
  wb=load_workbook(template);ws=wb.active
  if wb.sheetnames!=[sheet_name]or [c.value for c in ws[1]]!=contract['columns']:raise ValueError('Template header mismatch')
  if columns[:len(contract['columns'])]!=contract['columns']:raise ValueError('Output columns diverged from template')
  if len(columns)>len(contract['columns']):
   for j,k in enumerate(columns,1):ws.cell(1,j,k)
 else:
  wb=Workbook();ws=wb.active;ws.title=sheet_name;ws.append(columns)
 for rr in data:
  ws.append([rr.get(k)for k in columns])
  for cell in ws[ws.max_row]:
   if isinstance(cell.value,str):cell.data_type='s'
 for cell in ws[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='17365D');cell.alignment=Alignment(wrap_text=True,vertical='center')
 ws.row_dimensions[1].height=42;ws.freeze_panes='D2';ws.auto_filter.ref=ws.dimensions
 for n in range(1,len(columns)+1):ws.column_dimensions[get_column_letter(n)].width=24
 p=Path(output);p.parent.mkdir(parents=True,exist_ok=True);wb.save(p);saved=load_workbook(p,data_only=False);assert saved.sheetnames==[sheet_name];actual=list(saved.active.values)
 if english:save(p.with_suffix('.source_evidence.json'),{'archive_kind':'canonical_original_language_source_evidence_not_the_English_workbook_view','records':accepted,'canonical_plan_ids':plan_mapping,'self_reviews':load(Path(work)/'second.json',{})})
 if list(actual[0])!=columns or len(actual)!=len(data)+1:raise ValueError('Saved shape mismatch')
 for i,rr in enumerate(data,1):
  for j,k in enumerate(columns):
   expected=rr.get(k);got=actual[i][j]
   if expected==''and got is None:continue
   if isinstance(expected,(int,float))and isinstance(got,(int,float)):
    if not math.isclose(expected,got,rel_tol=1e-14,abs_tol=0):raise ValueError('Saved numeric mismatch')
   elif expected!=got:raise ValueError('Saved cell mismatch')
 from .review_delivery import write_review_bundle
 write_review_bundle(p,accepted,report,cfg)
 from .delivery_quality import grain_check
 grain=grain_check(p,book,len(data))
 if not grain['pass_check']:raise ValueError('Deliverable grain check failed: '+'; '.join(grain['errors']))
 qa_report=load(Path(work)/'qa/audit.json',{})
 if qa_report:qa_report['deliverable_grain_check']=grain;save(Path(work)/'qa/audit.json',qa_report)
 summary={'runtime_version':'1.5.7-rc4','workbook_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'output':str(p),'rows':len(data),'columns':len(columns),'worksheet_count':1,'status':'COMPLETE'if report['complete']else'PARTIAL','saved_cells_checked':len(actual)*len(columns),'grain_check':grain,'source_audit':report};save(p.with_suffix('.audit.json'),summary);return {k:v for k,v in summary.items()if k!='source_audit'}

def _contract_state(skill,work):
 accepted,errors,(cfg,sources,book,ents,tasks)=check_decisions(skill,work,verify_content=False)
 return {'accepted':accepted,'errors':errors,'cfg':cfg,'sources':sources,'book':book,'ents':ents,'tasks':tasks,'version':book['version']}


def _contract_command(skill,a):
 """Measurement-contract commands. Each writes one sidecar or one analysis-ready table."""
 from . import contracts as cl,codebook,tech_evidence,linkage,registry,human_validation,search_coverage,missingness,routes_contract,readiness
 name=a.command
 if name=='contracts-scorecard':
  cfg=load(Path(a.work)/'config.json')
  if not cfg:raise ValueError('Workspace is not initialized')
  state=cl.status(skill,Path(a.work),cfg)
  return {'level':state['level'],'armed':state['armed'],'gaps':state['gaps'],
          'inventory':readiness.capability_inventory(skill,cfg),
          'contracts':{key:{k:v for k,v in value.items()if k in('armed','blocking','recorded','valid','contract_version')}for key,value in state['contracts'].items()}}
 state=_contract_state(skill,a.work);cfg=state['cfg'];book=state['book'];version=state['version']
 if name=='contracts-status':
  return cl.status(skill,Path(a.work),cfg,version)
 if name=='codebook-show':
  payload=codebook.load(skill)
  return {'version':payload['version'],'title':payload['title'],'rules':payload['rules'],
          'attribution_levels':payload['attribution_levels'],
          'categories':[{'code':item['code'],'label':item['label'],'definition':item['definition'],
                         'positive_cues':item.get('positive_cues',[]),'exclusive_with':item.get('exclusive_with',[])}
                        for item in payload['categories']]}
 if name=='reason-apply':
  report=codebook.apply(skill,a.work,a.file,cfg,state['sources'],state['accepted'],state['ents'],version,
                        replace=getattr(a,'replace',False))
  report['invalid_decisions']=len(state['errors']);return report
 if name in {'reason-coverage','reason-summary'}:
  payload=cl.require_record(skill,Path(a.work),'reason_codebook',version)
  return payload['coverage']if name=='reason-coverage'else payload['summary']
 if name=='reason-export':
  return codebook.export_csv(skill,a.work,a.output,version)
 if name=='tech-apply':
  report=tech_evidence.apply(skill,a.work,a.file,cfg,state['sources'],state['accepted'],state['ents'],version,
                             replace=getattr(a,'replace',False))
  report['invalid_decisions']=len(state['errors']);return report
 if name in {'tech-capability','tech-coverage'}:
  payload=cl.require_record(skill,Path(a.work),'tech_evidence',version)
  if name=='tech-coverage':return payload['coverage']
  return {'summary':{k:v for k,v in payload['capability'].items()if k!='by_entity'},'by_entity':payload['capability']['by_entity']}
 if name=='tech-export':
  return tech_evidence.export_csv(skill,a.work,a.output,version)
 if name=='linkage-build':
  return linkage.build(skill,a.work,a.peer_work,version,a.window)
 if name=='linkage-pre-event':
  try:capability=cl.require_record(skill,Path(a.work),'tech_evidence',version)['capability']
  except (ValueError,OSError,KeyError):capability=None
  return linkage.export_csv(skill,a.work,a.output,version,capability)
 if name=='registry-init':
  return registry.init(skill,a.work,cfg)
 if name=='registry-verify':
  return registry.verify(skill,a.work,a.file,cfg,state['sources'],context(a.work)[2])
 if name=='registry-check':
  return registry.check(skill,a.work,cfg)
 if name=='comparability-import':
  return registry.import_comparability(skill,a.work,a.file,cfg)
 if name=='comparability-compare':
  return registry.compare(skill,a.work,a.company,a.fy_left,a.fy_right)
 if name=='human-blind':
  return human_validation.blind_predictions(skill,a.work,a.output,state['accepted'],version)
 if name=='human-template':
  return human_validation.template(skill,a.work,a.output,state['accepted'],a.split)
 if name=='human-evaluate':
  return human_validation.evaluate(skill,a.work,a.human,a.predictions,a.splits,version,
                                   getattr(a,'experiment','main'))
 if name=='human-adjudicate':
  return human_validation.adjudicate(skill,a.work,a.file,version)
 if name=='human-status':
  return human_validation.status(skill,Path(a.work),cfg,version)
 if name=='search-log-import':
  return search_coverage.import_log(skill,a.work,a.file,cfg,state['ents'],version)
 if name=='search-coverage':
  payload=cl.require_record(skill,Path(a.work),'search_coverage',version)
  return {'summary':payload['summary'],'companies':payload['companies']}
 if name=='missingness-report':
  return missingness.build(skill,a.work,state['accepted'],state['tasks'],state['sources'],book,version)
 if name=='missingness-export':
  return missingness.export_csv(skill,a.work,a.output,version)
 if name=='routes-check':
  report=routes_contract.check(skill,a.work,cfg,state['sources'],version)
  report.pop('companies_detail',None);return report
 if name=='readiness':
  payload=readiness.report(skill,Path(a.work),cfg,book,state['accepted'],state['ents'],state['sources'],state['tasks'],version)
  return {'mode':payload['mode'],'research_questions':payload['research_questions'],'comparisons':payload['comparisons'],'weakest_link':payload['weakest_link'],'human_validation':payload['human_validation'],'never_claimed':payload['never_claimed']}
 if name=='next-actions':
  return readiness.next_actions(skill,Path(a.work),cfg,book,state['accepted'],state['ents'],state['sources'],state['tasks'],version)
 raise ValueError('Unknown contract command '+name)


def main(skill,argv=None):
 skill=Path(skill).resolve();p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
 a=sub.add_parser('init');a.add_argument('--work',required=True);g=a.add_mutually_exclusive_group(required=True);g.add_argument('--companies');g.add_argument('--company',action='append');a.add_argument('--years',default='2019:2025');a.add_argument('--start',default='2020-01-01');a.add_argument('--end',default='2026-09-30');a.add_argument('--profile',choices=['proposal-core','full'],default='proposal-core');a.add_argument('--contract-level',dest='contract_level',choices=['baseline','strict'],default='strict');a.add_argument('--plan-granularity',dest='plan_granularity',choices=['announcement','plan'],default=None,help='plan additionally folds implementation_of/extension_of links into the canonical plan group')
 a=sub.add_parser('sync');a.add_argument('--work',required=True);a.add_argument('--manifest',required=True);a.add_argument('--offline',action='store_true');a.add_argument('--refresh',action='store_true')
 for command in ['prepare','prepare-second','audit','source-plan']:
  a=sub.add_parser(command);a.add_argument('--work',required=True)
 for command in ['apply','apply-second']:
  a=sub.add_parser(command);a.add_argument('--work',required=True);a.add_argument('--decisions',required=True)
 a=sub.add_parser('export');a.add_argument('--work',required=True);a.add_argument('--output',required=True);a.add_argument('--allow-partial',action='store_true')
 a=sub.add_parser('read');a.add_argument('--work',required=True);a.add_argument('--source',required=True);a.add_argument('--offset','--start',dest='offset',type=int,default=0);a.add_argument('--limit',type=int,default=16000);a.add_argument('--end',type=int)
 a=sub.add_parser('next');a.add_argument('--work',required=True);a.add_argument('--limit',type=int,default=10);a.add_argument('--entity');a.add_argument('--topic')
 a=sub.add_parser('next-second');a.add_argument('--work',required=True);a.add_argument('--limit',type=int,default=10);a.add_argument('--entity');a.add_argument('--topic')
 a=sub.add_parser('sec-prepare');a.add_argument('--work',required=True);a.add_argument('--offline');a.add_argument('--cache-only',action='store_true')
 for command in ['contracts-status','contracts-scorecard','codebook-show','reason-coverage','reason-summary','tech-capability','tech-coverage','registry-init','registry-check','search-coverage','missingness-report','routes-check','readiness','human-status','next-actions']:
  a=sub.add_parser(command);a.add_argument('--work',required=True)
 for command in ['reason-apply','tech-apply']:
  a=sub.add_parser(command);a.add_argument('--work',required=True);a.add_argument('--file',required=True)
  a.add_argument('--replace',action='store_true',help='Replace the whole sidecar instead of merging by key')
 for command in ['search-log-import','comparability-import','human-adjudicate','registry-verify']:
  a=sub.add_parser(command);a.add_argument('--work',required=True);a.add_argument('--file',required=True)
 for command in ['reason-export','tech-export','missingness-export','linkage-pre-event','human-blind']:
  a=sub.add_parser(command);a.add_argument('--work',required=True);a.add_argument('--output',required=True)
 a=sub.add_parser('human-template');a.add_argument('--work',required=True);a.add_argument('--output',required=True);a.add_argument('--split',choices=['seed','development','holdout'])
 a=sub.add_parser('human-evaluate');a.add_argument('--work',required=True);a.add_argument('--human',required=True);a.add_argument('--predictions',required=True);a.add_argument('--splits');a.add_argument('--experiment',default='main',help='A second held-out claim needs a new experiment id')
 a=sub.add_parser('linkage-build');a.add_argument('--work',required=True);a.add_argument('--peer-work',dest='peer_work',required=True);a.add_argument('--window',type=int)
 a=sub.add_parser('comparability-compare');a.add_argument('--work',required=True);a.add_argument('--company',required=True);a.add_argument('--fy-left',dest='fy_left',required=True,type=int);a.add_argument('--fy-right',dest='fy_right',required=True,type=int)
 a=p.parse_args(argv)
 try:
  if a.command=='init':
   from .company_routes import roster_from_names
   roster=a.companies if a.companies else roster_from_names(a.company)
   result=init(skill,a.work,roster,a.years,a.start,a.end,a.profile,a.contract_level,a.plan_granularity)
  elif a.command=='source-plan':
   from .company_routes import source_plan
   result=source_plan(skill,a.work)
  elif a.command=='sync':
   from .sources import ingest
   ss=ingest(Path(a.work),Path(a.manifest),a.offline,a.refresh);result={'sources':len(ss),'statuses':{s:sum(r['status']==s for r in ss)for s in {r['status']for r in ss}},'next':'prepare'}
  elif a.command=='read':
   cfg,ss,get_text=context(a.work);tx=get_text(a.source)
   size=a.end-a.offset if a.end is not None else a.limit
   if not 0<=a.offset<len(tx)or not 1<=size<=24000:raise ValueError('Invalid source offset/page size; read in chunks of at most 24000 characters')
   stop=min(a.offset+size,len(tx));result={'source_id':a.source,'text_sha256':ss[a.source]['text_sha256'],'start':a.offset,'end':stop,'total':len(tx),'next_offset':stop if stop<len(tx)else None,'text':tx[a.offset:stop],'not_a_semantic_judgment':True}
  elif a.command=='next':
   from .batches import next_batch
   result=next_batch(skill,a.work,a.limit,a.entity,a.topic)
  elif a.command=='next-second':
   from .batches import next_second_batch
   result=next_second_batch(skill,a.work,a.limit,a.entity,a.topic)
  elif a.command=='prepare':result=prepare(skill,a.work)
  elif a.command=='apply':result=apply(skill,a.work,a.decisions)
  elif a.command=='prepare-second':result=second_tasks(skill,a.work)
  elif a.command=='apply-second':result=apply_second(skill,a.work,a.decisions)
  elif a.command=='audit':result=audit(skill,a.work);result={k:v for k,v in result.items()if k not in ['pending_positions','second_pending_positions']}
  elif a.command=='sec-prepare':
   from .sec_bridge import sec_prepare
   result=sec_prepare(skill,Path(a.work),a.offline,a.cache_only)
  elif a.command in {'contracts-status','contracts-scorecard','codebook-show','reason-apply','reason-coverage','reason-summary','reason-export','tech-apply','tech-capability','tech-coverage','tech-export','linkage-build','linkage-pre-event','registry-init','registry-verify','registry-check','comparability-import','comparability-compare','human-blind','human-template','human-evaluate','human-adjudicate','human-status','search-log-import','search-coverage','missingness-report','missingness-export','routes-check','readiness','next-actions'}:
   result=_contract_command(skill,a)
  else:result=export(skill,a.work,a.output,a.allow_partial)
  print(json.dumps(result,ensure_ascii=False,indent=2));return 2 if result.get('pass')is False or a.command=='audit'and not result.get('complete')else 0
 except (ValueError,KeyError,OSError,TypeError)as ex:
  print(json.dumps({'error':str(ex)},ensure_ascii=False));return 2
