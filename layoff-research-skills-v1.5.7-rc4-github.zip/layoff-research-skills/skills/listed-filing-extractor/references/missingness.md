# Two denominators: review coverage and value availability

A single completion percentage hides the difference between a company that does not disclose a measure and a collection that has not finished looking. Both produce an empty cell; only one of them is a finding. `assets/missingness_contract.json` splits the accounting into two ratios that answer two different questions, and refuses to combine them into one headline number.

## The seven statuses

| status | reviewed | value | meaning |
| --- | --- | --- | --- |
| `observed` | yes | yes | A qualifying disclosure was found and a typed value recorded, with evidence |
| `reviewed_absent` | yes | no | Every applicable source was read and no qualifying disclosure exists — a finding about the company |
| `not_separate` | yes | no | The item is discussed but not separately quantified; the narrative stays `observed` in its text field |
| `not_applicable` | yes | no | A source-supported structural reason means the construct cannot exist; needs `applicability_basis` |
| `unresolved` | no | no | A specific unfinished dependency: a missing document, an unreadable table, a pending access request |
| `not_reviewed` | no | no | No judgment was submitted |
| `not_requested` | no | no | The variable is outside the selected profile |

## The two ratios

- **Review coverage** = reviewed positions ÷ (reviewed + not reviewed). `not_requested` is excluded from the denominator entirely.
- **Value availability** = `observed` ÷ (reviewed − `not_applicable`). A structurally impossible construct is not evidence of non-disclosure.

They are reported by variable, by year and by source type, and they are never multiplied, averaged or merged. A high review coverage with low availability is a real pattern: everything was read, and the company still does not report the item. A low review coverage with a high availability among what was read is also real, and the two must not be presented as one number.

## Why scarcity is expected

Training cost, dedicated AI spend and AI-linked compensation are genuinely scarce disclosures. A low availability rate there is a finding about disclosure practice, not a defect in the collection, and it should be reported as such rather than raised by filling.

## Numeric detail

Numeric availability additionally reports currency, period and total-versus-component basis. A comparable-looking number can still be a different measure: a segment figure is not a company total, a cash payment is not an expense, a closing balance is not an annual flow. `not_separate` exists so these cases are counted honestly instead of being forced into `observed`.

## Commands

```bash
python "$S/scripts/research.py" missingness-report --work "$W"
python "$S/scripts/research.py" missingness-export --work "$W" --output /outputs/missingness.csv
```

`missingness-report` recomputes from the current decision state, so it can be run at any point and always describes what exists now. The sidecar is `work/measurement/missingness.json`.

## Audit behaviour

`missingness` is a blocking contract: `audit` reports it as a gap until every company-year has been accounted for across the selected variables. Because `not_reviewed` and `unresolved` are themselves recorded statuses, the gap closes when the work is either finished or explicitly bounded — never by relabelling.

## What is never claimed

That an unknown value is zero; that a missing disclosure means the company does nothing; that one completion percentage describes both reading effort and disclosure practice. Empty cells with different statuses are different facts, and the export keeps the status rather than only the blank.
