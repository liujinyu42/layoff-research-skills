# Technology evidence: what kind, at what stage

"AI adoption" is not one variable. Cloud migration, warehouse automation, machine learning in production and a plan to deploy agents next year are four different things, and only one of them is a deployed capability. `assets/tech_evidence_contract.json` forces the distinction on the same 41 business fields: the workbook cell keeps the disclosure text and its flag, the sidecar `work/measurement/tech_evidence.json` records the typed evidence behind it.

## Technology class

| code | what the span must show |
| --- | --- |
| `generative_ai` | Generative AI, LLM, foundation model, copilot, prompt — an explicit generative cue |
| `general_ai_ml` | Machine learning, models, prediction, ranking, computer vision, NLP |
| `automation_robotics` | RPA, robots, automated lines, autonomous handling |
| `cloud_infrastructure` | Cloud platform, migration, data centre, SaaS infrastructure |
| `other_technology` | A named technology that fits none of the above |
| `unspecified_ai` | "AI" used with no further qualification |

Two consistency rules do the real work. `generative_ai` requires at least one generative cue inside the cited span — a generic "AI" mention cannot be promoted. And **cloud is not AI**: a span whose only technology cue is cloud or infrastructure cannot support an AI class, because cloud spend and cloud migration are routinely described in the same paragraph as efficiency and would otherwise be counted as artificial intelligence.

## Three ways a class may be supported

Cues are a reading aid, not a classifier, so the contract declares three executable paths (`classification_paths`). The record states which one was used in `cue_basis`.

- **`cue`** — a listed cue occurs inside the cited span. Fast, and enough for ordinary wording.
- **`semantic_review`** — the span describes the technology without using the cue list's words ("the platform recommends the next best action for every service agent"). Requires `semantic_basis` of at least thirty characters *and* `second_reviewer_id`; one coder's reading of a paraphrase is not evidence.
- **`translation`** — the evidence is not in English. Requires `translated_quote` and `translation_reviewer_id`; the original quote stays untouched in the record, and the class is read from the reviewed translation. A non-Latin span submitted without them is refused with `non_english_evidence`.

A cue hit is necessary but not sufficient: an AI field cannot take a pure automation or cloud class even when a cue is present, because the field would then measure something it does not define.

## AI fields and technology fields are not interchangeable

`ai_products`, `ai_integration` and `ai_adoption` describe AI. A pure-automation or infrastructure class belongs in `new_tech_adoption`, which accepts cloud and other technology; `ai_investment_disclosure` requires an expenditure scope and forbids cloud; `tech_opex_disclosure` accepts every class. Submitting a class outside a field's allowed list is an error, not a warning, and the message names the field rule that refused it (`outside the allowed classes for …`).

## Adoption stage

`planned`, `pilot`, `deployed_internal`, `deployed_customer`, `deployed_both`, `retired`, `unknown`. The stage must match the source: `deployed_*` needs operating-deployment language, and `planned` or `pilot` is rejected when the span reports operation with no plan or trial wording.

A qualifier inside the same sentence scopes the verb. "We use artificial intelligence in a limited pilot in two plants" is `pilot`: the record names the cue pair and does not demand a note, because requiring one would punish exactly the wording that separates a trial from a rollout. When the operating wording and the qualifier sit in **different** sentences ("We use AI broadly. We also run a pilot."), `stage_note` of twenty characters or more must say which part is the trial — the text alone does not settle it.

`unknown` is never upgraded to a deployment by implication, and `retired` is neither planned nor pilot. Only `deployed_*` stages enter the capability table.

## One project is one capability unit

Several spans that describe the same deployment are one unit. Give them the same `project_id` and they merge: the unit takes the highest observed stage (`deployed_both` > `deployed_customer` / `deployed_internal` > `pilot` > `planned` > `retired` / `unknown`) and keeps the set of stages it saw. Input order cannot change the answer, and a unit whose spans disagree about stage is flagged in `stages_conflict` rather than silently resolved — `audit` reports each conflict as a gap.

Without a `project_id`, a span is its own unit, keyed by the quote hash. That is the conservative default: two mentions are two units until the coder says they are one project.

## Context and expenditure

`use_context`: `internal_operations`, `customer_product`, `both`, `unspecified`. `expenditure_scope`: `ai_dedicated`, `mixed`, `not_applicable`. `mixed` never supports an AI amount claim in analysis — a "Technology and development" line that includes AI does not become AI spend.

## Coverage counts every rule

`tech-coverage` compares the observed fields that have a technology rule against the typed records, and lists `expected_variables` so the denominator is visible. It does not use a hand-listed subset of AI variables: a field with a rule and no typed record is a gap, whatever its name.

## Commands

```bash
python "$S/scripts/research.py" tech-apply      --work "$W" --file /input/tech-evidence.csv [--replace]
python "$S/scripts/research.py" tech-capability --work "$W"
python "$S/scripts/research.py" tech-coverage   --work "$W"
python "$S/scripts/research.py" tech-export     --work "$W" --output /outputs/tech_evidence.csv
```

Copy `assets/tech_evidence_template.csv`. `tech-apply` merges by `(entity_id, variable, project_id or quote hash)`, so a second batch adds to the first instead of replacing it; `--replace` is the explicit way to rebuild the sidecar from one file. Rejections come back with the row number and the failing rule.

## Audit behaviour

`audit` reports `tech_evidence` as a measurement-contract gap until every observed AI/technology construct has a typed record, and separately reports `contract_version_changed`, `stage_conflict` and any record whose class contradicts the AI-only rule. The sidecar carries the contract hash and a dependency fingerprint of the workspace, so editing the vocabulary — or the decisions it was typed against — raises `stale_record` and forces a recode rather than a silent migration.

## What is never claimed

That a keyword mention is adoption; that a plan is a capability; that cloud spending is AI spending; that a mixed line item is an AI amount; that a pilot is a deployment because the sentence also says "we use". Keyword counts are leads for reading, and `tech-capability` reports only what a deployment sentence supports.
