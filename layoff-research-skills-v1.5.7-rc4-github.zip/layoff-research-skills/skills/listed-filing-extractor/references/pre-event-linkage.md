# Pre-event public evidence matching

The two tables answer different questions at different dates. An annual observation is dated by fiscal year, an announcement by the day it was made. Comparing them naively assumes that a FY2023 annual report was observable before a March 2024 announcement — but that report was published in 2025. Its FY2023 facts were not public when the company announced the reduction, so it cannot support a claim about what the company was capable of beforehand.

`assets/linkage_contract.json` defines the classification; the sidecar is `work/measurement/linkage.json`, and the analysis-ready table is a separate CSV. Both tables keep their 43 / 41 fields; the pairing lives beside them.

## Grain: one unit per variable and cited document

A company-year is a reporting label, not an evidence unit. The same FY2023 filing set routinely holds an annual report filed in February and an AI exhibit filed in April; a March announcement can cite the first and not the second. The contract therefore classifies **each cited source inside each decision** (`evidence-level-v2`) and rolls the units up afterwards. It never aggregates a company-year to its earliest publication date and filters later — that is exactly how a late document borrowed an early document's eligibility.

`linkage.json` carries both grains: `rows` (one per event × company-year, for reporting) and `units` (one per variable × cited source, where the decision is made). The join to the technology side is `entity_id + source_id`, never `entity_id`.

## Anchor

The workforce-reduction announcement date. Every evidence unit is classified against it, twice: by the carrying document's `publication_date` and by the information period it reports (`information_as_of` / `period_end`).

| state | condition | enters the primary measure |
| --- | --- | --- |
| `pre_event_public` | published on or before the event **and** information period ended on or before the event | yes |
| `retrospective` | published after the event, or reports a period ending after it | no |
| `undetermined` | a required date is missing, a cited source is not ready, or publication is the same day as the event | no, and counted |

Every unit records its `basis`, so a reader can recount the decision: `published_and_period_before_event`, `published_after_event`, `information_period_after_event`, `same_day_no_intraday_order`, `publication_date_missing`, `information_period_missing`, `event_date_missing`, `no_cited_source`, `cited_source_not_ready`.

Classification never uses the fiscal-year label. A FY2022 report filed in 2024 is retrospective for a 2023 event no matter how the label reads, and a period end that cannot be established cannot establish pre-event availability.

## Same-day publication

Dates alone cannot order two events on one day, so publication equal to the event date is `undetermined` (`same_day_policy: undetermined` in the contract). Declaring another convention changes the verdict and stamps `same_day_declared_pre_event`; the code never assumes one.

## Row-level rollup

A company-year row is `pre_event_public` only when at least one variable qualifies and none is contaminated. `pre_event_variables` lists what may be used; `contaminated_variables` names what may not, so "this year is usable" never hides a late document behind an early one. The rollup is for reporting — capability enters the measure unit by unit.

## Typed evidence joins on the document

`linkage-pre-event` attaches the technology record whose `source_id` matches the unit's. A capability attested only in a document published after the event therefore cannot enter the pre-event measure, even when another document for the same fiscal year was published before it. `typed_evidence_in_cited_document` shows how many typed records were available in that specific document; `null` means the technology sidecar does not cover it, which is not the same as "no capability".

## Rules

- **Entity must match.** Only rows sharing a verified company identity are paired. A parent's annual report and a subsidiary's reduction are paired only through an explicit registry relationship; brand or name similarity is not identity.
- **Undetermined is not negative.** An undetermined unit is excluded *and counted*. It is never reclassified as retrospective to make a sample size.
- **No silent deletion.** Every excluded unit appears in the sidecar with its state and basis.
- **Derived records go stale.** The sidecar stores a dependency fingerprint over both workspaces (`config`, `decisions`, `entities`, `sources`). Editing either side and re-reading without `linkage-build` raises `stale_record` and names the changed file; `audit` reports it as a gap rather than using a stale pairing.
- **Window is explicit.** `--window` bounds how many years back a filing may sit, and the value is recorded.

## Commands

```bash
python "$S/scripts/research.py" linkage-build     --work "$W" --peer-work "$PAIRED" --window 3
python "$S/scripts/research.py" linkage-pre-event --work "$W" --output /outputs/pre_event_linkage.csv
```

`--peer-work` is the other skill's workspace for the same companies. `linkage-build` pairs, classifies each unit and summarises; `linkage-pre-event` exports the units that were public before the event, with the typed-evidence join.

The command refuses to run without a paired workspace, and `audit` reports `linkage` as a gap until one is supplied. This is a non-blocking contract: single-table collection and export stay valid, and every pre-event claim stays unavailable.

## What is never claimed

That a fiscal year earlier than an event implies prior public availability; that a retrospective disclosure describes what was knowable at the time; that undetermined pairs are unfavourable evidence; that a late document speaks for an early one. The pairing supports a comparison of what was *publicly observable* before an announcement, and nothing about intent or causation.
