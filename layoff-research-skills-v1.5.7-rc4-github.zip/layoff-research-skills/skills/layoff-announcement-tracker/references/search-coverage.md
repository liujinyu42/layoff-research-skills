# Executed search coverage vs discovered events

A registered plan proves an event was found. It never proves the company's other events were looked for. A one-row or zero-row event table therefore has two possible readings — "no reduction happened" and "nobody searched" — and the difference is only visible if the search itself is recorded. `assets/search_coverage_contract.json` makes that record a first-class object (`work/measurement/search_coverage.json`), separate from the event rows.

## Grain

One row per company × date window × channel × query. Two rows for the same window and different channels are two searches, not a duplicate.

```bash
python "$S/scripts/research.py" search-log-import --work "$W" --file /input/search-log.csv
python "$S/scripts/research.py" search-coverage    --work "$W"
```

Copy `assets/search_log_template.csv`; every column is required by the row checks below.

## Channels

`company_ir_site`, `sec_edgar`, `exchange_disclosure`, `regulator_warn`, `news_index`, `layoff_tracker`, `authorized_dataset`, `other`. An issuer investor-relations page, a statutory WARN notice and a third-party tracker are different evidence channels: a tracker hit is a candidate lead, never the original, and does not satisfy an original-source requirement on its own.

## The channel plan is declared, not implied

Searching one channel proves one channel. The contract ships a default plan (`channel_plan.default`), and a workspace may declare a different one with `search_channel_plan` in `config.json` — the declaration is recorded with the coverage result, so "we searched what we said we would" is checkable.

For each company the report lists every planned channel with `searches`, covered intervals, `covered` and `missing_planned_channels`; `channel_plan_complete` is false when a planned channel has no covering search. A plan that names four channels and a log that covers one is a named gap, not 25 percent of a percentage that hides which quarter is missing.

## Outcomes

| outcome | counts as coverage | requires |
| --- | --- | --- |
| `found_events` | yes | `events_registered` naming registered plan IDs |
| `none_found` | yes | `stop_condition` |
| `blocked` | no | `notes` naming the access, payment, language or platform limit |
| `out_of_scope` | no | `notes` explaining why the window or company is out of scope |
| `not_attempted` | no | `notes` |

`none_found` is a coverage result, not a finding. It creates no pseudo-event and no zero-valued row; the event table simply has no row for that window. `stop_condition` states how the search was stopped — page depth, date reached, index exhausted — because an unbounded "I looked" is not reproducible.

## Window coverage

For each company the requested event window (`event_start` … `event_end`) is merged against the covered intervals. `uncovered_intervals` lists the gaps and `window_coverage` is the covered share. `search-coverage` also reports `plans_with_a_search_record`, so a registered plan that no log row traces is visible as its own gap rather than hidden in a percentage.

Gate reasons, all repairable by importing a corrected log:

- `unsearched_window` — an interval of the requested window has no executed search.
- `plan_without_search_record` — a registered plan cannot be traced to any log row.
- `blocked_window` — a window is recorded as blocked and is not counted as reviewed.
- `planned_channel_not_searched` — a channel in the declared plan has no covering search for that company.

## Row validation

Rejected with the row number and the field name: an unknown `company_id`, a channel or outcome outside the vocabulary, a window outside the requested event window, `window_start` after `window_end`, a query shorter than five characters, a `none_found` row with no stop condition, a `blocked` or `out_of_scope` row with no note, a missing `executed_at`, and `found_events` with no registered plan.

## What is never claimed

That a company had no layoffs because a search found none; that a tracker or news index is a complete register; that search coverage, original-announcement coverage and coding completeness are the same number. The three are reported separately, and a blocked window stays a named limitation instead of becoming "reviewed, no events".
