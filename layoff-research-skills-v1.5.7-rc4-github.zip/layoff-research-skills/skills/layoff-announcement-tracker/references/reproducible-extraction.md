# Reproducible extraction and semantic review (1.5.7-rc4)

This is a reusable research infrastructure for the two proposal parts, not a Meta/Alphabet extractor. Defaults: event window 2020-01-01 to 2026-09-30; listed-company FY2019–FY2025. User scope overrides defaults. Historical corpus counts are researcher-provided background, never generated or certified by running this skill. The incomplete phrase “known parties affected by the” is interpreted as parties affected by the layoff, without adding a new construct.

## Keep two comparisons separate
Before comparing models, record model/provider/version as declared (unknown if unavailable), host, prompt hash, runtime/schema/contract hashes, tool access, search date, roster/window, source manifest hash, reused decisions, and review budget. Match issuers by verified legal identity/CIK, not ticker spelling. A reused event table is not independent discovery. Never infer a model performance ranking from one pair of outputs.

Use a fresh workspace with an identical frozen source corpus to compare coding; use independent fresh workspaces with identical source-channel obligations to compare discovery. Report event precision/recall only against an adjudicated reference corpus, normalized numeric agreement, disclosure confusion matrices, missingness by cause, evidence validity, and runtime/cost. Run repeated trials before a stability claim. Same-model second pass is not independent validation.

## Mandatory semantic receipts
The existing `audit` now adds `semantic_receipts_v1` gaps. It leaves PARTIAL export available but blocks COMPLETE until review records are supplied. These are review obligations, not a guarantee that a model has read correctly. Existing decisions remain archived; add receipts after reading and redo second review and derived contracts.

For `reviewed_absent`, `not_separate` and observed zero disclosure flags, add `negative_review`:
- `sections`: list of `{source_id, section, start, end, section_sha256, finding}`. Offsets refer to normalized source text, hash to that exact slice. Name each applicable section, including compensation discussion/performance assessment where relevant. Cover every source in `reviewed_scopes`; the older full-source review rule still applies.
- `near_misses`: list of `{source_id, quote, exclusion_reason}` for close candidates. If empty, include `no_candidate_basis`. A boilerplate “full report checked” does not explain why a candidate fails.

For positive `ai_integration` or `new_tech_adoption`, add `operational_use`: `{use_context: internal_operations|customer_product|both, stage: pilot|deployed_internal|deployed_customer|deployed_both, process, evidence_indices: [0]}`, using the published `tech_evidence_contract.json` vocabulary (legacy `internal` / `deployed` / `established_use` values are still read). Record pilot explicitly without claiming production; planned, retired, unknown and unspecified never qualify on their own. Future “will use” does not establish an operating construct, and a sales claim needs a named stage and process. AI risk text alone does not establish an identified operational workflow. Use the existing technology sidecar for class, stage and product/internal distinction; AI hardware can overlap AI and technology categories without being counted as two capabilities.

For positive `ai_exec_comp`, add `ai_pay_link`: `{link_type: dedicated_ai_metric|mixed_bonus_factor|ai_retention_award, recipient, award_basis}`. AI considered among multiple bonus criteria qualifies as qualitative disclosure even without a dedicated weight. AI amount remains null unless separately quantified. Read the assessment and recipient table together, not just strategy pages.

For positive `restructuring_charges`, add `charge_perimeter`: `{included: [...], other_charge_review, total_basis}`. A table headed Total is total only for its perimeter. Check nearby accelerated depreciation/rent, noncash stock compensation, plan-specific charges, reversals and current/comparative periods. Keep disjoint components and any calculated aggregate in sidecars unless the variable contract permits the aggregate. Do not silently widen its definition.

## Coverage and stopping
Every candidate announcement needs a disposition: canonical plan, supported duplicate/update, out of scope, or unresolved. Company, regulator/WARN, tracker and reliable-news channels must have executed-search records including unsuccessful attempts. Record brand/subsidiary employer scope. Profile/history/M&A/leadership fields are required review work, not optional enrichment; internal reorganization is not an acquisition. Unknown relationships stay unresolved; do not sum WARN sites or cumulative reports.

For filings, check actual fiscal periods and publication dates, Business, Risk Factors, MD&A, notes and incorporated compensation disclosures or documented local equivalents. SEC is the U.S.-listed route; HKEX/LSE/ASX/KRX/Xetra use their market-specific public reports and languages. A route being coded is not evidence it has been successfully collected for every market. Unsupported routes/access failures remain explicit. Report review coverage separately from disclosure prevalence and numeric availability; six technology-company years cannot establish prevalence across industries.

The infrastructure supports incremental updates with content hashes and stale-review detection; continuous monitoring requires an externally scheduled invocation. Never claim that scheduling, non-U.S. validation, cross-model equivalence or the historical sample has been demonstrated merely because the skill exists.

## Cross-run delivery and event ownership

Give each run an isolated output directory and a run identifier. If the requested directory already contains another run, preserve its complete deliverables and use a run-specific child directory. Preserve model/provider declarations and their provenance; an unexposed model remains unknown. Record unfinished work separately from inaccessible evidence. Available source material that still needs reading is an unfinished task, not an access blocker.

For a subsidiary event, bind the employing entity and issuer relationship to the announcement date. Record acquisition signing and closing separately. A later acquisition does not make an earlier event an issuer event. Keep excluded discoveries in the search ledger. Profile fields must identify whether they describe the employer or consolidated issuer; an issuer's founding date cannot fill a subsidiary's founding date.

Resolve same-plan relationships to one acyclic canonical root with the earliest announcement date. Keep cumulative updates and implementation notices in evidence. An included subsidiary component or WARN site notice does not create an additional disjoint plan. If evidence leaves membership unsettled, retain an unresolved candidate rather than declaring independence from lack of a matching phrase.

For comparative research, retain each source run before adjudication. Label re-exports reconstructed and retain their runtime and source-workspace hashes. Report coverage, observed availability, semantic correctness and second-review coverage separately. A source-verified disagreement can inform a general regression case; model agreement alone cannot establish correctness.

### Focused semantic review after the comparative audit
- For actual internal technology use, inspect cybersecurity, infrastructure and operating-process sections as well as Business. Shared infrastructure can support internal operations and external services simultaneously; extract the internal process separately. A generic phrase such as “internal systems” still needs process-specific evidence. Future development and customer sales alone are insufficient.
- For executive AI compensation, inspect individual performance assessments within the fiscal-year cash-incentive and equity-award discussion. A qualitative AI contribution among several award factors can qualify without a separate AI amount. Keep the amount null when inseparable.
- A non-GAAP adjustment row of zero for one prior programme is not evidence of zero issuer-wide restructuring expense. Identify the perimeter of severance, asset impairment, facilities and other charges before claiming a total. A number's exact quotation does not resolve its accounting scope.
- “Approximately N” may be a qualified point estimate; one-sided thresholds such as “more than N” or “up to N” are bounds. A definite count must not be erased with reviewed_absent when the reason itself acknowledges it. Retain all bounds and exact wording.
- The final workbook is part of the contract. Use the bundled exporter and run audit_deliverables.py on the actual delivered file. A decisions log is evidence, not a replacement Results table. A custom export cannot turn an unaudited run into COMPLETE. If blocked, deliver PARTIAL with the unsatisfied gates and preserve the original queue.
- Require field-specific section findings and close-candidate exclusions for negative decisions. Whole-document hashes and Boolean no-candidate attestations do not establish the absence of a disclosure. Gates validate structure, and semantic review must still check the claims.

rc4: default event grain is plan. Only verified implementation_of is folded in plan mode; extension_of remains a separate candidate until evidence establishes identical-plan identity via same_plan_update. Customer-only technology deployment cannot establish internal adoption. Missing bundled technology contract is an explicit error.
