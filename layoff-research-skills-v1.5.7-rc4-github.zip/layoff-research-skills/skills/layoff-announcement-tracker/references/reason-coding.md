# Stated-reason coding with attribution

The Results sheet keeps one free-text `stated_reason_text` cell per plan. That cell answers "what did the company say" for a human reader; it cannot answer "how often was AI cited" because a single plan may cite AI, cost and a reorganisation at once, and the answer depends on who is speaking. The codebook in `assets/reason_codebook.json` is the structured representation of the same evidence in a sidecar (`work/measurement/reason_codes.json`). It never overwrites the cell, never adds a column and never changes the 43-field contract.

## Grain and vocabulary

One row per plan per label. Nine categories, fixed at this version:

| code | when it applies |
| --- | --- |
| `ai_technology` | Role reduction attributed to AI, ML, generative AI, automation, robotics or an introduced system doing the work |
| `financial_operating` | Cost reduction, margin, profitability, budget or loss pressure |
| `strategic_restructuring` | Portfolio, footprint, business-model or organisation redesign |
| `mergers_acquisitions` | Merger, acquisition, divestiture, integration or synergy |
| `ipo_performance_targets` | Listing, guidance, covenant or performance-target pressure |
| `leadership_transition` | Incoming or outgoing leadership as the stated driver |
| `demand_market` | Demand, order book, market or macro conditions |
| `labor_cost_structure` | Wage, benefit, location, offshore or workforce-mix cost |
| `other_stated_reason` | An explicit reason that fits none of the above |

`other_stated_reason` is exclusive: it cannot co-occur with any substantive category. Use it only when the source states a reason and the eight categories genuinely do not cover it, and say which reason in the quote.

## Attribution decides whether a label exists

Four levels, in `attribution_levels`:

- `company_direct` — the issuer's own announcement or filing names the reason.
- `company_quote_in_news` — a named company representative is quoted in a news source.
- `reporter_interpretation` — the journalist or a third party explains the cause.
- `researcher_inference` — the coder's own reading.

The plan's level is never typed by hand. It is derived from the plan's `reason_attribution` decision through `maps_from`, so the event record and the codebook cannot drift apart. Levels whose `counts_as_stated_reason` is false, and the value `unclear`, force an **empty label set** with a recorded basis: a plan whose reason comes only from a reporter's explanation has no company-stated reason, and coding it anyway would manufacture one.

A label may carry its own `label_attribution` when the source mixes speakers — an executive quoting a supplier, a reporter quoting the executive. It must be a declared value, and it cannot exceed the plan level: a label cannot claim `company_direct` provenance when the plan's reason came from a reporter's interpretation. Each label records the level it was accepted at, so a frequency table can be recomputed at the stricter level.

## Per-label gates

Every label carries `source_id` and a verbatim `quote` of at least ten characters, located inside the plan's own stated-reason source. On top of that:

- **Cue gate.** If no positive cue for the category occurs inside the cited span, `cue_absent_justification` must explain why the span still satisfies the definition. Cue lists are reading aids; they are not a classifier, so a cue hit without a justification of the actual claim is not enough either.
- **Primary gate.** `primary_code` is recorded only when the source explicitly ranks or orders its reasons. `primary_basis` must contain the ordering language itself (`primarily`, `mainly`, `driven by`, `the largest factor`, …from `ordering_cues`), and `primary_basis_quote` must be that verbatim sentence, found inside one of the plan's cited sources. A primary that cannot be located in the text is a paraphrase, not an ordering. Frequency of mention never establishes primacy.
- **Empty-set gate.** An empty label set is a decision, so it needs a `no_label_status` — `not_yet_classified`, `outside_codebook`, `no_company_reason` or `not_a_reason` — plus notes of at least fifteen characters explaining the basis. A plan that is observed, attributed to the company, and then given neither a label nor a status is `labels_incomplete`; silence is not a finding.
- **Null gate.** If the source states no reason, the label set is empty and `stated_reason_text` is `reviewed_absent`. Absence of a stated reason is not the reason `financial_operating`.
- **No causal verdict.** The codebook never records that a reason is untrue, rhetorical or an excuse, and never records that it caused the reduction. That judgment belongs to the analysis, outside the data.

## Proposals are not labels

A coder who meets a real reason the taxonomy does not cover records it in `proposed_categories` with a code, a definition and the quote. The proposal is stored as `pending_human_review`, never added to `labels`, and `audit` reports `category_pending_human_review` until a human edits the codebook. Inventing a label to fit a sentence would change the taxonomy study by study; the proposal keeps the evidence without changing the measure.

## Commands

```bash
python "$S/scripts/research.py" codebook-show   --work "$W"     # the shipped taxonomy and rules
python "$S/scripts/research.py" reason-apply    --work "$W" --file /input/reason-coding.csv [--replace]
python "$S/scripts/research.py" reason-coverage --work "$W"     # plans coded / plans registered
python "$S/scripts/research.py" reason-summary  --work "$W"     # label counts by attribution level
python "$S/scripts/research.py" reason-export   --work "$W" --output /outputs/reason_codes.csv
```

`reason-apply` merges by plan, so coding a second batch adds to the first instead of overwriting it; `--replace` rebuilds the sidecar from the submitted file, which is what a deliberate recode looks like. Every rejection is returned with its row number and reason. Copy `assets/reason_coding_template.csv` to start.

## Coverage is three numbers, not one

`reason-coverage` separates plans that carry a label set, plans with a declared empty status (`plans_with_declared_no_label`) and plans that are attributed to the company yet have neither (`silently_unlabelled_plans`). The third number is the one a single "percent coded" figure hides.

## Audit behaviour

`audit` reports `reason_codebook` as a measurement-contract gap until every registered plan has either a label set or a `no_label_status` with notes. The sidecar carries the contract hash, the schema version and a dependency fingerprint of the workspace, so editing `reason_codebook.json` — or the decisions the codes were read against — invalidates existing codes and forces a recode rather than a silent migration. `--contract-level baseline` disables the gate for historical workspaces; it does not disable the codebook.

## What is never claimed

That a stated reason is the true cause, that it is dominant, that AI was or was not an excuse, or that the label frequency measures actual automation. The codebook measures what companies said, with attribution, and nothing more.
