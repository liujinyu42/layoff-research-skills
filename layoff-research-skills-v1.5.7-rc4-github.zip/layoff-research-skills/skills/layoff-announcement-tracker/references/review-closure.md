# Source review closure (v1.5.7-rc4)

Read this before source decisions and again before final export. These rules apply without prior chat history.

## Close the review, not the blanks
Run next-actions and resolve each pending position against the applicable full sections, statement notes and incorporated compensation disclosures. Group work by company, year and source to reuse reading. Record searched documents/sections and the result. An empty numeric value may be separately undisclosed, unavailable, inapplicable, conflicting or unfinished; never replace it with a proxy or zero. A disclosure flag is 0 only after a completed source-supported negative review. Do not copy a prior run's reviewed_absent status without checking its scope. Export genuine PARTIAL with the generated review queue when sources or judgments remain unavailable; do not stop merely because tasks were dispatched.

## Events and numbers
For each candidate plan, compare scope, initial authorization, incremental headcount and implementation dates against existing plans. Common acquisition context alone does not prove one plan; a different news date alone does not prove a new plan. Populate plan_relationship and related_plan_id only with supported judgments. Separate M&A/leadership background from company-stated reasons. Complete the declared issuer and other search channels before not_found_after_search.

Preserve numerical_claim_raw. Fewer than/under is an exclusive upper bound, not a point. Nearly implies a below-threshold approximation: retain its wording and resolve conflicting reports, rather than silently treating it as an exact or symmetric estimate. Keep source-specific claims when sources disagree. Never require a particular number of nonempty bound fields.

Separate first public announcement, report date and effective date; keep month/interval precision when a day is unverified. For event workforce denominators check both fact date and publication date. Use the latest appropriate observation publicly available before the event when constructing a pre-event measure; a fiscal-year label alone is insufficient. Do not replace an early-year denominator with a later year-end figure or expand the requested years silently.

## Annual constructs and evidence
Trace current-year versus comparative columns, totals versus components, actual costs versus commitments/policies, and actual awards versus future incentives. Preserve those distinctions in decision evidence and review notes. AI-specific amounts cannot be inferred from R&D, cloud capex, SBC or total executive pay.

Established cloud use may meet new_tech_adoption under the bundled definition but is not AI or first adoption. Distinguish GAI, other AI, automation and cloud; plan/pilot/deployed; internal use/customer products in the technology sidecar. MD&A expense composition is weaker evidence of HR strategy than an explicit action: describe what is actually supported. Same text may support multiple constructs and recur across annual filings; verify each occurrence and deduplicate real projects for capability counts. Do not create separate project identities solely because variable names differ.

## Deliver and interpret
Preserve the single English Results sheet and bundled columns. Deliver original sources, measurement records, review queue, sidecar index and audit together. Recompute derived records after upgrade; layered-v4 invalidates old algorithm records, not original source files. Verify the audit workbook hash before comparing runs. Separate runtime, schema and contract versions.

Local pre-event evidence is a descriptive prerequisite. A full RQ2 contrast also requires verified reason groups, eligible event-level joins, comparable measures and an appropriate analysis design. No causal conclusion follows from completeness or audit success. Profit changes after layoffs are not proof layoffs caused the changes. The historical corpus size is not a mandatory run quota; job-skill pairing remains a separate next step. Require independent human annotations before human reliability claims.

## Resume and release

Use the review queue to resolve fields, perform pending second reviews and run unfinished contracts. Group tasks by source IDs. Before ending a full run, re-audit and repeat actionable work until cleared or a specific source or execution limit prevents progress. Document the actual attempts and remaining blocker for each unfinished group. A successful inspection export does not close these tasks.

On workspace merge, retain a second review only when its decision and source bindings still match. Re-run the destination audit and reissue invalid or missing reviews. Keep source failure, semantic review and independent human validation distinct.

Route evidence already found to its affected fields. A documented acquisition belongs in event background if it meets the event-time definition. A mixed restructuring cost needs a separate adjudication of period, unit, scope and total before acceptance or exclusion. Keep verified issuer jurisdiction separate from affected-worker geography and reuse identity evidence only when the field definition and event date match.

Record plan existence separately from independence in decision notes. Review related candidates, WARN components and additional rounds against scope and timing before setting plan_identity_verified. Supply the relationship decision and cite the comparison or reviewed search scope. Leave unknown relationships unresolved.

Use the existing not_applicable and not_separate statuses where their evidence requirements are met. Record censored headcount in the evidence and missingness reason while leaving the exact value null. Apply typed technology evidence immediately after reviewing a positive decision with a technology rule. Read the full source context before assigning internal use or deployment.

## Delivery quality

Record each same_plan_update with its related_plan_id. The workbook exports the root plan and preserves update decisions and canonical IDs in the source evidence sidecar. Reconcile the root quantity, qualifiers and scope using the latest applicable cumulative disclosure while keeping the first announcement date. On the root layoff_count_basis decision, record canonical_update_reconciliation explaining which updates were read, which quantity was selected and why. Never sum overlapping cumulative announcements.

If a business text or quote exceeds 12,000 characters, review the original section and replace the span with focused excerpts. Preserve qualifiers and offsets. AI risk mentions alone do not establish an investment commitment.

For restructuring charges identify issuer total, plan total or component in the decision and justify the selected scope against the variable definition. A severance figure alone cannot establish the issuer total. Review comparative columns and keep non-separately disclosed amounts null. For negative flags, record all applicable document roles, reviewed sections and why close candidates were excluded, including incorporated proxy materials where relevant.

Verify WARN publisher and document provenance. Record official notice and aggregate register separately from issuer announcements and media reports. Preserve filing, publication and effective dates separately and document any uncertainty about public availability.

## Canonical selection in v1.5.6

For a group with updates, submit canonical_update_reconciliation on the root layoff_count_basis decision as an object with source_plan_id, reason and decision_bindings. Choose the reviewed record containing the applicable cumulative quantity bundle. Read audit coverage_gaps for expected_bindings. Copy those bindings only after reviewing the selected scope and all updates. Reapply and complete the root decision's second review.

The selected bundle includes counts, bounds, percentages, population and raw quantity wording. The first announcement remains on the root. Evidence retains the selected source plan. New or changed decisions invalidate selection. If no single record supports the full bundle, first submit a reconciled root bundle with exact evidence and then select the root.

Exported related_plan_id uses canonical IDs. Original IDs remain in evidence. Treat unknown relationships as unresolved decisions and continue relationship review. Downstream reason and linkage consumers must use the canonical mapping while retaining source publication dates for every update.
