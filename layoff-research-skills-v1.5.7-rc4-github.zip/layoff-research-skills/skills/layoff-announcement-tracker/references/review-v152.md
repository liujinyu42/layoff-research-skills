# Measurement maintenance

After upgrading, rebuild derived measurements; preserve original sources and decisions. Workspace format and output columns remain compatible, but algorithm fingerprints invalidate old sidecars.

Mixed-timing summaries conservatively flag the whole variable; retain individual evidence units for sensitivity analysis. Never add capability counts across variable/source rows. Internal deployment, customer products and pilot activity are distinct.

Use independent human annotation for actual accuracy claims. Report label-level errors, source availability and review coverage separately. No semantic accuracy or speed claim follows from offline test counts.

For stale batched measurements, reconstruct the full submission from current decisions before apply; do not submit a small replacement batch and assume stale records survived. Profile dependency granularity before claiming incremental performance gains.

Validate real sources across languages, markets, fiscal periods and unavailable disclosures before research use. Do not fill genuine missing values, add business columns, or infer causality.
