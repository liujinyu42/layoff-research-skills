# Fixed research variables

The 43 business fields below are the complete output scope. Both profile names select the same set. Identity columns are plan_id, company_id, company. The only other columns are delivery_status, field_status_json and evidence_json, with lossless horizontal __partN continuations if needed. Each Excel has one Results worksheet. All presented content is English.

The field dictionary and schema include the source roles and full criteria. Read [English output and measurement checks](english-and-measurement.md) before deciding. Keep text, disclosure codes and numerical amounts distinct. Code 0 means complete applicable-source review found no qualifying disclosure. Null means the amount is not separately disclosed, inapplicable with evidence, unavailable or unresolved according to its recorded status. Missing numbers do not become zero.

| Field | Meaning | Type |
|---|---|---|
| company_name_at_event | Legal company and operating unit at the event | text |
| announcement_date | Announcement date | date |
| announcement_date_raw | Original date wording | text |
| announcement_date_precision | Date precision | text |
| effective_date_start | Implementation start date | date |
| effective_date_end | Implementation end date | date |
| announcement_status | Announcement or implementation status | text |
| original_announcement_url | Original issuer announcement URL | text |
| original_announcement_status | Original announcement search status | text |
| announcement_source_kind | Evidence source kind | text |
| source_publication_date | Source publication date | date |
| layoff_count | Reported point count of affected people or roles | number |
| layoff_count_lower | Explicit lower threshold for affected people or roles | number |
| layoff_count_upper | Explicit upper threshold for affected people or roles | number |
| layoff_count_qualifier | Count qualifier and boundary direction | text |
| layoff_count_basis | Count population and measurement basis | text |
| layoff_percentage | Reported point percentage | number |
| layoff_percentage_lower | Explicit lower percentage threshold | number |
| layoff_percentage_upper | Explicit upper percentage threshold | number |
| layoff_percentage_qualifier | Percentage qualifier and boundary direction | text |
| layoff_percentage_denominator | Percentage denominator population | text |
| numerical_claim_raw | Original numerical claim | text |
| stated_reason_text | Stated layoff reason and attribution | text |
| reason_attribution | Speaker or reporter attribution | text |
| ma_activity | Event-time M&A activity | text |
| leadership_transition | Event-time leadership changes | text |
| firm_size | Event-time company workforce size | number |
| firm_size_basis | Workforce-size population basis | text |
| firm_size_as_of | Workforce-size information date | date |
| affected_parties | Known affected teams, roles or groups | text |
| listed_at_event | Listed status at the event | binary |
| exchange_at_event | Exchange at the event | text |
| ticker_at_event | Ticker at the event | text |
| cik | SEC company identifier if applicable | text |
| country | Country or jurisdiction | text |
| plan_identity_verified | Plan identity verification | binary |
| event_type | Workforce-action type | text |
| related_plan_id | Related plan identifier | text |
| plan_relationship | Relationship to the other plan | text |
| company_history | Company history known at the event | text |
| founding_year | Founding or incorporation year with entity basis | integer |
| products_services | Products and services at the event | text |
| business_model | Business model at the event | text |

For events, preserve the nine substantive proposal Part 1 constructs, original-versus-news status, attribution, dates, populations, numeric qualifiers and verified plan relationships. M&A and leadership context do not require a causal layoff connection, but a reason claim does. For annual reports, restrict data to HR, AI/new technology and financial performance. MD&A must be actual management discussion or an equivalent section. Monetary observations retain literal numbers, units, currency, sign, period and total/component basis. AI-linked compensation needs explicit AI and recipient linkage. Genuine unavailable public data remain explicit, and the historical research corpus is not required.
