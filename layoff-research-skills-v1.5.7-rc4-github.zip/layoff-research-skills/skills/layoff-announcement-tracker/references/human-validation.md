# Independent human validation

A second pass by the same model is a consistency check. Reporting it as reliability overstates what the data can carry, so the only thing that upgrades a coding pass into a validated measurement is a blind human annotation of a held-out split. `assets/human_validation_contract.json` defines the interface; the sidecar is `work/measurement/human_validation.json`.

## Order of operations is the design

1. `human-blind` freezes the model's answers **now** into `work/measurement/human_predictions.json` and a CSV of `record_key, variable, model_status, model_value, model_codes`.
2. `human-template` writes a blank `human_status` sheet with no model column, for one split or all of them.
3. An independent coder fills it in and returns `coded_at` on every row.
4. `human-evaluate` compares the two.

## What the freeze actually holds

The freeze is a payload, not a file name. It stores the rows themselves (`predictions`), a canonical digest of them (`predictions_sha256`, insensitive to row order), every `record_key`, the split assignment with its own digest (`splits_sha256`), the human-validation contract hash, the reason-codebook hash, and a dependency fingerprint of the workspace. Evaluation recomputes the payload from the CSV you pass and refuses on any difference:

| refusal | what it caught |
| --- | --- |
| `prediction_freeze_mismatch` | the file has the same keys but a value, status or code moved after annotation |
| `The human-validation design changed after the predictions were frozen` | the contract's split shares, minimums or columns were edited mid-study |
| `split_changed_since_freeze` | a new split assignment was supplied; the held-out claim would be re-defined after seeing results |
| `blind_violation` | the earliest `coded_at` predates `recorded_at` |
| `holdout_already_evaluated` | the held-out split of this experiment was already scored once |

Re-exporting predictions after annotation is therefore not a harmless refresh: it invalidates the freeze for the same reason a late annotation does.

## Splits

Deterministic and assigned by **group**, not by field: every record of one company (filings) or one plan (events) lands in the same split. The forty-three fields of a plan come from one document, so splitting them across development and held-out would let the model see the document it is being scored on. Shares come from the contract (`seed_share`, `holdout_share`); the order is fixed by a digest, so re-running cannot reshuffle the held-out set, and a key assigned to two splits raises `split_leakage`.

The seed split is what a codebook may be written from; development is for fixing the codebook after it was frozen; the held-out split is scored once.

## Status levels

| status | meaning | what may be claimed |
| --- | --- | --- |
| `not_executed` | no human file, or no rows | nothing about agreement; a complete answer, not a missing one |
| `seed_only` | only seed records annotated | the codebook was human-seeded |
| `development_only` | development annotated, held-out incomplete or below the per-class minimum | development agreement, not held-out accuracy |
| `holdout_evaluated` | blind held-out split met `min_holdout_per_class` for status and reason labels and was scored once | held-out agreement, class precision/recall, chance-corrected agreement |

`families_scored` lists which metric families actually had data — `status`, `binary`, `value`, `reason_labels`. A family with no holdout pairs is reported as absent, not as agreement of one.

## Metrics, and what they are computed over

Every scored metric uses the held-out split only, and the sidecar says so in `metric_scope`. Seed and development appear in `per_split` as agreement over their own records; they are never pooled into the headline number.

- Confusion matrix `matrix[human][model]` over the status vocabulary, including statuses only the model used, so a systematic over-call is visible.
- Per-label precision, recall, F1, support, predicted count and `meets_minimum`. A label with no predicted and no actual instance gets `f1 = 0.0` rather than a division error; a class seen fewer than `min_holdout_per_class` times reports its support with `meets_minimum: false`.
- `value_agreement`: exact and relative-tolerance agreement (1e-6) for numeric variables, so a rounding difference is not counted as a miss.
- `multi_label`: mean Jaccard over reason-code sets, with per-label support.
- `holdout_support` counts human instances per family; `deficient_classes` names the classes below the minimum, and those block `holdout_evaluated` for status and reason labels.

## Chance-corrected agreement is human–human

Cohen's κ and nominal Krippendorff's α compare **two annotators across the records both of them coded**, not the model against a human. `coders_compared` states how many annotators entered the calculation and is `0` when only one annotator exists — a single coder has no agreement to correct, and the field reports `null` instead of a number. Anchoring κ on the model would turn a validation statistic into a restatement of the model.

## Adjudication

Disagreements are data. `human-adjudicate` appends a human decision with `record_key`, `final_status`, `adjudicator_id` and a reason of at least fifteen characters; the log is append-only and never overwritten by the model's answer. A disagreement is not resolved by re-running the model.

## Commands

```bash
python "$S/scripts/research.py" human-blind      --work "$W" --output /outputs/model_predictions.csv
python "$S/scripts/research.py" human-template   --work "$W" --output /outputs/annotation.csv --split holdout
python "$S/scripts/research.py" human-evaluate   --work "$W" --human /input/annotation.csv --predictions /outputs/model_predictions.csv --experiment main
python "$S/scripts/research.py" human-adjudicate --work "$W" --file /input/adjudication.csv
python "$S/scripts/research.py" human-status     --work "$W"
```

A genuinely new held-out claim — a new codebook version, a new sample — needs a new `--experiment` id. Each evaluation is appended to `work/measurement/human_evaluations.jsonl` with its payload digests, so the sequence of held-out claims is auditable rather than overwritten.

## What is never claimed

Accuracy on records that were never annotated; the reliability of the model self-review pass; any interval for a class below the minimum support; that status agreement implies reason-label agreement. Because `human_validation` is a non-blocking contract, a workspace without annotation still collects and exports — it reports `not_executed` and withholds every reliability claim.
