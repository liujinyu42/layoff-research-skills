# Market document contracts, entity registry and year comparability

Three separate things keep a company-year honest: which documents that market normally publishes, which legal entity the row is about, and whether two years may be divided at all. They share one file in `assets/market_routes.json` and one registry under `work/registry/`.

## Market document contracts

`market_routes.json` ships ten contracts: `SEC_EDGAR`, `HKEX`, `LSE_RNS`, `ASX`, `KRX_DART`, `XETRA_FWB`, `CNINFO`, `EDINET`, `SEDAR`, `GENERIC_ISSUER`. Each states its required document roles, supporting roles, document types, portals, identity checks, fiscal-year quirks and adapter (`native` or import). A contract is a checklist for a registered source set, not a scraper: nothing here fetches anything.

```bash
python "$S/scripts/research.py" routes-check --work "$W"
```

The check runs at **company × fiscal year** grain. A FY2024 annual report does not satisfy FY2022, so each requested year is reported on its own terms: `per_year[fy]` names the roles that year has and the ones it lacks, `missing_years` lists the years that fail, and a company is satisfied only when every requested year is. A company-level "has an annual report" check would let a well-documented 2024 hide an undocumented 2022.

Two smaller fields close the same hole. A ready source with no `fy` cannot satisfy any year, so it appears in `sources_without_fiscal_year` (`source_fiscal_year_unknown` in the gate) rather than counting as coverage. And `company_years_requested` versus `company_years_satisfied` in the summary states the denominator explicitly.

The check also reports which identity facts are unverified. It reports the *document* contract, never the quality of the numbers inside a document. A generic issuer route exists for private companies and unlisted registrants; it is not a downgrade, it just has fewer statutory roles.

Fiscal-year quirks are part of the contract on purpose. A 52/53-week year, a fiscal year ending in June, or a change of year end makes a naive "same year" match wrong, so `target_fy_basis` is recorded rather than assumed.

## Entity registry

A `company_id` is a stable key, not an identity. `registry-init` seeds one unverified entry per roster company; `registry-verify` adds a name with `name_type` (`legal`, `brand`, `subsidiary`, `parent`, `trading`, `former`), a validity window, a country, a registration id and an optional parent — each backed by a ready source and a unique verbatim span of at least ten characters.

```bash
python "$S/scripts/research.py" registry-init   --work "$W"
python "$S/scripts/research.py" registry-verify --work "$W" --file /input/entity_registry.csv
python "$S/scripts/research.py" registry-check  --work "$W"
```

`registry-check` reports parent chains that contain a cycle, overlapping validity windows for the same name and type, a parent outside the requested roster, and any entry still unverified. Overlapping windows matter: if a brand and a legal name were both valid in the same year, a row cannot be attributed by name alone. The boundary is explicit — this records a name and a source, it is not a corporate-tree audit.

Copy `assets/entity_registry_template.csv`; pairing across the two tables requires a shared verified identity or an explicit parent relationship.

## Year-to-year comparability

```bash
python "$S/scripts/research.py" comparability-import  --work "$W" --file /input/comparability.csv
python "$S/scripts/research.py" comparability-compare --work "$W" --company C001 --fy-left 2022 --fy-right 2024
```

Each record states `period_start`, `period_end`, `currency`, `consolidation_scope` (`consolidated`, `parent_only`, `segment`, `unknown`) and `restatement_version`. Import rejects a period outside 300–400 days, a missing ISO currency and an unknown scope. `comparability-compare` returns `comparable: false` with named reasons — `currency_changed`, `period_length_differs`, `consolidation_scope_changed`, `restatement_version_differs` — instead of a ratio.

A growth rate across incomparable periods is not a measurement. Keep both levels and state the break; do not annualise, convert or silently pick the restated series.

## What is never claimed

That a market contract guarantees a document exists for a given company-year; that a verified name proves the corporate tree; that a later restatement supersedes the original for every purpose. Missing documents and unverified identity are reported as gaps, not filled.
