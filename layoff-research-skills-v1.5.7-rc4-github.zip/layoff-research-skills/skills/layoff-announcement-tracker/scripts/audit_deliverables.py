"""Read-only validation of the actual delivery grain. Does not certify semantic truth."""
import argparse,json,sys
from pathlib import Path

def check(path, expected_rows=None):
    base=Path(__file__).resolve().parents[1]
    schema_path=next(base.glob('assets/*_schema.json'))
    schema=json.loads(schema_path.read_text())
    sys.path.insert(0,str(base))
    from researchcore.delivery_quality import grain_check
    return grain_check(path,schema,expected_rows)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('file');p.add_argument('--expected-rows',type=int);a=p.parse_args()
    r=check(a.file,a.expected_rows);print(json.dumps(r));sys.exit(0 if r['pass_check'] else 1)
