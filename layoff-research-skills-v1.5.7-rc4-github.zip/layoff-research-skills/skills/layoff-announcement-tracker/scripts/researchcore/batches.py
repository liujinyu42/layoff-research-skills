"""Bounded host-model reading queue, including explicit supplemental-source tasks."""
from collections import Counter
from pathlib import Path


def next_batch(skill, work, limit=10, entity=None, topic=None):
    from .workflow import check_decisions, selected_fields, save, load
    if not 1 <= limit <= 30:
        raise ValueError('Batch limit must be between 1 and 30')
    accepted, errors, (cfg, sources, book, entities, tasks) = check_decisions(skill, work, verify_content=False)
    fields = {f['id']: f for f in selected_fields(book, cfg)}
    pending = [t for t in tasks if t['entity_id'] + '|' + t['variable'] not in accepted
               or accepted[t['entity_id'] + '|' + t['variable']]['status'] == 'unresolved']
    matched = [t for t in pending if (not entity or t['entity_id'] == entity) and (not topic or t['topic'] == topic)]
    # Prefer unsubmitted tasks before retrying unchanged unresolved findings.
    matched.sort(key=lambda t: (t['entity_id'] + '|' + t['variable'] in accepted, t['entity_id'], t['topic']))
    selected = []
    if matched:
        first = matched[0]
        selected = [t for t in matched if t['entity_id'] == first['entity_id'] and t['topic'] == first['topic']][:limit]
    ids = sorted({sid for t in selected for sid in t['source_ids']})
    definitions = []
    supplements = []
    for t in selected:
        field = fields[t['variable']]
        from .semantic_hints import hints_for
        leads=[hint for sid in t['source_ids']for hint in hints_for(work,sources[sid],t['variable'])]
        definitions.append({**t, 'type': field['type'], 'unit': field.get('unit'),
                            'coding_definition': field.get('coding_definition', field.get('definition', {})), 'counterevidence_to_inspect':leads})
        if not any(sources[sid].get('status') == 'ready' for sid in t['source_ids']):
            supplements.append({'entity_id': t['entity_id'], 'variable': t['variable'],
                                'needed_roles': t['source_roles'], 'reason': 'No ready applicable source',
                                'action': 'Discover official/reference source, register complete current manifest, sync, then retry; never fill 0'})
    candidates = load(Path(work) / 'review/sec-candidates.json', {}).get('rows', [])
    selected_keys = {(t['company_id'], str(t.get('fy')), t['variable'].removesuffix('_disclosed')) for t in selected}
    roster = {r['company_id']: r for r in cfg['roster']}
    cik_to_id = {r.get('cik'): cid for cid, r in roster.items() if r.get('cik')}
    matching_candidates = []
    matching_issues = []
    for c in candidates:
        cid = c.get('company_id') or cik_to_id.get(str(c.get('cik', '')).zfill(10))
        var = c.get('variable') or c.get('var_id')
        if (cid, str(c.get('fy')), var) in selected_keys:
            # Keep enough locator context, never dump the whole candidate ledger.
            item = {k: v for k, v in c.items() if k not in {'evidence_json', 'field_status_json'}}
            for key in ['quote', 'evidence', 'text', 'value']:
                if isinstance(item.get(key), str) and len(item[key]) > 2400:
                    item[key] = item[key][:2400] + ' [candidate preview only; read original]'
            matching_candidates.append(item)
    for issue in load(Path(work) / 'review/sec-candidates.json', {}).get('issues', []):
        cid = issue.get('company_id') or cik_to_id.get(str(issue.get('cik', '')).zfill(10))
        var = issue.get('variable') or issue.get('var_id')
        if (cid, str(issue.get('fy')), var) in selected_keys:
            matching_issues.append(issue)
    report = {'status': 'REPAIR_INVALID_DECISIONS' if errors else 'BATCH_READY' if selected else 'NO_MATCHING_TASKS' if pending else 'FIRST_PASS_DONE',
              'profile': cfg.get('profile'), 'pending_total': len(pending), 'invalid_decisions': len(errors), 'errors': errors[:10],
              'validation_level': 'Queue metadata bindings; read/audit validate original bytes. Queue readiness is not a factual verification.',
              'selected_entity': selected[0]['entity_id'] if selected else None,
              'selected_topic': selected[0]['topic'] if selected else None,
              'fields': definitions, 'sources': [{k: sources[sid].get(k) for k in
                  ['source_id', 'document_role', 'fy', 'form', 'status', 'text_sha256', 'n_chars', 'text_path', 'publication_date']}
                  for sid in ids], 'candidate_previews': matching_candidates[:30], 'candidate_warnings': matching_issues[:10], 'supplement_tasks': supplements,
              'next': 'Read applicable original sources; submit actual judgments with apply; repeat next. Unchanged unresolved tasks require a new source or a specific reported blocker.' if selected else 'prepare-second, actual semantic review, apply-second, audit, export; pending tasks may remain when filtered'}
    save(Path(work) / 'review/next-batch.json', report)
    return report


def supplement_tasks(tasks, sources, accepted):
    result = []
    seen = set()
    for task in tasks:
        key = task['entity_id'] + '|' + task['variable']
        decision = accepted.get(key, {})
        ready = any(sources[sid].get('status') == 'ready' for sid in task['source_ids'])
        if ready and decision.get('status') != 'unresolved':
            continue
        group = (task['entity_id'], tuple(task['source_roles']), decision.get('missing_reason', 'source_not_ready'))
        if group in seen:
            continue
        seen.add(group)
        result.append({'entity_id': task['entity_id'], 'needed_roles': task['source_roles'],
                       'reason': group[2], 'example_variable': task['variable'],
                       'action': 'Find and register an applicable source or document the specific external blocker; re-run prepare'})
    return result


def next_second_batch(skill, work, limit=10, entity=None, topic=None):
    from .workflow import second_tasks, load, schema, save
    if not 1 <= limit <= 30:
        raise ValueError('Batch limit must be between 1 and 30')
    second_tasks(skill, work)
    pending = load(Path(work) / 'review/second-tasks.json', [])
    fields = {f['id']: f for f in schema(skill)['fields']}
    matched = [t for t in pending if (not entity or t['entity_id'] == entity)
               and (not topic or fields[t['variable']].get('topic', 'general') == topic)]
    selected = []
    if matched:
        first = matched[0]
        group = fields[first['variable']].get('topic', 'general')
        selected = [{**t, 'coding_definition': fields[t['variable']].get('coding_definition', {})}
                    for t in matched if t['entity_id'] == first['entity_id']
                    and fields[t['variable']].get('topic', 'general') == group][:limit]
    result = {'status': 'REVIEW_BATCH_READY' if selected else 'NO_MATCHING_REVIEWS' if pending else 'NO_PENDING_REVIEWS',
              'remaining_reviews': len(pending), 'reviews': selected,
              'next': 'Actually reread source context and fill specific checks; apply-second; repeat. First-pass pending fields must also be resolved before COMPLETE.'}
    save(Path(work) / 'review/next-second-batch.json', result)
    return result
