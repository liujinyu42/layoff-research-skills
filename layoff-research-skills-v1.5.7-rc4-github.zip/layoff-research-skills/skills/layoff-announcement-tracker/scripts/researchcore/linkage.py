"""Evidence-level pre-event matching between the two proposal tables.

A fiscal year is a label, not a timestamp, and a company-year is not an evidence unit. The
same FY2023 filing set can hold an annual report published in February and an AI exhibit
published in April; a March announcement may use the first and not the second. This module
therefore classifies **each cited source inside each decision**, then rolls the units up. It
never aggregates to the year first and filters afterwards, which is how a late document used
to borrow an early document's eligibility.
"""
from __future__ import annotations

import csv
import datetime
import io
import json
from pathlib import Path

from . import contracts

ALGORITHM = 'evidence-level-v3'


def load(skill):
    payload = contracts.asset(skill, 'linkage')
    states = payload.get('states') or {}
    for required in ('pre_event_public', 'retrospective', 'undetermined'):
        if required not in states:
            raise ValueError('Linkage contract needs a ' + required + ' state')
    if not isinstance(payload.get('default_window_years'), int) or payload['default_window_years'] < 1:
        raise ValueError('Linkage contract needs a positive default_window_years')
    return payload


def _qualifies(contract, state):
    """Read the contract's own flag for a state. Never compare a name with a boolean."""
    entry = (contract.get('states') or {}).get(state) or {}
    return entry.get('enters_primary_measure') is True


def classify(contract, event_date, publication_date, information_as_of):
    """Return (state, basis) for one evidence unit. Every branch names why it decided.

    ``information_as_of`` is the end of the period the cited document reports on. A document
    published in time but describing a period that ends after the event is still retrospective.
    Same-day ordering cannot be established from dates alone, so it is undetermined unless the
    contract declares another convention. Dates may be ISO strings or ``datetime.date``.
    """
    event_date = event_date if isinstance(event_date, datetime.date) else contracts.iso_date(event_date)
    publication_date = (publication_date if isinstance(publication_date, datetime.date)
                        else contracts.iso_date(publication_date))
    information_as_of = (information_as_of if isinstance(information_as_of, datetime.date)
                         else contracts.iso_date(information_as_of))
    if not event_date:
        return 'undetermined', 'event_date_missing'
    if not publication_date:
        return 'undetermined', 'publication_date_missing'
    if not information_as_of:
        return 'undetermined', 'information_period_missing'
    if information_as_of > event_date:
        return 'retrospective', 'information_period_after_event'
    if publication_date > event_date:
        return 'retrospective', 'published_after_event'
    if publication_date == event_date:
        policy = str(contract.get('same_day_policy') or 'undetermined')
        if policy == 'pre_event_public':
            return 'pre_event_public', 'same_day_declared_pre_event'
        return 'undetermined', 'same_day_no_intraday_order'
    return 'pre_event_public', 'published_and_period_before_event'


def _read_workspace(path):
    path = Path(path)
    cfg = contracts.read_json(path / 'config.json')
    if not cfg:
        raise ValueError('Peer workspace has no config.json: ' + str(path))
    return {'path': path, 'cfg': cfg,
            'decisions': contracts.read_json(path / 'decisions.json', {}) or {},
            'entities': contracts.read_json(path / 'entities.json', {}) or {},
            'sources': (contracts.read_json(path / 'sources.json', {}) or {}).get('sources', [])}


def _date(value):
    return contracts.iso_date(value)


def event_dates(space):
    """Announcement date per plan, from the events workspace's own decisions."""
    dates = {}
    for key, decision in space['decisions'].items():
        plan, _, variable = key.partition('|')
        if variable == 'announcement_date' and decision.get('status') == 'observed':
            dates[plan] = _date(decision.get('value'))
    for plan, entity in space['entities'].items():
        dates.setdefault(plan, None)
    return dates


def _source_index(space):
    index = {}
    for source in space['sources']:
        if source.get('status') != 'ready' or not source.get('active', True):
            continue
        index[source['source_id']] = source
    return index


def evidence_units(space, contract, event_date, plan, company, window):
    """One unit per (variable, cited source). No year-level date is ever substituted."""
    sources = _source_index(space)
    units = []
    for key, decision in sorted(space['decisions'].items()):
        entity, _, variable = key.partition('|')
        entity_company, _, fy = entity.partition(':')
        if entity_company != company or not fy.isdigit():
            continue
        if decision.get('status') != 'observed':
            continue
        if event_date and int(fy) < int(str(event_date)[:4]) - window:
            continue
        period = _date(decision.get('period_end')) or _date(decision.get('information_as_of'))
        cited = []
        for item in decision.get('evidence') or []:
            source_id = item.get('source_id')
            if source_id and source_id not in cited:
                cited.append(source_id)
        if not cited:
            units.append(_unit(plan, company, int(fy), variable, None, None, period, None,
                               event_date, 'undetermined', 'no_cited_source'))
            continue
        for source_id in cited:
            source = sources.get(source_id)
            if source is None:
                # A cited source that is not ready cannot establish public availability.
                units.append(_unit(plan, company, int(fy), variable, source_id, None, period, None,
                                   event_date, 'undetermined', 'cited_source_not_ready'))
                continue
            published = _date(source.get('publication_date')) or _date(source.get('source_date'))
            state, basis = classify(contract, event_date, published, period)
            units.append(_unit(plan, company, int(fy), variable, source_id, published, period,
                               source.get('document_role'), event_date, state, basis))
    return units


def _unit(plan, company, fy, variable, source_id, published, period, role, event_date, state, basis):
    return {'company_id': company, 'plan_id': plan, 'event_date': event_date,
            'entity_id': f'{company}:{fy}', 'fy': fy, 'variable': variable,
            'source_id': source_id, 'document_role': role,
            'publication_date': published.isoformat() if published else None,
            'information_as_of': period.isoformat() if period else None,
            'fact_period_end': period.isoformat() if period else None,
            'state': state, 'basis': basis}


def _rollup(units, contract):
    """Entity-year summary, used for reporting only. Never the join key for capability."""
    years = {}
    for unit in units:
        row = years.setdefault((unit['plan_id'], unit['company_id'], unit['fy']), {
            'company_id': unit['company_id'], 'plan_id': unit['plan_id'],
            'event_date': unit['event_date'], 'entity_id': unit['entity_id'], 'fy': unit['fy'],
            'variables': [], 'states': {}, 'source_ids': set()})
        row['variables'].append(unit['variable'])
        row['states'].setdefault(unit['variable'], []).append(unit['state'])
        if unit['source_id']:
            row['source_ids'].add(unit['source_id'])
        row['publication_date'] = max(filter(None, [row.get('publication_date'), unit['publication_date']]),
                                      default=None)
    rows = []
    order = {'retrospective': 2, 'undetermined': 1, 'pre_event_public': 0}
    for (plan, company, fy), row in sorted(years.items()):
        states = {v: max(values, key=lambda x: order.get(x, 1)) for v, values in row['states'].items()}
        worst = max(states.values(), key=lambda state: order.get(state, 1))
        qualified = {variable for variable, state in states.items() if state == 'pre_event_public'}
        contaminated = {variable for variable, state in states.items() if state != 'pre_event_public'}
        rows.append({'company_id': company, 'plan_id': row['plan_id'], 'event_date': row['event_date'],
                     'entity_id': row['entity_id'], 'fy': fy,
                     'publication_date': row.get('publication_date'),
                     'information_as_of': max((u['information_as_of'] for u in units
                                               if u['entity_id'] == row['entity_id'] and u['plan_id'] == plan
                                               and u['information_as_of']), default=None),
                     'fy_relation': 'pre_event_fiscal_year'
                     if row['event_date'] and fy <= int(str(row['event_date'])[:4])
                     else 'post_event_fiscal_year',
                     'state': worst,
                     'enters_primary_measure': bool(qualified) and not contaminated,
                     'pre_event_variables': sorted(qualified),
                     'contaminated_variables': sorted(contaminated),
                     'source_ids': sorted(row['source_ids'])})
    return rows


def build(skill, work, peer_work, book_version, window_years=None):
    contract = load(skill)
    own = _read_workspace(work)
    peer = _read_workspace(peer_work)
    own_mode, peer_mode = own['cfg'].get('mode'), peer['cfg'].get('mode')
    if own_mode == peer_mode:
        raise ValueError('Linkage pairs an events workspace with a filings workspace; both are ' + str(own_mode))
    window = int(window_years or contract['default_window_years'])
    if window < 1:
        raise ValueError('window_years must be positive')
    events, filings = (own, peer) if own_mode == 'events' else (peer, own)
    dates = event_dates(events)
    companies = {row['company_id'] for row in events['cfg'].get('roster', [])}

    units = []
    for plan in sorted(dates):
        event = dates[plan]
        event_text = event.isoformat() if event else None
        plan_company = (events['entities'].get(plan) or {}).get('company_id')
        if not plan_company:
            plan_company = plan.split('|')[0] if '|' in plan else plan
        if plan_company not in companies:
            continue
        units.extend(evidence_units(filings, contract, event_text, plan, plan_company, window))
    if not units:
        raise ValueError('No decision in the paired workspace cites an observable source for these companies; '
                         'linkage needs at least one observed annual decision')

    rows = _rollup(units, contract)
    summary = {'pairs': len(rows), 'units': len(units),
               'pre_event_public': sum(1 for row in rows if row['state'] == 'pre_event_public'),
               'retrospective': sum(1 for row in rows if row['state'] == 'retrospective'),
               'undetermined': sum(1 for row in rows if row['state'] == 'undetermined'),
               'pre_event_units': sum(1 for unit in units if unit['state'] == 'pre_event_public'),
               'retrospective_units': sum(1 for unit in units if unit['state'] == 'retrospective'),
               'undetermined_units': sum(1 for unit in units if unit['state'] == 'undetermined'),
               'entities_entering_primary_measure': sum(1 for row in rows if row['enters_primary_measure']),
               'events': len({row['plan_id'] for row in rows}),
               'by_basis': _count(units, 'basis')}
    payload = {'rows': rows, 'units': units, 'summary': summary,
               'peer_workspace': str(Path(peer_work).resolve()),
               'window_years': window, 'events_workspace': str(events['path'].resolve()),
               'filings_workspace': str(filings['path'].resolve()),
               'grain': 'rows: one per event x company-year; units: one per variable x cited source',
               'same_day_policy': contract.get('same_day_policy', 'undetermined'),
               'anchor': contract['anchor'], 'caveat': contract['caveat']}
    contracts.record(work, 'linkage', payload, skill, book_version,
                     dependencies=contracts.fingerprint(work, peer_work))
    return {'pass': True, **summary, 'window_years': window,
            'output': str(contracts.sidecar(work, 'linkage'))}


def _count(rows, key):
    result = {}
    for row in rows:
        result[row[key]] = result.get(row[key], 0) + 1
    return dict(sorted(result.items()))


def _typed_index(capability_records):
    """(entity_id, source_id) -> typed technology records cited from that document."""
    index = {}
    for record in capability_records or []:
        index.setdefault((record['entity_id'], record.get('source_id'), record.get('variable')), []).append(record)
    return index


def pre_event_rows(skill, work, book_version, capability=None):
    """Pre-event units, joined to typed evidence **unit by unit**.

    The join key is (entity, source_id), not the entity-year. A capability attested only in a
    document published after the event therefore cannot enter the pre-event measure, even when
    another document for the same fiscal year was published before it.
    """
    payload = contracts.require_record(skill, work, 'linkage', book_version)
    typed = _typed_index((capability or {}).get('records'))
    rows = []
    for unit in payload.get('units', []):
        if unit['state'] != 'pre_event_public':
            continue
        matches = typed.get((unit['entity_id'], unit['source_id'], unit['variable']), [])
        item = dict(unit)
        item['has_ai_capability'] = any(r['technology_class_is_ai'] and r['counts_as_capability']
                                        for r in matches) if matches else None
        item['has_generative_capability'] = any(r['technology_class'] == 'generative_ai'
                                                and r['counts_as_capability'] for r in matches) if matches else None
        item['capability_units'] = len({r.get('project_id') or r.get('quote_sha256') for r in matches if r['counts_as_capability']}) if matches else None
        item['typed_evidence_in_cited_document'] = len(matches)
        rows.append(item)
    return payload, rows


def export_csv(skill, work, path, book_version, capability=None):
    payload, rows = pre_event_rows(skill, work, book_version, capability)
    path = Path(path)
    contracts.mkdir(path.parent)
    fields = ['plan_id', 'company_id', 'event_date', 'fy', 'entity_id', 'variable', 'source_id',
              'document_role', 'publication_date', 'information_as_of', 'has_ai_capability',
              'has_generative_capability', 'capability_units', 'typed_evidence_in_cited_document']
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fields, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)
    path.write_text(buffer.getvalue(), encoding='utf-8')
    return {'output': str(path), 'rows': len(rows), 'all_pairs': payload['summary']['pairs'],
            'all_units': payload['summary']['units'],
            'excluded_retrospective': payload['summary']['retrospective'],
            'excluded_undetermined': payload['summary']['undetermined'],
            'grain': 'one row per variable x cited source that was public before the event'}


def gate(skill, work, cfg, book_version):
    """Conditional contract: absent pairing is reported by readiness, not treated as an error."""
    if 'linkage' not in contracts.active(skill, cfg):
        return [], []
    try:
        payload = contracts.require_record(skill, work, 'linkage', book_version)
    except (ValueError, OSError) as exc:
        if 'stale_record' in str(exc):
            return [{'contract': 'linkage', 'reason': 'stale_record', 'detail': str(exc),
                     'expects': 'linkage-build rerun against the current paired workspaces'}], []
        return [], []
    if not payload.get('rows'):
        return [{'contract': 'linkage', 'reason': 'no_pairs',
                 'expects': 'a peer workspace with at least one shared company',
                 'claim': 'pre-event capability is measurable'}], []
    return [], []


def status(skill, work, cfg, book_version):
    if 'linkage' not in contracts.active(skill, cfg):
        return {'armed': False}
    try:
        payload = contracts.require_record(skill, work, 'linkage', book_version)
    except (ValueError, OSError) as exc:
        return {'armed': True, 'recorded': False, 'reason': str(exc),
                'next': 'linkage-build --peer-work <the other workspace>'}
    return {'armed': True, 'recorded': True, **payload['summary'], 'window_years': payload['window_years'],
            'grain': payload.get('grain')}
