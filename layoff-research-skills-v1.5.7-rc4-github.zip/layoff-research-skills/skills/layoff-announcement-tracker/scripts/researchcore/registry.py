"""Shared entity registry and year-to-year comparability metadata.

A name key is a placeholder, not an identity. This module records which legal entities a
company_id covers, when each name was valid, and how it relates to parents and
subsidiaries. Comparability records then decide whether two years may be divided at all.
"""
from __future__ import annotations

import datetime
from pathlib import Path

from . import contracts

NAME_TYPES = {'legal', 'brand', 'subsidiary', 'parent', 'trading', 'former'}
SCOPES = {'consolidated', 'parent_only', 'segment', 'unknown'}


def _path(work):
    return Path(work) / 'registry' / 'entities.json'


def _comparability_path(work):
    return Path(work) / 'registry' / 'comparability.json'


def init(skill, work, cfg):
    entries = {}
    for row in cfg['roster']:
        entries[row['company_id']] = {'company_id': row['company_id'],
                                      'display_name': row['company'],
                                      'company_en': row.get('company_en'),
                                      'status': 'unverified',
                                      'names': [{'name': row['company'], 'name_type': 'legal',
                                                 'valid_from': None, 'valid_to': None,
                                                 'verified': False, 'source_id': None}],
                                      'country': row.get('country'), 'registration_id': None,
                                      'parent_company_id': None, 'children': [],
                                      'listing_history': [], 'verification': None}
    payload = {'entries': entries, 'rule': 'A provisional name key is not an identity. Verify before pairing tables.'}
    contracts.write_json(_path(work), payload)
    return {'registry': str(_path(work)), 'entries': len(entries), 'unverified': len(entries),
            'next': 'registry-verify with one row per legal entity, brand or subsidiary'}


def read(work):
    return contracts.read_json(_path(work), {'entries': {}}) or {'entries': {}}


def _date(value, field):
    if value in (None, ''):
        return None
    try:
        return datetime.date.fromisoformat(str(value))
    except ValueError as exc:
        raise ValueError(field + ' must be an ISO date') from exc


def verify(skill, work, path, cfg, sources, get_text):
    registry = read(work)
    entries = registry['entries']
    errors, applied = [], []
    for number, row in enumerate(contracts.parse_rows(path), 1):
        try:
            company = str(row.get('company_id') or '').strip()
            if company not in entries:
                raise ValueError('company_id is not in the roster: ' + (company or '(empty)'))
            name = str(row.get('name') or '').strip()
            if len(name) < 2:
                raise ValueError('a verified name needs at least two characters')
            name_type = str(row.get('name_type') or 'legal').strip()
            if name_type not in NAME_TYPES:
                raise ValueError('name_type must be one of ' + ', '.join(sorted(NAME_TYPES)))
            valid_from = _date(row.get('valid_from'), 'valid_from')
            valid_to = _date(row.get('valid_to'), 'valid_to')
            if valid_from and valid_to and valid_from > valid_to:
                raise ValueError('valid_from is after valid_to')
            source_id = str(row.get('source_id') or '').strip()
            quote = row.get('quote')
            if source_id not in sources or sources[source_id].get('status') != 'ready':
                raise ValueError('verification needs a ready registered source')
            if not isinstance(quote, str) or len(quote.strip()) < 10:
                raise ValueError('verification needs a verbatim span of at least ten characters')
            text = get_text(source_id)
            if text.count(quote) != 1:
                raise ValueError('verification span is missing or ambiguous; supply a unique quotation')
            parent = str(row.get('parent_company_id') or '').strip() or None
            if parent and parent not in entries:
                raise ValueError('parent_company_id is not in the roster: ' + parent)
            if parent == company:
                raise ValueError('a company cannot be its own parent')
            entry = entries[company]
            entry['names'] = [item for item in entry['names']
                              if not (item['name'] == name and item['name_type'] == name_type
                                      and item.get('valid_from') == (valid_from.isoformat() if valid_from else None)
                                      and item.get('valid_to') == (valid_to.isoformat() if valid_to else None))]
            entry['names'].append({'name': name, 'name_type': name_type,
                                   'valid_from': valid_from.isoformat() if valid_from else None,
                                   'valid_to': valid_to.isoformat() if valid_to else None,
                                   'verified': True, 'source_id': source_id,
                                   'quote_sha256': contracts.digest({'q': quote})})
            for key in ('country', 'registration_id'):
                if row.get(key):
                    entry[key] = str(row[key]).strip()
            if parent:
                entry['parent_company_id'] = parent
            entry['status'] = 'verified'
            entry['verification'] = {'source_id': source_id, 'verified_at': contracts.now(),
                                     'reviewer_kind': row.get('reviewer_kind') or 'model',
                                     'reviewer_id': row.get('reviewer_id')}
            applied.append({'company_id': company, 'name': name, 'name_type': name_type})
        except (ValueError, KeyError, TypeError, OSError) as exc:
            errors.append({'row': number, 'company_id': row.get('company_id'), 'error': str(exc)})
    report = {'pass': not errors, 'errors': errors, 'verified_names': len(applied)}
    if errors:
        return report
    contracts.write_json(_path(work), registry)
    return report


def check(skill, work, cfg):
    registry = read(work)
    entries = registry.get('entries', {})
    errors, warnings = [], []
    roster = {row['company_id'] for row in cfg['roster']}
    for company, entry in entries.items():
        parent = entry.get('parent_company_id')
        seen, cursor = set(), company
        while cursor:
            if cursor in seen:
                errors.append({'company_id': company, 'error': 'parent chain contains a cycle'})
                break
            seen.add(cursor)
            cursor = (entries.get(cursor) or {}).get('parent_company_id')
        if parent and parent not in roster:
            warnings.append({'company_id': company,
                             'warning': 'parent is outside the requested roster; cross-table pairing needs it'})
        spans = {}
        for item in entry.get('names', []):
            if not item.get('verified'):
                continue
            key = (item['name'].casefold(), item['name_type'])
            spans.setdefault(key, []).append((item.get('valid_from'), item.get('valid_to')))
        for key, windows in spans.items():
            ordered = sorted(windows, key=lambda window: window[0] or '')
            for index in range(1, len(ordered)):
                previous_end, current_start = ordered[index - 1][1], ordered[index][0]
                if previous_end is None or current_start is None or current_start <= previous_end:
                    errors.append({'company_id': company,
                                   'error': 'overlapping validity windows for ' + key[0] + ' (' + key[1] + ')'})
        if entry.get('status') != 'verified':
            warnings.append({'company_id': company, 'warning': 'identity not verified'})
    return {'pass': not errors, 'errors': errors, 'warnings': warnings,
            'verified': sum(1 for entry in entries.values() if entry.get('status') == 'verified'),
            'unverified': sum(1 for entry in entries.values() if entry.get('status') != 'verified'),
            'boundary': 'Verification records a name and a source. It is not a corporate-tree audit.'}


def import_comparability(skill, work, path, cfg):
    rows = contracts.parse_rows(path)
    errors, records = [], {}
    for number, row in enumerate(rows, 1):
        try:
            company = str(row.get('company_id') or '').strip()
            if company not in {item['company_id'] for item in cfg['roster']}:
                raise ValueError('company_id is not in the roster: ' + (company or '(empty)'))
            fy = int(row.get('fy'))
            start = _date(row.get('period_start'), 'period_start')
            end = _date(row.get('period_end'), 'period_end')
            if not start or not end or start >= end:
                raise ValueError('period_start and period_end must be ISO dates with start before end')
            days = (end - start).days + 1
            if not 300 <= days <= 400:
                raise ValueError('an annual period should be 300 to 400 days; ' + str(days) + ' recorded')
            currency = str(row.get('currency') or '').strip().upper()
            if len(currency) != 3 or not currency.isalpha():
                raise ValueError('currency must be an explicit ISO code')
            scope = str(row.get('consolidation_scope') or '').strip()
            if scope not in SCOPES:
                raise ValueError('consolidation_scope must be one of ' + ', '.join(sorted(SCOPES)))
            records[f'{company}:{fy}'] = {'company_id': company, 'fy': fy,
                                          'period_start': start.isoformat(), 'period_end': end.isoformat(),
                                          'period_days': days, 'currency': currency,
                                          'consolidation_scope': scope,
                                          'restatement_version': str(row.get('restatement_version') or 'original').strip(),
                                          'source_id': str(row.get('source_id') or '').strip() or None,
                                          'notes': str(row.get('notes') or '').strip() or None}
        except (ValueError, KeyError, TypeError) as exc:
            errors.append({'row': number, 'company_id': row.get('company_id'), 'error': str(exc)})
    if errors:
        return {'pass': False, 'errors': errors}
    prior = contracts.read_json(_comparability_path(work), {}) or {}
    prior.update(records)
    contracts.write_json(_comparability_path(work), prior)
    return {'pass': True, 'records': len(records), 'total': len(prior),
            'output': str(_comparability_path(work))}


def compare(skill, work, company, fy_left, fy_right):
    records = contracts.read_json(_comparability_path(work), {}) or {}
    left = records.get(f'{company}:{fy_left}')
    right = records.get(f'{company}:{fy_right}')
    if not left or not right:
        missing = [label for label, item in ((f'{company}:{fy_left}', left), (f'{company}:{fy_right}', right)) if not item]
        raise ValueError('No comparability record for ' + ', '.join(missing))
    reasons = []
    if left['currency'] != right['currency']:
        reasons.append({'reason': 'currency_changed', 'left': left['currency'], 'right': right['currency']})
    if abs(left['period_days'] - right['period_days']) > 10:
        reasons.append({'reason': 'period_length_differs', 'left': left['period_days'],
                        'right': right['period_days']})
    if left['consolidation_scope'] != right['consolidation_scope']:
        reasons.append({'reason': 'consolidation_scope_changed', 'left': left['consolidation_scope'],
                        'right': right['consolidation_scope']})
    if left['restatement_version'] != right['restatement_version']:
        reasons.append({'reason': 'restatement_version_differs', 'left': left['restatement_version'],
                        'right': right['restatement_version']})
    return {'company_id': company, 'fy_left': int(fy_left), 'fy_right': int(fy_right),
            'comparable': not reasons, 'reasons': reasons,
            'advice': 'A growth rate across incomparable periods is not a measurement. Keep both levels and '
                      'state the break.' if reasons else 'Periods share currency, length, scope and restatement version.'}
