"""Evidence-bound semantic receipts. These gates check review structure, not truth."""
import hashlib
import json
from pathlib import Path

# Statuses that assert a negative/qualitative finding after a full applicable-source
# review. This set is the single source of truth: the main validator (workflow) and
# this receipt gate must agree, or a renamed status silently drops its receipt duty.
NEGATIVE_STATUSES = frozenset({"reviewed_absent", "not_separate"})

# Legacy receipt vocabulary accepted for old records and normalised to the published
# contract enums below.
_LEGACY_USE_CONTEXT = {"internal": "internal_operations"}
_LEGACY_STAGE = {"deployed": "deployed_internal", "established_use": "deployed_internal"}

# Stages that evidence an actual trial or operating deployment per the published
# adoption_stage vocabulary (tech_evidence_contract.json). planned, retired and
# unknown never establish an operating construct on their own.
_OPERATING_STAGES = frozenset({"pilot", "deployed_internal", "deployed_customer", "deployed_both"})

# Last-resort mirror of the published vocabularies, used only when no
# assets/tech_evidence_contract.json is reachable (both skills ship the same file).
_FALLBACK_CONTRACT_VERSION = "1.2.0"
_FALLBACK_VOCAB = {
    "use_context": ("internal_operations", "customer_product", "both", "unspecified"),
    "adoption_stage": ("planned", "pilot", "deployed_internal", "deployed_customer",
                       "deployed_both", "retired", "unknown"),
}

_contract_cache = None


def _contract_vocab():
    """Vocabularies from the published tech evidence contract; never a self-invented list."""
    global _contract_cache
    if _contract_cache is not None:
        return _contract_cache
    here = Path(__file__).resolve()
    candidates = [here.parents[2] / "assets" / "tech_evidence_contract.json",
                  here.parents[3] / "listed-filing-extractor" / "assets" / "tech_evidence_contract.json"]
    for path in candidates:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        vocab = payload.get("vocabularies") or {}
        use_context = set((vocab.get("use_context") or {}).keys())
        adoption_stage = set((vocab.get("adoption_stage") or {}).keys())
        if use_context and adoption_stage:
            _contract_cache = {"contract_version": payload.get("version"),
                               "use_context": use_context, "adoption_stage": adoption_stage}
            return _contract_cache
    raise RuntimeError("Bundled tech_evidence_contract.json missing or invalid; cannot validate semantic receipts")



def _is_negative(decision, var, fields=None):
    if decision.get("status") in NEGATIVE_STATUSES:
        return True
    if decision.get("status") == "observed" and decision.get("value") == 0:
        field = (fields or {}).get(var)
        if field is not None:
            return field.get("type") == "binary"
        return var.endswith("_disclosed")
    return False


def review_gaps(decisions, texts, fields=None):
    gaps = []
    def gap(position, reason):
        gaps.append(dict(contract="semantic_receipts_v1", position=position, reason=reason))
    vocab = _contract_vocab()
    for position, d in decisions.items():
        var = d.get("variable", position.rsplit("|", 1)[-1])
        value = d.get("value")
        negative = _is_negative(d, var, fields)
        if negative:
            receipt = d.get("negative_review") or {}
            sections = receipt.get("sections") or []
            covered = set()
            for s in sections:
                sid = s.get("source_id"); text = texts.get(sid)
                lo, hi = s.get("start"), s.get("end")
                valid = (text is not None and type(lo) is int and type(hi) is int
                         and 0 <= lo < hi <= len(text) and bool(s.get("section"))
                         and bool(s.get("finding")) and s.get("section_sha256") == hashlib.sha256(text[lo:hi].encode()).hexdigest())
                if valid: covered.add(sid)
                else: gap(position, "Negative review has missing/stale section evidence")
            expected = {s["source_id"] for s in d.get("reviewed_scopes", [])}
            if not expected or not expected.issubset(covered):
                gap(position, "Negative review requires named, hash-bound sections for every applicable source")
            candidates = receipt.get("near_misses")
            if not isinstance(candidates, list) or (not candidates and (not isinstance(receipt.get("no_candidate_basis"), str) or not receipt["no_candidate_basis"].strip())):
                gap(position, "Negative review must explain exclusion of closest candidates or why none exists")
            elif any(not c.get("quote") or not c.get("exclusion_reason") or c.get("quote") not in texts.get(c.get("source_id"), "") for c in candidates):
                gap(position, "Closest-candidate exclusion is unanchored")
        if d.get("status") == "observed" and value is not None and var == "restructuring_charges":
            receipt = d.get("charge_perimeter") or {}
            if not receipt.get("included") or not receipt.get("other_charge_review") or not receipt.get("total_basis"):
                gap(position, "Reconcile charge-table perimeter with adjacent notes and other charges before claiming issuer total")
        if d.get("status") != "observed" or value in (None, 0): continue
        if var in {"ai_integration", "new_tech_adoption"}:
            receipt = d.get("operational_use") or {}
            context = _LEGACY_USE_CONTEXT.get(receipt.get("use_context"), receipt.get("use_context"))
            stage = _LEGACY_STAGE.get(receipt.get("stage"), receipt.get("stage"))
            context_ok = context in vocab["use_context"] and context in {"internal_operations", "both"}
            stage_ok = stage in vocab["adoption_stage"] and stage in {"pilot", "deployed_internal", "deployed_both"}
            process_ok = isinstance(receipt.get("process"), str) and bool(receipt["process"].strip())
            if not (context_ok and stage_ok and process_ok):
                gap(position, "Operational construct needs a stated use context (internal_operations or both), an actual pilot/deployed stage and a concrete process; planned, retired, unknown and unspecified never qualify")
            if not receipt.get("evidence_indices") or any(type(i) is not int or not 0 <= i < len(d.get("evidence", [])) for i in receipt.get("evidence_indices", [])):
                gap(position, "Operational-use receipt must refer to its exact evidence spans")
        if var == "ai_exec_comp":
            receipt = d.get("ai_pay_link") or {}
            if receipt.get("link_type") not in {"dedicated_ai_metric", "mixed_bonus_factor", "ai_retention_award"} or not receipt.get("recipient") or not receipt.get("award_basis"):
                gap(position, "AI pay disclosure needs recipient, award basis and link type; mixed factor can qualify without an AI amount")
    return gaps
