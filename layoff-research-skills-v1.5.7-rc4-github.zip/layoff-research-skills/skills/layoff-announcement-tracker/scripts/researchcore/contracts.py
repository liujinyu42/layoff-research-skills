"""Versioned measurement contracts: assets, sidecars and enforcement levels.

The Excel column contract is frozen at 42 / 43 business fields. Nothing here adds a
column: each contract decides what may be *claimed* from the same cells. A contract is
armed when the skill ships its asset and the workspace was initialised with
``contract_level=strict`` (the default). A workspace without the asset, or one
explicitly initialised as ``baseline``, keeps the earlier behaviour, so historical
workspaces and synthetic test books are never silently re-scoped.

Every sidecar is content-addressed twice: it records the hash of the contract asset it
was produced against, and the hash of its own payload. Editing either invalidates the
record instead of letting a stale claim survive.
"""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path

LEVELS = ('baseline', 'strict')

# asset path -> which skill modes may arm it; sidecar basename under work/measurement.
# blocking=True means COMPLETE requires the sidecar. blocking=False is conditional on an
# external input (a paired workspace or human annotation) and is reported, never invented.
SPECS = {
    'reason_codebook': {'asset': 'assets/reason_codebook.json', 'modes': {'events'},
                        'sidecar': 'reason_codes.json', 'blocking': True,
                        'claim': 'Company-stated reasons are multi-label coded with attribution and per-label evidence.'},
    'tech_evidence': {'asset': 'assets/tech_evidence_contract.json', 'modes': {'filings'},
                      'sidecar': 'tech_evidence.json', 'blocking': True,
                      'claim': 'Generative AI, general AI, automation and cloud are separated with an explicit adoption stage.'},
    'linkage': {'asset': 'assets/linkage_contract.json', 'modes': {'events', 'filings'},
                'sidecar': 'linkage.json', 'blocking': False,
                'claim': 'Only evidence public before the event enters the pre-event capability measure.'},
    'human_validation': {'asset': 'assets/human_validation_contract.json', 'modes': {'events', 'filings'},
                         'sidecar': 'human_validation.json', 'blocking': False,
                         'claim': 'Model coding is compared with blind human annotation on a held-out split.'},
    'search_coverage': {'asset': 'assets/search_coverage_contract.json', 'modes': {'events'},
                        'sidecar': 'search_coverage.json', 'blocking': True,
                        'claim': 'Executed searches and discovered events are recorded as different things.'},
    'missingness': {'asset': 'assets/missingness_contract.json', 'modes': {'filings'},
                    'sidecar': 'missingness.json', 'blocking': True,
                    'claim': 'Review coverage and value availability are reported with separate denominators.'},
    'market_routes': {'asset': 'assets/market_routes.json', 'modes': {'events', 'filings'},
                      'sidecar': 'market_routes.json', 'blocking': True,
                      'claim': 'A company-year satisfies its market document contract or the gap is named.'},
}

REQUIRED_GAPS = {'reason_codebook': 'every registered plan', 'tech_evidence': 'every AI/technology field',
                 'missingness': 'every company-year', 'search_coverage': 'every requested company window',
                 'market_routes': 'every roster company', 'human_validation': 'a declared holdout',
                 'linkage': 'a paired workspace'}


def digest(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat()


def mkdir(path):
    """Create a directory without assuming the filesystem honours exist_ok."""
    path = Path(path)
    try:
        path.mkdir(parents=True, exist_ok=True)
    except FileExistsError:
        if not path.is_dir():
            raise
    return path


def read_json(path, default=None):
    path = Path(path)
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding='utf-8'))


def write_json(path, obj):
    path = Path(path)
    mkdir(path.parent)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def level(cfg):
    value = cfg.get('contract_level', 'strict')
    if value not in LEVELS:
        raise ValueError('Unknown contract_level ' + str(value))
    return value


def spec(name):
    if name not in SPECS:
        raise ValueError('Unknown measurement contract ' + name)
    return SPECS[name]


def asset_path(skill, name):
    return Path(skill) / spec(name)['asset']


def available(skill):
    return {name: asset_path(skill, name) for name in SPECS if asset_path(skill, name).is_file()}


def active(skill, cfg):
    """Contracts enforced for this workspace: armed by the shipped asset and by the level."""
    if level(cfg) == 'baseline':
        return {}
    mode = cfg.get('mode')
    return {name: path for name, path in available(skill).items() if mode in spec(name)['modes']}


def asset(skill, name):
    """Parse a contract asset and verify its own self-declared identity."""
    path = asset_path(skill, name)
    if not path.is_file():
        raise ValueError('This skill does not ship the ' + name + ' contract; run with contract_level=baseline '
                         'or install a skill release that includes assets/' + Path(SPECS[name]['asset']).name)
    payload = read_json(path)
    if payload.get('contract') != name:
        raise ValueError('Contract asset ' + str(path.name) + ' declares ' + str(payload.get('contract')) +
                         ', expected ' + name)
    if not isinstance(payload.get('version'), str) or not payload['version'].strip():
        raise ValueError('Contract asset ' + str(path.name) + ' needs a version')
    return payload


def asset_sha(skill, name):
    return hashlib.sha256(asset_path(skill, name).read_bytes()).hexdigest()


def sidecar(work, name):
    return Path(work) / 'measurement' / spec(name)['sidecar']


# Upstream files a derived record depends on. A sidecar binds the bytes it was computed
# from, so a later edit to a decision, a source or a peer workspace invalidates it. This is
# an integrity and invalidation check, not protection against someone who recomputes.
DEPENDENCY_FILES = ('config.json', 'decisions.json', 'entities.json', 'sources.json')


def _file_sha(path):
    path = Path(path)
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def fingerprint(work, peer=None):
    """Content digest of the upstream facts a sidecar is derived from."""
    work = Path(work)
    parts = {'algorithm': 'layered-v4',
             'workspace': {name: _file_sha(work / name) for name in DEPENDENCY_FILES}}
    if peer is not None:
        peer = Path(peer)
        parts['peer'] = {name: _file_sha(peer / name) for name in DEPENDENCY_FILES}
    return parts


def record(work, name, payload, skill, book_version, dependencies=None):
    """Persist a validated sidecar with its contract, schema and upstream bindings."""
    body = {'contract': name, 'contract_version': asset(skill, name)['version'],
            'contract_sha256': asset_sha(skill, name), 'book_version': book_version,
            'dependencies': dependencies if dependencies is not None else fingerprint(work),
            'generated_at': now(), 'payload': payload}
    body['record_sha256'] = digest(body)
    write_json(sidecar(work, name), body)
    return body


def load_record(work, name, skill=None, book_version=None, expect=None):
    """Return the stored payload, or raise when it is edited, rebound or out of date.

    ``expect`` is the current dependency fingerprint. When it differs from the stored one
    the record is stale: an upstream decision, source or peer workspace changed after the
    sidecar was produced, so the stored conclusion no longer follows from the workspace.
    """
    body = read_json(sidecar(work, name))
    if not body:
        raise ValueError('No ' + name + ' record in this workspace; run the command that produces it')
    stored = body.get('record_sha256')
    unsigned = {key: value for key, value in body.items() if key != 'record_sha256'}
    if stored != digest(unsigned):
        raise ValueError('The ' + name + ' record was modified after it was written')
    if skill is not None and body.get('contract_sha256') != asset_sha(skill, name):
        raise ValueError('The ' + name + ' contract changed since this record was produced; recompute it')
    if book_version is not None and body.get('book_version') != book_version:
        raise ValueError('The ' + name + ' record belongs to schema ' + str(body.get('book_version')) +
                         '; migrate or recompute it')
    if expect is not None and body.get('dependencies') != expect:
        raise stale_error(name, body.get('dependencies'), expect)
    return body['payload']


def stale_error(name, stored, current):
    """Name which dependency moved, so the operator recomputes the right thing."""
    changed = []
    for scope in ('workspace', 'peer'):
        before, after = (stored or {}).get(scope) or {}, (current or {}).get(scope) or {}
        for key in DEPENDENCY_FILES:
            if before.get(key) != after.get(key):
                changed.append(scope + '.' + key)
    if (stored or {}).get('algorithm') != (current or {}).get('algorithm'):
        changed.append('algorithm')
    detail = ', '.join(changed) or 'unspecified dependency'
    return ValueError('stale_record: the ' + name + ' record was computed before ' + detail +
                      ' changed; recompute it instead of reusing the earlier conclusion')


def expected_fingerprint(work, name):
    """Current upstream digest for a sidecar, including its peer workspace when paired."""
    body = read_json(sidecar(work, name), {}) or {}
    peer = (body.get('payload') or {}).get('peer_workspace') if name == 'linkage' else None
    return fingerprint(work, peer if peer else None)


def status(skill, work, cfg, book_version=None):
    """Armed / recorded / stale table. Never turns a missing optional pair into an error."""
    armed = active(skill, cfg)
    rows, gaps = {}, []
    for name in SPECS:
        if name not in armed:
            rows[name] = {'armed': False,
                          'reason': 'contract_level=baseline' if level(cfg) == 'baseline'
                          else 'asset not shipped for mode ' + str(cfg.get('mode'))}
            continue
        item = {'armed': True, 'blocking': spec(name)['blocking'],
                'asset_sha256': hashlib.sha256(armed[name].read_bytes()).hexdigest()}
        try:
            body = read_json(sidecar(work, name))
            if not body:
                item.update(recorded=False, valid=False)
                if spec(name)['blocking']:
                    gaps.append({'contract': name, 'reason': 'not_recorded',
                                 'expects': REQUIRED_GAPS[name], 'claim': spec(name)['claim']})
            else:
                unsigned = {key: value for key, value in body.items() if key != 'record_sha256'}
                fresh = (body.get('record_sha256') == digest(unsigned)
                         and body.get('contract_sha256') == item['asset_sha256']
                         and book_version in (None, body.get('book_version')))
                reason = None if fresh else 'record edited, or produced against a different contract/schema'
                if fresh and names_dependencies(name):
                    current = expected_fingerprint(work, name)
                    if body.get('dependencies') != current:
                        fresh = False
                        reason = str(stale_error(name, body.get('dependencies'), current))
                item.update(recorded=True, valid=fresh, contract_version=body.get('contract_version'),
                            generated_at=body.get('generated_at'), reason=reason)
                if not fresh:
                    gaps.append({'contract': name, 'reason': 'stale_record',
                                 'detail': reason,
                                 'expects': REQUIRED_GAPS[name], 'claim': spec(name)['claim']})
        except (ValueError, OSError) as exc:
            item.update(recorded=True, valid=False, reason=str(exc))
            gaps.append({'contract': name, 'reason': 'unreadable_record',
                         'expects': REQUIRED_GAPS[name], 'claim': spec(name)['claim']})
        rows[name] = item
    return {'level': level(cfg), 'armed': sorted(armed), 'not_armed': sorted(set(SPECS) - set(armed)),
            'contracts': rows, 'gaps': gaps}


# Records whose conclusion is derived from workspace facts and must be invalidated when those
# facts move. Search, missingness and market-route records are bookkeeping over their own
# submission, so they are version-bound but not dependency-bound.
DEPENDENCY_BOUND = {'reason_codebook', 'tech_evidence', 'linkage'}


def names_dependencies(name):
    return name in DEPENDENCY_BOUND


def require_record(skill, work, name, book_version):
    expect = expected_fingerprint(work, name) if names_dependencies(name) else None
    return load_record(work, name, skill, book_version, expect)


def iso_date(value):
    """A real calendar date, or None for a blank. A malformed date is an error, not a blank."""
    text = str(value or '').strip()
    if not text:
        return None
    try:
        return datetime.date.fromisoformat(text)
    except ValueError as exc:
        raise ValueError('Not a valid calendar date: ' + repr(value)) from exc


def parse_rows(path):
    """Read a submission as a JSON array, JSON lines or CSV; empty cells stay unknown."""
    path = Path(path)
    text = path.read_text(encoding='utf-8-sig')
    if path.suffix.lower() == '.csv':
        import csv
        import io
        csv.field_size_limit(max(csv.field_size_limit(), 2**31 - 1))
        return [dict(row) for row in csv.DictReader(io.StringIO(text))]
    rows = None
    if text.strip().startswith(('[', '{')):
        try:
            parsed = json.loads(text)
            rows = parsed if isinstance(parsed, list) else [parsed]
        except json.JSONDecodeError:
            rows = None
    if rows is None:
        rows = []
        for line in text.splitlines():
            if not line.strip():
                continue
            item = json.loads(line)
            rows.extend(item if isinstance(item, list) else [item])
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError('Submission ' + str(path.name) + ' must contain objects')
    return rows


def boolish(value):
    return value is True or (isinstance(value, str) and value.strip().lower() in {'true', 'yes', '1'})


def flag(value):
    """Tri-state flag: True / False / None. Blank cells stay unknown, never a silent 0."""
    if value is None or value == '':
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {'true', 'yes', '1'}:
            return True
        if text in {'false', 'no', '0'}:
            return False
    raise ValueError('Expected an explicit true/false flag, not ' + repr(value))
