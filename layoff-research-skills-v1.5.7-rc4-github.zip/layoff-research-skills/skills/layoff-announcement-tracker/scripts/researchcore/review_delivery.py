"""Export an explicit review queue; never infer absence or overwrite decisions."""
import json
from pathlib import Path

def coverage(decisions):
    grouped = {}
    for key, d in decisions.items():
        var = d.get('variable') or key.rsplit('|', 1)[-1]
        if not var.endswith('_disclosed'):
            continue
        row = grouped.setdefault(var, dict(positive=0, negative=0, unknown=0))
        if d.get('status') == 'observed' and d.get('value') == 1:
            row['positive'] += 1
        elif d.get('status') == 'observed' and d.get('value') == 0:
            row['negative'] += 1
        else:
            row['unknown'] += 1
    for row in grouped.values():
        n = sum(row.values())
        row.update(positions=n, disclosure_lower=row['positive']/n,
                   disclosure_upper=(row['positive']+row['unknown'])/n)
    return grouped

def write_review_bundle(output, decisions, audit, cfg):
    # Include not-yet-submitted tasks in the denominator.
    full = dict(decisions)
    for key in audit.get('pending_positions', []):
        full.setdefault(key, {'status':'not_reviewed'})
    tasks = []
    for kind, positions in (
        ('resolve_field', audit.get('pending_positions', [])),
        ('second_review', audit.get('second_pending_positions', [])),
    ):
        for key in positions:
            decision = full.get(key, {})
            entity, _, variable = key.rpartition('|')
            tasks.append({
                'kind': kind, 'position': key, 'entity': entity, 'variable': variable,
                'source_ids': sorted({e['source_id'] for e in decision.get('evidence', []) if e.get('source_id')}),
                'status': decision.get('status'), 'reason': decision.get('reason'),
                'missing_reason': decision.get('missing_reason'),
                'action': ('Run next-second and apply-second after reading the source.'
                           if kind == 'second_review' else
                           'Resolve against applicable sources and submit a supported decision.'),
            })
    actions = {'reason_codebook': 'reason-apply', 'search_coverage': 'search-log-import then search-coverage',
               'tech_evidence': 'tech-apply', 'missingness': 'missingness-report',
               'market_routes': 'routes-check', 'linkage': 'linkage-build',
               'semantic_receipts_v1': 'Add the required receipt to the cited decisions and re-apply; then re-run audit',
               'evidence_scope': 'Replace oversized quotes/values with focused excerpts and re-apply the decisions'}
    follow_up = [
        {'kind': 'contract', 'action': actions.get(gap.get('contract'), 'next-actions'), 'gap': gap}
        for gap in audit.get('contract_gaps', [])
    ]
    follow_up.extend({'kind': 'source_coverage', 'action': 'Review source coverage and plan boundaries.',
                      'gap': gap} for gap in audit.get('coverage_gaps', []))
    p = Path(output)
    p.with_suffix('.review_queue.json').write_text(json.dumps({
        'runtime_version':'1.5.7-rc4', 'mode':cfg['mode'], 'pending':tasks, 'follow_up':follow_up, 'source_failures':audit.get('source_failures', []),
        'disclosure_bounds':coverage(full), 'contract_gaps':audit.get('contract_gaps', []),
        'boundary':'Bounds describe declared positions, not accuracy. Unknown amounts remain null.'}, indent=2), encoding='utf-8')
    p.with_suffix('.sidecar_index.md').write_text("""# Supporting evidence and review index

The workbook is a fixed-column view, not the entire research dataset.
- `.audit.json`: integrity, completion, runtime/schema versions and workbook SHA-256.
- `.source_evidence.json`: canonical decisions, exact evidence and self-reviews.
- `.review_queue.json`: unfinished positions, contract gaps and disclosure bounds.
- Workspace `measurement/`: reason categories, technology class/stage/use context, missingness and linkage records. Use the bundled reason-export, tech-export and linkage-pre-event commands for readable CSVs when applicable.

Keep the workspace and original sources with this delivery. A source may support multiple constructs; never sum repeated capability counts across variable/source rows. RQ2 local pre-event evidence does not certify a reason-group comparison or causality. Same-model self-review is not independent human reliability.
""", encoding='utf-8')
