"""Company-neutral roster helpers and explicit source-discovery planning.

No company facts or search results are invented here. The invoking agent verifies
identity and finds official URLs before sync; these routes are not exchange APIs.
"""
import hashlib
import re
import unicodedata
from pathlib import Path


def roster_from_names(names):
    result, seen = [], set()
    for name in names:
        label = unicodedata.normalize('NFKC', name).strip()
        key = label.casefold()
        if not label or key in seen:
            raise ValueError('Company names must be nonempty and distinct; disambiguate legal entities explicitly')
        seen.add(key)
        stem = re.sub('[^a-z0-9]+', '-', key).strip('-')[:36] or 'company'
        stable = stem + '-' + hashlib.sha256(key.encode()).hexdigest()[:10]
        result.append({'company_id': stable, 'company': label, 'identity_status': 'needs_verification'})
    return result


def route_for(company):
    market = str(company.get('exchange') or company.get('market') or '').upper()
    if company.get('cik'):
        return 'SEC_EDGAR', 'An explicit CIK is available; verify its legal entity and target years before collection.'
    if market in {'NYSE', 'NASDAQ', 'AMEX', 'NYSE AMERICAN'}:
        return 'resolve_CIK_or_issuer_reports', 'Find the official CIK; lack of a CIK is not lack of disclosures.'
    choices = [
        ({'HKEX', 'SEHK'}, 'HKEX_and_issuer'),
        ({'LSE', 'AIM'}, 'UK_official_disclosures_and_issuer'),
        ({'ASX'}, 'ASX_and_issuer'),
        ({'KRX', 'KOSPI', 'KOSDAQ'}, 'DART_and_issuer'),
        ({'XETRA', 'FWB'}, 'German_official_disclosures_and_issuer'),
        ({'SSE', 'SZSE', 'BSE', 'SHANGHAI', 'SHENZHEN'}, 'China_exchange_CNINFO_and_issuer'),
        ({'TSE', 'JPX'}, 'EDINET_TDnet_and_issuer'),
        ({'TSX', 'TSXV'}, 'SEDAR_and_issuer'),
    ]
    for markets, route in choices:
        if market in markets:
            return route, 'Find official local and issuer reports; retain actual local titles and accounting periods.'
    return 'issuer_and_local_official_sources', 'Use official company reports, financial statements, registries and dated issuer disclosures; listing is not required.'


def source_plan(skill, work):
    from .workflow import load, save, schema, selected_fields
    work = Path(work)
    cfg = load(work / 'config.json')
    fields = selected_fields(schema(Path(skill)), cfg)
    requirements = {}
    for field in fields:
        requirements.setdefault(field.get('topic', 'general'), set()).update(field.get('source_roles', []))
    plans = []
    for company in cfg['roster']:
        route, rationale = route_for(company)
        plans.append({'company_id': company['company_id'], 'company': company['company'],
                      'route': route, 'route_basis': rationale, 'identity_verification_required': True,
                      'unverified_input_hints': {k: company[k] for k in ['website', 'country', 'exchange', 'cik', 'registration_id', 'listing_status'] if company.get(k)},
                      'identity_checks': ['legal entity vs brand/parent/subsidiary', 'country/registry or official website',
                                          'listing history and aliases when applicable'],
                      'years': list(range(cfg['year_start'], cfg['year_end'] + 1)) if cfg['mode'] == 'filings' else None,
                      'event_window': [cfg['event_start'], cfg['event_end']] if cfg['mode'] == 'events' else None,
                      'source_roles_by_topic': {k: sorted(v) for k, v in requirements.items()},
                      'discovery_actions': ['Locate and verify official source URLs or authorized local files.',
                                            'Follow incorporated compensation and financial cross-references.',
                                            'Save search/access limits; sync actual sources and execute the reading/decision batches.']})
    payload = {'version': '1.5.0', 'company_count': len(plans), 'plans': plans,
               'collection_started': False, 'historical_corpus_required': False,
               'availability_policy': 'An unavailable public source remains unresolved/public_not_available. Neither private status nor missing SEC records establishes zero or inapplicability of revenue, HR or AI activity.',
               'capability': 'Planning plus generic HTML/TXT/PDF imports. Host search/browser discovery is required outside the native SEC route; no universal exchange API is claimed.'}
    save(work / 'review/source-plan.json', payload)
    return payload
