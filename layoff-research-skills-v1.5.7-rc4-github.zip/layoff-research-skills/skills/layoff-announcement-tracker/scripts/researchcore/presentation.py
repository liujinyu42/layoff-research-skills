"""English workbook views with separate, unchanged canonical source evidence."""
import copy
import hashlib
import unicodedata
from urllib.parse import quote, urlsplit, urlunsplit


def non_latin_letters(value):
    return isinstance(value,str) and any(unicodedata.category(c).startswith('L') and 'LATIN' not in unicodedata.name(c,'') for c in value)


def check_generated_english(record):
    def visit(value,path=()):
        if isinstance(value,dict):
            for key,item in value.items(): visit(item,path+(key,))
        elif isinstance(value,list):
            for index,item in enumerate(value): visit(item,path+(str(index),))
        elif isinstance(value,str) and path and path[-1] not in {'quote','unit_quote','raw_text','source_url'} and non_latin_letters(value):
            raise ValueError('English generated content required at '+'.'.join(path)+'; preserve native evidence only in canonical source fields')
    visit(record)


def _url_english(url):
    bits=urlsplit(url)
    if not bits.scheme: return quote(url,safe='/:._-')
    return urlunsplit((bits.scheme,bits.netloc.encode('idna').decode(),quote(bits.path,safe='/%:@-._~'),
                       quote(bits.query,safe='=&%/:?@-._~'),quote(bits.fragment,safe='%/-._~')))


def english_evidence_view(record):
    """A translated display is never labeled an exact original-source quotation."""
    from .workflow import digest
    check_generated_english(record)
    out=copy.deepcopy(record)
    original_sha=out.pop('decision_sha256',None)
    if original_sha: out['original_decision_sha256']=original_sha
    translated_source=False
    for evidence in out.get('evidence',[]):
        original=evidence['quote']
        evidence['quote_kind']='verbatim_source'
        declared_language=str(evidence.get('quote_language')or'en').lower()
        if non_latin_letters(original)or declared_language not in {'en','eng','english'}and not declared_language.startswith('en-'):
            translated_source=True
            translated=evidence.get('quote_en')
            if not translated or non_latin_letters(translated) or evidence.get('translation_reviewed')is not True or not evidence.get('translation_reviewer_id'):
                raise ValueError('A reviewed English quote_en translation is required for native source evidence '+evidence['source_id'])
            evidence['quote']=translated
            evidence['quote_kind']='reviewed_English_translation'
            evidence['original_quote_language']=declared_language
            evidence['quote_language']='en'
            evidence['original_quote_sha256']=hashlib.sha256(original.encode()).hexdigest()
            evidence['offset_basis']='char_start/end refer to original source, not translated character positions'
        evidence.pop('quote_en',None)
        if evidence.get('source_url'): evidence['source_url']=_url_english(evidence['source_url'])
    def units(value):
        if isinstance(value,dict):
            if non_latin_letters(value.get('unit_quote'))or translated_source and value.get('unit_quote'):
                translated=value.get('unit_quote_en')
                if not translated or non_latin_letters(translated):raise ValueError('unit_quote_en is required for a native unit header')
                value['original_unit_quote_sha256']=hashlib.sha256(value['unit_quote'].encode()).hexdigest()
                value['unit_quote']=translated
            for key in list(value):
                if key in {'local_path','raw_path','text_path'}:value.pop(key)
                else:units(value[key])
        elif isinstance(value,list):
            for item in value:units(item)
    units(out)
    out['presentation_language']='en'
    out['presentation_record_sha256']=digest(out)
    ensure_english_output(out)
    return out


def ensure_english_output(value):
    if isinstance(value,dict):
        for key,item in value.items():
            if non_latin_letters(key):raise ValueError('Non-English presentation key')
            ensure_english_output(item)
    elif isinstance(value,list):
        for item in value:ensure_english_output(item)
    elif non_latin_letters(value):raise ValueError('Non-English letters in workbook presentation; provide an English display value or reviewed translation')
