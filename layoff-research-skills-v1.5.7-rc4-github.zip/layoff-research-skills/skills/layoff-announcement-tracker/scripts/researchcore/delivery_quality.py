"""Validate the output grain and flag evidence that needs a focused review."""

# plan_relationship values that keep a row inside one canonical plan family.
SAME_PLAN_RELATIONS = {'same_plan_update'}
# Relations that describe the same underlying programme rather than a new plan.
# Folded into canonical grouping only when the workspace sets
# plan_granularity='plan' (default); explicit announcement mode retains notices.
PLAN_LEVEL_RELATIONS = {'implementation_of'}

QUANTITY_FIELDS = (
    'layoff_count', 'layoff_count_lower', 'layoff_count_upper', 'layoff_count_qualifier',
    'layoff_count_basis', 'layoff_percentage', 'layoff_percentage_lower',
    'layoff_percentage_upper', 'layoff_percentage_qualifier',
    'layoff_percentage_denominator', 'numerical_claim_raw',
)

_NUMERIC_QUANTITY_FIELDS = (
    'layoff_count', 'layoff_count_lower', 'layoff_count_upper',
    'layoff_percentage', 'layoff_percentage_lower', 'layoff_percentage_upper',
)

_ONE_SIDED_LOWER = {'more_than', 'at_least'}
_ONE_SIDED_UPPER = {'less_than', 'at_most', 'up_to'}


def plan_groups(entities, decisions, granularity='plan'):
    parents = {}
    issues = []
    folded = set(SAME_PLAN_RELATIONS)
    if granularity == 'plan':
        folded |= PLAN_LEVEL_RELATIONS
    for plan, entity in entities.items():
        relation = decisions.get(f'{plan}|plan_relationship', {}).get('value')
        if relation not in folded:
            continue
        target = decisions.get(f'{plan}|related_plan_id', {}).get('value')
        if target not in entities or entities[target]['company_id'] != entity['company_id']:
            issues.append({'entity_id': plan, 'reason': 'Same-plan link needs a valid target for the same issuer'})
        else:
            parents[plan] = target
    mapping = {}
    for plan in entities:
        seen = set()
        root = plan
        while root in parents and root not in seen:
            seen.add(root)
            root = parents[root]
        if root in seen:
            issues.append({'entity_id': plan, 'reason': 'Cycle in same-plan relationships', 'fatal': True})
        else:
            mapping[plan] = root
    return mapping, issues


def review_gaps(decisions):
    gaps = []
    for position, decision in decisions.items():
        value = decision.get('value')
        quotes = decision.get('evidence', [])
        oversized = (isinstance(value, str) and len(value) > 12000
                     or any(len(item.get('quote', '')) > 12000 for item in quotes))
        if oversized:
            gaps.append({'contract': 'evidence_scope', 'position': position,
                         'reason': 'Review the span and replace it with focused source excerpts'})
    return gaps


def event_measure_gates(entity_id, accepted):
    """Hard structural gates for event quantities. Returns a list of error strings."""
    errors = []
    prefix = entity_id + '|'
    raw = accepted.get(prefix + 'numerical_claim_raw', {})
    if raw.get('status') == 'reviewed_absent' and raw.get('value') not in (None, ''):
        errors.append('reviewed_absent cannot coexist with a preserved numerical_claim_raw value')
    raw_text = raw.get('value') if raw.get('status') == 'observed' else None
    if isinstance(raw_text, str) and raw_text.strip():
        if all(accepted.get(prefix + field, {}).get('status') == 'reviewed_absent'
               for field in _NUMERIC_QUANTITY_FIELDS):
            errors.append('Preserved numerical_claim_raw contradicts reviewed_absent on every numeric quantity field; a definite claim must not be erased')
    for base in ('layoff_count', 'layoff_percentage'):
        point = accepted.get(prefix + base, {}).get('value')
        lo = accepted.get(prefix + base + '_lower', {}).get('value')
        hi = accepted.get(prefix + base + '_upper', {}).get('value')
        if lo is not None and hi is not None and lo > hi:
            errors.append(base + ' reversed bounds')
        qualifier = accepted.get(prefix + base + '_qualifier', {}).get('value')
        one_sided = qualifier in _ONE_SIDED_LOWER or qualifier in _ONE_SIDED_UPPER
        if one_sided and point is not None:
            errors.append(base + ' one-sided threshold must not be stored as a point estimate')
        if qualifier in _ONE_SIDED_LOWER and lo is None:
            errors.append(base + " lower-side qualifier '" + str(qualifier) + "' stores no lower bound; the threshold value is lost")
        if qualifier in _ONE_SIDED_UPPER and hi is None:
            errors.append(base + " upper-side qualifier '" + str(qualifier) + "' stores no upper bound; the threshold value is lost")
        for suffix, bound in (('_lower', lo), ('_upper', hi)):
            if bound is None:
                continue
            if not accepted.get(prefix + base + suffix, {}).get('explicit_bound_basis'):
                errors.append(base + suffix + ' requires explicit bound evidence; a qualifier or approximate point does not establish a bound by itself')
    return errors


def plan_count_by_relation(entities, accepted):
    """Row counts by observed plan relationship; rows are notices, not plans."""
    counts = {}
    for plan in entities:
        relation = accepted.get(plan + '|plan_relationship', {}).get('value')
        key = relation if relation else 'unreviewed'
        counts[key] = counts.get(key, 0) + 1
    return counts


def grain_check(path, book, expected_rows=None):
    """Read-only validation of the actual saved workbook grain; does not certify truth."""
    from openpyxl import load_workbook
    w = load_workbook(path, read_only=True)
    errors = []
    sheet = book.get('worksheet', 'Results')
    if w.sheetnames != [sheet]:
        errors.append('Exactly one worksheet named ' + sheet + ' is required')
    rows = list(w[sheet].values) if sheet in w.sheetnames else []
    headers = list(rows[0]) if rows else []
    required = [x['id'] for x in book['fields']]
    absent = [x for x in required if x not in headers]
    if absent:
        errors.append('Missing bundled variable columns: ' + ', '.join(absent))
    identity = 'plan_id' if book.get('grain') == 'layoff_plan' else 'fy'
    if identity not in headers:
        errors.append('Missing grain identity ' + identity)
    keys = []
    if identity in headers:
        for row in rows[1:]:
            d = dict(zip(headers, row))
            keys.append((d.get('company_id', d.get('company')), d.get(identity)))
        if len(set(keys)) != len(keys):
            errors.append('Duplicate output grain keys')
    if expected_rows is not None and len(rows) - 1 != expected_rows:
        errors.append('Unexpected row count')
    return dict(pass_check=not errors, rows=max(0, len(rows) - 1), errors=errors,
                semantic_truth_certified=False)


def reconciliation_bindings(root, mapping, decisions):
    members = {plan for plan, canonical in mapping.items() if canonical == root}
    return {key: decision.get('decision_sha256')
            for key, decision in sorted(decisions.items())
            if key.rsplit('|', 1)[0] in members and key != root + '|layoff_count_basis'}

def canonical_view(entities, decisions, granularity='plan'):
    from copy import deepcopy
    mapping, issues = plan_groups(entities, decisions, granularity)
    view = deepcopy(decisions)
    for root in sorted(set(mapping.values())):
        updates = [plan for plan, target in mapping.items() if target == root and plan != root]
        if not updates:
            continue
        dated = [(decisions.get(plan + '|announcement_date', {}).get('value'), plan)
                 for plan in [root] + updates]
        dated = [(date, plan) for date, plan in dated if isinstance(date, str)]
        root_date = decisions.get(root + '|announcement_date', {}).get('value')
        if dated and root_date and min(date for date, plan in dated) < root_date:
            issues.append({'entity_id': root, 'reason': 'Canonical root does not preserve the earliest announcement date',
                           'fatal': True})
        record = decisions.get(root + '|layoff_count_basis', {}).get('canonical_update_reconciliation')
        valid = isinstance(record, dict) and bool(record.get('reason'))
        valid = valid and record.get('source_plan_id') in [root] + updates
        valid = valid and record.get('decision_bindings') == reconciliation_bindings(root, mapping, decisions)
        if not valid:
            issues.append({'entity_id': root, 'reason': 'Canonical quantity selection missing or stale',
                           'expected_bindings': reconciliation_bindings(root, mapping, decisions)})
            continue
        selected = record['source_plan_id']
        if selected != root:
            for field in QUANTITY_FIELDS:
                source = decisions.get(selected + '|' + field)
                if source is None:
                    view.pop(root + '|' + field, None)
                else:
                    view[root + '|' + field] = deepcopy(source)
                    view[root + '|' + field]['canonical_source_plan_id'] = selected
    for plan, entity in entities.items():
        key = plan + '|related_plan_id'
        target = view.get(key, {}).get('value')
        if target:
            if target not in mapping or entities[target]['company_id'] != entity['company_id']:
                issues.append({'entity_id': plan, 'reason': 'Related plan is absent or belongs to another issuer'})
            else:
                view[key]['original_related_plan_id'] = target
                view[key]['value'] = mapping[target]
    for key, decision in decisions.items():
        if key.endswith('|plan_relationship') and decision.get('status') == 'observed':
            if decision.get('value') in {'unknown', 'unresolved'}:
                issues.append({'entity_id': key.rsplit('|', 1)[0],
                               'reason': 'Observed plan relationship contains a semantic unknown'})
    return view, mapping, issues
