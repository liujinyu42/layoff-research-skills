"""Missingness accounting with two denominators instead of one misleading percentage.

Review coverage answers "how much of the requested panel was actually examined".
Value availability answers "when it was examined, how often was a value there".
A company that never discloses training cost and a collection that never read the report
both leave an empty cell; only this report separates them.
"""
from __future__ import annotations

import csv
import io
from pathlib import Path

from . import contracts


def load(skill):
    payload = contracts.asset(skill, 'missingness')
    statuses = payload.get('statuses') or []
    if len(statuses) < 5:
        raise ValueError('Missingness contract needs the full status taxonomy')
    codes = [item.get('code') for item in statuses]
    if len(set(codes)) != len(codes) or any(not code for code in codes):
        raise ValueError('Missingness statuses must be unique and non-empty')
    for item in statuses:
        if not isinstance(item.get('reviewed'), bool) or not isinstance(item.get('value_present'), bool):
            raise ValueError('Missingness status ' + str(item.get('code')) +
                             ' needs explicit reviewed and value_present flags')
    return payload


def _ratio(numerator, denominator):
    return round(numerator / denominator, 6) if denominator else None


def compute(contract, accepted, tasks, sources, book):
    """Build the matrix from the submitted decisions and the selected positions."""
    statuses = {item['code']: item for item in contract['statuses']}
    selected = {field['id']: field for field in book['fields']}
    by_variable, by_year = {}, {}
    source_type_counts = {}
    numeric_detail = {}
    totals = {code: 0 for code in statuses}
    positions = 0
    for task in tasks:
        key = task['entity_id'] + '|' + task['variable']
        decision = accepted.get(key)
        status = decision['status'] if decision else 'not_reviewed'
        if status not in statuses:
            status = 'unresolved'
        positions += 1
        totals[status] = totals.get(status, 0) + 1
        year = str(task.get('fy') if task.get('fy') is not None else task['entity_id'].partition(':')[2] or 'event')
        variable = task['variable']
        row = by_variable.setdefault(variable, {code: 0 for code in statuses})
        row[status] += 1
        by_year.setdefault(year, {code: 0 for code in statuses})[status] += 1
        if decision and status == 'observed':
            for evidence in decision.get('evidence', []):
                source = sources.get(evidence.get('source_id'), {})
                kind = source.get('document_role') or source.get('source_type') or 'unspecified'
                source_type_counts[kind] = source_type_counts.get(kind, 0) + 1
            field = selected.get(variable, {})
            if field.get('type') in {'number', 'integer'}:
                detail = numeric_detail.setdefault(variable, {'observed': 0, 'currencies': [],
                                                              'scopes': [], 'with_period_fy': 0})
                detail['observed'] += 1
                if isinstance(decision.get('amount'), dict):
                    currency = decision['amount'].get('currency')
                    if currency and currency not in detail['currencies']:
                        detail['currencies'].append(currency)
                scope = decision.get('measurement_scope')
                if scope and scope not in detail['scopes']:
                    detail['scopes'].append(scope)
                if decision.get('period_fy') is not None:
                    detail['with_period_fy'] += 1
    reviewed = sum(totals[code] for code in statuses if statuses[code]['reviewed'])
    reviewed_with_value = sum(totals[code] for code in statuses if statuses[code]['value_present'])
    not_applicable = totals.get('not_applicable', 0)
    table = {}
    for variable, counts in sorted(by_variable.items()):
        row_reviewed = sum(counts[code] for code in statuses if statuses[code]['reviewed'])
        row_value = sum(counts[code] for code in statuses if statuses[code]['value_present'])
        table[variable] = {**counts,
                           'positions': sum(counts.values()),
                           'review_coverage': _ratio(row_reviewed, sum(counts.values())),
                           'value_availability': _ratio(row_value, max(row_reviewed - counts.get('not_applicable', 0), 0))}
    years = {}
    for year, counts in sorted(by_year.items()):
        year_reviewed = sum(counts[code] for code in statuses if statuses[code]['reviewed'])
        years[year] = {**counts, 'positions': sum(counts.values()),
                       'review_coverage': _ratio(year_reviewed, sum(counts.values()))}
    return {'positions': positions, 'by_status': totals,
            'review_coverage': _ratio(reviewed, positions),
            'value_availability': _ratio(reviewed_with_value, max(reviewed - not_applicable, 0)),
            'by_variable': table, 'by_year': years,
            'observed_evidence_by_source_role': dict(sorted(source_type_counts.items())),
            'numeric_detail': {key: {'observed': value['observed'],
                                     'currencies': sorted(value['currencies']),
                                     'measurement_scopes': sorted(value['scopes']),
                                     'with_period_fy': value['with_period_fy']}
                               for key, value in sorted(numeric_detail.items())},
            'definitions': {item['code']: item['definition'] for item in contract['statuses']},
            'population_note': contract['denominators']['population_note']}


def build(skill, work, accepted, tasks, sources, book, book_version):
    contract = load(skill)
    payload = compute(contract, accepted, tasks, sources, book)
    contracts.record(work, 'missingness', payload, skill, book_version)
    return {'pass': True, 'positions': payload['positions'], 'by_status': payload['by_status'],
            'review_coverage': payload['review_coverage'],
            'value_availability': payload['value_availability'],
            'output': str(contracts.sidecar(work, 'missingness'))}


def gate(skill, work, cfg, book_version, tasks):
    if 'missingness' not in contracts.active(skill, cfg):
        return [], []
    try:
        payload = contracts.require_record(skill, work, 'missingness', book_version)
    except (ValueError, OSError) as exc:
        return [{'contract': 'missingness', 'reason': 'not_recorded', 'detail': str(exc),
                 'expects': 'review coverage and value availability per variable'}], []
    gaps = []
    if payload.get('positions') != len(tasks):
        gaps.append({'contract': 'missingness', 'reason': 'stale_positions',
                     'recorded': payload.get('positions'), 'current': len(tasks),
                     'expects': 'recompute after the last apply'})
    return gaps, []


def export_csv(skill, work, path, book_version):
    payload = contracts.require_record(skill, work, 'missingness', book_version)
    status_codes = sorted({code for row in payload['by_variable'].values() for code in row
                           if code not in {'positions', 'review_coverage', 'value_availability'}})
    path = Path(path)
    contracts.mkdir(path.parent)
    buffer = io.StringIO()
    fields = ['variable'] + status_codes + ['positions', 'review_coverage', 'value_availability']
    writer = csv.DictWriter(buffer, fieldnames=fields, extrasaction='ignore')
    writer.writeheader()
    for variable, row in payload['by_variable'].items():
        writer.writerow({'variable': variable, **row})
    path.write_text(buffer.getvalue(), encoding='utf-8')
    return {'output': str(path), 'rows': len(payload['by_variable']),
            'grain': 'one row per variable with both denominators'}
