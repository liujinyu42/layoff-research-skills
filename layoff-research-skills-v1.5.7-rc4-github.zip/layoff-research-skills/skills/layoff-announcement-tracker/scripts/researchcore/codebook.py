"""Versioned, multi-label coding of company-stated layoff reasons.

`stated_reason_text` keeps the verbatim reason in the Results sheet. This module turns
that cell into a reproducible structured representation in a sidecar: several labels,
each bound to its own quotation, each carrying the attribution the event already
records. Nothing here adds a column, and nothing here decides whether a reason is true.
"""
from __future__ import annotations

import csv
import hashlib
import io
import re
from pathlib import Path

from . import contracts


def _digest(obj):
    return contracts.digest(obj)


def _cue_hit(text, cue):
    """A cue is a reading aid. Require a word start so 'cost' cannot match 'accosted'."""
    if not cue:
        return False
    return re.search(r'(?<![a-z0-9])' + re.escape(cue.lower()), text.lower()) is not None


def validate_book(book):
    """Structural checks on the codebook itself, before any record is accepted."""
    levels = book.get('attribution_levels')
    categories = book.get('categories')
    if not isinstance(levels, list) or len(levels) < 2:
        raise ValueError('Codebook needs declared attribution levels')
    if not isinstance(categories, list) or len(categories) < 3:
        raise ValueError('Codebook needs declared reason categories')
    level_codes = [item.get('code') for item in levels]
    if any(not code for code in level_codes) or len(set(level_codes)) != len(level_codes):
        raise ValueError('Attribution level codes must be unique and non-empty')
    for item in levels:
        if not isinstance(item.get('counts_as_stated_reason'), bool):
            raise ValueError('Attribution level ' + str(item.get('code')) +
                             ' needs an explicit counts_as_stated_reason flag')
    seen = set()
    for item in categories:
        code = item.get('code')
        if not code or code in seen:
            raise ValueError('Reason category codes must be unique and non-empty')
        seen.add(code)
        if not str(item.get('definition', '')).strip():
            raise ValueError('Reason category ' + code + ' needs a definition')
        if not isinstance(item.get('positive_cues', []), list):
            raise ValueError('Reason category ' + code + ' positive_cues must be a list')
        for other in item.get('exclusive_with', []):
            if other != 'all' and other not in {c.get('code') for c in categories}:
                raise ValueError('Reason category ' + code + ' excludes unknown code ' + str(other))
    mapped = {}
    for item in levels:
        for value in item.get('maps_from', []):
            if value in mapped and mapped[value] != item['code']:
                raise ValueError('reason_attribution value ' + value + ' maps to more than one level')
            mapped[value] = item['code']
    return book


def load(skill):
    return validate_book(contracts.asset(skill, 'reason_codebook'))


def category_map(book):
    return {item['code']: item for item in book['categories']}


def level_map(book):
    return {item['code']: item for item in book['attribution_levels']}


def attribution_of(book, value):
    """Derive the level from the event's reason_attribution decision value."""
    for item in book['attribution_levels']:
        if value in item.get('maps_from', []):
            return item
    return None


def _labels_from_row(row):
    """Accept a nested labels list or the flat CSV form with one span shared by all codes."""
    if isinstance(row.get('labels'), list):
        return [dict(item) for item in row['labels']]
    raw = row.get('codes') or row.get('reason_codes') or ''
    if isinstance(raw, list):
        codes = [str(code).strip() for code in raw if str(code).strip()]
    else:
        codes = [code.strip() for code in re.split(r'[;|,]', str(raw)) if code.strip()]
    shared = {'source_id': row.get('source_id'), 'quote': row.get('quote'),
              'char_start': row.get('char_start') or row.get('char_offset'),
              'cue_absent_justification': row.get('cue_absent_justification'),
              'label_attribution': row.get('label_attribution'),
              'note': row.get('label_note')}
    return [{**shared, 'code': code} for code in codes]


def _span(sources, get_text, source_id, quote, char_start):
    if source_id not in sources:
        raise ValueError('Label cites an unregistered source ' + str(source_id))
    if sources[source_id].get('status') != 'ready':
        raise ValueError('Label cites a source that is not ready: ' + str(source_id))
    if not isinstance(quote, str) or len(quote.strip()) < 10:
        raise ValueError('Each reason label needs a verbatim span of at least ten characters')
    text = get_text(source_id)
    if char_start in (None, ''):
        if text.count(quote) != 1:
            raise ValueError('Label span is missing or ambiguous; supply char_start')
        start = text.index(quote)
    else:
        start = int(char_start)
        if text[start:start + len(quote)] != quote:
            raise ValueError('Label span does not match the bound original source')
    return {'start': start, 'end': start + len(quote), 'text': text}


def normalize(book, row, decisions, sources, get_text):
    """Validate one plan's coding against its own decisions and the source bytes.

    decisions maps variable -> decision, so the stated reason and its attribution stay
    separate inputs and neither can be inferred from the other.
    """
    if not row.get('plan_id') and not row.get('entity_id'):
        raise ValueError('Coding needs the plan_id it belongs to')
    plan = str(row.get('plan_id') or row.get('entity_id'))
    if row.get('plan_id') and row.get('entity_id') and str(row['plan_id']) != str(row['entity_id']):
        raise ValueError('plan_id and entity_id disagree')
    decision = (decisions or {}).get('stated_reason_text')
    attribution_decision = (decisions or {}).get('reason_attribution')
    if decision is None:
        raise ValueError('No stated_reason_text decision exists for ' + plan + '; code after the decision')
    status = decision.get('status')
    if status == 'unresolved':
        raise ValueError('Resolve the stated_reason_text decision before coding reasons for ' + plan)
    if not row.get('coder_id') or row.get('coder_kind') not in {'human', 'model'}:
        raise ValueError('Coding needs coder_id and coder_kind human|model')

    attribution_value = (attribution_decision or {}).get('value') \
        if (attribution_decision or {}).get('status') == 'observed' else None
    attribution = attribution_of(book, str(attribution_value or '').strip())
    labels = _labels_from_row(row) if status == 'observed' else []
    counts = status == 'observed' and bool(attribution and attribution['counts_as_stated_reason'])
    assigned = {str(item.get('code') or '').strip() for item in labels}
    if 'other_stated_reason' in assigned and len(assigned) > 1:
        raise ValueError('other_stated_reason cannot co-occur with a substantive category')

    allowed_evidence = {item['source_id'] for item in decision.get('evidence', [])}
    categories = category_map(book)
    out_labels = []
    seen = set()
    for label in labels:
        code = str(label.get('code') or '').strip()
        if code not in categories:
            raise ValueError('Unknown reason category ' + code +
                             '; record a proposed category for human review instead of a formal label')
        if code in seen:
            raise ValueError('Duplicated reason category ' + code + ' for ' + plan)
        seen.add(code)
        if source_id := label.get('source_id'):
            if source_id not in allowed_evidence:
                raise ValueError('Label ' + code + ' cites a source the stated_reason decision does not use')
        else:
            raise ValueError('Label ' + code + ' needs a source_id')
        span = _span(sources, get_text, label['source_id'], label.get('quote'), label.get('char_start'))
        cue_quotes = [cue for cue in categories[code].get('positive_cues', [])
                      if _cue_hit(span['text'][span['start']:span['end']], cue)]
        justification = str(label.get('cue_absent_justification') or '').strip()
        if categories[code].get('positive_cues') and not cue_quotes and len(justification) < 15:
            raise ValueError('Label ' + code + ' cites no positive cue; explain why the category still '
                             'applies in cue_absent_justification')
        label_level = attribution
        raw_level = str(label.get('label_attribution') or '').strip()
        if raw_level:
            label_level = attribution_of(book, raw_level)
            if label_level is None:
                raise ValueError('label_attribution ' + raw_level + ' is not a declared attribution value')
            if not label_level['counts_as_stated_reason']:
                raise ValueError('label_attribution ' + raw_level + ' is not a company statement; '
                                 'record it in notes instead of as a stated reason')
        out_labels.append({'code': code, 'source_id': label['source_id'], 'quote': label['quote'],
                           'char_start': span['start'], 'char_end': span['end'],
                           'quote_sha256': hashlib.sha256(label['quote'].encode()).hexdigest(),
                           'cue_observed': cue_quotes,
                           'cue_absent_justification': justification or None,
                           'attribution_level': (label_level or {}).get('code'),
                           'attribution_value': str(label.get('label_attribution') or '').strip() or None})

    if out_labels and not counts:
        raise ValueError('Attribution ' + str(attribution_value) + ' is not a company statement; '
                         'labels are not allowed. Record the basis in notes instead')
    if 'other_stated_reason' in seen and len(seen) > 1:
        raise ValueError('other_stated_reason cannot co-occur with a substantive category')

    no_label_status = str(row.get('no_label_status') or '').strip()
    statuses = book.get('no_label_statuses') or {}
    if counts and not out_labels:
        if no_label_status not in statuses:
            raise ValueError('A company-stated reason is present but no category was assigned; state '
                             'no_label_status (' + ', '.join(statuses or ['not_yet_classified']) +
                             ') and explain it in notes. Silence is not a completed classification')
        if len(str(row.get('notes') or '').strip()) < 15:
            raise ValueError('no_label_status=' + no_label_status + ' needs notes explaining the basis '
                             'in at least fifteen characters')

    primary = str(row.get('primary_code') or row.get('primary') or '').strip() or None
    basis = str(row.get('primary_basis') or '').strip()
    basis_quote = str(row.get('primary_basis_quote') or '').strip()
    ordering = book.get('ordering_cues') or []
    if primary:
        if primary not in seen:
            raise ValueError('Primary code ' + primary + ' is not among the assigned labels')
        if len(basis) < 15:
            raise ValueError('A primary reason needs primary_basis quoting the ordering language')
        if ordering and not any(_cue_hit(basis, cue) for cue in ordering):
            raise ValueError('primary_basis must quote the ordering language (' + ', '.join(ordering[:4]) +
                             '); a longer explanation is not evidence of primacy')
        if len(basis_quote) < 10:
            raise ValueError('A primary reason needs primary_basis_quote, the verbatim ordering sentence')
        cited = [label['quote'] for label in out_labels]
        located = any(basis_quote in quote for quote in cited) or any(
            basis_quote in get_text(source_id) for source_id in allowed_evidence if source_id in sources)
        if not located:
            raise ValueError('primary_basis_quote does not occur in any cited source of this plan')

    proposed = []
    for item in row.get('proposed_categories') or []:
        code = str(item.get('code') or '').strip()
        definition = str(item.get('definition') or '').strip()
        quote = str(item.get('quote') or '').strip()
        if not code or len(definition) < 20 or len(quote) < 10:
            raise ValueError('A proposed category needs a code, a definition of twenty characters and a quote')
        proposed.append({'code': code, 'definition': definition, 'quote': quote,
                         'source_id': item.get('source_id') or row.get('source_id'),
                         'status': 'pending_human_review'})

    return {'plan_id': plan, 'company_id': decision.get('company_id') or plan.split('|')[0],
            'attribution_level': attribution['code'] if attribution else None,
            'attribution_value': attribution_value,
            'counts_as_stated_reason': counts,
            'labels': out_labels, 'label_count': len(out_labels),
            'primary_code': primary if counts else None,
            'primary_basis': basis if counts and primary else None,
            'primary_basis_quote': basis_quote if counts and primary else None,
            'no_label_status': no_label_status if counts and not out_labels else None,
            'basis_when_no_label': (str(row.get('notes') or '').strip() or None) if not out_labels else None,
            'proposed_categories': proposed,
            'notes': str(row.get('notes') or '').strip() or None,
            'coder_id': row['coder_id'], 'coder_kind': row['coder_kind'],
            'decision_sha256': decision.get('decision_sha256'),
            'attribution_decision_sha256': (attribution_decision or {}).get('decision_sha256'),
            'codebook_version': book['version'], 'codebook_sha256': _digest(book)}


def apply(skill, work, path, cfg, sources, accepted, ents, book_version, replace=False):
    """Merge a coding batch into the existing sidecar. A later batch never deletes an earlier one."""
    book = load(skill)
    get_text = _text_accessor(work, sources)
    rows = contracts.parse_rows(path)
    existing = {}
    if not replace:
        try:
            previous = contracts.require_record(skill, work, 'reason_codebook', book_version)
            existing = {item['plan_id']: item for item in previous.get('records', [])}
        except (ValueError, OSError):
            existing = {}
    errors, records, seen = [], {}, set()
    for number, row in enumerate(rows, 1):
        try:
            plan = str(row.get('plan_id') or row.get('entity_id') or '')
            if plan not in ents:
                raise ValueError('plan_id is not a registered plan in this workspace: ' + plan)
            if plan in seen:
                raise ValueError('Duplicate coding record for ' + plan + ' in this submission')
            seen.add(plan)
            decisions = {variable: accepted.get(plan + '|' + variable)
                         for variable in ('stated_reason_text', 'reason_attribution')}
            record = normalize(book, {**row, 'plan_id': plan}, decisions, sources, get_text)
            record['company_id'] = ents[plan]['company_id']
            records[plan] = record
        except (ValueError, KeyError, TypeError, OSError) as exc:
            errors.append({'row': number, 'plan_id': row.get('plan_id') or row.get('entity_id'),
                           'error': str(exc)})
    merged = dict(existing)
    merged.update(records)
    report = {'pass': not errors, 'errors': errors, 'submitted': len(rows), 'records': len(merged),
              'labels': sum(item['label_count'] for item in merged.values()), 'merged': not replace}
    if errors:
        return report
    missing = sorted(set(ents) - set(merged))
    payload = {'records': [merged[plan] for plan in sorted(merged)],
               'uncoded_plans': missing, 'summary': summarize(merged),
               'coverage': coverage_of(merged, ents)}
    contracts.record(work, 'reason_codebook', payload, skill, book_version)
    report.update(payload['summary'], **payload['coverage'])
    return report


def _text_accessor(work, sources):
    from .sources import text_for
    cache = {}

    def get_text(source_id):
        if source_id not in sources:
            raise ValueError('Unknown source ' + str(source_id))
        if source_id not in cache:
            cache[source_id] = text_for(Path(work), sources[source_id])
        return cache[source_id]
    return get_text


def summarize(records):
    """Descriptive frequency. Deliberately reports the AI-plus-cost overlap instead of resolving it."""
    by_code, by_level, by_no_label, ai_financial = {}, {}, {}, 0
    for record in records.values():
        by_level[record['attribution_level'] or 'none'] = by_level.get(record['attribution_level'] or 'none', 0) + 1
        codes = {label['code'] for label in record['labels']}
        for code in codes:
            by_code[code] = by_code.get(code, 0) + 1
        if {'ai_technology', 'financial_operating'} <= codes:
            ai_financial += 1
        if record.get('no_label_status'):
            status = record['no_label_status']
            by_no_label[status] = by_no_label.get(status, 0) + 1
    coded = sum(1 for record in records.values() if record['label_count'])
    proposed = sum(len(record.get('proposed_categories') or []) for record in records.values())
    return {'coded_plans': len(records), 'plans_with_label': coded,
            'plans_without_label': len(records) - coded,
            'plans_with_declared_no_label_status': sum(by_no_label.values()),
            'by_no_label_status': dict(sorted(by_no_label.items())),
            'proposed_categories_pending': proposed,
            'labels_total': sum(record['label_count'] for record in records.values()),
            'multi_label_plans': sum(1 for record in records.values() if record['label_count'] > 1),
            'ai_and_financial_overlap': ai_financial,
            'by_category': dict(sorted(by_code.items())), 'by_attribution': dict(sorted(by_level.items()))}


def coverage_of(records, ents):
    company_stated = {plan for plan, record in records.items() if record['counts_as_stated_reason']}
    labelled = {plan for plan, record in records.items() if record['label_count']}
    declared_empty = {plan for plan, record in records.items()
                      if record['counts_as_stated_reason'] and not record['label_count']
                      and record.get('no_label_status')}
    return {'registered_plans': len(ents), 'coded_plans': len(records),
            'company_attributed_plans': len(company_stated),
            'plans_with_at_least_one_label': len(labelled),
            'plans_with_declared_no_label': len(declared_empty),
            'silently_unlabelled_plans': len(company_stated - labelled - declared_empty),
            'not_company_attributed': len(records) - len(company_stated),
            'uncoded_plans': len(set(ents) - set(records))}


def gate(skill, work, cfg, ents, book_version):
    """Audit gate: gaps are missing claims, not data errors."""
    armed = contracts.active(skill, cfg)
    if 'reason_codebook' not in armed:
        return [], []
    gaps, errors = [], []
    try:
        payload = contracts.require_record(skill, work, 'reason_codebook', book_version)
    except (ValueError, OSError) as exc:
        reason = 'stale_record' if 'stale_record' in str(exc) else 'not_recorded'
        return [{'contract': 'reason_codebook', 'reason': reason, 'detail': str(exc),
                 'expects': 'one coding record per registered plan'}], []
    coded = {item['plan_id'] for item in payload.get('records', [])}
    missing = sorted(set(ents) - coded)
    if missing:
        gaps.append({'contract': 'reason_codebook', 'reason': 'uncoded_plans', 'count': len(missing),
                     'example': missing[:5], 'expects': 'one coding record per registered plan'})
    stale = [item['plan_id'] for item in payload.get('records', [])
             if item.get('codebook_version') != load(skill)['version']]
    if stale:
        gaps.append({'contract': 'reason_codebook', 'reason': 'codebook_version_changed',
                     'count': len(stale), 'example': stale[:5],
                     'expects': 'recoding against the shipped codebook version'})
    extra = sorted(coded - set(ents))
    if extra:
        gaps.append({'contract': 'reason_codebook', 'reason': 'coded_plans_not_registered',
                     'count': len(extra), 'example': extra[:5], 'expects': 'registered plan identities'})
    silent = [item['plan_id'] for item in payload.get('records', [])
              if item.get('counts_as_stated_reason') and not item.get('label_count')
              and not item.get('no_label_status')]
    if silent:
        gaps.append({'contract': 'reason_codebook', 'reason': 'labels_incomplete', 'count': len(silent),
                     'example': silent[:5],
                     'expects': 'a label set, or an explicit no_label_status with notes'})
    pending = [(item['plan_id'], proposal['code'])
               for item in payload.get('records', []) for proposal in item.get('proposed_categories') or []]
    if pending:
        gaps.append({'contract': 'reason_codebook', 'reason': 'category_pending_human_review',
                     'count': len(pending), 'example': [f'{plan}:{code}' for plan, code in pending[:5]],
                     'expects': 'a human decision that either adds the category to the codebook or rejects it'})
    for item in payload.get('records', []):
        if item.get('label_count') and not item.get('counts_as_stated_reason'):
            errors.append({'plan_id': item['plan_id'],
                           'error': 'Reason labels exist for a non-company attribution'})
        for label in item.get('labels', []):
            if label.get('attribution_level') and not item.get('counts_as_stated_reason'):
                errors.append({'plan_id': item['plan_id'],
                               'error': 'Per-label attribution survives even though the event is not a company statement'})
    return gaps, errors


def export_csv(skill, work, path, book_version):
    payload = contracts.require_record(skill, work, 'reason_codebook', book_version)
    rows = []
    for record in payload.get('records', []):
        if not record['labels']:
            rows.append({'plan_id': record['plan_id'], 'company_id': record['company_id'],
                         'code': '', 'attribution_level': record['attribution_level'] or '',
                         'no_label_status': record.get('no_label_status') or '',
                         'cue_observed': '', 'primary': '', 'primary_basis_quote': '', 'quote_sha256': '',
                         'char_start': '', 'char_end': '', 'label_count': 0})
            continue
        for label in record['labels']:
            rows.append({'plan_id': record['plan_id'], 'company_id': record['company_id'],
                         'code': label['code'],
                         'attribution_level': label.get('attribution_level') or record['attribution_level'],
                         'no_label_status': '',
                         'cue_observed': ';'.join(label['cue_observed']),
                         'primary': 'yes' if record.get('primary_code') == label['code'] else '',
                         'primary_basis_quote': record.get('primary_basis_quote') or '',
                         'quote_sha256': label['quote_sha256'],
                         'char_start': label['char_start'], 'char_end': label['char_end'],
                         'label_count': record['label_count']})
    path = Path(path)
    contracts.mkdir(path.parent)
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]) if rows else
                            ['plan_id', 'company_id', 'code', 'attribution_level', 'no_label_status',
                             'cue_observed', 'primary', 'primary_basis_quote', 'quote_sha256', 'char_start',
                             'char_end', 'label_count'])
    writer.writeheader()
    writer.writerows(rows)
    path.write_text(buffer.getvalue(), encoding='utf-8')
    return {'output': str(path), 'rows': len(rows), 'plans': len(payload.get('records', [])),
            'grain': 'one row per plan-label; a plan with no label keeps one row with an empty code'}
