"""What the collected data can actually answer, stated per research comparison.

This module never converts a research question into a causal claim, and it never treats "the
module has some data" as "the comparison is computable". Each comparison is built from an
explicit eligibility table: the units that satisfy every condition, the units excluded, and
the reason for each exclusion. When two modules have data but share no unit, the answer is
``not_measurable``.

Five comparisons are reported separately, because a study can support one and not another:

1. reason_description — company-stated reasons, multi-label
2. financial_contrast — those reasons against a contemporaneous financial or workforce signal
3. pre_event_capability — a typed capability attested in a document public before the event
4. longitudinal_performance — two comparable company-years for the same entity
5. job_skill_pairing — always not_available in this collection
"""
from __future__ import annotations

from pathlib import Path

from . import contracts

COMMANDS = (
    'init', 'source-plan', 'sync', 'prepare', 'next', 'read', 'apply', 'prepare-second',
    'next-second', 'apply-second', 'audit', 'export', 'sec-prepare',
    'contracts-status', 'contracts-scorecard', 'codebook-show', 'reason-apply',
    'reason-coverage', 'reason-summary', 'reason-export', 'tech-apply', 'tech-capability',
    'tech-coverage', 'tech-export', 'linkage-build', 'linkage-pre-event', 'registry-init',
    'registry-verify', 'registry-check', 'comparability-import', 'comparability-compare',
    'human-blind', 'human-template', 'human-evaluate', 'human-adjudicate', 'human-status',
    'search-log-import', 'search-coverage', 'missingness-report', 'missingness-export',
    'routes-check', 'readiness', 'next-actions',
)

FINANCIAL_CORE = ('headcount', 'revenue', 'operating_income')
DISTRESS_VARIABLES = ('revenue', 'operating_income', 'layoff_count')

COMPARISONS = ('reason_description', 'financial_contrast', 'pre_event_capability',
               'longitudinal_performance', 'job_skill_pairing')


def _gate(status, question, blockers, evidence):
    return {'question': question, 'status': status, 'blockers': blockers, 'evidence': evidence}


def _status(count, blockers, partial_ok):
    if not blockers:
        return 'measurable'
    return 'partially_measurable' if partial_ok else 'not_measurable'


def _record_or_none(skill, work, name, book_version):
    try:
        return contracts.require_record(skill, work, name, book_version)
    except (ValueError, OSError):
        return None


def _verified(work):
    registry = contracts.read_json(Path(work) / 'registry' / 'entities.json', {}) or {}
    return {code for code, entry in (registry.get('entries') or {}).items()
            if entry.get('status') == 'verified'}


def _reason_plans(skill, work, book_version):
    payload = _record_or_none(skill, work, 'reason_codebook', book_version)
    if not payload:
        return None, {}
    records = {item['plan_id']: item for item in payload.get('records', [])}
    return payload, records


def reason_description(skill, work, book_version, ents):
    payload, records = _reason_plans(skill, work, book_version)
    question = 'Which reasons do companies state, and how do the categories co-occur?'
    if payload is None:
        return {'comparison': 'reason_description', 'status': 'not_measurable',
                'question': question, 'n': 0, 'eligible': [],
                'blockers': ['reason_codebook not recorded: stated reasons are free text only'],
                'evidence': {}}
    eligible = sorted(plan for plan, record in records.items() if record.get('label_count'))
    excluded = []
    for plan in sorted(set(ents) - set(eligible)):
        record = records.get(plan)
        if record is None:
            excluded.append({'plan_id': plan, 'reason': 'no_coding_record'})
        elif not record.get('counts_as_stated_reason'):
            excluded.append({'plan_id': plan, 'reason': 'not_a_company_statement'})
        elif not record.get('label_count'):
            excluded.append({'plan_id': plan, 'reason': record.get('no_label_status') or 'no_label'})
    blockers = []
    if not eligible:
        blockers.append('no plan carries a labelled company-stated reason')
    if len(eligible) < 2:
        blockers.append('fewer than two labelled plans: co-occurrence cannot be described')
    summary = payload.get('summary', {})
    return {'comparison': 'reason_description', 'status': _status(len(eligible), blockers, bool(eligible)),
            'question': question, 'n': len(eligible), 'eligible': eligible[:20],
            'excluded': excluded[:20], 'excluded_count': len(excluded), 'blockers': blockers,
            'evidence': {'by_category': summary.get('by_category'),
                         'ai_and_financial_overlap': summary.get('ai_and_financial_overlap'),
                         'multi_label_plans': summary.get('multi_label_plans'),
                         'plans_with_declared_no_label_status': summary.get('plans_with_declared_no_label_status'),
                         'boundary': 'A reason frequency describes what companies said. It is not the cause of the '
                                     'reduction and does not test whether a reason was an excuse.'}}


def financial_contrast(skill, work, book_version, accepted, ents, mode):
    """Reason labels and a contemporaneous distress signal on the same plan, not two lists."""
    payload, records = _reason_plans(skill, work, book_version)
    question = 'Do AI-citing plans differ in contemporaneous financial or workforce signals?'
    if mode != 'events':
        return {'comparison': 'financial_contrast', 'status': 'not_measurable', 'question': question, 'n': 0,
                'eligible': [], 'blockers': ['reason labels live in the events workspace; pair it with linkage'],
                'evidence': {}}
    if payload is None:
        return {'comparison': 'financial_contrast', 'status': 'not_measurable', 'question': question, 'n': 0,
                'eligible': [], 'blockers': ['reason_codebook not recorded'], 'evidence': {}}
    eligible, excluded = [], []
    for plan in sorted(ents):
        record = records.get(plan) or {}
        codes = {label['code'] for label in record.get('labels') or []}
        signals = [name for name in DISTRESS_VARIABLES
                   if (accepted.get(plan + '|' + name) or {}).get('status') == 'observed']
        if not codes:
            excluded.append({'plan_id': plan, 'reason': 'no_reason_label'})
        elif not signals:
            excluded.append({'plan_id': plan, 'reason': 'no_financial_or_workforce_signal'})
        else:
            eligible.append({'plan_id': plan, 'codes': sorted(codes), 'signals': signals})
    ai_side = [item for item in eligible if 'ai_technology' in item['codes']]
    holders = [item for item in eligible if 'financial_operating' in item['codes']]
    blockers = []
    if not eligible:
        blockers.append('no plan has both a reason label and a revenue, operating-income or headcount value')
    if not ai_side:
        blockers.append('no eligible plan cites AI, so the contrast group is empty')
    if not holders:
        blockers.append('no eligible plan cites financial or operating reasons, so the comparison group is empty')
    return {'comparison': 'financial_contrast', 'status': _status(len(eligible), blockers, bool(eligible)),
            'question': question, 'n': len(eligible), 'eligible': eligible[:20],
            'excluded': excluded[:20], 'excluded_count': len(excluded), 'blockers': blockers,
            'evidence': {'ai_group': len(ai_side), 'financial_group': len(holders),
                         'boundary': 'Revenue and operating income are not solvency, financing constraints or every '
                                     'form of market pressure. No balance-sheet or cash-flow field is collected.'}}


def pre_event_capability(skill, work, book_version, accepted, ents, mode, cfg):
    question = 'Did companies that cited AI already disclose an observable AI capability before the reduction?'
    linkage = _record_or_none(skill, work, 'linkage', book_version)
    tech = _record_or_none(skill, work, 'tech_evidence', book_version)
    verified = _verified(work)
    if mode == 'events':
        return {'comparison': 'pre_event_capability', 'status': 'not_measurable', 'question': question, 'n': 0,
                'eligible': [],
                'blockers': ['capability evidence lives in the filings workspace; run readiness there'],
                'evidence': {'pre_event_public_pairs': (linkage or {}).get('summary', {}).get('pre_event_public')}}
    blockers = []
    if not linkage:
        blockers.append('linkage not recorded: pre-event availability of each cited document is unknown')
    if not tech:
        blockers.append('tech_evidence not recorded: the technology class and adoption stage are unknown')
    if not verified:
        blockers.append('no company identity is verified; parent and subsidiary rows may be mixed')
    typed = {}
    for record in (tech or {}).get('capability', {}).get('records', []):
        typed.setdefault((record['entity_id'], record.get('source_id')), []).append(record)
    eligible = []
    if linkage:
        for unit in linkage.get('units', []):
            if unit['state'] != 'pre_event_public':
                continue
            matches = [record for record in typed.get((unit['entity_id'], unit['source_id']), [])
                       if record.get('counts_as_capability')]
            company = unit['company_id']
            if not matches:
                continue
            if company not in verified:
                continue
            eligible.append({'entity_id': unit['entity_id'], 'plan_id': unit['plan_id'],
                             'company_id': company, 'source_id': unit['source_id'],
                             'variables': sorted({record['variable'] for record in matches}),
                             'ai': any(record['technology_class_is_ai'] for record in matches),
                             'generative': any(record['technology_class'] == 'generative_ai' for record in matches)})
    entities = {item['entity_id'] for item in eligible}
    ai_entities = {item['entity_id'] for item in eligible if item['ai']}
    if linkage and not entities:
        blockers.append('no pre-event document carries both a typed capability and a verified identity')
    if eligible and not ai_entities:
        blockers.append('the pre-event capability is recorded only for non-AI technology')
    return {'comparison': 'pre_event_capability', 'status': _status(len(entities), blockers, bool(entities)),
            'question': question, 'n': len(entities), 'eligible': eligible[:20],
            'blockers': blockers,
            'evidence': {'pre_event_units': len(eligible), 'entities_with_pre_event_ai': len(ai_entities),
                         'verified_identities': len(verified),
                         'pre_event_public_pairs': (linkage or {}).get('summary', {}).get('pre_event_public'),
                         'boundary': 'One necessary condition is a pre-event disclosure of capability. Absence of a '
                                     'disclosure is not absence of capability, and a customer-facing product does not '
                                     'prove the capability replaces the internal roles that were cut.'}}


def longitudinal_performance(skill, work, book_version, accepted, ents, mode):
    from . import registry
    question = 'How do technology investment and workforce change relate to subsequent operating performance?'
    if mode == 'events':
        return {'comparison': 'longitudinal_performance', 'status': 'not_measurable', 'question': question, 'n': 0,
                'eligible': [], 'blockers': ['financial and workforce measures live in the filings workspace'],
                'evidence': {}}
    by_company = {}
    for key, decision in accepted.items():
        entity, _, variable = key.partition('|')
        if variable not in FINANCIAL_CORE or decision.get('status') != 'observed':
            continue
        company, _, fy = entity.partition(':')
        if fy.isdigit():
            by_company.setdefault(company, set()).add(int(fy))
    comparable_pairs, incomparable, complete_years = [], [], 0
    for company, years in sorted(by_company.items()):
        ordered = sorted(years)
        for index, fy in enumerate(ordered):
            complete_years += 1
            if index == 0:
                continue
            previous = ordered[index - 1]
            if fy - previous != 1:
                continue
            try:
                verdict = registry.compare(skill, work, company, previous, fy)
            except (ValueError, KeyError, OSError) as exc:
                incomparable.append({'company_id': company, 'fy': [previous, fy], 'reason': str(exc)})
                continue
            if verdict.get('comparable'):
                comparable_pairs.append({'company_id': company, 'fy': [previous, fy]})
            else:
                incomparable.append({'company_id': company, 'fy': [previous, fy],
                                     'reason': (verdict.get('reasons') or [{}])[0].get('reason')})
    blockers = []
    if not complete_years:
        blockers.append('no company-year has headcount, revenue and operating income observed together')
    if not comparable_pairs:
        blockers.append('no adjacent company-years pass the comparability check '
                        '(period length, currency, consolidation scope, restatement version)')
    return {'comparison': 'longitudinal_performance',
            'status': _status(len(comparable_pairs), blockers, bool(complete_years)),
            'question': question, 'n': len(comparable_pairs), 'eligible': comparable_pairs[:20],
            'excluded': incomparable[:20], 'excluded_count': len(incomparable), 'blockers': blockers,
            'evidence': {'complete_company_years': complete_years,
                         'companies': sorted(by_company),
                         'boundary': 'A within-company description. A causal effect needs a design this collection '
                                     'does not supply.'}}


def job_skill_pairing():
    return {'comparison': 'job_skill_pairing', 'status': 'not_available',
            'question': 'Which occupational skills do the reduced roles require, and how do they pair with the '
                        'technology the firm adopted?',
            'n': 0, 'eligible': [],
            'blockers': ['no occupational skill or job-posting data is collected by these two skills'],
            'evidence': {'boundary': 'Proposal P43-P46 is a later stage. Nothing in these outputs supports a '
                                     'skill-pairing statement.'}}


def capability_inventory(skill, cfg):
    """Objective counts of what the shipped contracts define, for comparison across releases."""
    inventory = {'commands': len(COMMANDS), 'contracts_armed': len(contracts.active(skill, cfg)),
                 'comparisons': len(COMPARISONS)}
    try:
        book = contracts.asset(skill, 'reason_codebook')
        inventory['reason_categories'] = len(book['categories'])
        inventory['attribution_levels'] = len(book['attribution_levels'])
        inventory['codebook_rules'] = len(book.get('rules', {}))
        inventory['reason_cues'] = sum(len(item.get('positive_cues', [])) for item in book['categories'])
        inventory['no_label_statuses'] = len(book.get('no_label_statuses') or {})
        inventory['ordering_cues'] = len(book.get('ordering_cues') or [])
    except (ValueError, OSError, KeyError):
        pass
    try:
        contract = contracts.asset(skill, 'tech_evidence')
        vocab = contract['vocabularies']
        inventory['technology_classes'] = len(vocab['technology_class'])
        inventory['adoption_stages'] = len(vocab['adoption_stage'])
        inventory['use_contexts'] = len(vocab['use_context'])
        inventory['expenditure_scopes'] = len(vocab['expenditure_scope'])
        inventory['technology_field_rules'] = len(contract.get('field_rules', {}))
        inventory['technology_consistency_rules'] = len(contract.get('consistency_rules', []))
        inventory['technology_cues'] = sum(len(item.get('cue_any', []))
                                           for item in vocab['technology_class'].values())
        inventory['classification_paths'] = len(contract.get('classification_paths') or {})
    except (ValueError, OSError, KeyError):
        pass
    try:
        inventory['missingness_statuses'] = len(contracts.asset(skill, 'missingness')['statuses'])
    except (ValueError, OSError, KeyError):
        pass
    try:
        search = contracts.asset(skill, 'search_coverage')
        inventory['search_channels'] = len(search['channels'])
        inventory['search_outcomes'] = len(search['outcomes'])
    except (ValueError, OSError, KeyError):
        pass
    try:
        markets = contracts.asset(skill, 'market_routes')['markets']
        inventory['markets'] = len(markets)
        inventory['required_document_roles'] = sum(len(item['required_roles']) for item in markets.values())
        inventory['identity_checks'] = sum(len(item['identity_checks']) for item in markets.values())
    except (ValueError, OSError, KeyError):
        pass
    try:
        human = contracts.asset(skill, 'human_validation')
        inventory['human_status_levels'] = len(human['status_levels'])
        inventory['annotation_columns'] = len(human['annotation_columns'])
        inventory['human_rules'] = len(human.get('rules', []))
        inventory['metrics'] = sum(len(value) for value in human.get('metrics', {}).values())
    except (ValueError, OSError, KeyError):
        pass
    try:
        linkage = contracts.asset(skill, 'linkage')
        inventory['linkage_states'] = len(linkage['states'])
        inventory['linkage_rules'] = len(linkage.get('rules', []))
    except (ValueError, OSError, KeyError):
        pass
    inventory['sidecar_kinds'] = len(contracts.SPECS)
    return inventory


def _questions(tables):
    rq1_blockers = []
    if tables['reason_description']['status'] not in {'measurable', 'partially_measurable'}:
        rq1_blockers.extend(tables['reason_description']['blockers'])
    if tables['financial_contrast']['status'] not in {'measurable', 'partially_measurable'}:
        rq1_blockers.extend(tables['financial_contrast']['blockers'])
    rq1 = _gate('measurable' if not rq1_blockers else (
        'partially_measurable' if tables['reason_description']['status'] != 'not_measurable' else 'not_measurable'),
        'Are AI-related reasons a distinct stated category, how do they co-occur with financial reasons, and do '
        'they differ on contemporaneous signals?', rq1_blockers,
        {'reason_description': tables['reason_description']['status'],
         'financial_contrast': tables['financial_contrast']['status'],
         'n_reason_plans': tables['reason_description']['n'],
         'n_contrast_plans': tables['financial_contrast']['n'],
         'boundary': 'Descriptive only. Reason frequency is not a cause and does not test whether AI was an excuse.'})
    pre = tables['pre_event_capability']
    # Local pre-event evidence is a prerequisite, not a verified reason-group comparison.
    rq2_blockers = list(pre['blockers'])
    rq2_blockers.append('A joined event-level AI-reason versus other-reason capability comparison has not been validated by this local readiness check')
    rq2 = _gate('partially_measurable' if pre['n'] else 'not_measurable',
                'Did companies that cited AI already disclose observable AI capability before the reduction?',
                rq2_blockers, {**pre['evidence'], 'local_pre_event_status': pre['status'],
                              'inference_level': 'descriptive_prerequisite_only'})
    rq3 = _gate(tables['longitudinal_performance']['status'],
                'How do AI/technology investment and workforce change relate to subsequent operating performance?',
                tables['longitudinal_performance']['blockers'],
                {key: value for key, value in tables['longitudinal_performance']['evidence'].items()})
    return {'RQ1': rq1, 'RQ2': rq2, 'RQ3': rq3}


def report(skill, work, cfg, book, accepted, ents, sources, tasks, book_version):
    mode = cfg.get('mode')
    tables = {'reason_description': reason_description(skill, work, book_version, ents),
              'financial_contrast': financial_contrast(skill, work, book_version, accepted, ents, mode),
              'pre_event_capability': pre_event_capability(skill, work, book_version, accepted, ents, mode, cfg),
              'longitudinal_performance': longitudinal_performance(skill, work, book_version, accepted, ents, mode),
              'job_skill_pairing': job_skill_pairing()}
    questions = _questions(tables)
    order = {'measurable': 2, 'partially_measurable': 1, 'not_measurable': 0}
    payload = {'mode': mode, 'research_questions': questions, 'comparisons': tables,
               'weakest_link': min(questions, key=lambda key: order[questions[key]['status']]),
               'capability_inventory': capability_inventory(skill, cfg),
               'contracts': contracts.status(skill, work, cfg, book_version),
               'human_validation': _human_status(skill, work, cfg, book_version),
               'never_claimed': ['that a stated reason is the true cause',
                                 'that pre-event capability caused the reduction',
                                 'that held-out human agreement exists without an annotation file',
                                 'that the searched channels exhaust all public events',
                                 'that a reason label implies the reason was not an excuse',
                                 'that these two tables support occupational skill pairing']}
    return payload


def _human_status(skill, work, cfg, book_version):
    if 'human_validation' not in contracts.active(skill, cfg):
        return {'armed': False}
    payload = _record_or_none(skill, work, 'human_validation', book_version)
    if not payload:
        return {'armed': True, 'status': 'not_executed',
                'reporting_rule': 'State plainly that no human benchmark exists. Do not call the self-review pass '
                                  'reliability.'}
    return {'armed': True, 'status': payload.get('status'), 'annotations': payload.get('annotations'),
            'claim_allowed': payload.get('claim_allowed')}


def next_actions(skill, work, cfg, book, accepted, ents, sources, tasks, book_version):
    """State-driven next steps: deterministic checks first, semantic reading last."""
    status = contracts.status(skill, work, cfg, book_version)
    actions = []
    pending = [task for task in tasks
               if not accepted.get(task['entity_id'] + '|' + task['variable'])
               or (accepted.get(task['entity_id'] + '|' + task['variable']) or {}).get('status') == 'unresolved']
    if pending:
        actions.append({'action': 'next', 'why': str(len(pending)) + ' positions still need a decision',
                        'command': 'next --work <W>', 'kind': 'semantic'})
    for name, gap in ((gap['contract'], gap) for gap in status['gaps']):
        command = {
            'reason_codebook': 'reason-apply --file <coding.csv>',
            'tech_evidence': 'tech-apply --file <typing.csv>',
            'linkage': 'linkage-build --peer-work <other workspace>',
            'search_coverage': 'search-log-import --file <search_log.csv>',
            'missingness': 'missingness-report',
            'market_routes': 'routes-check',
            'human_validation': 'human-blind then human-template'
        }.get(name, 'contracts-status')
        actions.append({'action': name, 'why': gap.get('reason'), 'detail': gap.get('detail'),
                        'command': command, 'kind': 'deterministic'})
    readiness = report(skill, work, cfg, book, accepted, ents, sources, tasks, book_version)
    for name, table in readiness['comparisons'].items():
        if table['status'] not in {'measurable'}:
            actions.append({'action': 'readiness:' + name, 'why': '; '.join(table['blockers'][:2]),
                            'command': 'readiness --work <W>', 'kind': 'semantic'})
    order = {'deterministic': 0, 'semantic': 1}
    actions.sort(key=lambda item: order.get(item['kind'], 2))
    return {'actions': actions[:12], 'counts': {'deterministic': sum(1 for a in actions if a['kind'] == 'deterministic'),
                                                'semantic': sum(1 for a in actions if a['kind'] == 'semantic')},
            'reading_order': 'Run deterministic commands first. They never decide a value; they only settle what is '
                             'missing.', 'complete': not actions}
