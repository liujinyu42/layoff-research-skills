"""Deterministic evidence checks; substantive interpretation remains with the reader."""
import math
import re


def _number(raw, decimal_separator='.', group_separator=','):
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError('Money needs raw_text copied literally from its evidence')
    if decimal_separator not in {'.', ','} or group_separator not in {',', '.', ' ', "'", '’', ''} or decimal_separator == group_separator:
        raise ValueError('Explicit decimal_separator and group_separator are invalid or identical')
    cleaned = re.sub(r'[\s$€£¥%]', '', raw).replace('−', '-')
    if group_separator and group_separator != ' ': cleaned = cleaned.replace(group_separator, '')
    if decimal_separator == ',': cleaned = cleaned.replace(',', '.')
    if cleaned.startswith('(') and cleaned.endswith(')'):
        cleaned = '-' + cleaned[1:-1]
    if not re.fullmatch(r'-?(?:\d+(?:\.\d+)?|\.\d+)', cleaned):
        raise ValueError('raw_text must be the original numeric token, including its sign')
    return float(cleaned)


_HSPACE = ' \t\u00a0\u2007\u2009\u202f'  # horizontal space only; a newline ends the context
_CURRENCY_CUE = '$€£¥'
_NEGATING_LEFT = '-−('  # characters that make the following number negative


def _skip_left(text, index):
    i = index - 1
    while i >= 0 and (text[i] in _HSPACE or text[i] in _CURRENCY_CUE):
        i -= 1
    return text[i] if i >= 0 else ''


def _skip_right(text, index):
    j = index
    while j < len(text) and text[j] in _HSPACE:
        j += 1
    return text[j] if j < len(text) else ''


def _token_problem(text, start, length, positive):
    """Describe why the number at this exact position is not the token that was submitted."""
    end = start + length
    if start > 0 and text[start - 1].isdigit():
        return 'part of a longer number on its left'
    if start > 0 and text[start - 1] in '.,\'’':
        return 'part of a longer number on its left'
    if positive:
        left = _skip_left(text, start)
        if left and left in _NEGATING_LEFT:
            return 'negated by a sign immediately before it in the source'
    after = text[end] if end < len(text) else ''
    if after.isdigit():
        return 'part of a longer number on its right'
    if after and after in '.,' and end + 1 < len(text) and text[end + 1].isdigit():
        return 'part of a longer number on its right'
    if positive and _skip_right(text, end) == ')':
        return 'closed by an accounting parenthesis in the source'
    return ''


def _occurrences(text, raw):
    start = text.find(raw)
    while start >= 0:
        yield start
        start = text.find(raw, start + 1)


def _literal_amount(amount, evidence, source_text=None):
    raw = amount.get('raw_text')
    if not math.isclose(_number(raw, amount.get('decimal_separator','.'), amount.get('group_separator',',')), amount['raw_value'], rel_tol=1e-12, abs_tol=1e-10):
        raise ValueError('raw_value differs from literal raw_text')
    quotes = [e['quote'] for e in evidence]
    positive = amount['raw_value'] >= 0
    # A literal check must resolve the whole source token, not just the characters inside a
    # quote: a quote may start after a minus/accounting sign, and table gaps can be wide.
    matches, reasons, originals = [], [], {}
    for element in evidence:
        quote = element['quote']
        bound = element.get('char_start')
        for offset in _occurrences(quote, raw):
            problem = _token_problem(quote, offset, len(raw), positive)
            if problem:
                reasons.append(problem)
                continue
            if source_text is not None:
                sid = element['source_id']
                if sid not in originals:
                    originals[sid] = source_text(sid)
                full = originals[sid]
                if type(bound) is not int or full[bound:bound + len(quote)] != quote:
                    raise ValueError('Quoted evidence does not match its bound original span')
                absolute = bound + offset
                problem = _token_problem(full, absolute, len(raw), positive)
                if problem:
                    reasons.append(problem)
                    continue
            matches.append((element, offset))
    if not matches:
        detail = '; it is ' + reasons[0] if reasons else ''
        raise ValueError('Literal raw_text does not occur as a complete number in quoted evidence' + detail)
    unit = amount['unit_quote']
    if not any(unit in q for q in quotes):
        raise ValueError('Unit header/sentence must be quoted as evidence, not merely present elsewhere in source')
    for word, scale in [('billion', 1e9), ('million', 1e6), ('thousand', 1e3)]:
        if re.search(r'\b' + word + r's?\b', unit, re.I) and amount['scale'] != scale:
            raise ValueError('Scale disagrees with the literal unit quote')


def check_raw_amount(decision, evidence, source_text=None):
    amount = decision['amount']
    if amount.get('kind', 'reported') == 'reported':
        _literal_amount(amount, evidence, source_text)
        return
    if amount.get('kind') != 'derived_sum':
        raise ValueError('Amount kind must be reported or explicit derived_sum')
    components = amount.get('components', [])
    if len(components) < 2 or not decision.get('derivation_basis'):
        raise ValueError('Derived sum requires named components and derivation_basis')
    names = [c.get('name') for c in components]
    if not all(names) or len(names) != len(set(names)):
        raise ValueError('Derived components need distinct names; exclude overlapping subtotals')
    total = 0
    for component in components:
        if component.get('currency') != amount['currency']:
            raise ValueError('Derived components use different currencies')
        _literal_amount(component, evidence, source_text)
        total += component['raw_value'] * component['scale']
    if not math.isclose(total, decision['value'], rel_tol=1e-12, abs_tol=1e-8):
        raise ValueError('Derived component sum does not reconcile to value')
    if decision['variable'] == 'total_comp_expense' and decision.get('component_coverage') != 'exhaustive_disjoint':
        raise ValueError('Total compensation cannot be reconstructed from an incomplete selection of components')


def required_review_checks(field, decision, mode):
    checks = ['definition', 'entity', 'period', 'context_and_negation']
    if field.get('unit') == 'currency_base':
        checks += ['raw_number_and_unit', 'total_component_and_accounting_basis']
    if field.get('topic') == 'compensation':
        checks += ['recipient_and_compensation_basis' if field.get('measure_kind') == 'ai_compensation' else 'executive_and_compensation_basis', 'ai_link_if_claimed']
    if mode == 'events' and field.get('topic') == 'context':
        checks += ['information_available_at_event']
    if mode == 'events' and field.get('topic') == 'event_reason':
        checks += ['company_attribution_and_causal_link']
    if decision['status'] in {'reviewed_absent', 'not_separate'} or (
        field['type'] == 'binary' and decision.get('value') == 0
    ):
        checks += ['complete_applicable_scope', 'negative_counterevidence']
    return checks


def check_second_review(review, field, decision, mode, source_text=None):
    if review.get('review_outcome') != 'confirm':
        raise ValueError('Second review must confirm; revise the first decision or keep it unresolved when evidence disagrees')
    checks = review.get('checks', {})
    missing = [name for name in required_review_checks(field, decision, mode)
               if not isinstance(checks.get(name), str) or not checks[name].strip()]
    if missing:
        raise ValueError('Specific semantic review checks missing: ' + ', '.join(missing))
    if decision.get('evidence'):
        source_checks = review.get('source_checks', [])
        originals = {(e['source_id'], e['char_start'], e['char_end'], e['quote']) for e in decision['evidence']}
        checked = {(e.get('source_id'), e.get('char_start'), e.get('char_end'), e.get('quote')) for e in source_checks}
        if not checked or not checked.issubset(originals) or {e[0] for e in checked} != {e[0] for e in originals}:
            raise ValueError('Second review must quote an actual bound evidence span after re-reading its context')
    else:
        scopes = {s['source_id']: s for s in decision.get('reviewed_scopes', [])}
        source_checks = review.get('source_checks', [])
        if not scopes or {e.get('source_id') for e in source_checks} != set(scopes):
            raise ValueError('Negative second review requires an actual source_checks span from every applicable source scope')
        for item in source_checks:
            scope = scopes[item['source_id']]
            lo, hi, quote = item.get('char_start'), item.get('char_end'), item.get('quote')
            if type(lo) is not int or type(hi) is not int or not scope['start'] <= lo < hi <= scope['end'] or not isinstance(quote, str) or len(quote.strip()) < 10 or hi-lo != len(quote):
                raise ValueError('Invalid negative source_checks span')
            if source_text is not None and source_text(item['source_id'])[lo:hi] != quote:
                raise ValueError('Negative second-review quote differs from original source span')
