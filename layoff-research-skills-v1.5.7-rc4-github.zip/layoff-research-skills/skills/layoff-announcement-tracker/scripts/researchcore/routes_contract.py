"""Market document contracts: turn a routing label into a checkable requirement.

`route_for` already says where to look. This module says what a registered source set must
contain before a company-**year** counts as documented. Requirements are checked per fiscal
year, because a 2024 annual report cannot satisfy 2022: a year with material and a year
without it are different documentation states, and averaging them hides the gap.
"""
from __future__ import annotations

from pathlib import Path

from . import contracts


def load(skill):
    payload = contracts.asset(skill, 'market_routes')
    markets = payload.get('markets') or {}
    if not markets:
        raise ValueError('Market route contract needs at least one market')
    for code, item in markets.items():
        if not item.get('required_roles'):
            raise ValueError('Market ' + code + ' needs required_roles')
        if not item.get('routes'):
            raise ValueError('Market ' + code + ' needs the route labels it serves')
        if item.get('adapter') not in {'native', 'import_only'}:
            raise ValueError('Market ' + code + ' needs adapter native|import_only')
    return payload


def market_for(payload, route):
    for code, item in payload['markets'].items():
        if route in item['routes']:
            return code, item
    raise ValueError('No market contract serves route ' + str(route))


def _years(cfg):
    start, end = int(cfg.get('year_start') or 0), int(cfg.get('year_end') or 0)
    if not start or end < start:
        return []
    return list(range(start, end + 1))


def check(skill, work, cfg, sources, book_version):
    from .company_routes import route_for
    payload = load(skill)
    by_company = {}
    errors = []
    years = _years(cfg) if cfg.get('mode') == 'filings' else []
    for entry in cfg['roster']:
        company = entry['company_id']
        route, rationale = route_for(entry)
        code, market = market_for(payload, route)
        ready = [source for source in sources.values()
                 if source.get('company_id') == company and source.get('status') == 'ready'
                 and source.get('active', True)]
        # A role is satisfied per fiscal year. A source with no fy cannot satisfy a year.
        per_year = {}
        for fy in years:
            roles = sorted({source.get('document_role') for source in ready
                            if source.get('document_role') and str(source.get('fy')) == str(fy)})
            missing = [role for role in market['required_roles'] if role not in roles]
            per_year[fy] = {'roles': roles, 'missing_roles': missing, 'satisfied': not missing}
        all_roles = sorted({source.get('document_role') for source in ready if source.get('document_role')})
        undated = sorted({source['source_id'] for source in ready if source.get('fy') in (None, '')})
        missing_years = sorted(fy for fy, item in per_year.items() if not item['satisfied'])
        identity_verified = str(entry.get('identity_status') or '') in {'verified', 'confirmed'}
        by_company[company] = {'company': entry['company'], 'route': route, 'route_basis': rationale,
                               'market': code, 'market_label': market['label'],
                               'adapter': market['adapter'],
                               'ready_document_roles': all_roles,
                               'required_roles': market['required_roles'],
                               'per_year': per_year,
                               'missing_years': missing_years,
                               'missing_roles': sorted({role for fy in missing_years
                                                        for role in per_year[fy]['missing_roles']}),
                               'sources_without_fiscal_year': undated,
                               'identity_verified': identity_verified,
                               'fiscal_year_note': market['fiscal_year_note'],
                               'identity_checks': market['identity_checks'],
                               'limits': market['limits'],
                               'satisfied': not missing_years}
        if missing_years and cfg.get('mode') == 'filings' and ready:
            errors.append({'company_id': company,
                           'error': 'Fiscal year(s) ' + ', '.join(str(fy) for fy in missing_years) +
                                    ' lack the market requirement: ' + ', '.join(by_company[company]['missing_roles'])})
    satisfied = sum(1 for item in by_company.values() if item['satisfied'])
    summary = {'companies': len(by_company), 'satisfied': satisfied,
               'unsatisfied': len(by_company) - satisfied,
               'company_years_requested': len(by_company) * len(years),
               'company_years_satisfied': sum(1 for item in by_company.values()
                                              for fy in item['per_year'] if item['per_year'][fy]['satisfied']),
               'markets_in_use': sorted({item['market'] for item in by_company.values()}),
               'native_adapters': sorted({item['market'] for item in by_company.values()
                                          if item['adapter'] == 'native'}),
               'grain': 'one requirement row per company x fiscal year' if cfg.get('mode') == 'filings' else 'event source routing; coverage is checked by search_coverage',
               'boundary': 'A satisfied contract means the required document roles are registered and ready for that '
                           'year, not that every figure inside them has been extracted.'}
    record = contracts.record(work, 'market_routes', {'by_company': by_company, 'summary': summary},
                              skill, book_version)
    return {'pass': True, **summary, 'companies_detail': list(by_company.values()),
            'record_sha256': record['record_sha256']}


def gate(skill, work, cfg, book_version):
    if 'market_routes' not in contracts.active(skill, cfg):
        return [], []
    try:
        payload = contracts.require_record(skill, work, 'market_routes', book_version)
    except (ValueError, OSError) as exc:
        return [{'contract': 'market_routes', 'reason': 'not_recorded', 'detail': str(exc),
                 'expects': 'one row per roster company x fiscal year stating satisfied roles'}], []
    gaps = []
    for company, item in payload.get('by_company', {}).items():
        per_year = {str(key): value for key, value in (item.get('per_year') or {}).items()}
        for fy in item.get('missing_years') or []:
            gaps.append({'contract': 'market_routes', 'reason': 'market_requirement_unmet',
                         'company_id': company, 'fy': fy,
                         'missing_roles': (per_year.get(str(fy)) or {}).get('missing_roles')})
        if cfg.get('mode') == 'filings' and item.get('sources_without_fiscal_year'):
            gaps.append({'contract': 'market_routes', 'reason': 'source_fiscal_year_unknown', 'company_id': company,
                         'example': item['sources_without_fiscal_year'][:3],
                         'expects': 'every ready source assigned to a fiscal year'})
    return gaps, []
