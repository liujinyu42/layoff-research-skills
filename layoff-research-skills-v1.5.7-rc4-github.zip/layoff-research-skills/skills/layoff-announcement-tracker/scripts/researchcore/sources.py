"""Immutable source snapshots and incremental text delivery, without semantic extraction.

Document content is data. This module never executes instructions found in a source.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

MAX_BYTES = 25 * 1024 * 1024
ALLOWED_TYPES = {
    "company_announcement", "sec_filing", "exchange_filing", "news",
    "layoffs_fyi", "company_profile", "company_annual_report", "warn", "company_registry", "company_disclosure",
}
OPTIONAL_FIELDS = (
    "source_url", "local_path", "document_role", "fy", "plan_id",
    "publication_date", "source_date", "exchange", "form", "target_fy_basis", "target_fy_status", "accession", "period",
)


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _slug(source_id: str) -> str:
    stem = re.sub(r"[^A-Za-z0-9_-]", "_", source_id)[:60] or "source"
    return stem + "-" + _sha(source_id.encode())[:12]


def _load_manifest(path: Path) -> tuple[list[dict], str]:
    raw = path.read_bytes()
    text = raw.decode("utf-8-sig")
    if path.suffix.lower() == ".csv":
        csv.field_size_limit(max(csv.field_size_limit(), 2**31 - 1))
        rows = list(csv.DictReader(io.StringIO(text)))
    elif text.lstrip().startswith("["):
        rows = json.loads(text)
    else:
        rows = [json.loads(line) for line in text.splitlines() if line.strip()]
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Source manifest must contain objects")
    return rows, _sha(raw)


def _roster(work: Path) -> set[str]:
    config = json.loads((work / "config.json").read_text(encoding="utf-8"))
    roster = config.get("roster")
    if not isinstance(roster, list):
        raise ValueError("config.json must contain roster list")
    ids = [str(row.get("company_id", "")) if isinstance(row, dict) else str(row) for row in roster]
    if any(not value for value in ids) or len(ids) != len(set(ids)):
        raise ValueError("Roster contains empty or duplicate company_id")
    return set(ids)


def _validate(rows: list[dict], company_ids: set[str]) -> list[dict]:
    seen = set()
    result = []
    for index, raw in enumerate(rows, 1):
        row = dict(raw)
        for field in ("source_id", "company_id", "source_type"):
            if not isinstance(row.get(field), str) or not row[field].strip():
                raise ValueError(f"Source row {index}: {field} required as text")
            row[field] = row[field].strip()
        if row["source_id"] in seen:
            raise ValueError("Duplicate source_id: " + row["source_id"])
        seen.add(row["source_id"])
        if row["company_id"] not in company_ids:
            raise ValueError("Unknown company_id: " + row["company_id"])
        if row["source_type"] not in ALLOWED_TYPES:
            raise ValueError("Unsupported source_type: " + row["source_type"])
        for field in OPTIONAL_FIELDS:
            row.setdefault(field, "")
        if row["fy"] not in (None, ""):
            try:
                value = int(row["fy"])
            except (ValueError, TypeError) as exc:
                raise ValueError(f"Source row {index}: fy must be an integer") from exc
            if isinstance(row["fy"], float) and row["fy"] != value:
                raise ValueError(f"Source row {index}: fy must be an integer")
            row["fy"] = value
        else:
            row["fy"] = None
        if not row.get("source_url") and not row.get("local_path"):
            # Keep the registered task: absent locations become a failed row in ingest.
            row["local_path"] = ""
        result.append(row)
    return result


def read_sources(work: Path) -> dict[str, dict]:
    path = Path(work) / "sources.json"
    if not path.is_file():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload.get("sources", []) if isinstance(payload, dict) else payload
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise ValueError("Invalid sources ledger")
    if len({row["source_id"] for row in rows}) != len(rows):
        raise ValueError("Duplicate source identity in ledger")
    return {row["source_id"]: row for row in rows}


def _bound_path(work: Path, relative: str) -> Path:
    path = (work / relative).resolve()
    if not path.is_relative_to(work.resolve()):
        raise ValueError("Snapshot path escapes workspace")
    return path


def text_for(work: Path, entry: dict) -> str:
    """Deliver exact normalized text only after raw and text integrity checks."""
    work = Path(work)
    if entry.get("status") != "ready":
        raise ValueError("Source text is not ready: " + str(entry.get("status")))
    raw_path = _bound_path(work, entry["raw_path"])
    text_path = _bound_path(work, entry["text_path"])
    raw = raw_path.read_bytes()
    text_raw = text_path.read_bytes()
    if _sha(raw) != entry["content_sha256"]:
        raise ValueError("Raw source changed: " + entry["source_id"])
    if _sha(text_raw) != entry["text_sha256"]:
        raise ValueError("Normalized source text changed: " + entry["source_id"])
    return text_raw.decode("utf-8")


def _download(url: str) -> tuple[bytes, str]:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("Only explicit http/https source URLs may be fetched")
    headers = {"User-Agent": "LayoffResearchSkills/1.5.7-rc4", "Accept": "text/html,application/pdf,text/plain"}
    hostname = (parsed.hostname or "").lower()
    if hostname == "sec.gov" or hostname.endswith(".sec.gov"):
        agent = os.environ.get("SEC_USER_AGENT", "")
        if not agent or "@" not in agent or not agent.isascii():
            raise ValueError("SEC_USER_AGENT must contain an actual ASCII contact and email")
        headers["User-Agent"] = agent
    import requests
    last = None
    for attempt in range(3):
        try:
            with requests.get(url, headers=headers, timeout=30, stream=True) as response:
                if response.status_code in {429, 500, 502, 503, 504} and attempt < 2:
                    time.sleep(0.5 * (attempt + 1))
                    continue
                response.raise_for_status()
                chunks = []; size = 0
                for chunk in response.iter_content(65536):
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise ValueError("Source exceeds 25 MiB snapshot limit")
                    chunks.append(chunk)
                return b"".join(chunks), response.headers.get("Content-Type", "").split(";", 1)[0].lower()
        except requests.RequestException as exc:
            last = exc
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
    raise ValueError("Source request failed: " + str(last))


def _normalize(raw: bytes, suffix: str, mime: str) -> tuple[str, list[dict], list[int], str]:
    if raw.startswith(b"\x1f\x8b"):
        raise ValueError("Compressed transport bytes require decoding before source normalization; retain the transport original separately")
    if raw.startswith(b"%PDF") or suffix == ".pdf" or mime == "application/pdf":
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(raw)); parts = []; pages = []; visual = []; offset = 0
        for number, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ""
            if not text.strip() and len(page.images):
                visual.append(number)
            if parts:
                parts.append("\n\n"); offset += 2
            pages.append({"page": number, "start": offset, "end": offset + len(text)})
            parts.append(text); offset += len(text)
        text = "".join(parts)
        state = "requires_visual_review" if visual or not text.strip() else "ready"
        return text, pages, visual, state
    if suffix in {".htm", ".html"} or mime == "text/html" or raw.lstrip()[:100].lower().startswith((b"<!doctype html", b"<html")):
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(raw, "html.parser")
        for node in soup(["script", "style", "noscript"]):
            node.decompose()
        return "\n".join(soup.stripped_strings), [], [], "ready"
    if suffix in {".txt", ".md", ".csv"} or mime.startswith("text/"):
        return raw.decode("utf-8-sig"), [], [], "ready"
    if suffix in {".jpg", ".jpeg", ".png", ".tif", ".tiff"} or mime.startswith("image/"):
        return "", [], [1], "requires_visual_review"
    raise ValueError("Unsupported source format: " + (suffix or mime or "unknown"))


def ingest(work: Path, manifest_path: Path, offline: bool = False, refresh: bool = False) -> list[dict]:
    """Snapshot all declared sources; reuse valid unchanged snapshots; retain failed tasks.

    Each source_id identifies a declared source, not an inferred layoff plan. Changing
    company identity under an existing source_id is rejected rather than rematched.
    """
    work = Path(work).resolve(); manifest_path = Path(manifest_path).resolve()
    rows, manifest_sha = _load_manifest(manifest_path)
    rows = _validate(rows, _roster(work))
    old = read_sources(work); output = []
    for row in rows:
        prior = old.get(row["source_id"], {})
        if prior and prior.get("company_id") != row["company_id"]:
            raise ValueError("Existing source_id cannot change company_id: " + row["source_id"])
    for row in rows:
        prior = old.get(row["source_id"], {})
        row_sha = _sha(json.dumps(row, ensure_ascii=False, sort_keys=True).encode())
        current = {**row, "active": True, "manifest_sha256": manifest_sha, "row_sha256": row_sha, "checked_at": _now(), "from_cache": False}
        try:
            local = row.get("local_path")
            raw = None; mime = ""
            if local:
                path = Path(local)
                path = path if path.is_absolute() else manifest_path.parent / path
                if not path.is_file():
                    raise ValueError("Local source is missing: " + str(path))
                if path.stat().st_size > MAX_BYTES:
                    raise ValueError("Source exceeds 25 MiB snapshot limit")
                raw = path.read_bytes(); suffix = path.suffix.lower()
            else:
                suffix = Path(urlparse(row.get("source_url") or "").path).suffix.lower()
                if prior.get("status") == "ready" and prior.get("source_url") == row.get("source_url") and not refresh:
                    text_for(work, prior)
                    raw = _bound_path(work, prior["raw_path"]).read_bytes()
                    mime = prior.get("mime", "")
                else:
                    if offline:
                        raise ValueError("Offline source has no usable current snapshot")
                    if not row.get("source_url"):
                        raise ValueError("Neither local_path nor source_url provided")
                    raw, mime = _download(row["source_url"])
            if len(raw) > MAX_BYTES:
                raise ValueError("Source exceeds 25 MiB snapshot limit")
            content_sha = _sha(raw)
            if prior.get("status") == "ready" and content_sha == prior.get("content_sha256"):
                text_for(work, prior)
                current.update({k: prior[k] for k in ["raw_path", "content_sha256", "text_path", "text_sha256", "n_chars", "page_spans", "visual_pages", "status", "acquired_at", "mime"] if k in prior})
                current["from_cache"] = True
            else:
                slug = _slug(row["source_id"])
                # Content bytes are never overwritten. A changed source gets a new path.
                extension = suffix if re.fullmatch(r"\.[A-Za-z0-9]{1,8}", suffix or "") else ".bin"
                raw_path = work / "raw" / slug / (content_sha + extension)
                raw_path.parent.mkdir(parents=True, exist_ok=True)
                if raw_path.exists() and _sha(raw_path.read_bytes()) != content_sha:
                    raise ValueError("Immutable snapshot path was modified")
                if not raw_path.exists(): raw_path.write_bytes(raw)
                current.update(raw_path=raw_path.relative_to(work).as_posix(), content_sha256=content_sha)
                text, pages, visual, state = _normalize(raw, suffix, mime)
                if state == "ready" and not text.strip():
                    raise ValueError("Source has no extractable text")
                text_raw = text.encode("utf-8")
                text_path = work / "text" / slug / (content_sha + ".txt")
                text_path.parent.mkdir(parents=True, exist_ok=True)
                if text_path.exists() and text_path.read_bytes() != text_raw:
                    raise ValueError("Immutable normalized text path was modified")
                if not text_path.exists(): text_path.write_bytes(text_raw)
                current.update(raw_path=raw_path.relative_to(work).as_posix(), content_sha256=content_sha,
                    text_path=text_path.relative_to(work).as_posix(), text_sha256=_sha(text_raw), n_chars=len(text),
                    page_spans=pages, visual_pages=visual, status=state, acquired_at=_now(), mime=mime)
            if prior and prior.get("content_sha256") != content_sha:
                current["previous_version"] = {k: prior[k] for k in ["content_sha256", "text_sha256", "raw_path", "text_path", "acquired_at"] if k in prior}
        except Exception as exc:  # Per-source parser/request failures remain explicit ledger tasks.
            current.update(status="failed", error=str(exc), acquired_at=None)
            if prior:
                current["previous_version"] = {k: prior[k] for k in ["content_sha256", "text_sha256", "raw_path", "text_path", "acquired_at"] if k in prior}
        output.append(current)
    active_ids = {row["source_id"] for row in rows}
    for source_id, previous in old.items():
        if source_id not in active_ids:
            output.append({**previous, "active": False, "retired_from_manifest": True})
    _write_json(work / "sources.json", {"version": "1.5.0", "manifest_sha256": manifest_sha, "sources": output})
    return output
