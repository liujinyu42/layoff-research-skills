"""Executable separation of generative AI, general AI, automation and cloud.

The Results sheet keeps one narrative cell per construct. This module records, beside it,
what kind of technology the sentence actually describes and how mature it is. A capability
claim therefore needs an operating deployment, not the word AI.

Cues are a reading aid, never the only permission. Three exceptions are executable:

* a reviewed semantic basis for wording the cue list does not happen to contain,
* a reviewed translation for non-English evidence, with the original left untouched,
* an explicit project key so one deployment described twice is not counted twice.
"""
from __future__ import annotations

import csv
import hashlib
import io
import re
from pathlib import Path

from . import contracts

# Variables whose meaning is "AI or new technology". A pure-automation or cloud statement
# belongs in new_tech_adoption, not in an AI field.
AI_ONLY_VARIABLES = ('ai_products', 'ai_integration', 'ai_adoption')
NON_LATIN = re.compile(r'[^\x00-\x7f]')


def _hit(text, cue):
    if not cue:
        return False
    return re.search(r'(?<![a-z0-9])' + re.escape(cue.lower()) + r'(?![a-z0-9])', text.lower()) is not None


def hits(text, cues):
    return [cue for cue in cues or [] if _hit(text, cue)]


def _sentences(text):
    return [part for part in re.split(r'(?<=[.!?;])\s+|\n+', text or '') if part.strip()]


def _scoped_by_one_sentence(text, stage_cues, operating):
    """True when a single sentence carries both the stage qualifier and the operating wording.

    "We use artificial intelligence in a limited pilot in two plants" is a trial, not a
    deployment: the qualifier scopes the verb in the same clause. Requiring a human note here
    would punish exactly the wording that distinguishes a pilot from a rollout, so the record
    states the cue pair instead. Wording split across sentences ("We use AI broadly. We also
    run a pilot.") still needs a human note, because the text does not settle which use the
    trial covers.
    """
    for sentence in _sentences(text):
        low = sentence.lower()
        if any(cue.lower() in low for cue in stage_cues) and any(cue.lower() in low for cue in operating):
            return True
    return False


def validate_contract(contract):
    vocab = contract.get('vocabularies') or {}
    for group in ('technology_class', 'adoption_stage', 'use_context', 'expenditure_scope'):
        if not isinstance(vocab.get(group), dict) or not vocab[group]:
            raise ValueError('Technology contract needs a non-empty ' + group + ' vocabulary')
    for code, item in vocab['technology_class'].items():
        if not isinstance(item.get('is_ai'), bool):
            raise ValueError('Technology class ' + code + ' needs an explicit is_ai flag')
        if not str(item.get('definition', '')).strip():
            raise ValueError('Technology class ' + code + ' needs a definition')
    for code, item in vocab['adoption_stage'].items():
        if not isinstance(item.get('counts_as_capability'), bool):
            raise ValueError('Adoption stage ' + code + ' needs an explicit counts_as_capability flag')
    rules = contract.get('field_rules') or {}
    if not rules:
        raise ValueError('Technology contract needs field_rules')
    for variable, rule in rules.items():
        for code in rule.get('allowed_classes', []):
            if code not in vocab['technology_class']:
                raise ValueError('Field rule ' + variable + ' allows unknown class ' + code)
    return contract


def load(skill):
    return validate_contract(contracts.asset(skill, 'tech_evidence'))


def _span(sources, get_text, source_id, quote, char_start):
    if source_id not in sources:
        raise ValueError('Evidence cites an unregistered source ' + str(source_id))
    if sources[source_id].get('status') != 'ready':
        raise ValueError('Evidence cites a source that is not ready: ' + str(source_id))
    if not isinstance(quote, str) or len(quote.strip()) < 10:
        raise ValueError('Technology evidence needs a verbatim span of at least ten characters')
    text = get_text(source_id)
    if char_start in (None, ''):
        if text.count(quote) != 1:
            raise ValueError('Evidence span is missing or ambiguous; supply char_start')
        start = text.index(quote)
    else:
        start = int(char_start)
        if text[start:start + len(quote)] != quote:
            raise ValueError('Evidence span does not match the bound original source')
    return start, start + len(quote), text


def _cue_text(span, row):
    """Match cues on the span, or on a reviewed translation when the original is not English."""
    translation = str(row.get('translated_quote') or '').strip()
    if NON_LATIN.search(span):
        reviewer = str(row.get('translation_reviewer_id') or '').strip()
        if not translation:
            raise ValueError('non_english_evidence: the cited span is not English; keep the original and supply '
                             'translated_quote plus translation_reviewer_id. Do not rewrite the source')
        if len(translation) < 10 or not reviewer:
            raise ValueError('translation_review: translated_quote needs ten characters and '
                             'translation_reviewer_id before it can support a technology class')
        return translation, 'translation'
    return span, 'original'


def normalize(contract, row, decision, sources, get_text):
    variable = str(row.get('variable') or '').strip()
    rules = contract.get('field_rules') or {}
    if variable not in rules:
        raise ValueError('Variable ' + variable + ' has no technology-evidence rule')
    rule = rules[variable]
    vocab = contract['vocabularies']
    if decision is None:
        raise ValueError('No decision exists for ' + variable + '; record technology evidence only for a decided field')
    if decision.get('status') != 'observed':
        raise ValueError('Technology evidence applies to an observed disclosure; ' + variable +
                         ' is ' + str(decision.get('status')))
    entity = str(row.get('entity_id') or '')
    if entity != decision.get('entity_id'):
        raise ValueError('entity_id disagrees with the bound decision')
    if not row.get('coder_id') or row.get('coder_kind') not in {'human', 'model'}:
        raise ValueError('Technology evidence needs coder_id and coder_kind human|model')
    source_id = row.get('source_id')
    allowed = {item.get('source_id') for item in decision.get('evidence', [])}
    if allowed and source_id not in allowed:
        raise ValueError('Technology evidence must cite a source the underlying decision uses; ' +
                         str(source_id) + ' is not in ' + ', '.join(sorted(allowed)))
    start, end, text = _span(sources, get_text, source_id, row.get('quote'), row.get('char_start'))
    span = text[start:end]

    tech = str(row.get('technology_class') or '').strip()
    if tech not in vocab['technology_class']:
        raise ValueError('technology_class must be one of ' + ', '.join(vocab['technology_class']))
    is_ai = bool(vocab['technology_class'][tech].get('is_ai'))
    if variable in AI_ONLY_VARIABLES and not is_ai:
        raise ValueError('ai_field_requires_ai_class: ' + variable + ' describes AI; ' + tech +
                         ' is not an AI class. Record it under new_tech_adoption instead of an AI field')
    if tech not in rule.get('allowed_classes', []):
        raise ValueError('technology_class ' + tech + ' is outside the allowed classes for ' + variable)
    cue_source, cue_language = _cue_text(span, row)
    class_cues = hits(cue_source, vocab['technology_class'][tech].get('cue_any'))
    semantic = str(row.get('semantic_basis') or '').strip()
    reviewer = str(row.get('second_reviewer_id') or '').strip()
    cue_basis = 'cue'
    if not class_cues:
        if len(semantic) >= 30 and reviewer:
            cue_basis = 'semantic_review'
        else:
            raise ValueError('technology_class ' + tech + ' is not supported by any declared cue inside the cited '
                             'span; either quote the wording that names it, or supply semantic_basis (30+ chars) '
                             'and second_reviewer_id for a reviewed semantic classification')
    if tech == 'generative_ai' and cue_basis == 'cue':
        generative = hits(cue_source, vocab['technology_class']['generative_ai'].get('cue_any'))
        if not generative:
            raise ValueError('generative_ai requires an explicit generative cue or a reviewed semantic basis')
    if is_ai and cue_basis == 'cue':
        ai_cues = [cue for code, item in vocab['technology_class'].items() if item.get('is_ai')
                   for cue in hits(cue_source, item.get('cue_any'))]
        if not ai_cues and not (len(semantic) >= 30 and reviewer):
            raise ValueError('cloud_is_not_ai: the cited span has no AI cue, so it cannot support ' + tech)

    stage = str(row.get('adoption_stage') or '').strip()
    if rule.get('stage_required') and stage not in vocab['adoption_stage']:
        raise ValueError('adoption_stage must be one of ' + ', '.join(vocab['adoption_stage']))
    stage_note = None
    if stage:
        item = vocab['adoption_stage'][stage]
        contradicted = hits(cue_source, item.get('contradicted_by'))
        if contradicted:
            raise ValueError('adoption_stage ' + stage + ' contradicts the cited span (' + contradicted[0] + ')')
        stage_cues = hits(cue_source, item.get('cue_any'))
        operating = [cue for code in ('deployed_internal', 'deployed_customer', 'deployed_both')
                     for cue in hits(cue_source, vocab['adoption_stage'][code].get('cue_any'))]
        note = str(row.get('stage_note') or '').strip()
        if stage in {'planned', 'pilot'}:
            if operating and not stage_cues:
                raise ValueError('adoption_stage ' + stage + ' is contradicted by operating language (' +
                                 operating[0] + ') with no planned/pilot wording; record the actual stage')
            if operating and stage_cues:
                if len(note) >= 20:
                    stage_note = note
                elif _scoped_by_one_sentence(cue_source, stage_cues, operating):
                    stage_note = ('the "' + stage_cues[0] + '" qualifier sits in the same sentence as the operating '
                                  'wording "' + operating[0] + '", so it scopes the use; stage read from the qualifier')
                else:
                    raise ValueError('adoption_stage ' + stage + ' co-occurs with operating language in a separate '
                                     'sentence; explain in stage_note (20+ chars) which part of the span is the plan '
                                     'or the trial')
            elif not stage_cues:
                stage_note = 'stage cue not literal in span; semantic review accepted the stage'
        elif item.get('counts_as_capability') and not stage_cues:
            if not (len(semantic) >= 30 and reviewer):
                raise ValueError('adoption_stage ' + stage + ' needs operating-deployment language inside the cited span')
            stage_note = 'stage supported by reviewed semantic basis, not by a literal deployment cue'
        elif stage == 'retired' and not stage_cues:
            stage_note = 'retirement recorded; confirm the discontinuation wording during self-review'

    context = str(row.get('use_context') or '').strip()
    if rule.get('context_required') and context not in vocab['use_context']:
        raise ValueError('use_context must be one of ' + ', '.join(vocab['use_context']))

    scope = str(row.get('expenditure_scope') or '').strip()
    if rule.get('expenditure_required') and scope not in vocab['expenditure_scope']:
        raise ValueError('expenditure_scope must be one of ' + ', '.join(vocab['expenditure_scope']))

    project = str(row.get('project_id') or '').strip() or None
    return {'entity_id': entity, 'variable': variable, 'technology_class': tech,
            'technology_class_is_ai': is_ai,
            'adoption_stage': stage or None,
            'counts_as_capability': bool(stage and vocab['adoption_stage'][stage].get('counts_as_capability')),
            'use_context': context or None, 'expenditure_scope': scope or None,
            'supports_ai_amount': scope == 'ai_dedicated',
            'source_id': source_id, 'quote': row.get('quote'), 'translated_quote': row.get('translated_quote'),
            'char_start': start, 'char_end': end,
            'quote_sha256': hashlib.sha256(row['quote'].encode()).hexdigest(),
            'cue_observed': class_cues, 'cue_basis': cue_basis, 'cue_language': cue_language,
            'semantic_basis': semantic or None, 'second_reviewer_id': reviewer or None,
            'translation_reviewer_id': str(row.get('translation_reviewer_id') or '').strip() or None,
            'project_id': project, 'stage_note': stage_note,
            'context_unspecified': context == 'unspecified',
            'evidence_basis': str(row.get('evidence_basis') or '').strip() or None,
            'notes': str(row.get('notes') or '').strip() or None,
            'coder_id': row['coder_id'], 'coder_kind': row['coder_kind'],
            'decision_sha256': decision.get('decision_sha256'),
            'contract_version': contract['version'], 'contract_sha256': contracts.digest(contract)}


def _text_accessor(work, sources):
    from .sources import text_for
    cache = {}

    def get_text(source_id):
        if source_id not in sources:
            raise ValueError('Unknown source ' + str(source_id))
        if source_id not in cache:
            cache[source_id] = text_for(Path(work), sources[source_id])
        return cache[source_id]
    return get_text


def _record_key(record):
    return (record['entity_id'], record['variable'], record.get('project_id') or record['quote_sha256'])


def apply(skill, work, path, cfg, sources, accepted, ents, book_version, replace=False):
    """Merge new typing into the existing sidecar. A batch never deletes an earlier batch."""
    contract = load(skill)
    get_text = _text_accessor(work, sources)
    rows = contracts.parse_rows(path)
    existing = {}
    if not replace:
        try:
            previous = contracts.require_record(skill, work, 'tech_evidence', book_version)
            existing = {_record_key(item): item for item in previous.get('records', [])}
        except (ValueError, OSError):
            existing = {}
    errors, records, seen = [], [], set()
    for number, row in enumerate(rows, 1):
        try:
            entity = str(row.get('entity_id') or '')
            if entity not in ents:
                raise ValueError('entity_id is not a registered company-year: ' + entity)
            variable = str(row.get('variable') or '')
            decision = accepted.get(entity + '|' + variable)
            record = normalize(contract, {**row, 'entity_id': entity, 'variable': variable},
                               decision, sources, get_text)
            key = _record_key(record)
            if key in seen:
                raise ValueError('One span may be typed once per variable; conflicting or repeated typing')
            seen.add(key)
            existing[key] = record
        except (ValueError, KeyError, TypeError, OSError) as exc:
            errors.append({'row': number, 'entity_id': row.get('entity_id'),
                           'variable': row.get('variable'), 'error': str(exc)})
    records = [existing[key] for key in sorted(existing, key=lambda item: (item[0], item[1], str(item[2])))]
    report = {'pass': not errors, 'errors': errors, 'submitted': len(rows), 'records': len(records),
              'merged': not replace}
    if errors:
        return report
    payload = {'records': records, 'capability': capability_of(records),
               'coverage': coverage_of(records, accepted, ents, contract)}
    contracts.record(work, 'tech_evidence', payload, skill, book_version)
    report.update({key: value for key, value in payload['coverage'].items()})
    report['capability_units'] = sum(1 for item in records if item['counts_as_capability'])
    return report


def _projects(records):
    """Group typed spans into projects. An explicit project_id wins; otherwise one span is one unit."""
    projects = {}
    for record in records:
        key = (record['entity_id'], record.get('project_id') or record['quote_sha256'])
        unit = projects.setdefault(key, {'entity_id': record['entity_id'],
                                         'project_id': record.get('project_id'),
                                         'technology_classes': set(), 'stages': set(),
                                         'use_contexts': set(),                                          'variables': set(),
                                         'spans': 0, 'stages_conflict': False})
        unit['technology_classes'].add(record['technology_class'])
        unit['stages'].add(record['adoption_stage'] or 'unknown')
        unit['use_contexts'].add(record['use_context'] or 'unspecified')
        unit['variables'].add(record['variable'])
        unit['spans'] += 1
    return projects


def capability_of(records):
    """One project is one unit. Order of input never changes the result."""
    projects = _projects(records)
    table = {}
    stage_rank = {'deployed_both': 4, 'deployed_customer': 3, 'deployed_internal': 3,
                  'pilot': 2, 'planned': 1, 'retired': 0, 'unknown': 0}
    for key in sorted(projects):
        unit = projects[key]
        stages = sorted(unit['stages'])
        resolved = max(stages, key=lambda stage: stage_rank.get(stage, 0))
        unit['stages_conflict'] = len(stages) > 1
        counts = resolved in {'deployed_internal', 'deployed_customer', 'deployed_both'}
        row = table.setdefault(unit['entity_id'], {
            'entity_id': unit['entity_id'], 'units': [], 'capability_units': 0,
            'has_ai_capability': False, 'has_generative_capability': False,
            'has_automation_capability': False, 'has_customer_facing_capability': False,
            'planned_only_units': 0, 'pilot_units': 0, 'unknown_stage_units': 0, 'retired_units': 0,
            'stage_conflicts': 0, 'evidence_spans': 0, 'context_unspecified_units': 0,
            'only_planned_or_pilot': False})
        row['units'].append({'project_id': unit['project_id'], 'stages': stages,
                             'resolved_stage': resolved, 'spans': unit['spans'],
                             'technology_classes': sorted(unit['technology_classes']),
                             'use_contexts': sorted(unit['use_contexts']),
                             'variables': sorted(unit['variables']),
                             'counts_as_capability': counts,
                             'stages_conflict': unit['stages_conflict']})
        row['evidence_spans'] += unit['spans']
        if unit['stages_conflict']:
            row['stage_conflicts'] += 1
        if counts:
            row['capability_units'] += 1
            if 'generative_ai' in unit['technology_classes']:
                row['has_generative_capability'] = True
                row['has_ai_capability'] = True
            if unit['technology_classes'] & {'general_ai_ml', 'unspecified_ai'}:
                row['has_ai_capability'] = True
            if 'automation_robotics' in unit['technology_classes']:
                row['has_automation_capability'] = True
            if 'deployed_customer' in stages or 'deployed_both' in stages:
                row['has_customer_facing_capability'] = True
        elif resolved == 'pilot':
            row['pilot_units'] += 1
        elif resolved == 'planned':
            row['planned_only_units'] += 1
        elif resolved == 'retired':
            row['retired_units'] += 1
        else:
            row['unknown_stage_units'] += 1
        if 'unspecified' in unit['use_contexts']:
            row['context_unspecified_units'] += 1
    for row in table.values():
        row['units'] = sorted(row['units'], key=lambda unit: (str(unit['project_id']), unit['resolved_stage']))
        row['only_planned_or_pilot'] = (row['planned_only_units'] + row['pilot_units'] > 0
                                        and row['capability_units'] == 0
                                        and row['unknown_stage_units'] == 0
                                        and row['retired_units'] == 0)
    return {'by_entity': table, 'records': sorted(records, key=lambda item: (item['entity_id'], item['variable'],
                                                                            item['quote_sha256'])),
            'entities_with_records': len(table),
            'entities_with_ai_capability': sum(1 for row in table.values() if row['has_ai_capability']),
            'entities_with_generative_capability': sum(1 for row in table.values() if row['has_generative_capability']),
            'entities_with_automation_capability': sum(1 for row in table.values() if row['has_automation_capability']),
            'entities_with_customer_facing_capability': sum(1 for row in table.values()
                                                            if row['has_customer_facing_capability']),
            'entities_with_stage_conflict': sum(1 for row in table.values() if row['stage_conflicts']),
            'capability_units': sum(row['capability_units'] for row in table.values()),
            'evidence_spans': sum(row['evidence_spans'] for row in table.values()),
            'planned_only_entities': sum(1 for row in table.values() if row['only_planned_or_pilot']),
            'grain': 'one capability unit per entity x project (or per distinct span when no project_id is given)'}


def coverage_of(records, accepted, ents, contract=None):
    """Every observed field with a technology rule needs a typed record."""
    rules = (contract or {}).get('field_rules') or {}
    variables = sorted(rules) if rules else sorted(AI_ONLY_VARIABLES)
    covered = {(record['entity_id'], record['variable']) for record in records}
    expected = [(entity, variable) for entity in ents for variable in variables
                if (accepted.get(entity + '|' + variable) or {}).get('status') == 'observed']
    missing = [f'{entity}|{variable}' for entity, variable in expected if (entity, variable) not in covered]
    return {'expected_constructs': len(expected), 'typed_constructs': len(covered),
            'untyped_constructs': len(missing), 'untyped_examples': missing[:10],
            'expected_variables': variables}


def gate(skill, work, cfg, accepted, ents, book_version):
    armed = contracts.active(skill, cfg)
    if 'tech_evidence' not in armed:
        return [], []
    gaps, errors = [], []
    contract = load(skill)
    try:
        payload = contracts.require_record(skill, work, 'tech_evidence', book_version)
    except (ValueError, OSError) as exc:
        reason = 'stale_record' if 'stale_record' in str(exc) else 'not_recorded'
        return [{'contract': 'tech_evidence', 'reason': reason, 'detail': str(exc),
                 'expects': 'one typed record for every observed AI/technology construct'}], []
    coverage = coverage_of(payload.get('records', []), accepted, ents, contract)
    if coverage['untyped_constructs']:
        gaps.append({'contract': 'tech_evidence', 'reason': 'untyped_disclosure',
                     'count': coverage['untyped_constructs'],
                     'example': coverage.get('untyped_examples', [])[:5],
                     'expects': 'a technology class and adoption stage for every observed field with a rule'})
    stale = [item['entity_id'] + '|' + item['variable'] for item in payload.get('records', [])
             if item.get('contract_version') != contract['version']]
    if stale:
        gaps.append({'contract': 'tech_evidence', 'reason': 'contract_version_changed',
                     'count': len(stale), 'example': stale[:5],
                     'expects': 'evidence recomputed against the shipped vocabulary'})
    for item in payload.get('records', []):
        if item.get('technology_class') == 'generative_ai' and item.get('cue_basis') == 'cue' \
                and not item.get('cue_observed'):
            errors.append({'variable': item['variable'], 'error': 'Generative AI recorded without a generative cue'})
        if item.get('cue_basis') == 'semantic_review' and not item.get('second_reviewer_id'):
            errors.append({'variable': item['variable'], 'error': 'Semantic classification needs a second reviewer'})
        if item.get('variable') in AI_ONLY_VARIABLES and not item.get('technology_class_is_ai'):
            errors.append({'variable': item['variable'], 'error': 'An AI field carries a non-AI technology class'})
    for entity, row in (payload.get('capability') or {}).get('by_entity', {}).items():
        if row.get('stage_conflicts'):
            gaps.append({'contract': 'tech_evidence', 'reason': 'stage_conflict', 'entity_id': entity,
                         'count': row['stage_conflicts'],
                         'expects': 'one resolved stage per project, or a recorded explanation for the conflict'})
    return gaps, errors


def export_csv(skill, work, path, book_version):
    payload = contracts.require_record(skill, work, 'tech_evidence', book_version)
    rows = []
    for record in payload.get('records', []):
        rows.append({'entity_id': record['entity_id'], 'variable': record['variable'],
                     'project_id': record.get('project_id') or '',
                     'technology_class': record['technology_class'],
                     'is_ai': 'yes' if record['technology_class_is_ai'] else 'no',
                     'adoption_stage': record['adoption_stage'] or '',
                     'counts_as_capability': 'yes' if record['counts_as_capability'] else 'no',
                     'use_context': record['use_context'] or '',
                     'expenditure_scope': record['expenditure_scope'] or '',
                     'supports_ai_amount': 'yes' if record['supports_ai_amount'] else 'no',
                     'cue_basis': record.get('cue_basis'), 'cue_language': record.get('cue_language'),
                     'cue_observed': ';'.join(record['cue_observed']),
                     'quote_sha256': record['quote_sha256'],
                     'char_start': record['char_start'], 'char_end': record['char_end']})
    path = Path(path)
    contracts.mkdir(path.parent)
    buffer = io.StringIO()
    fields = ['entity_id', 'variable', 'project_id', 'technology_class', 'is_ai', 'adoption_stage',
              'counts_as_capability', 'use_context', 'expenditure_scope', 'supports_ai_amount',
              'cue_basis', 'cue_language', 'cue_observed', 'quote_sha256', 'char_start', 'char_end']
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)
    path.write_text(buffer.getvalue(), encoding='utf-8')
    return {'output': str(path), 'rows': len(rows), 'grain': 'one row per typed technology claim'}
