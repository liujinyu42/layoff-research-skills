"""Register SEC originals independently from extraction success.

The engine proposes values; neither a download nor its legacy ``verified``
label is a new semantic judgment. Proxy report dates may be meeting dates.
"""
from __future__ import annotations

import csv
import hashlib
import os
import re
import sqlite3
import subprocess
import sys
import warnings
from collections import Counter, defaultdict
from pathlib import Path

from .workflow import load, save, rows

ANNUAL_FORMS = {"10-K", "10-K/A", "20-F", "20-F/A"}
PROXY_FORMS = {"DEF 14A", "DEF 14A/A", "DEFM14A"}
MANIFEST_FIELDS = {
    "source_id", "company_id", "source_type", "source_url", "local_path",
    "document_role", "fy", "plan_id", "publication_date", "source_date",
    "exchange", "form", "accession", "period", "target_fy_basis",
    "target_fy_status", "target_fy_evidence", "origin",
}


def engine_root(skill):
    for path in [skill / "scripts/vendor", skill.parents[1] / "engine"]:
        if (path / "skills/layoff-hcm-tracker/scripts/track.py").is_file():
            return path
    raise ValueError("Bundled SEC engine missing; reinstall this skill")


def _read_rows(path):
    return rows(path) if Path(path).is_file() else []


def _html(path):
    if not path or not Path(path).is_file():
        return ""
    return Path(path).read_text(encoding="utf-8", errors="replace")


def _soup(html):
    from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", XMLParsedAsHTMLWarning)
        return BeautifulSoup(html, "lxml")


def _clean(value):
    return re.sub(r"\s+", " ", value.replace("\u200b", "")).strip()


def _year(value):
    try:
        value = int(value)
        return value if 1900 <= value <= 2100 else None
    except (ValueError, TypeError):
        return None


def _annual_year(filing, html, anchors):
    """Use annual document FY/selected annual period, not publication year."""
    if html:
        values = {_year(tag.get_text(strip=True)) for tag in _soup(html).find_all(
            attrs={"name": re.compile(r"(?:^|:)DocumentFiscalYearFocus$", re.I)})}
        values.discard(None)
        if len(values) == 1:
            return next(iter(values)), "dei:DocumentFiscalYearFocus"
    anchor_years = anchors.get(filing["accession"], set())
    if len(anchor_years) == 1:
        return next(iter(anchor_years)), "selected_annual_period"
    period = str(filing.get("period") or "")
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", period):
        year = int(period[:4])
        if period[5:7] == "01" and int(period[8:10]) <= 10:
            year -= 1
        return year, "annual_report_period"
    return None, "annual_fiscal_year_unresolved"


def _proxy_year(filing, html, neo_rows):
    """Find principal SCT year without requiring a parsed pay amount.

    The latest explicit SCT row year is principal. Historical comparisons in a
    later proxy never automatically attach that source to earlier company-years.
    A researcher can explicitly register an older-year correction as a source.
    """
    if html:
        soup = _soup(html)
        table_years = set()
        for table in soup.find_all("table"):
            text = _clean(table.get_text(" ", strip=True))
            if len(text) > 60000 or not all(re.search(pattern, text, re.I) for pattern in
                    (r"\bsalary\b", r"\b(?:stock awards|bonus)\b", r"\byear\b", r"\btotal\b")):
                continue
            header_seen = False
            for tr in table.find_all("tr"):
                cells = [_clean(c.get_text(" ", strip=True)) for c in tr.find_all(["td", "th"], recursive=False)]
                cells = [c for c in cells if c and c != "$"]
                if any(re.fullmatch(r"(?:fiscal\s+)?year(?:\s*\(\d+\))?", c, re.I) for c in cells):
                    header_seen = True
                    continue
                if header_seen:
                    years = [int(c[:4]) for c in cells if re.fullmatch(r"20\d{2}(?:\s*\(\d+\))?", c)]
                    if len(years) == 1:
                        table_years.add(years[0])
        if table_years:
            value = max(table_years)
            return value, "explicit_sct_year_column", {"principal_year": value, "comparison_years": sorted(table_years - {value})}
        text = _clean(soup.get_text(" ", strip=True))
        headings = list(re.finditer(r"\b(20\d{2})\s+Summary Compensation Table\b", text, re.I))
        if headings:
            value = max(int(m.group(1)) for m in headings)
            return value, "explicit_sct_heading", {"quote": next(m.group(0) for m in headings if int(m.group(1)) == value)}
        # Some older proxies use positioned divs instead of HTML tables. Read
        # the SCT's explicit period sentence, never a nearby filing/meeting year.
        periods = []
        for heading in re.finditer(r"\bSummary Compensation Table\b", text, re.I):
            scope = text[heading.end():heading.end() + 1200]
            if not re.search(r"following table.{0,180}compensation", scope, re.I):
                continue
            match = re.search(r"(?:fiscal\s+)?years?\s+ended\s+(?:[A-Za-z]+\s+\d{1,2},?\s*)?(20\d{2})\b", scope, re.I)
            if match:
                periods.append((int(match.group(1)), match.group(0)))
        if periods:
            value, quote = max(periods)
            return value, "explicit_sct_period_sentence", {"quote": quote}
    # A stale CSV or its status label is insufficient: fallback rows must bind
    # to the current source bytes, and still do not confirm any money amount.
    if html:
        source_sha = hashlib.sha256(html.encode()).hexdigest()
        years = {_year(r.get("fy")) for r in neo_rows if r.get("accession") == filing["accession"]
                 and r.get("source_sha256") == source_sha}
        years.discard(None)
        if years:
            value = max(years)
            return value, "source_bound_sct_rows", {"principal_year": value}
    return None, "proxy_target_requires_review", {}


def inventory_sources(work, cfg):
    """Return all in-scope annual/proxy sources and unresolved mapping tasks."""
    work = Path(work).resolve()
    engine_work = work / "sec"
    database = engine_work / "state/state.db"
    if not database.is_file():
        raise ValueError("SEC inventory database missing")
    db = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)
    db.row_factory = sqlite3.Row
    try:
        filings = [dict(row) for row in db.execute("SELECT * FROM filings ORDER BY cik,filed,accession")]
    finally:
        db.close()
    roster = {str(r["cik"]).zfill(10): r["company_id"] for r in cfg["roster"] if r.get("cik")}
    anchors = defaultdict(set)
    for row in load(engine_work / "panel/panel_meta.json", {}).get("company_periods", []):
        year = _year(row.get("fy"))
        if year is not None:
            anchors[row["accession"]].add(year)
    neo_rows = _read_rows(engine_work / "review/neo_verified.csv")
    manifest, pending, ignored = [], [], []
    for filing in filings:
        cik = str(filing.get("cik") or "").zfill(10)
        form = filing.get("form")
        if cik not in roster or form not in ANNUAL_FORMS | PROXY_FORMS:
            continue
        path = engine_work / filing["path"] if filing.get("path") else None
        original = _html(path)
        if form in ANNUAL_FORMS:
            fy, basis = _annual_year(filing, original, anchors)
            proof, role = {"period": filing.get("period")}, "annual_report"
        else:
            fy, basis, proof = _proxy_year(filing, original, neo_rows)
            role = "proxy"
        if fy is None:
            pending.append({"company_id": roster[cik], "cik": cik, "accession": filing["accession"],
                            "form": form, "filed": filing.get("filed"), "period": filing.get("period"),
                            "reason": basis, "local_path": str(path.resolve()) if path else "",
                            "action": "Read target fiscal year in original and register an explicit source mapping; publication/report meeting year is not target FY."})
            continue
        if not cfg["year_start"] <= fy <= cfg["year_end"]:
            ignored.append({"accession": filing["accession"], "fy": fy, "reason": "outside_requested_fiscal_years"})
            continue
        acc = filing["accession"]
        manifest.append({"source_id": "sec-" + acc + "-" + str(fy), "company_id": roster[cik],
                         "source_type": "sec_filing", "document_role": role, "fy": fy, "form": form,
                         "source_url": f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace('-', '')}/{filing['primary_doc']}",
                         "local_path": str(path.resolve()) if path else str((engine_work / "missing" / acc).resolve()),
                         "publication_date": filing.get("filed", ""), "exchange": "SEC", "accession": acc,
                         "period": filing.get("period", ""), "target_fy_status": "identified_from_source",
                         "target_fy_basis": basis, "target_fy_evidence": proof, "origin": "sec_inventory"})
    return manifest, pending, ignored, neo_rows


def review_candidates(candidate_rows, manifest, neo_rows):
    """Expose scope errors and SCT conflicts; never silently resolve values."""
    allowed = {(str(r["source_url"]).split("/data/")[1].split("/")[0].zfill(10), int(r["fy"]), r["accession"])
               for r in manifest}
    active, quarantined, issues = [], [], []
    for raw in candidate_rows:
        row = dict(raw)
        fy, cik = _year(row.get("fy")), str(row.get("cik") or "").zfill(10)
        accession = row.get("accession")
        if accession and (cik, fy, accession) not in allowed:
            quarantined.append({**row, "candidate_status": "source_not_mapped_to_target_year"})
            issues.append({"cik": cik, "fy": fy, "variable": row.get("var_id"), "accession": accession,
                           "reason": "candidate_source_outside_target_inventory", "action": "Re-read target-year source; do not adopt a future proxy comparative value automatically."})
        else:
            active.append({**row, "candidate_status": "unreviewed_candidate"})
        if row.get("var_id") == "ceo_total_comp" and row.get("value") not in (None, ""):
            alternatives = [r for r in neo_rows if str(r.get("cik", "")).zfill(10) == cik and _year(r.get("fy")) == fy
                            and re.search(r"chief executive|\bCEO\b", r.get("name_title", ""), re.I)
                            and str(r.get("arithmetic_pass")).lower() in {"1", "true"}
                            and (cik, fy, r.get("accession")) in allowed]
            try:
                differing = [r for r in alternatives if abs(float(r["total"]) - float(row["value"])) > 1]
            except (ValueError, TypeError, KeyError):
                differing = []
            if differing:
                issues.append({"cik": cik, "fy": fy, "variable": "ceo_total_comp", "reason": "candidate_conflict_with_named_sct_row",
                               "candidate_value": row["value"], "candidate_accession": accession,
                               "alternatives": [{k: r.get(k) for k in ("accession", "name_title", "total", "salary", "stock_awards", "all_other", "quote")} for r in differing],
                               "action": "Adjudicate named executive, target year, SCT versus CAP, and component arithmetic in original table."})
    return active, quarantined, issues


def sec_prepare(skill, work, offline=None, cache_only=False):
    skill, work = Path(skill), Path(work)
    cfg = load(work / "config.json")
    if cfg["mode"] != "filings":
        raise ValueError("SEC annual candidate extraction belongs to listed-filing-extractor; event source URLs use sync")
    if offline and cache_only:
        raise ValueError("Choose offline fixture discovery or cache-only existing workspace")
    roster = [r for r in cfg["roster"] if r.get("cik")]
    excluded = [r["company_id"] for r in cfg["roster"] if not r.get("cik")]
    if not roster:
        from .company_routes import source_plan
        source_plan(skill, work)
        return {"status": "official_source_route", "sources": 0, "companies_without_cik": excluded,
                "next": "Use source-plan; identify CIK if appropriate or discover official issuer/local reports, then sync. No SEC request was made; no missing value was classified as zero."}
    if len({r["cik"] for r in roster}) != len(roster):
        raise ValueError("Multiple company IDs share a CIK; reconcile identities first")
    scripts = engine_root(skill) / "skills/layoff-hcm-tracker/scripts"
    engine_work, inp = work / "sec", work / "input"
    inp.mkdir(parents=True, exist_ok=True)
    companies = inp / "sec-companies.csv"
    with companies.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["cid", "cik", "company", "ticker"])
        writer.writeheader()
        writer.writerows({"cid": i, "cik": r["cik"], "company": r["company"], "ticker": r.get("ticker", "")} for i, r in enumerate(roster, 1))
    commands = []
    if not (engine_work / "config/companies.csv").is_file():
        commands.append([str(scripts / "track.py"), "init", "--work", str(engine_work), "--companies", str(companies)])
    years = str(cfg["year_start"]) + ":" + str(cfg["year_end"])
    if not cache_only:
        commands.append([str(scripts / "track.py"), "fetch", "--work", str(engine_work), "--years", years] + (["--offline", str(Path(offline).resolve())] if offline else []))
    commands.extend([[str(scripts / "track.py"), "extract", "--work", str(engine_work)],
                     [str(scripts / "track.py"), "build", "--work", str(engine_work), "--years", years],
                     [str(scripts / "track.py"), "verify", "--work", str(engine_work)],
                     [str(scripts / "review.py"), "--work", str(engine_work)]])
    logs = work / "qa/sec-logs"
    logs.mkdir(parents=True, exist_ok=True)
    for i, cmd in enumerate(commands):
        target = logs / (str(i) + "-" + Path(cmd[0]).stem + ".log")
        env = dict(os.environ)
        env.pop("PYTHONPATH", None)
        with target.open("w") as f:
            result = subprocess.run([sys.executable, *cmd], stdout=f, stderr=subprocess.STDOUT, env=env)
        if result.returncode:
            save(work / "qa/sec-status.json", {"status": "failed", "log": str(target), "exit_code": result.returncode})
            raise ValueError("SEC collection/extraction incomplete; see " + str(target))
    manifest, pending, ignored, neo_rows = inventory_sources(work, cfg)
    from .sources import read_sources, ingest
    new_ids = {r["source_id"] for r in manifest}
    preserved = [{k: v for k, v in source.items() if k in MANIFEST_FIELDS}
                 for source in read_sources(work).values()
                 if source.get("active", True) and source.get("origin") != "sec_inventory" and source["source_id"] not in new_ids]
    path = inp / "sec-source-manifest.json"
    save(path, preserved + manifest)
    ingest(work, path, offline=True)
    candidates = _read_rows(engine_work / "review/research_long.csv") or _read_rows(engine_work / "panel/panel_long.csv")
    active, quarantined, issues = review_candidates(candidates, manifest, neo_rows)
    save(work / "review/sec-candidates.json", {"status": "candidates_only_not_reviewed", "rows": active,
         "quarantined_rows": quarantined, "issues": issues,
         "note": "Inventory and candidate labels do not confirm semantic accuracy. Re-read original, target FY, units and scope. Historical proxy comparisons require explicit source mapping."})
    save(work / "qa/sec-source-inventory.json", {"status": "targeting_review_needed" if pending else "inventory_ready",
         "sources": len(manifest), "by_role": dict(Counter(r["document_role"] for r in manifest)),
         "unmapped_filings": pending, "outside_requested_years": ignored, "candidate_issues": issues,
         "note": "No value was required to register an annual/proxy original. Missing files remain failed snapshot tasks."})
    save(work / "qa/sec-status.json", {"status": "candidates_ready", "filing_sources": len(manifest),
         "companies_without_cik": excluded, "unmapped_filing_targets": len(pending), "candidate_issues": len(issues),
         "quarantined_candidates": len(quarantined),
         "native_forms": ["10-K", "10-K/A", "20-F", "20-F/A", "DEF 14A", "DEF 14A/A", "8-K", "6-K"],
         "40_F": "use explicit official source manifest; native annual anchoring is not claimed", "engine_version": "0.8.3"})
    return {"sources": len(manifest), "candidates": len(active), "quarantined_candidates": len(quarantined),
            "targeting_tasks": len(pending), "companies_without_cik": excluded,
            "next": "Resolve source targeting tasks; prepare/next; read current group only. Candidates do not complete semantic review."}
