"""Source-linked review leads, never automatic semantic codes or monetary values."""
import re
from pathlib import Path

RULES = {
 'rd_expense': r'research\s+and\s+development\s+(?:expenses?|costs?).{0,170}?(?:were|was|amounted).{0,400}',
 'new_tech_adoption': r'(?:we|the company).{0,100}?(?:utiliz\w*|architect\w*|run|deploy\w*|use).{0,220}?(?:cloud|AWS|robot\w*|automat\w*).{0,200}',
 'ai_risk_disclosure': r'[^.\n]{0,170}\b(?:generative (?:AI|artificial intelligence)|AI-generated|artificial intelligence)[^.\n]{0,250}',
}


def hints_for(work,source,variable):
    from .workflow import load,save
    from .sources import text_for
    variable=variable.removesuffix('_disclosed')
    if variable not in RULES or source.get('status')!='ready':return []
    cache=Path(work)/'review/semantic-index'/(source['text_sha256']+'-v2.json')
    index=load(cache)
    if index is None:
        text=text_for(Path(work),source)
        index={key:[{'quote':m.group(0),'char_start':m.start(),'char_end':m.end()}for m in list(re.finditer(pattern,text,re.I|re.S))[:8]]for key,pattern in RULES.items()}
        save(cache,index)
    return [{**item,'source_id':source['source_id'],'text_sha256':source['text_sha256'],
             'review_question':{'rd_expense':'Check the literal R&D expense label, target year and scale. A mixed technology operating line may be a different measure.',
                'new_tech_adoption':'Check actual operational use. Established use may qualify without a first-adoption date, but cloud alone does not establish AI.',
                'ai_risk_disclosure':'Collect all distinct AI-specific risks across applicable sections; do not stop at the first competition passage. A mention alone is not automatically a risk.'}[variable]}
            for item in index.get(variable,[])]
