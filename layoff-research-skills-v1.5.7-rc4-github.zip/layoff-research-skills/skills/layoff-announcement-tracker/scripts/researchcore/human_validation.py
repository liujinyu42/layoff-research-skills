"""Blind human annotation, agreement metrics and explicit validation status.

Four things stay apart on purpose:

* the annotation template an independent coder fills in,
* the frozen model payload it is compared with, byte for byte,
* the split assignment, fixed at freeze time and never reassigned silently,
* the evaluation, appended to a log instead of overwriting the previous one.

The module never upgrades a self-review into reliability. If no human file exists the status
is ``not_executed`` and that is the complete answer.

Metric families are scored separately and only on the held-out split: status, binary
disclosure code, numeric value and reason label set. Two coders agreeing that a field is
``observed`` says nothing about whether they assigned the same reasons.
"""
from __future__ import annotations

import csv
import datetime
import io
import json
from collections import Counter
from pathlib import Path

from . import contracts

FAMILIES = ('status', 'binary', 'value', 'reason_labels')
SETTINGS = ('observed', 'reviewed_absent', 'not_separate', 'not_applicable', 'unresolved', 'not_reviewed')


def load(skill):
    payload = contracts.asset(skill, 'human_validation')
    levels = payload.get('status_levels') or {}
    for required in ('not_executed', 'seed_only', 'development_only', 'holdout_evaluated'):
        if required not in levels:
            raise ValueError('Human validation contract needs the ' + required + ' status')
    if not payload.get('annotation_columns'):
        raise ValueError('Human validation contract needs annotation_columns')
    return payload


def _write(path, rows, fields):
    path = Path(path)
    contracts.mkdir(path.parent)
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fields, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)
    path.write_text(buffer.getvalue(), encoding='utf-8')
    return str(path)


def _keys(accepted):
    return sorted(accepted)


def _group(key):
    """Split unit. Fields of one company-year or one plan never straddle two splits."""
    stem = str(key).split('|')[0]
    return stem.split(':')[0] if ':' in stem else stem


def assign_splits(contract, accepted):
    """Deterministic group-level assignment, stable under reordering and additions.

    Grouping prevents the leakage that per-field assignment creates: the forty-three fields of
    one plan come from the same document, so they cannot be half development and half held out.
    """
    design = contract['design']
    groups = {}
    for key in _keys(accepted):
        groups.setdefault(_group(key), []).append(key)
    ordered = sorted(groups, key=lambda group: (contracts.digest({'g': group}), group))
    total = len(ordered)
    seed_n = round(total * design['seed_share'])
    holdout_n = round(total * design['holdout_share'])
    if total >= 3:
        seed_n = max(1, seed_n)
        holdout_n = max(1, holdout_n)
    development_n = max(total - seed_n - holdout_n, 0)
    splits = {}
    for index, group in enumerate(ordered):
        if index < seed_n:
            name = 'seed'
        elif index < seed_n + development_n:
            name = 'development'
        else:
            name = 'holdout'
        for key in groups[group]:
            splits[key] = name
    return splits


def template(skill, work, path, accepted, split=None):
    contract = load(skill)
    splits = assign_splits(contract, accepted) if accepted else {}
    fields = contract['annotation_columns']
    rows = []
    for key in _keys(accepted):
        if split and splits.get(key) != split:
            continue
        rows.append({'record_key': key, 'variable': accepted[key]['variable'], 'human_status': '',
                     'human_value': '', 'human_codes': '', 'annotator_id': '', 'annotation_round': '',
                     'coded_at': '', 'confidence': '', 'notes': ''})
    output = _write(path, rows, fields)
    return {'output': output, 'rows': len(rows), 'split': split or 'all',
            'splits': {name: sum(1 for value in splits.values() if value == name)
                       for name in ('seed', 'development', 'holdout')} if splits else {},
            'instructions': 'Leave human_status blank unless the coder made a judgment. Use the same status '
                            'vocabulary as the decision record. Do not open the model predictions file.'}


def _canonical(rows):
    """Byte-stable representation of the prediction payload, independent of row order."""
    ordered = sorted(rows, key=lambda row: str(row.get('record_key')))
    return json.dumps(ordered, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def blind_predictions(skill, work, path, accepted, book_version):
    """Freeze the model payload before any annotation is read.

    The freeze stores the exact rows, the codebook identity, the split assignment and the
    source fingerprint. A later evaluation recomputes the payload and refuses to proceed when
    a single value moved, so keeping the keys is not enough to reuse a frozen file.
    """
    contract = load(skill)
    fields = ['record_key', 'variable', 'model_status', 'model_value', 'model_codes']
    rows = []
    for key in _keys(accepted):
        decision = accepted[key]
        rows.append({'record_key': key, 'variable': decision['variable'],
                     'model_status': decision['status'],
                     'model_value': '' if decision.get('value') is None else decision['value'],
                     'model_codes': ''})
    codebook_sha = None
    try:
        reason = contracts.require_record(skill, work, 'reason_codebook', book_version)
        coding = {item['plan_id']: item for item in reason.get('records', [])}
        codebook_sha = contracts.asset_sha(skill, 'reason_codebook')
        for row in rows:
            plan, _, variable = row['record_key'].partition('|')
            if variable == 'stated_reason_text' and plan in coding:
                row['model_codes'] = ';'.join(label['code'] for label in coding[plan]['labels'])
    except (ValueError, OSError):
        pass
    output = _write(path, rows, fields)
    splits = assign_splits(contract, accepted)
    payload = {'predictions_path': output, 'recorded_at': contracts.now(), 'rows': len(rows),
               'book_version': book_version, 'record_keys': [row['record_key'] for row in rows],
               'predictions_sha256': contracts.digest(_canonical(rows)),
               'predictions': rows,
               'human_contract_sha256': contracts.asset_sha(skill, 'human_validation'),
               'codebook_sha256': codebook_sha,
               'splits': splits, 'splits_sha256': contracts.digest(splits),
               'source_fingerprint': contracts.fingerprint(work),
               'experiment': 'main'}
    contracts.write_json(Path(work) / 'measurement' / 'human_predictions.json', payload)
    return {'output': output, 'rows': len(rows), 'recorded_at': payload['recorded_at'],
            'predictions_sha256': payload['predictions_sha256'],
            'note': 'Compare only after the human file exists. Re-exporting after annotation invalidates blindness.'}


def _read(path):
    return contracts.parse_rows(path)


def cohen_kappa(first, second):
    """Nominal kappa for two coders over the same, aligned record set."""
    if len(first) != len(second) or not first:
        return None
    n = len(first)
    observed = sum(1 for a, b in zip(first, second) if a == b) / n
    left, right = Counter(first), Counter(second)
    expected = sum(left[label] * right[label] for label in set(left) | set(right)) / (n * n)
    if expected >= 1:
        return None
    return round((observed - expected) / (1 - expected), 6)


def krippendorff_alpha(units):
    """Nominal alpha with missing values. units is a list of per-coder label lists."""
    usable = [[value for value in unit if value not in (None, '')] for unit in units]
    usable = [unit for unit in usable if len(unit) >= 2]
    if not usable:
        return None
    total = sum(len(unit) for unit in usable)
    observed = 0.0
    for unit in usable:
        counts = Counter(unit)
        disagreements = sum(count * (len(unit) - count) for count in counts.values())
        observed += disagreements / (len(unit) - 1)
    observed /= total
    pooled = Counter(value for unit in usable for value in unit)
    expected = sum(pooled[a] * pooled[b] for a in pooled for b in pooled if a != b)
    if expected == 0:
        return None
    expected = expected / (total * (total - 1))
    if expected == 0:
        return None
    return round(1 - observed / expected, 6)


def _class_metrics(pairs, minimum):
    """Per-label precision/recall/F1 on ``(predicted, human)`` pairs.

    Labels that only the model predicted are included, because dropping them hides the false
    positives. ``support`` counts human instances; ``predicted`` counts model instances. A
    defined F1 of zero stays zero instead of becoming null.
    """
    labels = sorted({label for pair in pairs for label in pair if label})
    table = {}
    for label in labels:
        tp = sum(1 for pair in pairs if label in pair[0] and label in pair[1])
        fp = sum(1 for pair in pairs if label in pair[0] and label not in pair[1])
        fn = sum(1 for pair in pairs if label in pair[1] and label not in pair[0])
        precision = round(tp / (tp + fp), 6) if tp + fp else None
        recall = round(tp / (tp + fn), 6) if tp + fn else None
        if precision is None or recall is None:
            f1 = None
        else:
            f1 = 0.0 if precision + recall == 0 else round(2 * precision * recall / (precision + recall), 6)
        table[label] = {'precision': precision, 'recall': recall, 'f1': f1,
                        'support': tp + fn, 'predicted': tp + fp,
                        'meets_minimum': (tp + fn) >= minimum,
                        'false_negatives': fn, 'false_positives': fp}
    return table


def _status_matrix(pairs):
    """Rows are the human status, columns the model status: matrix[human][model]."""
    labels = sorted({label for pair in pairs for label in pair if label})
    matrix = {expected: {predicted: 0 for predicted in labels} for expected in labels}
    for predicted, expected in pairs:
        matrix.setdefault(expected, {name: 0 for name in labels})[predicted] += 1
    return matrix


def _numeric_agreement(rows_by_key):
    compared = exact = tolerant = 0
    for key, (model, human) in rows_by_key.items():
        if model in ('', None) or human in ('', None):
            continue
        compared += 1
        if str(model).strip() == str(human).strip():
            exact += 1
            tolerant += 1
            continue
        try:
            left, right = float(model), float(human)
        except (TypeError, ValueError):
            continue
        if left == right:
            exact += 1
            tolerant += 1
        elif right != 0 and abs(left - right) / abs(right) <= 1e-6:
            tolerant += 1
    return {'compared': compared, 'exact': exact, 'within_relative_tolerance': tolerant,
            'exact_agreement': round(exact / compared, 6) if compared else None,
            'tolerance_agreement': round(tolerant / compared, 6) if compared else None}


def _sets(codes):
    return {code for code in str(codes or '').replace('|', ';').split(';') if code.strip()}


def _multi_label_summary(pairs):
    if not pairs:
        return {'records': 0}
    jaccard = sum(len(model & human) / len(model | human) if model | human else 1.0
                  for model, human in pairs) / len(pairs)
    micro_p = sum(len(model & human) for model, human in pairs) / max(sum(len(model) for model, _ in pairs), 1)
    micro_r = sum(len(model & human) for model, human in pairs) / max(sum(len(human) for _, human in pairs), 1)
    f1 = 0.0 if micro_p + micro_r == 0 else 2 * micro_p * micro_r / (micro_p + micro_r)
    return {'records': len(pairs), 'mean_jaccard': round(jaccard, 6),
            'micro_precision': round(micro_p, 6), 'micro_recall': round(micro_r, 6),
            'micro_f1': round(f1, 6), 'by_label': {label: _class_metrics([('1' if label in m else '0', '1' if label in h else '0') for m,h in pairs], 1).get('1') for label in sorted(set().union(*(m | h for m,h in pairs)))}}


def _validate_annotations(humans, predicted_keys):
    errors = []
    seen = {}
    for number, row in enumerate(humans, 1):
        key = str(row.get('record_key') or '').strip()
        annotator = str(row.get('annotator_id') or '').strip()
        status = str(row.get('human_status') or '').strip()
        if key not in predicted_keys:
            raise ValueError('Annotation for an unknown record_key ' + str(key))
        if not annotator:
            errors.append({'row': number, 'error': 'annotator_id is required; an anonymous row cannot establish agreement'})
        if status not in SETTINGS + ('',):
            errors.append({'row': number, 'error': 'human_status ' + status + ' is not in the contract vocabulary'})
        identity = (key, annotator)
        signature = contracts.digest(row)
        if identity in seen and seen[identity] != signature:
            errors.append({'row': number, 'error': 'conflicting duplicate annotation for ' + key + ' by ' + annotator})
        seen[identity] = signature
    if errors:
        raise ValueError('annotation_invalid: ' + json.dumps(errors[:5], ensure_ascii=False))
    return seen


def _boundary_log(work):
    path = Path(work) / 'measurement' / 'human_evaluations.jsonl'
    if not path.is_file():
        return path, []
    return path, [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def evaluate(skill, work, human_path, predictions_path, split_path=None, book_version=None, experiment='main'):
    contract = load(skill)
    frozen = contracts.read_json(Path(work) / 'measurement' / 'human_predictions.json')
    if not frozen:
        raise ValueError('Freeze the model predictions before annotating: run human-blind first')
    book_version = book_version or frozen.get('book_version')
    predictions = _read(predictions_path)
    if contracts.digest(_canonical(predictions)) != frozen.get('predictions_sha256'):
        raise ValueError('prediction_freeze_mismatch: the prediction file differs from the frozen payload; '
                         'keys may match while values changed, which voids the blind comparison')
    if frozen.get('human_contract_sha256') and contracts.asset_sha(skill, 'human_validation') != frozen['human_contract_sha256']:
        raise ValueError('The human-validation design changed after the predictions were frozen; refreeze before scoring')
    keyed = {row['record_key']: row for row in predictions}
    humans = _read(human_path)
    if not humans:
        payload = {'status': 'not_executed', 'annotations': 0,
                   'reason': 'no human annotation file rows',
                   'claim_allowed': contract['status_levels']['not_executed']['may_claim']}
        contracts.record(work, 'human_validation', payload, skill, book_version)
        return {'pass': True, **payload}
    earliest = min(str(row.get('coded_at') or '').strip() for row in humans)
    if any(not str(row.get('coded_at') or '').strip() for row in humans):
        raise ValueError('Every annotation row needs coded_at as ISO timestamps; '
                         'blindness cannot be verified otherwise')
    try:
        coded_at = datetime.datetime.fromisoformat(earliest.replace('Z', '+00:00'))
        recorded_at = datetime.datetime.fromisoformat(frozen['recorded_at'].replace('Z', '+00:00'))
    except ValueError as exc:
        raise ValueError('coded_at and recorded_at must be ISO timestamps') from exc
    if coded_at < recorded_at:
        raise ValueError('blind_violation: the earliest annotation predates the frozen prediction; '
                         'the comparison is not blind')

    _validate_annotations(humans, set(keyed))

    splits = dict(frozen.get('splits') or {})
    if split_path:
        supplied = {}
        for row in _read(split_path):
            key = row['record_key']
            value = str(row.get('split') or '').strip()
            if key in supplied and supplied[key] != value:
                raise ValueError('split_leakage: ' + key + ' is assigned to both ' + supplied[key] +
                                 ' and ' + value + '; the held-out claim is void')
            supplied[key] = value
        if contracts.digest(supplied) != frozen.get('splits_sha256'):
            raise ValueError('split_changed_since_freeze: a new assignment needs a new experiment '
                             '(refreeze and pass a new experiment id), otherwise the held-out claim is void')
        splits = supplied
    by_group = {}
    for key, split in splits.items():
        by_group.setdefault(_group(key), set()).add(split)
    crossed = {group: sorted(names) for group, names in by_group.items() if len(names) > 1}
    if crossed:
        group, names = sorted(crossed.items())[0]
        raise ValueError('split_leakage: group ' + group + ' appears in ' + ' and '.join(names) +
                         '; the held-out claim is void')
    if set(splits) != set(keyed):
        raise ValueError('The split assignment does not cover exactly the frozen record keys')

    annotators = sorted({str(row.get('annotator_id') or '').strip() for row in humans})
    by_annotator = {}
    for row in humans:
        by_annotator.setdefault(str(row['annotator_id']).strip(), {})[row['record_key']] = row

    def slice_of(keys):
        return [key for key in keys if splits.get(key) == 'holdout']

    holdout_keys = slice_of(list(keyed))

    def pairs_for(keys, annotator):
        entries = by_annotator.get(annotator, {})
        return [(str(keyed[key]['model_status']), str(entries[key].get('human_status') or '').strip())
                for key in keys if key in entries]

    primary = annotators[0]
    pairs = pairs_for(holdout_keys, primary)
    per_split = {}
    for name in ('seed', 'development', 'holdout'):
        keys = [key for key in keyed if splits.get(key) == name]
        values = pairs_for(keys, primary)
        per_split[name] = {'n': len(values),
                           'annotated': len(values),
                           'agreement': round(sum(1 for a, b in values if a == b) / len(values), 6) if values else None}

    numeric, multiline, binary_pairs = {}, [], []
    for key in holdout_keys:
        entries = by_annotator.get(primary, {})
        if key not in entries:
            continue
        model, human = keyed[key], entries[key]
        numeric[key] = (model['model_value'], human.get('human_value'))
        model_codes, human_codes = _sets(model.get('model_codes')), _sets(human.get('human_codes'))
        if model_codes or human_codes:
            multiline.append((model_codes, human_codes))
        mv, hv = str(model['model_value']).strip(), str(human.get('human_value') or '').strip()
        if mv in {'0', '1'} and hv in {'0', '1'}:
            binary_pairs.append((mv, hv))

    minimum = int(contract['design']['min_holdout_per_class'])
    status_metrics = _class_metrics(pairs, minimum)
    binary_metrics = _class_metrics(binary_pairs, minimum) if binary_pairs else {}

    # Human support per metric family, on the held-out split only.
    support = {'status': {}, 'binary': {}, 'reason_labels': {}}
    for _, human in pairs:
        if human:
            support['status'][human] = support['status'].get(human, 0) + 1
    for _, human in binary_pairs:
        support['binary'][human] = support['binary'].get(human, 0) + 1
    for _, human_codes in multiline:
        for code in human_codes:
            support['reason_labels'][code] = support['reason_labels'].get(code, 0) + 1
    deficient = {family: sorted(code for code, count in counts.items() if count < minimum)
                 for family, counts in support.items()}
    families_with_data = [family for family in FAMILIES
                          if (family == 'status' and pairs) or (family == 'binary' and binary_pairs)
                          or (family == 'value' and any(value[0] not in ('', None) and value[1] not in ('', None)
                                                        for value in numeric.values()))
                          or (family == 'reason_labels' and multiline)]
    blocking = {family: deficient[family] for family in families_with_data
                if family in ('status', 'reason_labels') and deficient[family]}
    complete_holdout = bool(pairs) and not blocking

    kappa = alpha = None
    coders_compared = 0
    if len(annotators) >= 2:
        left, right = annotators[0], annotators[1]
        common = sorted(set(by_annotator[left]) & set(by_annotator[right]) & set(holdout_keys))
        if common:
            first = [str(by_annotator[left][key].get('human_status') or '').strip() for key in common]
            second = [str(by_annotator[right][key].get('human_status') or '').strip() for key in common]
            kappa = cohen_kappa(first, second)
            alpha = krippendorff_alpha([list(pair) for pair in zip(first, second)])
            coders_compared = 2

    if not pairs:
        status = 'development_only' if per_split['development']['n'] else (
            'seed_only' if per_split['seed']['n'] else 'not_executed')
    elif not complete_holdout:
        status = 'development_only'
    else:
        status = 'holdout_evaluated'

    log_path, history = _boundary_log(work)
    human_sha = contracts.digest(_canonical(humans))
    previous = [entry for entry in history
                if entry.get('experiment') == experiment and entry.get('status') == 'holdout_evaluated']
    if previous and status == 'holdout_evaluated':
        raise ValueError('holdout_already_evaluated: experiment ' + experiment + ' was already scored once at ' +
                         str(previous[-1].get('evaluated_at')) + '; a second held-out claim needs a new '
                         'experiment id (human-evaluate --experiment <id>)')

    payload = {'status': status, 'experiment': experiment,
               'annotations': len({row['record_key'] for row in humans}), 'annotators': annotators,
               'splits': {name: per_split[name]['n'] for name in per_split},
               'holdout': per_split['holdout'],
               'status_agreement': round(sum(1 for a, b in pairs if a == b) / len(pairs), 6) if pairs else None,
               'confusion_matrix': _status_matrix(pairs),
               'class_metrics': status_metrics,
               'binary_disclosure_metrics': binary_metrics,
               'value_agreement': _numeric_agreement(numeric),
               'multi_label': _multi_label_summary(multiline),
               'chance_corrected': {'cohen_kappa': kappa, 'krippendorff_alpha_nominal': alpha,
                                    'coders_compared': coders_compared,
                                    'note': 'Human-human agreement only. The model is not a coder here.'},
               'holdout_support': support, 'deficient_classes': blocking,
               'families_scored': families_with_data,
               'per_split': per_split,
               'min_holdout_per_class': minimum,
               'metric_scope': 'held-out split only; seed and development are reported separately, never pooled',
               'predictions_recorded_at': frozen['recorded_at'],
               'predictions_sha256': frozen.get('predictions_sha256'),
               'human_sha256': human_sha,
               'splits_sha256': frozen.get('splits_sha256'),
               'earliest_annotation': earliest,
               'claim_allowed': contract['status_levels'][status]['may_claim'],
               'not_claimed': ['accuracy on records that were never annotated',
                               'reliability of the model self-review pass',
                               'that status agreement implies reason-label agreement',
                               'that a same-model second pass is independent annotation']}
    contracts.record(work, 'human_validation', payload, skill, book_version)
    with log_path.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps({'experiment': experiment, 'evaluated_at': contracts.now(),
                                 'status': status, 'predictions_sha256': frozen.get('predictions_sha256'),
                                 'human_sha256': human_sha, 'splits_sha256': frozen.get('splits_sha256')},
                                ensure_ascii=False) + '\n')
    return {'pass': True, **{key: payload[key] for key in
                             ('status', 'annotations', 'status_agreement', 'chance_corrected',
                              'claim_allowed', 'families_scored', 'holdout')}}


def adjudicate(skill, work, path, book_version):
    """Record a human decision on a disagreement. The reason is mandatory."""
    payload = contracts.require_record(skill, work, 'human_validation', book_version)
    rows = contracts.parse_rows(path)
    errors, decisions = [], []
    for number, row in enumerate(rows, 1):
        try:
            if not row.get('record_key') or not row.get('adjudicator_id'):
                raise ValueError('adjudication needs record_key and adjudicator_id')
            if not str(row.get('final_status') or '').strip():
                raise ValueError('adjudication needs final_status')
            if len(str(row.get('reason') or '').strip()) < 15:
                raise ValueError('adjudication needs a specific reason, at least fifteen characters')
            decisions.append({'record_key': row['record_key'], 'final_status': str(row['final_status']).strip(),
                              'final_value': row.get('final_value'),
                              'adjudicator_id': row['adjudicator_id'],
                              'reason': str(row['reason']).strip(),
                              'recorded_at': contracts.now()})
        except (ValueError, KeyError, TypeError) as exc:
            errors.append({'row': number, 'error': str(exc)})
    if errors:
        return {'pass': False, 'errors': errors}
    payload = {**payload, 'adjudications': decisions + payload.get('adjudications', [])}
    contracts.record(work, 'human_validation', payload, skill, book_version)
    return {'pass': True, 'adjudications': len(decisions)}


def status(skill, work, cfg, book_version):
    if 'human_validation' not in contracts.active(skill, cfg):
        return {'armed': False}
    try:
        payload = contracts.require_record(skill, work, 'human_validation', book_version)
    except (ValueError, OSError):
        return {'armed': True, 'status': 'not_executed',
                'next': 'human-blind, human-template, then human-evaluate'}
    return {'armed': True, 'status': payload.get('status'), 'annotations': payload.get('annotations'),
            'claim_allowed': payload.get('claim_allowed'),
            'metric_scope': payload.get('metric_scope')}
