#!/usr/bin/env python3
from pathlib import Path
import sys
HERE=Path(__file__).resolve()
sys.path.insert(0,str(HERE.parents[3]/'shared'))
sys.path.insert(0,str(HERE.parent))
from researchcore.workflow import main
if __name__=='__main__':raise SystemExit(main(HERE.parents[1]))
