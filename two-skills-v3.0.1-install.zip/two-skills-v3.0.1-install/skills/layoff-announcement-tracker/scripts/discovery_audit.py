"""Persist search results before review and reconcile each company's evidence."""
from coverage_planner import source_year, queries
import tempfile, os
import argparse
import datetime
import hashlib
import json
from pathlib import Path

def read(path, default):
    return json.loads(path.read_text()) if path.exists() else default

def record(folder, receipt):
    required = ('query','executed_at','status','hits')
    if not all(k in receipt for k in required) or not receipt['query'].strip() or not isinstance(receipt['hits'],list):
        raise ValueError('Incomplete search receipt')
    datetime.datetime.fromisoformat(receipt['executed_at'].replace('Z','+00:00'))
    status=receipt['status']
    if status not in ('results','empty','blocked') or (status=='results')!=bool(receipt['hits']) or (status=='blocked' and not receipt.get('reason')):
        raise ValueError('Status must agree with hits and blocker')
    for hit in receipt['hits']:
        if not hit.get('title') or not hit.get('url','').startswith(('https://','http://')):
            raise ValueError('Each displayed hit needs a title and URL')
    body=json.dumps(receipt,sort_keys=True,ensure_ascii=False)
    key=hashlib.sha256(body.encode()).hexdigest()[:20]
    directory=folder/'search-receipts'
    directory.mkdir(parents=True,exist_ok=True)
    path=directory/(key+'.json')
    if not path.exists():
        with tempfile.NamedTemporaryFile(mode="w",dir=directory,delete=False) as tmp:
            tmp.write(body)
        os.replace(tmp.name,path)
    return key

def audit(folder, result, start, end, company):
    rows=read(folder/'tracker.json',{}).get('rows',[])
    leads={f'tracker:{i}':r for i,r in enumerate(rows)}
    covered=set()
    searched=set()
    blocked=[]
    singles=set()
    metadata=read(folder/"source-metadata.json",{})
    count=0
    for path in sorted((folder/'search-receipts').glob('*.json')):
        count+=1
        r=read(path,{})
        if r['status']=='blocked':
            blocked.append(r['query'])
        elif r.get('target_year'):
            searched.add(int(r['target_year']))
        elif r.get('target_start') and r.get('target_end'):
            lo,hi=int(r['target_start']),int(r['target_end'])
            if 0<=hi-lo<=2:
                if lo==hi or r['status']=='empty':
                    searched.update(range(lo,hi+1))
                else:
                    singles.update(range(lo,hi+1))
        for i,h in enumerate(r['hits']):
            leads[f'{path.stem}:{i}']=h
            year=source_year(h,metadata)
            if year is not None:
                covered.add(year)
    plans={e['plan_id'] for e in result.get('events',[])}
    decisions=result.get('lead_decisions',{})
    pending=[]
    unresolved=[]
    for key in leads:
        decision=decisions.get(key,{})
        status=decision.get('status')
        if status=='unresolved':
            unresolved.append(key)
        if (status not in ('included','merged','excluded','unresolved') or not decision.get('reason')
            or (status in ('included','merged') and decision.get('plan_id') not in plans)):
            pending.append(key)
    years=set(range(start,min(end,datetime.date.today().year)+1))
    return dict(company=company,lead_count=len(leads),pending=pending,unresolved=unresolved,
                blocked=blocked,receipt_count=count,missing_receipts=count==0,
                followups=queries(company,years-covered-searched,singles),
                years_without_independent_hits=sorted(years-covered))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('folder',type=Path)
    p.add_argument('receipt',type=Path)
    a=p.parse_args()
    print(record(a.folder,read(a.receipt,{})))
