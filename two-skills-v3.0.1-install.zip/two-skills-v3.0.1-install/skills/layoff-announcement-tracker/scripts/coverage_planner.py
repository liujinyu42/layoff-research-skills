"""Group short gaps; retain year-level outcomes for skewed result sets."""
from urllib.parse import urlsplit
from review_packet import canonical
import re

def source_year(hit, metadata):
    url=canonical(hit['url'])
    host=(urlsplit(url).hostname or '').lower()
    if any(host==d or host.endswith('.'+d) for d in ('layoffs.fyi','layoffs.nl','trueup.io','wikipedia.org')):
        return None
    info=metadata.get(url,{})
    kind=info.get('source_kind') or hit.get('source_kind')
    if kind not in ('employer','regulator','original_reporting'):
        return None
    if not info.get('relevant',hit.get('relevant',False)):
        return None
    date=info.get('publication_date') or hit.get('date') or ''
    match=re.match(r'^(\d{4})(?:-|$)',str(date))
    return int(match[1]) if match else None

def queries(company, missing, singles):
    blocks=[]
    for y in sorted(missing):
        if blocks and y not in singles and blocks[-1][-1] not in singles and blocks[-1][-1]==y-1 and len(blocks[-1])<3:
            blocks[-1].append(y)
        else:
            blocks.append([y])
    return [dict(target_start=b[0],target_end=b[-1],query=f'"{company}" layoffs OR "job cuts" after:{b[0]-1}-12-31 before:{b[-1]+1}-01-01') for b in blocks]
