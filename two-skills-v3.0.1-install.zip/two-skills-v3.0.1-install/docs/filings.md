# Listed filing extractor
Supply companies, fiscal years, an output directory, and a contact email for SEC requests. Verify the issuer, exchange and fiscal-year boundaries. Use applicable annual reports, financial notes, MD&A, risk factors and incorporated compensation disclosures. For issuers outside the United States, follow the official local exchange or issuer source route.

| Category | Fixed measurements |
|---|---|
| HR and workforce | Workforce size, training and development spending, layoff disclosures, labor and hiring risks, MD&A labor and restructuring narratives |
| AI and technology | Products and initiatives, internal deployment and adoption, risks, investments and infrastructure costs, R&D, capitalized software |
| Financial performance and pay | Revenue, operating income, restructuring expense, total employee compensation and explicitly AI-linked pay |

Review evidence for the correct issuer, period, unit and measurement scope. Distinguish customer products from internal deployment. Check financial notes for amounts and proxy disclosures for pay links. Use the bundled nullable coding rules. Keep unavailable amounts blank with a reason. Export 2_listed_company_filings.xlsx and its evidence and review files; retain a row for each requested company-year.

[Full workflow and field definitions](../skills/listed-filing-extractor/SKILL.md)
