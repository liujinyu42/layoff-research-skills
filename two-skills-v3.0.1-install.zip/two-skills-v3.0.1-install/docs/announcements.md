# Layoff announcement tracker
Supply a company roster (company names and research IDs), an announcement window, and a new output directory. The agent configures the bundled local Python runner. Each employer has its own work folder and can enter review as soon as its tracker rows are available.

1. Retrieve Layoffs.fyi company records and preserve dates, counts, percentages and source links.
2. Search Google for independent leads. Save each actual search receipt before screening. Run the coverage audit to identify missing years and group consecutive gaps for follow-up.
3. Verify the employer, unit, geography, timeline and size in publisher evidence. Reuse a downloaded page across leads. Preserve bounds and original quotations. Assign every lead a disposition and link included or merged leads to a plan.
4. Run the local audit and finalize the export. Review 1_layoff_announcements.xlsx (Results), coverage-audit.json, measurement ledger and export audit. A PARTIAL release identifies unresolved items. Calendar-year search coverage alone cannot establish absence of layoffs.

[Full workflow and runner options](../skills/layoff-announcement-tracker/SKILL.md)
