"""Regression cases from source-role coupling, dropped work, and measurement errors."""
import json
from pathlib import Path

import pytest

from test_proposal_workflow import setup_project, judgment, apply_rows, finish_second, write_rows
from researchcore.sources import ingest, read_sources, text_for
from researchcore.workflow import audit, prepare, second_tasks, apply_second, load, export
from researchcore.batches import next_batch


def full_scope(work, sid):
    return {'source_id': sid, 'start': 0, 'end': len(text_for(work, read_sources(work)[sid]))}


def test_profile_addition_does_not_expand_event_reason_absence(tmp_path):
    fields = [{'id': 'reason_ai', 'type': 'binary', 'topic': 'event_reason',
               'source_roles': ['layoff_announcement']},
              {'id': 'company_history', 'type': 'text', 'topic': 'context',
               'source_roles': ['company_profile']}]
    sources = [{'source_id': 's1', 'company_id': 'a', 'source_type': 'company_announcement',
                'document_role': 'layoff_announcement', 'plan_id': 'p1', 'local_path': 'source.txt'}]
    sk, work, manifest = setup_project(tmp_path, fields, mode='events', sources=sources)
    d = judgment('reason_ai', 0, entity='p1', evidence=False, scope_read=True,
                 reviewed_scopes=[full_scope(work, 's1')])
    assert apply_rows(tmp_path, sk, work, [d])['pass']
    finish_second(tmp_path, sk, work)
    (tmp_path / 'profile.txt').write_text('The company was founded in 1990. A substantial company history follows.')
    write_rows(manifest, sources + [{'source_id': 'profile', 'company_id': 'a', 'source_type': 'company_profile',
                                    'document_role': 'company_profile', 'local_path': 'profile.txt'}])
    ingest(work, manifest, offline=True)
    result = audit(sk, work)
    assert result['integrity_pass']  # no reread of unrelated profile to preserve reason 0
    assert result['not_reviewed'] == 1
    groups = prepare(sk, work)
    assert groups['remaining'] == 1
    batch = next_batch(sk, work)
    assert batch['fields'][0]['variable'] == 'company_history'
    assert {s['source_id'] for s in batch['sources']} == {'profile'}


def test_new_applicable_source_invalidates_old_zero(tmp_path):
    fields = [{'id': 'ai_adoption', 'type': 'binary', 'source_roles': ['annual_report']}]
    sk, work, manifest = setup_project(tmp_path, fields)
    d = judgment('ai_adoption', 0, evidence=False, scope_read=True, reviewed_scopes=[full_scope(work, 's1')])
    assert apply_rows(tmp_path, sk, work, [d])['pass']
    rows = [json.loads(l) for l in manifest.read_text().splitlines()]
    rows.append({**rows[0], 'source_id': 'amendment'})
    write_rows(manifest, rows)
    ingest(work, manifest, offline=True)
    result = audit(sk, work)
    assert not result['integrity_pass'] and not result['complete']


def test_compensation_source_is_required_and_cannot_be_replaced_by_annual(tmp_path):
    fields = [{'id': 'ai_exec_comp', 'type': 'text', 'topic': 'compensation',
               'source_roles': ['proxy', 'compensation_report']}]
    sk, work, _ = setup_project(tmp_path, fields)
    result = apply_rows(tmp_path, sk, work, [judgment('ai_exec_comp', 'Some executive AI statement')])
    assert not result['pass'] and 'source role' in result['errors'][0]['error']
    batch = next_batch(sk, work)
    assert batch['sources'] == [] and batch['supplement_tasks'][0]['needed_roles'] == ['proxy', 'compensation_report']
    status = audit(sk, work)
    assert not status['source_coverage_pass'] and not status['semantic_review_complete']


def test_unrequested_extensions_do_not_count_as_missing_or_become_zero(tmp_path):
    fields = [{'id': 'core', 'type': 'text', 'core': True}, {'id': 'extra', 'type': 'text', 'core': False}]
    sk, work, _ = setup_project(tmp_path, fields, book_extra={'profiles': {'proposal-core': ['core'], 'full': ['core', 'extra']}})
    assert prepare(sk, work)['tasks'] == 1
    assert apply_rows(tmp_path, sk, work, [judgment('core', 'An actual core disclosure')])['pass']
    finish_second(tmp_path, sk, work)
    assert audit(sk, work)['complete']
    export(sk, work, tmp_path / 'selected.xlsx')
    from openpyxl import load_workbook
    row = list(load_workbook(tmp_path / 'selected.xlsx').active.values)[1]
    assert row[4] is None and json.loads(row[6])['extra'] == 'not_requested'
    assert not apply_rows(tmp_path, sk, work, [judgment('extra', 'Unrequested')])['pass']


@pytest.mark.parametrize('raw_text,raw_value,unit_quote', [
    ('2100', 2100, 'million'),
    ('2.1', 2100, 'billion'),
    ('2.1', 2.1, 'million'),
])
def test_original_number_and_unit_cannot_be_rewritten(tmp_path, raw_text, raw_value, unit_quote):
    fields = [{'id': 'severance', 'type': 'number', 'unit': 'currency_base',
               'measure_kind': 'annual_flow', 'raw_evidence_required': True}]
    sk, work, _ = setup_project(tmp_path, fields, text='In millions USD. Total FY2023 severance was 2.1 billion USD.')
    d = judgment('severance', 2100000000, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_text': raw_text, 'raw_value': raw_value, 'scale': 2100000000 / raw_value,
                         'currency': 'USD', 'unit_quote': unit_quote})
    d['evidence'] = [{'source_id': 's1', 'quote': 'Total FY2023 severance was 2.1 billion USD.'}]
    result = apply_rows(tmp_path, sk, work, [d])
    assert not result['pass']


def test_reported_money_preserves_literal_billion_and_can_pass(tmp_path):
    fields = [{'id': 'severance', 'type': 'number', 'unit': 'currency_base',
               'measure_kind': 'annual_flow', 'raw_evidence_required': True}]
    sk, work, _ = setup_project(tmp_path, fields, text='Total FY2023 severance was 2.1 billion USD.')
    d = judgment('severance', 2100000000, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_text': '2.1', 'raw_value': 2.1, 'scale': 1000000000, 'currency': 'USD', 'unit_quote': 'billion USD'})
    d['evidence'] = [{'source_id': 's1', 'quote': 'Total FY2023 severance was 2.1 billion USD.'}]
    assert apply_rows(tmp_path, sk, work, [d])['pass']
    finish_second(tmp_path, sk, work)
    assert audit(sk, work)['complete']


def test_signature_only_second_review_is_not_accepted(tmp_path):
    sk, work, _ = setup_project(tmp_path, [{'id': 'risk', 'type': 'text'}])
    assert apply_rows(tmp_path, sk, work, [judgment('risk', 'A supported risk')])['pass']
    second_tasks(sk, work)
    task = load(work / 'review/second-tasks.json')[0]
    forged = {**task, 'reviewed_again': True, 'reviewer_kind': 'model', 'reviewer_id': 'A',
              'criterion_application': 'Confirmed'}
    report = apply_second(sk, work, write_rows(tmp_path / 'signature.jsonl', [forged]))
    assert not report['pass'] and 'Second review must confirm' in report['errors'][0]['error']
    assert audit(sk, work)['second_pending'] == 1
    finish_second(tmp_path, sk, work)
    assert audit(sk, work)['complete']


def test_not_separate_quantity_does_not_erase_disclosed_software_text(tmp_path):
    fields = [{'id': 'software', 'type': 'text'}, {'id': 'software_disclosed', 'type': 'binary'},
              {'id': 'software_amount', 'type': 'number', 'unit': 'currency_base',
               'measure_kind': 'annual_flow', 'raw_evidence_required': True}]
    sk, work, _ = setup_project(tmp_path, fields, text='Capitalized software development costs were not material; no dollar amount was quantified.')
    quote = [{'source_id': 's1', 'quote': 'Capitalized software development costs were not material'}]
    decisions = [judgment('software', quote[0]['quote'], evidence=False),
                 judgment('software_disclosed', 1, evidence=False),
                 judgment('software_amount', None, evidence=False, status='not_separate', scope_read=True,
                          reviewed_scopes=[full_scope(work, 's1')])]
    for d in decisions: d['evidence'] = quote
    assert apply_rows(tmp_path, sk, work, decisions)['pass']
    finish_second(tmp_path, sk, work)
    assert audit(sk, work)['complete']


def test_future_context_requires_explicit_retrospective_timing(tmp_path):
    fields = [{'id': 'announcement_date', 'type': 'date'}, {'id': 'plan_identity_verified', 'type': 'binary'},
              {'id': 'firm_size', 'type': 'number', 'topic': 'context', 'source_roles': ['company_profile']}]
    sources = [{'source_id': 's1', 'company_id': 'a', 'source_type': 'company_announcement', 'document_role': 'layoff_announcement', 'plan_id': 'p1', 'local_path': 'source.txt'},
               {'source_id': 'profile', 'company_id': 'a', 'source_type': 'company_profile', 'document_role': 'company_profile', 'publication_date': '2024-01-01', 'local_path': 'source.txt'}]
    sk, work, _ = setup_project(tmp_path, fields, mode='events', sources=sources)
    ds = [judgment('announcement_date', '2023-01-20', entity='p1'), judgment('plan_identity_verified', 1, entity='p1'),
          judgment('firm_size', 1200, entity='p1', information_as_of='2022-12-31')]
    ds[-1]['evidence'][0]['source_id'] = 'profile'
    assert apply_rows(tmp_path, sk, work, ds)['pass']
    assert any('retrospective' in e['error'] for e in audit(sk, work)['errors'])
    ds[-1].update(source_timing='retrospective', retrospective_basis='Later report explicitly describes the 2022 workforce, not the 2024 count')
    assert apply_rows(tmp_path, sk, work, [ds[-1]])['pass']
    assert audit(sk, work)['integrity_pass']


def test_absent_monetary_value_with_real_quote_needs_no_fake_amount(tmp_path):
    fields = [{'id': 'ai_executive_comp_amount', 'type': 'number', 'unit': 'currency_base',
               'measure_kind': 'executive_compensation', 'raw_evidence_required': True}]
    sk, work, _ = setup_project(tmp_path, fields, text='No AI-linked compensation amount is disclosed in this complete report.')
    d = judgment('ai_executive_comp_amount', None, evidence=False, status='reviewed_absent',
                 scope_read=True, reviewed_scopes=[full_scope(work, 's1')])
    d['evidence'] = [{'source_id': 's1', 'quote': 'No AI-linked compensation amount is disclosed'}]
    assert apply_rows(tmp_path, sk, work, [d])['pass']
    finish_second(tmp_path, sk, work)
    assert audit(sk, work)['complete']


def test_invalid_batch_reports_zero_applied_and_preserves_prior_decisions(tmp_path):
    sk, work, _ = setup_project(tmp_path, [{'id': 'a', 'type': 'text'}, {'id': 'b', 'type': 'binary'}])
    result = apply_rows(tmp_path, sk, work, [judgment('a', 'Valid'), judgment('b', 7)])
    assert not result['pass'] and result['validated'] == 1
    assert result['accepted'] == result['applied'] == 0 and not (work / 'decisions.json').exists()


def test_queue_cache_does_not_waive_final_source_integrity(tmp_path):
    sk, work, _ = setup_project(tmp_path, [{'id': 'a', 'type': 'text'}])
    assert apply_rows(tmp_path, sk, work, [judgment('a', 'Actual reviewed result')])['pass']
    source = read_sources(work)['s1']
    (work / source['raw_path']).write_text('Corrupted source bytes')
    assert next_batch(sk, work)['status'] == 'FIRST_PASS_DONE'
    assert not audit(sk, work)['integrity_pass']
    with pytest.raises(ValueError, match='Invalid source/decision'):
        export(sk, work, tmp_path / 'corrupt.xlsx', partial=True)


def test_second_reading_queue_is_bounded_and_resumes_after_apply(tmp_path):
    from researchcore.batches import next_second_batch
    fields = [{'id': f'field_{i}', 'type': 'text', 'topic': 'hr_business'} for i in range(4)]
    sk, work, _ = setup_project(tmp_path, fields)
    assert apply_rows(tmp_path, sk, work, [judgment(f['id'], 'Supported observation') for f in fields])['pass']
    first = next_second_batch(sk, work, limit=2)
    assert len(first['reviews']) == 2 and first['remaining_reviews'] == 4
    reviews = [{**t, 'reviewed_again': True, 'review_outcome': 'confirm', 'reviewer_kind': 'model', 'reviewer_id': 'A',
                'criterion_application': 'Re-read the complete short source and criterion',
                'checks': {k: 'Source context supports this ' + k for k in t['required_checks']},
                'source_checks': t['evidence_to_reread']} for t in first['reviews']]
    assert apply_second(sk, work, write_rows(tmp_path / 'two-second.jsonl', reviews))['pass']
    rest = next_second_batch(sk, work, limit=2)
    assert rest['remaining_reviews'] == 2
    assert not ({t['variable'] for t in rest['reviews']} & {t['variable'] for t in first['reviews']})


@pytest.mark.parametrize('source_token', ['-2,088', '(2,088)', '( 2,088 )', '− 2,088'])
def test_negative_source_money_cannot_match_a_positive_substring(tmp_path, source_token):
    fields = [{'id': 'operating_income', 'type': 'number', 'unit': 'currency_base',
               'measure_kind': 'annual_flow', 'raw_evidence_required': True}]
    quote = f'FY2023 operating income was {source_token} million USD.'
    sk, work, _ = setup_project(tmp_path, fields, text=quote)
    d = judgment('operating_income', 2088000000, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_text': '2,088', 'raw_value': 2088, 'scale': 1000000, 'currency': 'USD', 'unit_quote': 'million USD'})
    d['evidence'] = [{'source_id': 's1', 'quote': quote}]
    assert not apply_rows(tmp_path, sk, work, [d])['pass']
    d['value'] = -2088000000
    d['amount'].update(raw_text=source_token, raw_value=-2088)
    assert apply_rows(tmp_path, sk, work, [d])['pass']


@pytest.mark.parametrize('token,cut', [('-2,088', '2,088'), ('(2,088)', '2,088')])
def test_money_sign_just_outside_the_quoted_span_is_not_ignored(tmp_path, token, cut):
    fields = [{'id': 'operating_income', 'type': 'number', 'unit': 'currency_base',
               'measure_kind': 'annual_flow', 'raw_evidence_required': True}]
    text = f'FY2023 consolidated operating income (loss) was {token} million USD.'
    sk, work, _ = setup_project(tmp_path, fields, text=text)
    d = judgment('operating_income', 2088000000, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_text': '2,088', 'raw_value': 2088, 'scale': 1000000, 'currency': 'USD', 'unit_quote': 'million USD'})
    # A quote may start anywhere; the sign of the original token still governs its value.
    d['evidence'] = [{'source_id': 's1', 'quote': text[text.index(cut):]}]
    report = apply_rows(tmp_path, sk, work, [d])
    assert not report['pass'] and 'complete number' in report['errors'][0]['error']
    assert not audit(sk, work)['complete']


def test_money_sign_further_than_a_short_lookback_is_not_ignored(tmp_path):
    fields = [{'id': 'operating_income', 'type': 'number', 'unit': 'currency_base',
               'measure_kind': 'annual_flow', 'raw_evidence_required': True}]
    text = 'FY2023 consolidated operating income (loss) was -' + ' ' * 30 + '2,088 million USD.'
    sk, work, _ = setup_project(tmp_path, fields, text=text)
    d = judgment('operating_income', 2088000000, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_text': '2,088', 'raw_value': 2088, 'scale': 1000000, 'currency': 'USD', 'unit_quote': 'million USD'})
    d['evidence'] = [{'source_id': 's1', 'quote': text}]
    report = apply_rows(tmp_path, sk, work, [d])
    assert not report['pass'] and 'complete number' in report['errors'][0]['error']


def test_positive_amount_with_ordinary_punctuation_or_unit_header_still_passes(tmp_path):
    fields = [{'id': 'severance', 'type': 'number', 'unit': 'currency_base',
               'measure_kind': 'annual_flow', 'raw_evidence_required': True}]
    text = 'Item 8. In millions USD, severance was 2,088. Cash payments followed.'
    sk, work, _ = setup_project(tmp_path, fields, text=text)
    d = judgment('severance', 2088000000, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_text': '2,088', 'raw_value': 2088, 'scale': 1000000, 'currency': 'USD', 'unit_quote': 'In millions USD'})
    d['evidence'] = [{'source_id': 's1', 'quote': text}]
    assert apply_rows(tmp_path, sk, work, [d])['pass']
    finish_second(tmp_path, sk, work)
    assert audit(sk, work)['complete']


def test_new_amendment_requeues_previously_confirmed_positive(tmp_path):
    fields = [{'id': 'revenue', 'type': 'number', 'unit': 'currency_base', 'measure_kind': 'annual_flow',
               'source_roles': ['annual_report'], 'raw_evidence_required': True}]
    sk, work, manifest = setup_project(tmp_path, fields, text='FY2023 total revenue was 100 million USD.')
    d = judgment('revenue', 100000000, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_text': '100', 'raw_value': 100, 'scale': 1000000, 'currency': 'USD', 'unit_quote': 'million USD'})
    d['evidence'] = [{'source_id': 's1', 'quote': 'FY2023 total revenue was 100 million USD.'}]
    assert apply_rows(tmp_path, sk, work, [d])['pass']
    finish_second(tmp_path, sk, work)
    assert audit(sk, work)['complete']
    (tmp_path / 'amendment.txt').write_text('Amended FY2023 total revenue was 80 million USD, correcting the earlier filing.')
    originals = [json.loads(l) for l in manifest.read_text().splitlines()]
    write_rows(manifest, originals + [{**originals[0], 'source_id': 'amendment', 'form': '10-K/A', 'local_path': 'amendment.txt'}])
    ingest(work, manifest, offline=True)
    assert next_batch(sk, work)['fields'][0]['variable'] == 'revenue'
    assert not audit(sk, work)['complete']
    with pytest.raises(ValueError, match='Invalid source/decision'):
        export(sk, work, tmp_path / 'stale-positive.xlsx', partial=True)


def test_absence_second_review_requires_real_scope_spans(tmp_path):
    sk, work, _ = setup_project(tmp_path, [{'id': 'ai', 'type': 'binary'}])
    d = judgment('ai', 0, evidence=False, scope_read=True, reviewed_scopes=[full_scope(work, 's1')])
    assert apply_rows(tmp_path, sk, work, [d])['pass']
    second_tasks(sk, work)
    task = load(work / 'review/second-tasks.json')[0]
    r = {**task, 'reviewed_again': True, 'review_outcome': 'confirm', 'reviewer_kind': 'model', 'reviewer_id': 'A',
         'criterion_application': 'Actually reread full source for the absent construct',
         'checks': {k: 'Complete source reread for ' + k for k in task['required_checks']}, 'source_checks': []}
    result = apply_second(sk, work, write_rows(tmp_path / 'negative-without-span.jsonl', [r]))
    assert not result['pass'] and 'actual source_checks span' in result['errors'][0]['error']
    finish_second(tmp_path, sk, work)
    assert audit(sk, work)['complete']
