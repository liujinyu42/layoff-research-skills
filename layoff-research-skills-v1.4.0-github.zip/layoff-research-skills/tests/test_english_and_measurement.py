"""Observable language, provenance, censoring and review-lead behavior."""
import hashlib
import json
from pathlib import Path
import pytest
from openpyxl import load_workbook
from test_proposal_workflow import setup_project, judgment, apply_rows
from researchcore.workflow import export, audit, load
from researchcore.sources import read_sources
from researchcore.semantic_hints import hints_for
from researchcore.presentation import ensure_english_output
from researchcore.presentation import english_evidence_view

EN={'presentation_language':'en','worksheet':'Results'}

def test_authored_chinese_value_and_review_explanation_are_rejected(tmp_path):
    sk,w,_=setup_project(tmp_path,[{'id':'text','type':'text'}],book_extra=EN)
    d=judgment('text','中文说明')
    assert not apply_rows(tmp_path,sk,w,[d])['pass']
    d['value']='An English summary';d['reason']='中文理由'
    r=apply_rows(tmp_path,sk,w,[d]);assert not r['pass']and 'English generated content' in r['errors'][0]['error']

def test_reviewed_native_translation_displays_english_and_preserves_canonical_source(tmp_path):
    quote='公司在2023年度使用云计算服务。'
    sk,w,_=setup_project(tmp_path,[{'id':'text','type':'text'}],book_extra=EN,text=quote,
        companies=[{'company_id':'a','company':'示例公司','company_en':'Example Company'}])
    d=judgment('text','The company uses cloud computing.',evidence=False)
    d['evidence']=[{'source_id':'s1','quote':quote}]
    assert apply_rows(tmp_path,sk,w,[d])['pass']
    with pytest.raises(ValueError,match='reviewed English'):export(sk,w,tmp_path/'bad.xlsx',partial=True)
    d['evidence'][0].update(quote_en='The company used cloud computing services during FY2023.',translation_reviewed=True,translation_reviewer_id='test-reader')
    assert apply_rows(tmp_path,sk,w,[d])['pass']
    output=tmp_path/'english.xlsx';export(sk,w,output,partial=True)
    wb=load_workbook(output);assert wb.sheetnames==['Results']
    headers=[c.value for c in wb.active[1]];values=[c.value for c in wb.active[2]]
    assert values[headers.index('company')]=='Example Company'
    ensure_english_output([headers,values])
    proof=json.loads(values[headers.index('evidence_json')]);e=proof['text']['evidence'][0]
    assert e['quote_kind']=='reviewed_English_translation'
    assert e['original_quote_sha256']==hashlib.sha256(quote.encode()).hexdigest()
    assert e['char_end']==len(quote) and 'original source' in e['offset_basis']
    assert 'decision_sha256'not in proof['text'] and proof['text']['original_decision_sha256']
    archive=load(output.with_suffix('.source_evidence.json'))
    assert archive['records']['a:2023|text']['evidence'][0]['quote']==quote

@pytest.mark.parametrize('qualifier,value,lower,error',[
    ('more_than',50,50,'one-sided threshold'),('at_least',50,50,'one-sided threshold'),
    ('approximately',150,150,'explicit bound evidence')])
def test_censored_points_and_approximate_derived_bounds_block_integrity(tmp_path,qualifier,value,lower,error):
    fields=[{'id':'layoff_count','type':'number'},{'id':'layoff_count_lower','type':'number'},{'id':'layoff_count_qualifier','type':'text'}]
    src=[{'source_id':'s1','company_id':'a','source_type':'company_announcement','document_role':'layoff_announcement','plan_id':'p1','local_path':'source.txt'}]
    sk,w,_=setup_project(tmp_path,fields,mode='events',sources=src)
    ds=[judgment(v,x,entity='p1')for v,x in [('layoff_count',value),('layoff_count_lower',lower),('layoff_count_qualifier',qualifier)]]
    assert apply_rows(tmp_path,sk,w,ds)['pass']
    a=audit(sk,w);assert not a['integrity_pass'] and any(error in e['error']for e in a['errors'])
    with pytest.raises(ValueError,match='Invalid source/decision'):export(sk,w,tmp_path/'bad.xlsx',partial=True)

def test_review_leads_retain_source_spans_but_do_not_create_findings(tmp_path):
    text='Research and development expenses were $12 million for 2023. We utilize cloud computing for our operations. '
    sk,w,_=setup_project(tmp_path,[{'id':'rd_expense','type':'number'},{'id':'new_tech_adoption','type':'text'}],text=text)
    s=read_sources(w)['s1']
    for var in ['rd_expense','new_tech_adoption','new_tech_adoption_disclosed']:
        hints=hints_for(w,s,var);assert hints
        for h in hints:
            assert text[h['char_start']:h['char_end']]==h['quote'] and h['text_sha256']==s['text_sha256']
    assert not(w/'decisions.json').exists()
    assert len(list((w/'review/semantic-index').glob('*.json')))==1
    assert hints_for(w,s,'ai_adoption')==[]

def test_native_source_without_english_company_alias_cannot_leak_to_workbook(tmp_path):
    sk,w,_=setup_project(tmp_path,[{'id':'text','type':'text'}],book_extra=EN,companies=[{'company_id':'a','company':'示例公司'}])
    with pytest.raises(ValueError,match='Non-English'):export(sk,w,tmp_path/'bad.xlsx',partial=True)

def test_declared_spanish_requires_reviewed_translation_despite_latin_script():
    d={'evidence':[{'source_id':'s','quote':'La empresa utiliza servicios de nube.','quote_language':'es'}]}
    with pytest.raises(ValueError,match='reviewed English'):english_evidence_view(d)
    d['evidence'][0].update(quote_en='The company uses cloud services.',translation_reviewed=True,translation_reviewer_id='reader')
    v=english_evidence_view(d);assert v['evidence'][0]['quote_kind']=='reviewed_English_translation'
