import json
import subprocess
import sys
from pathlib import Path
import pytest
from researchcore.company_routes import roster_from_names, route_for, source_plan
from researchcore.workflow import init, load, prepare, apply, export
from researchcore.sources import ingest

ROOT = Path(__file__).resolve().parents[1]
ANNUAL = ROOT / 'skills/listed-filing-extractor'


def test_names_work_without_cik_or_original_dataset(tmp_path):
    result = subprocess.run([sys.executable, str(ANNUAL / 'scripts/research.py'), 'init', '--work', str(tmp_path / 'w'),
                             '--company', '示例制造有限公司', '--company', 'New Example GmbH', '--years', '2024:2024'], capture_output=True, text=True)
    assert result.returncode == 0, result.stdout
    config = load(tmp_path / 'w/config.json')
    assert len(config['roster']) == 2 and all(not r.get('cik') for r in config['roster'])
    plan = source_plan(ANNUAL, tmp_path / 'w')
    assert plan['company_count'] == 2 and not plan['historical_corpus_required']
    assert {p['route'] for p in plan['plans']} == {'issuer_and_local_official_sources'}


def test_name_keys_stable_and_duplicates_require_resolution():
    assert roster_from_names(['Example Company'])[0]['company_id'] == roster_from_names(['example company'])[0]['company_id']
    assert roster_from_names(['同名公司甲'])[0]['company_id'] != roster_from_names(['同名公司乙'])[0]['company_id']
    with pytest.raises(ValueError, match='distinct'): roster_from_names(['Company A', 'company a'])


def test_no_cik_makes_no_sec_request_and_no_zero_judgment(tmp_path):
    init(ANNUAL, tmp_path / 'w', [{'company_id': 'private', 'company': 'Private Issuer', 'listing_status': 'private'}], '2024:2024', '2020-01-01', '2026-09-30')
    result = subprocess.run([sys.executable, str(ANNUAL / 'scripts/research.py'), 'sec-prepare', '--work', str(tmp_path / 'w')], capture_output=True, text=True)
    assert result.returncode == 0 and json.loads(result.stdout)['status'] == 'official_source_route'
    assert not (tmp_path / 'w/sec').exists() and not (tmp_path / 'w/decisions.json').exists()
    assert prepare(ANNUAL, tmp_path / 'w')['tasks'] == 42


def test_private_local_statement_and_decimal_comma_output(tmp_path):
    work = tmp_path / 'w'
    init(ANNUAL, work, [{'company_id': 'p', 'company': 'Private Local Issuer', 'listing_status': 'private'}], '2024:2024', '2020-01-01', '2026-09-30')
    quote = 'For FY2024 total revenue was 1.234,50 million EUR.'
    source = tmp_path / 'statement.txt'; source.write_text(quote)
    manifest = tmp_path / 'sources.json'; manifest.write_text(json.dumps([{'source_id': 's', 'company_id': 'p', 'source_type': 'company_disclosure', 'document_role': 'financial_statements', 'fy': 2024, 'local_path': str(source)}]))
    ingest(work, manifest, offline=True)
    decision = {'entity_id': 'p:2024', 'variable': 'revenue', 'status': 'observed', 'value': 1234500000,
        'period_fy': 2024, 'measurement_scope': 'company_total', 'reason': 'Statement reports consolidated annual revenue.',
        'criterion_application': 'Target-year company total, EUR million and decimal comma explicitly preserved.', 'reviewer_id': 'test', 'reviewer_kind': 'model',
        'amount': {'raw_text': '1.234,50', 'raw_value': 1234.5, 'scale': 1000000, 'currency': 'EUR', 'unit_quote': 'million EUR', 'decimal_separator': ',', 'group_separator': '.'},
        'evidence': [{'source_id': 's', 'quote': quote}]}
    path = tmp_path / 'decisions.json'; path.write_text(json.dumps([decision]))
    assert apply(ANNUAL, work, path)['pass']
    export(ANNUAL, work, tmp_path / 'partial.xlsx', partial=True)
    from openpyxl import load_workbook
    wb = load_workbook(tmp_path / 'partial.xlsx'); values = list(wb.active.values)
    assert wb.sheetnames == ['Results'] and len(values[0]) == 48
    assert values[1][values[0].index('revenue')] == 1234500000
    assert 'sbc' not in values[0] and 'ceo_total_comp' not in values[0]


@pytest.mark.parametrize('company, expected', [
    ({'company': 'Any SEC company', 'cik': '1234'}, 'SEC_EDGAR'),
    ({'company': 'Any HK company', 'exchange': 'HKEX'}, 'HKEX_and_issuer'),
    ({'company': 'Any CN company', 'exchange': 'SZSE'}, 'China_exchange_CNINFO_and_issuer'),
    ({'company': 'Any unknown company'}, 'issuer_and_local_official_sources')])
def test_routing_uses_metadata_not_company_names(company, expected):
    assert route_for(company)[0] == expected


def test_ai_compensation_from_integrated_report_needs_link_and_recipient(tmp_path):
    work = tmp_path / 'w'
    init(ANNUAL, work, [{'company_id': 'p', 'company': 'Another Private Issuer'}], '2024:2024', '2020-01-01', '2026-09-30')
    quote = 'FY2024 AI-launch awards paid to the engineering employee group totaled 5,000 USD.'
    raw = tmp_path / 'report.txt'; raw.write_text(quote)
    manifest = tmp_path / 'sources.json'; manifest.write_text(json.dumps([{'source_id': 's', 'company_id': 'p', 'fy': 2024,
        'source_type': 'company_disclosure', 'document_role': 'company_report', 'local_path': str(raw)}]))
    ingest(work, manifest, offline=True)
    d = {'entity_id': 'p:2024', 'variable': 'ai_executive_comp_amount', 'status': 'observed', 'value': 5000,
         'period_fy': 2024, 'reason': 'An explicitly AI-linked group reward is disclosed.',
         'criterion_application': 'This is a specific AI launch award to employees, not ordinary CEO or group compensation.',
         'reviewer_id': 'test', 'reviewer_kind': 'model', 'recipient_scope': 'employee_group',
         'compensation_basis': 'Paid FY2024 launch award for the specified engineering group',
         'amount': {'raw_text': '5,000', 'raw_value': 5000, 'scale': 1, 'currency': 'USD', 'unit_quote': 'USD'},
         'evidence': [{'source_id': 's', 'quote': quote}]}
    path = tmp_path / 'decisions.json'; path.write_text(json.dumps([d]))
    assert not apply(ANNUAL, work, path)['pass']
    d['ai_link_basis'] = 'The original calls these AI-launch awards, explicitly identifying the technology and recipient group.'
    path.write_text(json.dumps([d])); assert apply(ANNUAL, work, path)['pass']


def test_clipped_decimal_token_cannot_be_adopted_as_a_larger_amount(tmp_path):
    from test_proposal_workflow import setup_project, judgment, apply_rows
    fields = [{'id': 'revenue', 'type': 'number', 'unit': 'currency_base', 'measure_kind': 'annual_flow', 'raw_evidence_required': True}]
    sk, work, _ = setup_project(tmp_path, fields, text='FY2023 revenue was 0.2088 million USD.')
    d = judgment('revenue', 2088000000, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_text': '2088', 'raw_value': 2088, 'scale': 1000000, 'currency': 'USD', 'unit_quote': 'million USD'})
    d['evidence'] = [{'source_id': 's1', 'quote': '2088 million USD.'}]
    assert not apply_rows(tmp_path, sk, work, [d])['pass']
