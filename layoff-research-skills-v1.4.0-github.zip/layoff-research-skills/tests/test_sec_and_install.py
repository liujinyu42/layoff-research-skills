from pathlib import Path
import json,subprocess,sys,os,importlib.util
ROOT=Path(__file__).resolve().parents[1]
def test_only_two_installed_skills_run_sec_candidate_flow(tmp_path):
 dest=tmp_path/'skills'
 result=subprocess.run([sys.executable,str(ROOT/'install.py'),'--dest',str(dest)],capture_output=True,text=True)
 assert result.returncode==0,result.stderr
 assert sorted(p.name for p in dest.iterdir())==['layoff-announcement-tracker','listed-filing-extractor']
 for sk in dest.iterdir():
  result=subprocess.run([sys.executable,str(sk/'scripts/research.py'),'--help'],cwd=tmp_path,capture_output=True,text=True)
  assert result.returncode==0,result.stderr
 spec=importlib.util.spec_from_file_location('fixture_builder',ROOT/'tests/fixtures_builder.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.OUT=tmp_path/'fixtures';m.COMPANIES=m.COMPANIES[:1];m.build()
 roster=tmp_path/'companies.csv';roster.write_text('company_id,company,cik,exchange,listing_status\na,Northwind Systems,0001000001,NASDAQ,delisted\nb,Other issuer,,HKEX,listed\n')
 w=tmp_path/'work';entry=dest/'listed-filing-extractor/scripts/research.py'
 for args in [['init','--companies',str(roster),'--years','2023:2023'],['sec-prepare','--offline',str(m.OUT)],['prepare'],['export','--output',str(tmp_path/'partial.xlsx'),'--allow-partial']]:
  result=subprocess.run([sys.executable,str(entry),*args,'--work',str(w)],cwd=tmp_path,capture_output=True,text=True)
  assert result.returncode==0,result.stdout+result.stderr
 assert json.loads((w/'qa/sec-status.json').read_text())['companies_without_cik']==['b']
 sources=json.loads((w/'sources.json').read_text())['sources'];assert any(s.get('document_role')=='annual_report'and s['status']=='ready'for s in sources)
 from openpyxl import load_workbook
 wb=load_workbook(tmp_path/'partial.xlsx');assert wb.sheetnames==['Results']and wb.active.max_row==3
 assert wb.active.max_column==48  # identities3+42fields+status/evidence3
 assert len(json.loads((w/'review/definitions.json').read_text()))==42
 assert json.loads((w/'qa/audit.json').read_text())['fields_per_entity']==42
 assert not(w/'decisions.json').exists()  # candidates did not become semantic judgments
