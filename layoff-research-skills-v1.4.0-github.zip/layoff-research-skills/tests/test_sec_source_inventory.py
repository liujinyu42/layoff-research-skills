"""The source inventory must not depend on a positive extracted metric."""
import json
import sqlite3
from pathlib import Path
from types import SimpleNamespace

from researchcore.sec_bridge import inventory_sources, review_candidates, sec_prepare


def project(tmp_path, *, years=(2023, 2023)):
    work = tmp_path / "work"
    (work / "sec/state").mkdir(parents=True)
    (work / "sec/config").mkdir()
    (work / "sec/config/companies.csv").write_text("already initialized")
    cfg = {"mode": "filings", "roster": [{"company_id": "a", "company": "Alpha", "cik": "0001000001"}],
           "year_start": years[0], "year_end": years[1]}
    (work / "config.json").write_text(json.dumps(cfg))
    db = sqlite3.connect(work / "sec/state/state.db")
    db.execute("CREATE TABLE filings(accession TEXT,cik TEXT,form TEXT,filed TEXT,period TEXT,fy INTEGER,path TEXT,primary_doc TEXT,status TEXT)")
    db.close()
    return work, cfg


def add(work, accession, form, *, html=None, fy=2024, filed="2024-04-25", period="2024-06-01"):
    path = Path("raw/docs") / accession.replace("-", "") / "report.htm"
    if html is not None:
        local = work / "sec" / path
        local.parent.mkdir(parents=True, exist_ok=True)
        local.write_text(html)
    db = sqlite3.connect(work / "sec/state/state.db")
    db.execute("INSERT INTO filings VALUES(?,?,?,?,?,?,?,?,?)",
               (accession, "0001000001", form, filed, period, fy, str(path), "report.htm", "parsed" if html else "failed"))
    db.commit()
    db.close()


def sct(*years):
    return "<html><h1>Annual meeting</h1><table><tr><th>Name</th><th>Year</th><th>Salary</th><th>Stock Awards</th><th>Total</th></tr>" + "".join(
        f"<tr><td>Alex Chief Executive Officer</td><td>{year}</td><td>unparsed</td><td>unparsed</td><td>unparsed</td></tr>" for year in years) + "</table></html>"


def test_proxy_with_no_extracted_value_is_registered_for_explicit_sct_year(tmp_path):
    work, cfg = project(tmp_path)
    add(work, "annual", "10-K", html="<p>Annual original</p>", fy=2023, period="2023-12-31", filed="2024-02-01")
    add(work, "proxy", "DEF 14A", html=sct(2023, 2022, 2021))
    manifest, pending, ignored, neo_rows = inventory_sources(work, cfg)
    assert {(r["accession"], r["fy"], r["document_role"]) for r in manifest} == {
        ("annual", 2023, "annual_report"), ("proxy", 2023, "proxy")}
    assert not pending and not ignored and not neo_rows
    proof = next(r for r in manifest if r["document_role"] == "proxy")
    assert proof["target_fy_basis"] == "explicit_sct_year_column"
    assert proof["target_fy_evidence"]["comparison_years"] == [2021, 2022]


def test_later_proxy_comparisons_are_not_mapped_to_previous_company_years(tmp_path):
    work, cfg = project(tmp_path)
    add(work, "p2024", "DEF 14A", html=sct(2024, 2023, 2022), filed="2025-04-25", period="2025-06-01")
    manifest, pending, ignored, _ = inventory_sources(work, cfg)
    assert manifest == [] and pending == []
    assert ignored == [{"accession": "p2024", "fy": 2024, "reason": "outside_requested_fiscal_years"}]


def test_no_proxy_year_is_inferred_from_filing_or_meeting_year(tmp_path):
    work, cfg = project(tmp_path)
    add(work, "unknown", "DEF 14A", html="<p>2024 Annual Meeting of Shareholders. No fiscal-year compensation table.</p>")
    manifest, pending, _, _ = inventory_sources(work, cfg)
    assert manifest == []
    assert pending[0]["reason"] == "proxy_target_requires_review"
    assert "fy" not in pending[0]


def test_positioned_sct_uses_explicit_compensation_period_sentence(tmp_path):
    work, cfg = project(tmp_path, years=(2019, 2019))
    add(work, "old", "DEF 14A", html="<div>2020 Annual Meeting</div><div>SUMMARY COMPENSATION TABLE</div><div>The following table sets forth information regarding the compensation paid to, or earned by, our named executive officers for the fiscal years ended December 31, 2019, 2018, and 2017.</div>", filed="2020-04-24", period="2020-06-03")
    manifest, pending, _, _ = inventory_sources(work, cfg)
    assert not pending and manifest[0]["fy"] == 2019
    assert manifest[0]["target_fy_basis"] == "explicit_sct_period_sentence"


def test_all_annual_amendments_are_inventory_sources_and_use_document_fy(tmp_path):
    work, cfg = project(tmp_path)
    add(work, "original", "10-K", html="<p>Annual original</p>", period="2023-12-31")
    add(work, "amendment", "10-K/A", html='<html><ix:nonNumeric name="dei:DocumentFiscalYearFocus">2023</ix:nonNumeric><p>Amended executive information</p></html>',
        fy=2025, period="2025-06-01", filed="2025-06-01")
    manifest, pending, _, _ = inventory_sources(work, cfg)
    assert {r["accession"] for r in manifest} == {"original", "amendment"}
    assert all(r["fy"] == 2023 and r["document_role"] == "annual_report" for r in manifest)
    assert not pending


def test_failed_annual_download_stays_a_snapshot_task(tmp_path):
    work, cfg = project(tmp_path)
    add(work, "missing", "10-K", fy=2023, period="2023-12-31")
    manifest, pending, _, _ = inventory_sources(work, cfg)
    assert len(manifest) == 1 and not pending
    assert not Path(manifest[0]["local_path"]).is_file()


def test_future_proxy_candidate_is_quarantined_and_named_sct_conflict_is_explicit(tmp_path):
    work, cfg = project(tmp_path, years=(2020, 2023))
    add(work, "p2020", "DEF 14A", html=sct(2020), filed="2021-04-01")
    add(work, "p2023", "DEF 14A", html=sct(2023, 2022, 2021), filed="2024-04-01")
    manifest, _, _, _ = inventory_sources(work, cfg)
    candidate = {"cik": "0001000001", "fy": 2020, "var_id": "ceo_total_comp", "value": 7410162, "accession": "p2023"}
    neo = {"cik": "0001000001", "fy": 2020, "accession": "p2020", "name_title": "Alex Chief Executive Officer", "arithmetic_pass": "1", "total": 7425547}
    active, quarantined, issues = review_candidates([candidate], manifest, [neo])
    assert not active and quarantined[0]["value"] == 7410162
    assert {i["reason"] for i in issues} == {"candidate_source_outside_target_inventory", "candidate_conflict_with_named_sct_row"}
    assert issues[-1]["alternatives"][0]["total"] == 7425547


def test_sec_prepare_preserves_external_and_explicit_manual_sources(tmp_path, monkeypatch):
    work, cfg = project(tmp_path)
    add(work, "annual", "10-K", html="<p>Annual source with no parsed positives</p>", period="2023-12-31")
    profile = tmp_path / "profile.txt"
    profile.write_text("Official historical company profile and source description.")
    previous = [{"source_id": "external-profile", "company_id": "a", "source_type": "company_profile", "document_role": "company_profile", "local_path": str(profile), "active": True},
                {"source_id": "sec-explicit-correction", "company_id": "a", "source_type": "sec_filing", "document_role": "proxy", "local_path": str(profile), "fy": 2023, "active": True}]
    (work / "sources.json").write_text(json.dumps({"sources": previous}))
    import researchcore.sec_bridge as bridge
    monkeypatch.setattr(bridge, "engine_root", lambda skill: tmp_path / "engine")
    monkeypatch.setattr(bridge.subprocess, "run", lambda *args, **kwargs: SimpleNamespace(returncode=0))
    result = sec_prepare(tmp_path / "listed-filing-extractor", work, cache_only=True)
    ledger = json.loads((work / "sources.json").read_text())["sources"]
    assert {s["source_id"] for s in ledger if s.get("active", True)} == {"external-profile", "sec-explicit-correction", "sec-annual-2023"}
    assert all(s["status"] == "ready" for s in ledger)
    assert result["sources"] == 1
    assert not (work / "decisions.json").exists()
