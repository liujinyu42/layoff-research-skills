"""The bundled filing book is a closed variable set; every derived asset must agree with it.

These tests read the shipped assets rather than a synthetic book, because the workflow tests build
their own schemas and therefore cannot notice a bundled asset drifting from the schema.
"""
import csv
import hashlib
import json
from pathlib import Path

from openpyxl import load_workbook
from researchcore.workflow import digest, selected_fields

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / 'skills/listed-filing-extractor'
ANN = ROOT / 'skills/layoff-announcement-tracker'
ASSETS = SKILL / 'assets'
BOOK = json.loads((ASSETS / 'filing_schema.json').read_text())
CONTRACT = json.loads((ASSETS / 'output_contract.json').read_text())

# Frozen on purpose: widening the panel must be a deliberate edit here, not an accidental import.
ALLOWED = {
    'headcount',
    'training_costs', 'training_costs_disclosed', 'training_costs_amount',
    'layoff_statement', 'layoff_statement_disclosed',
    'mdna_hr_discussion', 'mdna_hr_discussion_disclosed',
    'restructuring_narrative', 'restructuring_narrative_disclosed',
    'labor_talent_risk', 'labor_talent_risk_disclosed',
    'talent_competition_risk', 'talent_competition_risk_disclosed',
    'ai_products', 'ai_products_disclosed',
    'ai_integration', 'ai_integration_disclosed',
    'ai_adoption', 'ai_adoption_disclosed',
    'new_tech_adoption', 'new_tech_adoption_disclosed',
    'ai_risk_disclosure', 'ai_risk_disclosure_disclosed',
    'ai_investment_disclosure', 'ai_investment_disclosure_disclosed',
    'ai_investment_amount',
    'ai_opex_amount',
    'tech_opex_amount', 'tech_opex_disclosure', 'tech_opex_disclosure_disclosed',
    'rd_expense',
    'capitalized_software', 'capitalized_software_disclosed', 'capitalized_software_amount',
    'revenue',
    'operating_income',
    'restructuring_charges',
    'total_comp_expense',
    'ai_exec_comp', 'ai_exec_comp_disclosed', 'ai_executive_comp_amount',
}

RETIRED = {
    'hcm_disclosure', 'ft_pt_split', 'turnover_rate', 'retention_rate', 'dei_metrics',
    'union_coverage', 'training_investment', 'talent_programs', 'engagement_survey',
    'comp_benefits', 'flexible_work', 'union_risk', 'workforce_restructuring_risk',
    'new_tech_challenge_risk', 'ai_regulatory_risk', 'ai_cyber_risk', 'ai_operational_risk',
    'ai_rd', 'ai_impact', 'ai_known_trends', 'ai_forward_looking', 'tech_investments',
    'ai_capex_amount', 'net_income', 'total_assets', 'leverage',
    'operating_cash_flow', 'sbc', 'severance', 'accrued_restructuring_liability',
    'ceo_total_comp', 'pay_ratio', 'cap', 'sct', 'neo_avg_total_comp', 'capex', 'iprd',
}

OUTPUT_TAIL = ['delivery_status', 'field_status_json', 'evidence_json']


def field_ids():
    return [f['id'] for f in BOOK['fields']]


def test_scope_is_exactly_the_requested_constructs():
    # Freeze the requested scope independently from the generated templates.
    assert BOOK['version'] == '1.4.0'
    ids = field_ids()
    assert len(ids) == len(set(ids)) == 42
    assert set(ids) == ALLOWED
    assert not RETIRED & set(ids)


def test_every_field_belongs_to_a_declared_scope_group():
    groups = BOOK['scope']['groups']
    assert set(groups) == {'hr_practices_and_layoff', 'ai_and_new_technology', 'financial_performance'}
    declared = [vid for group in groups.values() for vid in group]
    assert len(declared) == len(set(declared)) == 27
    ids = set(field_ids())
    assert set(declared) <= ids
    # The only ungrouped fields are the paired disclosure codes of a grouped text construct.
    ungrouped = ids - set(declared)
    assert ungrouped == {f'{vid}_disclosed' for vid in declared if f'{vid}_disclosed' in ids}


def test_both_profile_names_resolve_to_the_same_closed_set():
    cfg = {'profile': 'proposal-core'}
    assert [f['id'] for f in selected_fields(BOOK, cfg)] == field_ids()
    assert [f['id'] for f in selected_fields(BOOK, {'profile': 'full'})] == field_ids()
    assert {k: len(v) for k, v in BOOK['profiles'].items()} == {'proposal-core': 42, 'full': 42}


def test_related_fields_never_point_outside_the_scope():
    scope = set(field_ids())
    for field in BOOK['fields']:
        for holder in (field, field.get('coding_definition', {})):
            for related in holder.get('related_fields', []):
                assert related in scope, (field['id'], related)


def test_every_field_is_codable_with_source_roles_and_definition():
    for field in BOOK['fields']:
        assert field.get('topic')
        assert field.get('type') in {'text', 'binary', 'number', 'integer', 'date'}
        assert field.get('source_roles'), field['id']
        definition = field.get('coding_definition') or {}
        assert definition.get('definition') or definition.get('label'), field['id']
        assert definition.get('absence_rule'), field['id']
        if field['type'] == 'number':
            assert field.get('unit') in {'persons', 'currency_base'}, field['id']
    numeric = [f['id'] for f in BOOK['fields'] if f['type'] == 'number']
    assert len(numeric) == 12
    assert sum(1 for f in BOOK['fields'] if f['id'].endswith('_disclosed')) == 15


def test_contract_columns_and_hashes_match_the_book():
    expected = ['company_id', 'company', 'fy'] + field_ids() + OUTPUT_TAIL
    assert CONTRACT['columns'] == expected
    assert len(CONTRACT['columns']) == 48
    assert CONTRACT['schema_sha256'] == digest(BOOK)
    template = (ASSETS / 'output_template.xlsx').read_bytes()
    assert CONTRACT['template_sha256'] == hashlib.sha256(template).hexdigest()
    assert CONTRACT['profiles'] == {'proposal-core': 42, 'full': 42}
    assert CONTRACT['version'] == BOOK['version']


def test_template_and_header_csv_carry_exactly_the_contract_header():
    book = load_workbook(ASSETS / 'output_template.xlsx')
    assert book.sheetnames == ['Results']
    sheet = book.active
    assert [cell.value for cell in sheet[1]] == CONTRACT['columns']
    assert sheet.max_row == 1 and sheet.max_column == len(CONTRACT['columns'])
    assert sheet.freeze_panes == 'D2'
    header = (ASSETS / 'output_header.csv').read_text().strip().split(',')
    assert header == CONTRACT['columns']


def test_dictionary_lists_exactly_the_scoped_fields():
    with (ASSETS / 'field_dictionary.csv').open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    assert [row['id'] for row in rows] == field_ids()
    for row in rows:
        assert row['topic'] and row['source_roles']
        assert row['definition'], row['id']


def test_docs_validation_counts_match_the_measured_assets():
    validation = json.loads((ROOT / 'docs/validation.json').read_text())
    filings = validation['templates']['filings']
    assert filings['data_fields'] == len(field_ids())
    assert filings['default_profile_fields'] == 42
    assert filings['columns'] == len(CONTRACT['columns'])
    assert filings['binary_disclosure_companions'] == 15
    assert filings['currency_fields_requiring_literal_amounts'] == sum(
        1 for f in BOOK['fields'] if f.get('raw_evidence_required'))


EVENT_SUBSTANTIVE = {'stated_reason_text', 'ma_activity', 'leadership_transition', 'company_history', 'firm_size',
                    'founding_year', 'products_services', 'business_model', 'affected_parties'}
EVENT_RETIRED = {'reason_ai', 'reason_new_technology', 'reason_financial', 'reason_operational', 'reason_ma',
                 'reason_strategic_restructuring', 'reason_ipo_targets', 'reason_leadership_transition',
                 'other_stated_reason', 'sector', 'event_notes'}


def test_announcement_book_keeps_all_proposal_part_one_variables_without_extensions():
    book = json.loads((ANN / 'assets/event_schema.json').read_text())
    contract = json.loads((ANN / 'assets/output_contract.json').read_text())
    ids = [f['id'] for f in book['fields']]
    assert len(ids) == len(set(ids)) == 43
    assert not EVENT_RETIRED & set(ids)
    assert set(book['scope']['removed_extensions']) == EVENT_RETIRED
    assert EVENT_SUBSTANTIVE <= set(ids)
    # Everything the event record needs survives: identity, measures, reason codes and firm size.
    for required in ['layoff_count', 'layoff_percentage', 'stated_reason_text',
                     'firm_size', 'firm_size_as_of', 'affected_parties',
                     'ma_activity', 'leadership_transition', 'ticker_at_event', 'cik', 'event_type']:
        assert required in ids, required
    assert len(contract['columns']) == 49
    assert contract['columns'] == ['plan_id', 'company_id', 'company'] + ids + [
        'delivery_status', 'field_status_json', 'evidence_json']
    assert contract['schema_sha256'] == digest(book)
    assert contract['template_sha256'] == hashlib.sha256(
        (ANN / 'assets/output_template.xlsx').read_bytes()).hexdigest()
    assert contract['profiles'] == {'proposal-core': 43, 'full': 43}


def test_announcement_template_header_and_dictionary_agree_with_the_book():
    book = json.loads((ANN / 'assets/event_schema.json').read_text())
    contract = json.loads((ANN / 'assets/output_contract.json').read_text())
    sheet = load_workbook(ANN / 'assets/output_template.xlsx').active
    assert [cell.value for cell in sheet[1]] == contract['columns']
    assert sheet.max_column == len(contract['columns'])
    assert (ANN / 'assets/output_header.csv').read_text().strip().split(',') == contract['columns']
    with (ANN / 'assets/field_dictionary.csv').open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    assert [row['id'] for row in rows] == [f['id'] for f in book['fields']]
