# Layoff Research Skills 3.0.3
Collect public layoff announcements and company fiscal-year disclosures in two independent workflows. The release includes the v3.0.3 announcement tracker and the filing extractor distributed in the v3.0.2 strict filing schema.

| Skill | Unit of observation | Guide | Copyable prompt |
|---|---|---|---|
| Layoff announcement tracker | One distinct event or plan | [Collection and verification](docs/announcements.md) | [Event collection prompt](prompts/announcements.md) |
| Listed filing extractor | One company and fiscal year | [Sources and measurements](docs/filings.md) | [Filing extraction prompt](prompts/filings.md) |

## Install
Unzip the installation archive and open a terminal in the directory containing install.py. Use Python 3.10+ on macOS or Linux for the local tracker runner. Install dependencies in the Python environment used by your agent.

~~~sh
python3 -m pip install -r requirements.txt
python3 install.py --target workbuddy
~~~

For Codex use --target codex. For WorkBuddy AI use --target workbuddy-ai. Preview the destination with --dry-run. To upgrade existing copies, stop active jobs and repeat the install command with --force. The installer backs up existing directories and prints the backup location. Open a fresh agent session and paste either prompt after replacing its placeholders.
