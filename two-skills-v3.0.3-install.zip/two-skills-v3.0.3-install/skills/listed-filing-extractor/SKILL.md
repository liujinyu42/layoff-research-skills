---
name: listed-filing-extractor
description: Extract only the specified HR, AI and financial disclosures from listed-company filings.
---
# Listed-company filings — strict scope
Collect only the fields listed below for listed issuers in the supplied layoff roster. Default to FY2019 through FY2025 using each issuer's fiscal calendar. Verify listing and reporting scope before initializing the workspace. Use SEC EDGAR for NYSE/Nasdaq issuers and the appropriate official exchange or issuer filings for HKEX, LSE, ASX, KRX and Xetra.
Read Item 1, Item 1A, Item 7, Item 8, Item 11 or local equivalents, financial notes and incorporated compensation documents. Distinguish AI deployment from customer products, AI-specific spending from mixed infrastructure expense, and current-year amounts from comparisons. Record missing or separately undisclosed amounts as null. Retain citations, units, source dates and review status in sidecars.
Use the bundled filing schema for both extraction profiles. Keep one Results row per company and fiscal year. Collect no additional measures, independent layoff-statement field, general non-AI adoption field, or binary disclosure companions. Use a fresh workspace.

HR

headcount, training_costs_amount, labor_talent_risk, talent_competition_risk, mdna_hr_discussion, restructuring_narrative

AI and technology

ai_products, ai_integration, ai_adoption, ai_risk_disclosure, ai_investment_disclosure, ai_investment_amount, tech_opex_amount, rd_expense, capitalized_software_amount

Financial performance

revenue, operating_income, restructuring_charges, total_comp_expense, ai_exec_comp, ai_executive_comp_amount

Follow references/workflow.md for operational commands. This whitelist controls field scope.
