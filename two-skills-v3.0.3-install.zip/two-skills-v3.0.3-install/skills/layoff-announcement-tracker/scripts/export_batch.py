"""Export company JSON results and audit the persisted workbook."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit
from openpyxl import Workbook, load_workbook

def encode(value):
    return json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else value

def publish(results, out):
    files = sorted(results.glob('*.json'))
    if not files:
        raise ValueError('No company results found')
    companies = [json.loads(p.read_text()) for p in files]
    identities = collections.defaultdict(set)
    for company in companies:
        identities[str(company['cid'])].add(company['slug'])
    ids = collections.Counter(e['plan_id'] for c in companies for e in c['events'])
    header = next(csv.reader((Path(__file__).resolve().parents[1]/'assets/output_header.csv').open()))
    book = Workbook()
    sheet = book.active
    sheet.title = 'Results'
    sheet.append(header)
    ledger = []
    expected = []
    for c in companies:
        for event in c['events']:
            e = dict(event)
            pid = e['plan_id']
            cid = str(c['cid'])
            issues = []
            evidence = e.get('evidence') or []
            usable = [item for item in evidence if isinstance(item,dict) and urlsplit(str(item.get('url'))).scheme in ('http','https') and item.get('quote')]
            if len(identities[cid]) != 1 or ids[pid] != 1 or not usable:
                issues.append('Review identity, duplicate plan ID or missing source quotation')
            excluded = bool(issues)
            e.update(company_id=cid,company=c['company'],evidence_json=evidence)
            if usable and not e.get('verification_source_url'):
                e['verification_source_url'] = usable[0]['url']
            ledger.append(dict(plan_id=pid,cid=cid,excluded=excluded,issues=issues,evidence=evidence,
                               original_announcement_url=e.get('original_announcement_url'),
                               verification_source_url=e.get('verification_source_url')))
            if not excluded:
                row=[encode(e.get(k)) for k in header]
                if any(isinstance(v,str) and len(v)>32767 for v in row):
                    raise ValueError('Excel cell limit exceeded for '+pid)
                sheet.append(row)
                expected.append(row)
    out.mkdir(parents=True,exist_ok=True)
    path=out/'1_layoff_announcements.xlsx'
    book.save(path)
    saved=load_workbook(path,read_only=True)
    rows=list(saved['Results'].values)
    if saved.sheetnames!=['Results'] or list(rows[0])!=header or list(rows[1:])!=[tuple(None if v=='' else v for v in r) for r in expected]:
        raise ValueError('Workbook readback mismatch')
    audit=dict(input_events=len(ledger),exported=len(expected),quarantined=len(ledger)-len(expected),status='PARTIAL',sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    for name,data in [('export-audit',audit),('measurement-ledger',ledger)]:
        (out/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
    print(json.dumps(audit))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--results',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    publish(args.results,args.out)
