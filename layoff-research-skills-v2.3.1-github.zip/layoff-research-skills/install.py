#!/usr/bin/env python3
"""Install the two self-contained v2.3.1 skills; no collection or scheduling starts."""
from pathlib import Path
import argparse, shutil, tempfile, datetime, json, sys

NAMES = ('layoff-announcement-tracker', 'listed-filing-extractor')


def stage(source, target):
    shutil.copytree(
        source,
        target,
        ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '_install.json'),
    )


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target', choices=['codex', 'workbuddy', 'workbuddy-ai'], default='workbuddy')
    p.add_argument('--dest')
    p.add_argument('--force', action='store_true')
    p.add_argument('--dry-run', action='store_true')
    a = p.parse_args()
    root = Path(__file__).resolve().parent
    dest = Path(a.dest).expanduser().resolve() if a.dest else Path.home() / ('.' + a.target) / 'skills'
    src = root / 'skills'
    if any((dest / n).resolve().is_relative_to(src.resolve()) for n in NAMES):
        raise ValueError('Destination overlaps source')
    existing = [n for n in NAMES if (dest / n).exists()]
    if a.dry_run:
        print(json.dumps({'version': '2.3.1', 'skills': NAMES, 'destination': str(dest), 'replace': existing, 'collection_started': False}))
        return
    if existing and not a.force:
        raise ValueError('Existing skills: ' + ','.join(existing) + '; use --force after stopping active tasks')
    dest.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup = dest.parent / ('proposal-skill-backups-' + stamp)
    with tempfile.TemporaryDirectory(prefix='proposal-skills-', dir=dest) as tmp:
        for n in NAMES:
            stage(src / n, Path(tmp) / n)
        for n in existing:
            backup.mkdir(exist_ok=True)
            shutil.copytree(dest / n, backup / n, symlinks=True)
        for n in NAMES:
            if (dest / n).is_symlink():
                raise ValueError('Refusing to replace a symlink; copy/install into a separate directory')
            if (dest / n).exists():
                shutil.rmtree(dest / n)
            shutil.move(str(Path(tmp) / n), dest / n)
    print(json.dumps({'version': '2.3.1', 'installed': list(NAMES), 'destination': str(dest),
                      'backup': str(backup) if existing else None, 'collection_started': False},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError) as e:
        print(str(e), file=sys.stderr)
        raise SystemExit(2)
