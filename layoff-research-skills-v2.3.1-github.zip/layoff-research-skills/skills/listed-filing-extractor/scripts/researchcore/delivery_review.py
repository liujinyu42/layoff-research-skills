"""Check review coverage against current decisions and source manifests."""
import csv


AMOUNTS = (
    "training_costs_amount", "ai_investment_amount", "tech_opex_amount",
    "rd_expense", "capitalized_software_amount", "revenue", "operating_income",
    "restructuring_charges", "total_comp_expense", "ai_executive_comp_amount",
)


def review_gaps(work, mode, entities, decisions, sources):
    event_mode = mode == "events"
    filename = "event_candidate_review.csv" if event_mode else "filing_amount_followup.csv"
    required = (
        ("candidate_id", "company", "reported_date", "source_url", "affected_scope",
         "disposition", "plan_id", "evidence_url", "reason")
        if event_mode else
        ("company_id", "variable", "source_id", "text_sha256", "section", "fiscal_period", "result")
    )
    gaps = []

    def gap(reason):
        gaps.append({"contract": "delivery_review", "reason": reason})

    try:
        with (work / filename).open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if not set(required).issubset(reader.fieldnames or ()):
                raise ValueError("Missing required columns")
            rows = [{key: (row.get(key) or "").strip() for key in required} for row in reader]
    except (OSError, ValueError, csv.Error) as exc:
        gap(f"{filename}: {exc}")
        return gaps

    if event_mode:
        seen, included = set(), set()
        ready_pairs = {(src.get("plan_id"), src.get("source_url")) for src in sources.values()
                       if src.get("status") == "ready"}
        for row in rows:
            cid, disposition, plan = (row[key] for key in ("candidate_id", "disposition", "plan_id"))
            if not cid or cid in seen or not all(row[key] for key in ("company", "source_url", "reason")):
                gap(f"Invalid or duplicate candidate: {cid}")
            seen.add(cid)
            if disposition in {"included", "merged"}:
                if plan not in entities or (plan, row["evidence_url"]) not in ready_pairs:
                    gap(f"Candidate {cid} lacks a registered plan or ready evidence source")
                elif disposition == "included":
                    included.add(plan)
            elif disposition == "unresolved":
                gap(f"Unresolved event candidate: {cid}")
            elif disposition != "excluded" or plan:
                gap(f"Invalid disposition or plan link for candidate: {cid}")
        recorded_urls = {row["source_url"] for row in rows} | {row["evidence_url"] for row in rows}
        for url in sorted({url for _, url in ready_pairs if url} - recorded_urls):
            gap(f"Ready event source has no candidate disposition: {url}")
        for plan in sorted(set(entities) - included):
            gap(f"Registered plan lacks an included candidate: {plan}")
        return gaps

    by_company = {}
    for eid, entity in entities.items():
        by_company.setdefault(entity["company_id"], set()).add(eid)
    checked = set()
    for row in rows:
        source = sources.get(row["source_id"], {})
        if (source.get("status") != "ready" or not row["text_sha256"]
                or source.get("text_sha256") != row["text_sha256"]
                or source.get("company_id") != row["company_id"]
                or not all(row[key] for key in ("section", "fiscal_period", "result"))):
            gap(f"Invalid or stale amount follow-up: {row['company_id']} / {row['variable']}")
            continue
        checked.add((row["company_id"], row["variable"]))
    for company, entity_ids in sorted(by_company.items()):
        for variable in AMOUNTS:
            if all(decisions.get(f"{eid}|{variable}", {}).get("value") is None for eid in entity_ids):
                if (company, variable) not in checked:
                    gap(f"Missing amount follow-up: {company} / {variable}")
    return gaps
