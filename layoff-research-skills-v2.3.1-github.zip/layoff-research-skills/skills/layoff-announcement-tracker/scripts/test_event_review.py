"""Regression cases for secondary evidence, notice scope and stale reviews."""
import csv
import json
from pathlib import Path
import tempfile
import unittest

from researchcore.candidate_review import audit, row_hash
from researchcore.event_sources import verification_url, is_event_source
from researchcore.search_coverage import normalize, coverage


class EventReviewTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.work = Path(self.tmp.name)
        self.source = {'source_id': 'n', 'source_type': 'news', 'document_role': 'news_report',
                       'status': 'ready', 'company_id': 'c', 'plan_id': 'p',
                       'source_url': 'https://example.org/report', 'row_sha256': 'row',
                       'text_sha256': 'text'}
        self.sources = {'n': self.source}
        self.entities = {'p': {'company_id': 'c'}}
        self.row = dict(candidate_id='candidate', company='Example', reported_date='2025-01-01',
                        source_url=self.source['source_url'], affected_scope='Local staff',
                        disposition='included', plan_id='p', evidence_url=self.source['source_url'],
                        reason='Spokesperson confirms reductions')
        self.receipt = {'candidate_sha256': row_hash(self.row), 'reviewer_id': 'A',
                        'criterion_application': 'Statement confirms the reported action',
                        'checks': {key: 'Source-supported finding' for key in
                                   ('entity', 'date_basis', 'action', 'credibility', 'count_scope')},
                        'evidence': [{'source_id': 'n', 'char_start': 0, 'quote': 'Confirmed',
                                      'row_sha256': 'row', 'text_sha256': 'text'}]}

    def review(self):
        with (self.work / 'event_candidate_review.csv').open('w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=self.row)
            writer.writeheader()
            writer.writerow(self.row)
        (self.work / 'candidate_reviews.json').write_text(json.dumps({'candidate': self.receipt}))
        return audit(self.work, {}, self.entities, self.sources, lambda _: 'Confirmed reductions')

    def test_news_and_warn_are_real_source_types(self):
        decisions = {'p|layoff_count': {'evidence': [{'source_id': 'n'}]}}
        self.assertEqual(verification_url('p', decisions, self.sources), self.source['source_url'])
        self.assertTrue(is_event_source({**self.source, 'source_type': 'warn', 'document_role': 'event_filing'}))

    def test_global_count_link_wins_over_local_notice_context(self):
        self.sources['w'] = {**self.source, 'source_id': 'w', 'source_type': 'warn',
                             'source_url': 'https://example.org/local-notice'}
        decisions = {'p|layoff_count': {'evidence': [{'source_id': 'n'}]},
                     'p|affected_parties': {'evidence': [{'source_id': 'w'}]}}
        self.assertEqual(verification_url('p', decisions, self.sources), self.source['source_url'])

    def test_secondary_report_can_verify_candidate(self):
        self.assertEqual(self.review()['gaps'], [])

    def test_notice_alone_can_verify_candidate(self):
        self.source.update(source_type='warn', document_role='event_filing')
        self.assertEqual(self.review()['gaps'], [])

    def test_manifest_change_requires_review(self):
        self.source['row_sha256'] = 'changed'
        self.assertTrue(self.review()['gaps'])

    def test_candidate_change_requires_review(self):
        self.row['affected_scope'] = 'Different staff'
        self.assertTrue(self.review()['gaps'])

    def test_null_evidence_is_reported(self):
        self.receipt['evidence'] = [None]
        self.assertTrue(self.review()['gaps'])

    def test_merge_requires_relationship_evidence(self):
        self.row['disposition'] = 'merged'
        self.receipt['candidate_sha256'] = row_hash(self.row)
        self.assertTrue(any('plan-link' in gap['reason'] for gap in self.review()['gaps']))

    def test_blocked_is_not_an_exclusion_reason(self):
        self.row.update(disposition='excluded', plan_id='')
        self.receipt.update(candidate_sha256=row_hash(self.row), exclusion_code='paywall')
        self.assertTrue(any('access failure' in gap['reason'] for gap in self.review()['gaps']))

    def test_event_lookup_does_not_cover_year(self):
        contract = {'channels': {'news_index': {}},
                    'outcomes': {'found_events': {'counts_as_covered': True}},
                    'channel_plan': {'default': ['news_index']}}
        cfg = {'roster': [{'company_id': 'c', 'company': 'Example'}],
               'event_start': '2025-01-01', 'event_end': '2025-12-31'}
        row = {'company_id': 'c', 'window_start': '2025-01-01', 'window_end': '2025-12-31',
               'channel': 'news_index', 'query': 'Example January layoffs', 'executed_at': '2026-01-01',
               'outcome': 'found_events', 'events_registered': 'p'}
        record = normalize(contract, row, 1, cfg, self.entities)
        result = coverage(contract, cfg, self.entities, [record])
        self.assertEqual(result['summary']['mean_window_coverage'], 0)


if __name__ == '__main__':
    unittest.main()
