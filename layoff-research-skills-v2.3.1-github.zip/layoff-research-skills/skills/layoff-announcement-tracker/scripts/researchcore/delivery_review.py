"""Check review coverage against current decisions and source manifests."""
import csv


AMOUNTS = (
    "training_costs_amount", "ai_investment_amount", "tech_opex_amount",
    "rd_expense", "capitalized_software_amount", "revenue", "operating_income",
    "restructuring_charges", "total_comp_expense", "ai_executive_comp_amount",
)


def measure_gaps(decisions):
    """Reject count codings whose point value contradicts the stated qualifier."""
    gaps = []

    def cell(entity, variable):
        return decisions.get(entity + "|" + variable, {})

    for entity in sorted({key.split("|")[0] for key in decisions}):
        qualifier = cell(entity, "layoff_count_qualifier")
        count = cell(entity, "layoff_count")
        lower = cell(entity, "layoff_count_lower")
        upper = cell(entity, "layoff_count_upper")
        q = qualifier.get("value")
        if qualifier.get("status") == "observed":
            if q == "exact":
                if count.get("status") != "observed" or not isinstance(count.get("value"), (int, float)):
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier exact requires a numeric layoff_count point value"})
            elif q in {"more_than", "at_least"}:
                if count.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": a one-sided lower threshold (" + q + ") cannot be stored as a layoff_count point value; set layoff_count null and use layoff_count_lower"})
                if lower.get("status") != "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier " + q + " requires an observed layoff_count_lower"})
                if upper.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier " + q + " must leave layoff_count_upper null"})
            elif q in {"less_than", "up_to"}:
                if count.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": a one-sided upper threshold (" + q + ") cannot be stored as a layoff_count point value; set layoff_count null and use layoff_count_upper"})
                if upper.get("status") != "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier " + q + " requires an observed layoff_count_upper"})
                if lower.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier " + q + " must leave layoff_count_lower null"})
            elif q == "range":
                if count.get("status") == "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": a range cannot be stored as a layoff_count point value"})
                if lower.get("status") != "observed" or upper.get("status") != "observed":
                    gaps.append({"contract": "measure_coherence", "reason": entity + ": qualifier range requires both layoff_count_lower and layoff_count_upper"})
            elif q == "unknown" and count.get("status") == "observed":
                gaps.append({"contract": "measure_coherence", "reason": entity + ": an unknown qualifier cannot carry a layoff_count point value"})
        lo = lower.get("value") if lower.get("status") == "observed" else None
        hi = upper.get("value") if upper.get("status") == "observed" else None
        if isinstance(lo, (int, float)) and isinstance(hi, (int, float)) and lo > hi:
            gaps.append({"contract": "measure_coherence", "reason": entity + ": layoff_count_lower exceeds layoff_count_upper"})
        pct = cell(entity, "layoff_percentage")
        denominator = cell(entity, "layoff_percentage_denominator")
        if pct.get("status") == "observed" and denominator.get("status") != "observed":
            gaps.append({"contract": "measure_coherence", "reason": entity + ": an observed layoff_percentage requires an observed layoff_percentage_denominator"})
    return gaps


def review_gaps(work, mode, entities, decisions, sources):
    event_mode = mode == "events"
    filename = "event_candidate_review.csv" if event_mode else "filing_amount_followup.csv"
    required = (
        ("candidate_id", "company", "reported_date", "source_url", "affected_scope",
         "disposition", "plan_id", "evidence_url", "reason")
        if event_mode else
        ("company_id", "variable", "source_id", "text_sha256", "section", "fiscal_period", "result")
    )
    gaps = []

    def gap(reason):
        gaps.append({"contract": "delivery_review", "reason": reason})

    try:
        with (work / filename).open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if not set(required).issubset(reader.fieldnames or ()):
                raise ValueError("Missing required columns")
            rows = [{key: (row.get(key) or "").strip() for key in required} for row in reader]
    except (OSError, ValueError, csv.Error) as exc:
        gap(f"{filename}: {exc}")
        return gaps

    if event_mode:
        from .event_sources import is_event_source
        seen, included = set(), set()
        ready_pairs = {(src.get("plan_id"), src.get("source_url")) for src in sources.values()
                       if is_event_source(src)}
        for row in rows:
            cid, disposition, plan = (row[key] for key in ("candidate_id", "disposition", "plan_id"))
            if not cid or cid in seen or not all(row[key] for key in ("company", "source_url", "reason")):
                gap(f"Invalid or duplicate candidate: {cid}")
            seen.add(cid)
            if disposition in {"included", "merged"}:
                if plan not in entities or (plan, row["evidence_url"]) not in ready_pairs:
                    gap(f"Candidate {cid} lacks a registered plan or ready evidence source")
                elif disposition == "included":
                    included.add(plan)
            elif disposition == "unresolved":
                gap(f"Unresolved event candidate: {cid}")
            elif disposition != "excluded" or plan:
                gap(f"Invalid disposition or plan link for candidate: {cid}")
        recorded_urls = {row["source_url"] for row in rows} | {row["evidence_url"] for row in rows}
        try:
            with (work / "tracker_seed.csv").open(encoding="utf-8-sig", newline="") as handle:
                seed_reader = csv.DictReader(handle)
                if not {"candidate_id", "tracker", "source_url"}.issubset(seed_reader.fieldnames or ()):
                    raise ValueError("Missing required columns")
                seed_ids = set()
                for seed in seed_reader:
                    cid = (seed.get("candidate_id") or "").strip()
                    if not cid or cid in seed_ids or not seed.get("tracker") or not seed.get("source_url"):
                        gap(f"Invalid or duplicate tracker seed: {cid}")
                    elif cid not in seen:
                        gap(f"Tracker seed has no candidate disposition: {cid}")
                    seed_ids.add(cid)
        except (OSError, ValueError, csv.Error) as exc:
            gap(f"tracker_seed.csv: {exc}")
        for url in sorted({url for _, url in ready_pairs if url} - recorded_urls):
            gap(f"Ready event source has no candidate disposition: {url}")
        for plan in sorted(set(entities) - included):
            gap(f"Registered plan lacks an included candidate: {plan}")
        gaps.extend(measure_gaps(decisions))
        return gaps

    by_company = {}
    for eid, entity in entities.items():
        by_company.setdefault(entity["company_id"], set()).add(eid)
    checked = set()
    for row in rows:
        source = sources.get(row["source_id"], {})
        if (source.get("status") != "ready" or not row["text_sha256"]
                or source.get("text_sha256") != row["text_sha256"]
                or source.get("company_id") != row["company_id"]
                or not all(row[key] for key in ("section", "fiscal_period", "result"))):
            gap(f"Invalid or stale amount follow-up: {row['company_id']} / {row['variable']}")
            continue
        checked.add((row["company_id"], row["variable"]))
    for company, entity_ids in sorted(by_company.items()):
        for variable in AMOUNTS:
            if all(decisions.get(f"{eid}|{variable}", {}).get("value") is None for eid in entity_ids):
                if (company, variable) not in checked:
                    gap(f"Missing amount follow-up: {company} / {variable}")
    return gaps
