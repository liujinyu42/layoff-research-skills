"""Local discovery planning and receipt checks for the host's search tools."""
from __future__ import annotations

import csv
from contextlib import contextmanager
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
from urllib.parse import urldefrag, urlsplit


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode()).hexdigest()


def _atomic(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _save(path, value):
    _atomic(path, json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def _read(path, default):
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else default


@contextmanager
def _import_lock(work):
    """Fail safely on overlapping writers; the caller can retry the whole batch."""
    lock = work / "discovery/import.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise ValueError("Discovery import is already running; retry after its lock is released") from exc
    try:
        with os.fdopen(fd, "w", encoding="ascii") as handle:
            handle.write(str(os.getpid()))
        yield
    finally:
        lock.unlink()


def _aliases(company):
    extra = company.get("aliases") or []
    if isinstance(extra, str):
        extra = extra.split(";")
    return sorted({str(name).strip() for name in [company["company"], *extra]
                   if str(name).strip()}, key=str.casefold)


def _tasks(cfg):
    start, end = (dt.date.fromisoformat(cfg[key]) for key in ("event_start", "event_end"))
    if start > end:
        raise ValueError("event_start must precede event_end")
    tasks = []
    for company in cfg["roster"]:
        aliases = _aliases(company)
        names = "(" + " OR ".join('"' + name.replace('"', '') + '"' for name in aliases) + ")"
        for year in range(start.year, end.year + 1):
            lower = max(start, dt.date(year, 1, 1)).isoformat()
            upper = min(end, dt.date(year, 12, 31)).isoformat()
            for family, terms in (("broad_news", "(layoffs OR \"job cuts\" OR redundancies)"),
                                  ("unit_notice", "(WARN OR \"layoff notice\" OR \"team cuts\" OR \"local layoffs\")")):
                scope = {"company_id": company["company_id"], "company": company["company"],
                         "aliases": aliases, "window_start": lower, "window_end": upper,
                         "family": family}
                task_id = "search-" + _digest(scope)[:20]
                tasks.append({**scope, "task_id": task_id,
                              "query": f"{names} {terms} {year}",
                              "scope_sha256": _digest(scope)})
    return tasks


def candidate_id(company_id, url):
    """Stable discovery identity; this does not identify or merge a layoff plan."""
    return "hit-" + _digest([company_id, urldefrag(url)[0]])[:24]


def plan(work, cfg):
    work = Path(work)
    tasks = _tasks(cfg)
    payload = {"version": 1, "tasks": tasks,
               "boundary": "Task completion records searched scope, not exhaustive public-event coverage."}
    _save(work / "discovery/plan.json", payload)
    return status(work, cfg, _candidates(work))


def _candidates(work):
    path = work / 'event_candidate_review.csv'
    if not path.is_file():
        return []
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def _capture(work, result_path):
    path = Path(result_path)
    path = (path if path.is_absolute() else work / path).resolve()
    if not path.is_relative_to(work.resolve()) or not path.is_file():
        raise ValueError("result_path must identify a saved search result inside the workspace")
    raw = path.read_bytes()
    if not raw:
        raise ValueError("Saved search result is empty")
    return str(path.relative_to(work.resolve())), hashlib.sha256(raw).hexdigest()


def import_results(work, cfg, path):
    """Validate a batch, archive receipts, then atomically replace current state.

    Repeating an identical import is idempotent. Replacing a task receipt archives
    both revisions. Current inbox and pending files are reproducible projections.
    """
    work = Path(work)
    tasks = {item["task_id"]: item for item in _tasks(cfg)}
    batch = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if not isinstance(batch, list):
        raise ValueError("Search import must be a JSON array")
    receipts = []
    seen = set()
    for item in batch:
        task_id = item.get("task_id")
        if task_id not in tasks or task_id in seen:
            raise ValueError("Unknown or duplicate task_id: " + str(task_id))
        seen.add(task_id)
        task = tasks[task_id]
        if item.get("query") != task["query"]:
            raise ValueError("Record the planned broad query; targeted event searches cannot replace it")
        dt.date.fromisoformat(item["executed_at"])
        if item.get("outcome") not in {"completed", "blocked", "partial"}:
            raise ValueError("Invalid search outcome")
        if len(str(item.get("stop_basis") or "").strip()) < 15:
            raise ValueError("A specific search stopping or blocking reason is required")
        relative_path, capture_hash = _capture(work, item["result_path"])
        hits = item.get("hits")
        if not isinstance(hits, list):
            raise ValueError("hits must contain every returned result inspected for relevance")
        normalized = []
        for hit in hits:
            url = str(hit.get("url") or "").strip()
            parsed = urlsplit(url)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise ValueError("Search hits require absolute HTTP URLs")
            if not hit.get("title") or type(hit.get("relevant")) is not bool:
                raise ValueError("Each hit needs title and a boolean relevant flag")
            if not hit["relevant"] and not str(hit.get("exclusion_reason") or "").strip():
                raise ValueError("Irrelevant results require an exclusion reason")
            normalized.append({"url": url, "title": str(hit["title"]),
                               "relevant": hit["relevant"],
                               "exclusion_reason": str(hit.get("exclusion_reason") or ""),
                               "candidate_id": candidate_id(task["company_id"], url)})
        receipt = {**task, "executed_at": item["executed_at"], "outcome": item["outcome"],
                   "stop_basis": item["stop_basis"], "result_path": relative_path,
                   "result_sha256": capture_hash, "hits": normalized}
        receipt["receipt_sha256"] = _digest(receipt)
        receipts.append(receipt)
    with _import_lock(work):
        current = _read(work / "discovery/receipts.json", {})
        for receipt in receipts:
            _save(work / "discovery/history" / (receipt["receipt_sha256"] + ".json"), receipt)
            current[receipt["task_id"]] = receipt
        _save(work / "discovery/receipts.json", current)
    return status(work, cfg, _candidates(work))


def status(work, cfg, candidates):
    """Return named gaps and compact tasks without treating old logs as receipts."""
    work = Path(work)
    tasks = _tasks(cfg)
    receipts = _read(work / "discovery/receipts.json", {})
    candidates = list(candidates)
    by_id = {row.get("candidate_id"): row for row in candidates}
    pending, gaps, inbox = [], [], {}
    relevant_ids = set()
    for task in tasks:
        receipt = receipts.get(task["task_id"])
        reason = None
        if receipt is None:
            reason = "search_not_executed"
        else:
            unsigned = {key: value for key, value in receipt.items() if key != "receipt_sha256"}
            if receipt.get("scope_sha256") != task["scope_sha256"] or receipt.get("receipt_sha256") != _digest(unsigned):
                reason = "search_receipt_changed"
            else:
                try:
                    _, actual_hash = _capture(work, receipt["result_path"])
                    if actual_hash != receipt.get("result_sha256"):
                        reason = "search_capture_changed"
                except (OSError, ValueError, KeyError):
                    reason = "search_capture_unavailable"
            if reason is None and receipt.get("outcome") != "completed":
                reason = "search_" + str(receipt.get("outcome"))
            for hit in receipt.get("hits", []):
                cid = hit["candidate_id"]
                row = inbox.setdefault(cid, {"candidate_id": cid, "company_id": task["company_id"],
                                           "company": task["company"], "source_url": hit["url"],
                                           "title": hit["title"], "task_ids": set(), "relevant": False})
                row["task_ids"].add(task["task_id"])
                row["relevant"] = row["relevant"] or hit["relevant"]
                if hit["relevant"]:
                    relevant_ids.add(cid)
                    candidate = by_id.get(cid)
                    if candidate is None:
                        gaps.append({"contract": "discovery", "reason": "search_hit_unaccounted",
                                     "candidate_id": cid, "source_url": hit["url"]})
                    elif (candidate.get("company_id") not in {None, "", task["company_id"]}
                          or candidate.get("company") not in task["aliases"]
                          or urldefrag(candidate.get("source_url") or "")[0] != urldefrag(hit["url"])[0]):
                        gaps.append({"contract": "discovery", "reason": "candidate_identity_mismatch",
                                     "candidate_id": cid})
        if reason:
            gaps.append({"contract": "discovery", "reason": reason, "task_id": task["task_id"]})
            pending.append({**task, "reason": reason})
    # Projection writes are replaceable; current receipts remain the authoritative state.
    fields = ["candidate_id", "company_id", "company", "source_url", "title", "task_ids", "relevant"]
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    for row in sorted(inbox.values(), key=lambda item: item["candidate_id"]):
        writer.writerow({**row, "task_ids": ";".join(sorted(row["task_ids"]))})
    _atomic(work / "discovery/inbox.csv", buffer.getvalue())
    result = {"pass": not gaps, "tasks": len(tasks), "pending_tasks": len(pending),
              "unique_relevant_hits": len(relevant_ids), "gaps": gaps,
              "boundary": "Receipts document searches and result accounting; they do not prove exhaustive web coverage."}
    _save(work / "review/discovery-next.json", {"pending": pending, "gaps": gaps,
                                               "inbox": "discovery/inbox.csv"})
    return result
