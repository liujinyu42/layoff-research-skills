"""Executed-search registry, kept separate from discovered events.

`found_events` proves a plan exists. `none_found` proves a window was searched.
Neither is a claim about the world beyond the searched channel and stop condition.
"""
from __future__ import annotations

import csv
import datetime
import io
from pathlib import Path

from . import contracts


def load(skill):
    payload = contracts.asset(skill, 'search_coverage')
    for group in ('channels', 'outcomes'):
        if not isinstance(payload.get(group), dict) or not payload[group]:
            raise ValueError('Search coverage contract needs a non-empty ' + group + ' vocabulary')
    for code, item in payload['outcomes'].items():
        if not isinstance(item.get('counts_as_covered'), bool):
            raise ValueError('Outcome ' + code + ' needs an explicit counts_as_covered flag')
    return payload


def _date(value, field, number):
    text = str(value or '').strip()
    if not text:
        raise ValueError(f'Row {number}: {field} is required')
    try:
        return datetime.date.fromisoformat(text)
    except ValueError as exc:
        raise ValueError(f'Row {number}: {field} must be an ISO date') from exc


def _flag(value):
    return contracts.flag(value) is True


def normalize(contract, row, number, cfg, ents):
    channels = contract['channels']
    outcomes = contract['outcomes']
    company = str(row.get('company_id') or '').strip()
    roster = {item['company_id']: item for item in cfg['roster']}
    if company not in roster:
        raise ValueError(f'Row {number}: unknown company_id ' + (company or '(empty)'))
    channel = str(row.get('channel') or '').strip()
    if channel not in channels:
        raise ValueError(f'Row {number}: channel must be one of ' + ', '.join(channels))
    outcome = str(row.get('outcome') or '').strip()
    if outcome not in outcomes:
        raise ValueError(f'Row {number}: outcome must be one of ' + ', '.join(outcomes))
    query = str(row.get('query') or '').strip()
    if len(query) < 5:
        raise ValueError(f'Row {number}: record the actual query, at least five characters')
    start = _date(row.get('window_start'), 'window_start', number)
    end = _date(row.get('window_end'), 'window_end', number)
    if start > end:
        raise ValueError(f'Row {number}: window_start is after window_end')
    requested_start = datetime.date.fromisoformat(cfg['event_start'])
    requested_end = datetime.date.fromisoformat(cfg['event_end'])
    if outcome != 'out_of_scope' and (end < requested_start or start > requested_end):
        raise ValueError(f'Row {number}: window lies outside the requested event window; '
                         'use outcome=out_of_scope and explain in notes')
    executed = str(row.get('executed_at') or '').strip()
    if outcome in {'found_events', 'none_found'}:
        _date(executed, 'executed_at', number)
    notes = str(row.get('notes') or '').strip()
    stop = str(row.get('stop_condition') or '').strip()
    search_scope = row.get('search_scope') or 'event_lookup'
    if search_scope not in {'event_lookup', 'window_sweep'}:
        raise ValueError(f'Row {number}: invalid search_scope')
    if search_scope == 'window_sweep' and len(stop) < 15:
        raise ValueError(f'Row {number}: window_sweep requires a coverage stopping basis')
    if outcome == 'none_found' and len(stop) < 15:
        raise ValueError(f'Row {number}: none_found needs a stop_condition describing how the search ended')
    if outcome == 'blocked' and len(notes) < 15:
        raise ValueError(f'Row {number}: blocked needs a specific access or platform limitation in notes')
    if outcome == 'out_of_scope' and len(notes) < 15:
        raise ValueError(f'Row {number}: out_of_scope needs a reason in notes')
    registered = row.get('events_registered')
    if isinstance(registered, str):
        registered = [plan.strip() for plan in registered.replace('|', ';').split(';') if plan.strip()]
    registered = registered or []
    if outcome == 'found_events' and not registered:
        raise ValueError(f'Row {number}: found_events needs the plan_id values it produced in events_registered')
    for plan in registered:
        if plan not in ents:
            raise ValueError(f'Row {number}: events_registered names an unregistered plan ' + str(plan))
        if ents[plan]['company_id'] != company:
            raise ValueError(f'Row {number}: plan ' + str(plan) + ' belongs to another company')
    return {'company_id': company, 'company': roster[company]['company'],
            'window_start': start.isoformat(), 'window_end': end.isoformat(),
            'channel': channel, 'query': query,
            'executed_at': executed or None,
            'pages_reviewed': row.get('pages_reviewed'),
            'stop_condition': stop or None, 'outcome': outcome,
            'search_scope': search_scope,
            'counts_as_covered': bool(outcomes[outcome]['counts_as_covered']) and search_scope == 'window_sweep',
            'candidates_found': row.get('candidates_found'),
            'events_registered': registered, 'source_ids': [s.strip() for s in
                                                           str(row.get('source_ids') or '').replace('|', ';').split(';')
                                                           if s.strip()],
            'operator': str(row.get('operator') or '').strip() or None,
            'notes': notes or None}


def import_log(skill, work, path, cfg, ents, book_version):
    contract = load(skill)
    rows = contracts.parse_rows(path)
    errors, records = [], []
    for number, row in enumerate(rows, 1):
        try:
            records.append(normalize(contract, row, number, cfg, ents))
        except (ValueError, KeyError, TypeError) as exc:
            errors.append({'row': number, 'company_id': row.get('company_id'), 'error': str(exc)})
    report = {'pass': not errors, 'errors': errors, 'rows': len(records)}
    if errors:
        return report
    payload = coverage(contract, cfg, ents, records)
    contracts.record(work, 'search_coverage', payload, skill, book_version)
    report.update(payload['summary'])
    return report


def _merge(intervals):
    merged = []
    for start, end in sorted(intervals):
        if merged and start <= merged[-1][1] + datetime.timedelta(days=1):
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return merged


def _uncovered(start, end, covered):
    gaps, cursor = [], start
    for lo, hi in covered:
        if lo > cursor:
            gaps.append((cursor, min(lo - datetime.timedelta(days=1), end)))
        cursor = max(cursor, hi + datetime.timedelta(days=1))
        if cursor > end:
            break
    if cursor <= end:
        gaps.append((cursor, end))
    return [(lo, hi) for lo, hi in gaps if lo <= hi]


def coverage(contract, cfg, ents, records):
    start = datetime.date.fromisoformat(cfg['event_start'])
    end = datetime.date.fromisoformat(cfg['event_end'])
    plan = list(cfg.get('search_channel_plan') or (contract.get('channel_plan') or {}).get('default') or [])
    by_company = {}
    for row in records:
        item = by_company.setdefault(row['company_id'], {'company_id': row['company_id'],
                                                         'company': row['company'],
                                                         'windows': [], 'outcomes': {},
                                                         'per_channel': {}, 'registered_plans': set()})
        item['outcomes'][row['outcome']] = item['outcomes'].get(row['outcome'], 0) + 1
        channel = item['per_channel'].setdefault(row['channel'], {'windows': [], 'searches': 0,
                                                                  'covered': False})
        channel['searches'] += 1
        if row['counts_as_covered']:
            channel['windows'].append((datetime.date.fromisoformat(row['window_start']),
                                       datetime.date.fromisoformat(row['window_end'])))
            channel['covered'] = True
        if row['counts_as_covered']:
            item['windows'].append((datetime.date.fromisoformat(row['window_start']),
                                    datetime.date.fromisoformat(row['window_end'])))
        item['registered_plans'].update(row['events_registered'])
    companies = []
    for entry in cfg['roster']:
        item = by_company.get(entry['company_id'], {'company_id': entry['company_id'],
                                                    'company': entry['company'], 'windows': [],
                                                    'outcomes': {}, 'per_channel': {},
                                                    'registered_plans': set()})
        merged = _merge(item['windows'])
        gaps = _uncovered(start, end, merged)
        covered_days = sum((hi - lo).days + 1 for lo, hi in merged)
        total_days = (end - start).days + 1
        channels = {}
        for channel in sorted(set(plan) | set(item['per_channel'])):
            data = item['per_channel'].get(channel) or {'windows': [], 'searches': 0, 'covered': False}
            channel_gaps = _uncovered(start, end, _merge(data['windows']))
            channels[channel] = {'planned': channel in plan, 'searches': data['searches'],
                                 'covered': data['covered'],
                                 'uncovered_intervals': [[lo.isoformat(), hi.isoformat()] for lo, hi in channel_gaps]}
        missing_channels = [channel for channel in plan if channels[channel]['uncovered_intervals']]
        companies.append({'company_id': entry['company_id'], 'company': entry['company'],
                          'searches': sum(item['outcomes'].values()),
                          'outcomes': dict(sorted(item['outcomes'].items())),
                          'covered_intervals': [[lo.isoformat(), hi.isoformat()] for lo, hi in merged],
                          'uncovered_intervals': [[lo.isoformat(), hi.isoformat()] for lo, hi in gaps],
                          'covered_days': covered_days, 'requested_days': total_days,
                          'window_coverage': round(covered_days / total_days, 6),
                          'channel_plan': plan, 'channels': channels,
                          'missing_planned_channels': missing_channels,
                          'channel_plan_complete': not missing_channels,
                          'registered_plans': sorted(item['registered_plans'])})
    searched = {item['company_id'] for item in companies if item['searches']}
    plans_with_search = {plan_id for item in records for plan_id in item['events_registered']}
    summary = {'companies_requested': len(cfg['roster']),
               'companies_with_executed_search': len(searched),
               'companies_never_searched': len({item['company_id'] for item in cfg['roster']} - searched),
               'none_found_searches': sum(item['outcomes'].get('none_found', 0) for item in companies),
               'blocked_searches': sum(item['outcomes'].get('blocked', 0) for item in companies),
               'pending_searches': sum(item['outcomes'].get('pending', 0) for item in companies),
               'registered_plans': len(ents),
               'plans_with_a_search_record': len(plans_with_search & set(ents)),
               'plans_without_a_search_record': len(set(ents) - plans_with_search),
               'channel_plan': plan,
               'companies_with_complete_channel_plan': sum(1 for item in companies if item['channel_plan_complete']),
               'companies_missing_a_planned_channel': [item['company_id'] for item in companies
                                                       if not item['channel_plan_complete']],
               'mean_window_coverage': round(sum(item['window_coverage'] for item in companies) /
                                             max(len(companies), 1), 6),
               'boundary': 'Coverage measures executed searches per declared channel, not the existence of every '
                           'public event.'}
    return {'companies': companies, 'summary': summary, 'records': records,
            'channel_plan': plan, 'requested_window': [start.isoformat(), end.isoformat()]}


def gate(skill, work, cfg, ents, book_version):
    if 'search_coverage' not in contracts.active(skill, cfg):
        return [], []
    try:
        payload = contracts.require_record(skill, work, 'search_coverage', book_version)
    except (ValueError, OSError) as exc:
        return [{'contract': 'search_coverage', 'reason': 'not_recorded', 'detail': str(exc),
                 'expects': 'one registry row per company x window x channel searched'}], []
    gaps = []
    never = [item['company_id'] for item in payload['companies'] if not item['searches']]
    if never:
        gaps.append({'contract': 'search_coverage', 'reason': 'company_never_searched',
                     'count': len(never), 'example': never[:5],
                     'expects': 'a search row even when it finds nothing'})
    partial = [{'company_id': item['company_id'], 'uncovered': item['uncovered_intervals'][:3]}
               for item in payload['companies'] if item['searches'] and item['uncovered_intervals']]
    if partial:
        gaps.append({'contract': 'search_coverage', 'reason': 'unsearched_window',
                     'count': len(partial), 'example': partial[:3],
                     'expects': 'contiguous coverage of the requested event window, or a named blocker'})
    unlogged = [plan for plan in ents
                if plan not in {p for item in payload['records'] for p in item['events_registered']}]
    if unlogged:
        gaps.append({'contract': 'search_coverage', 'reason': 'plan_without_search_record',
                     'count': len(unlogged), 'example': unlogged[:5],
                     'expects': 'every registered plan traceable to the search that found it'})
    unplanned = [{'company_id': item['company_id'], 'channels': item['missing_planned_channels']}
                 for item in payload['companies']
                 if item['searches'] and item['missing_planned_channels']]
    if unplanned:
        gaps.append({'contract': 'search_coverage', 'reason': 'planned_channel_not_searched',
                     'count': len(unplanned), 'example': unplanned[:3],
                     'expects': 'an executed search row for every channel in the declared plan, or a named blocker'})
    return gaps, []


def export_csv(skill, work, path, book_version):
    payload = contracts.require_record(skill, work, 'search_coverage', book_version)
    fields = ['company_id', 'company', 'window_start', 'window_end', 'channel', 'query', 'executed_at',
              'pages_reviewed', 'stop_condition', 'outcome', 'candidates_found',
              'events_registered', 'source_ids', 'operator', 'notes', 'search_scope']
    path = Path(path)
    contracts.mkdir(path.parent)
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fields, extrasaction='ignore')
    writer.writeheader()
    for row in payload['records']:
        writer.writerow({**row, 'events_registered': ';'.join(row['events_registered']),
                         'source_ids': ';'.join(row['source_ids'])})
    path.write_text(buffer.getvalue(), encoding='utf-8')
    return {'output': str(path), 'rows': len(payload['records']),
            'grain': 'one row per executed company x window x channel search'}
