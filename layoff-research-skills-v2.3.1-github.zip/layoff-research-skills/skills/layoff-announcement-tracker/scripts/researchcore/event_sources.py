"""Use the ingest vocabulary for event evidence and display selection."""
from .sources import ALLOWED_TYPES
from urllib.parse import urlsplit


EVENT_ROLES = {'layoff_announcement', 'event_filing', 'news_report', 'official_disclosure'}
PRIMARY_TYPES = {'company_announcement', 'sec_filing', 'exchange_filing', 'warn', 'company_disclosure'}
EVENT_TYPES = PRIMARY_TYPES | {'news'}
assert EVENT_TYPES <= ALLOWED_TYPES


def is_event_source(source):
    url = urlsplit(source.get('source_url') or '')
    search_page = (url.hostname or '').startswith(('www.google.', 'news.google.')) and url.path.startswith('/search')
    return (source.get('status') == 'ready' and url.scheme in {'https', 'http'}
            and bool(url.netloc) and not search_page
            and source.get('source_type') in EVENT_TYPES
            and source.get('document_role') in EVENT_ROLES)


def verification_url(entity_id, decisions, sources):
    """Pick a cited event source, preserving primary/secondary provenance."""
    candidates = {}
    priorities = ('layoff_count', 'layoff_count_lower', 'layoff_count_upper', 'announcement_date',
                  'event_type', 'affected_parties', 'numerical_claim_raw', 'source_publication_date')
    for priority, variable in enumerate(priorities):
        decision = decisions.get(entity_id + '|' + variable, {})
        for evidence in decision.get('evidence', []):
            source = sources.get(evidence.get('source_id'), {})
            if source.get('plan_id') == entity_id and is_event_source(source):
                tier = 0 if source.get('source_type') in PRIMARY_TYPES - {'warn'} else 1
                rank = (priority, tier, source['source_id'])
                current = candidates.get(source['source_id'])
                if current is None or rank < current[0]:
                    candidates[source['source_id']] = (rank, source)
    if not candidates:
        return None
    _, selected = min(candidates.values(), key=lambda item: item[0])
    return selected['source_url']
