"""Bind candidate disposition review to actual source spans and ledger content."""
import csv
import hashlib
import json
from pathlib import Path

from .event_sources import is_event_source


FIELDS = ('candidate_id', 'company', 'reported_date', 'source_url', 'affected_scope',
          'disposition', 'plan_id', 'evidence_url', 'reason')
EXCLUSIONS = {'outside_window', 'wrong_entity', 'duplicate_candidate', 'no_workforce_reduction',
              'voluntary_only', 'contractor_only', 'speculation_only', 'context_document'}


def row_hash(row):
    content = {key: (row.get(key) or '').strip() for key in FIELDS}
    return hashlib.sha256(json.dumps(content, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def audit(work, cfg, entities, sources, get_text):
    work = Path(work)
    ledger = work / 'event_candidate_review.csv'
    if not ledger.is_file():
        return {'gaps': [{'candidate_id': None, 'reason': 'candidate ledger missing'}], 'tasks': []}
    with ledger.open(encoding='utf-8-sig', newline='') as handle:
        candidates = list(csv.DictReader(handle))
    receipts_path = work / 'candidate_reviews.json'
    receipts = json.loads(receipts_path.read_text()) if receipts_path.is_file() else {}
    if not isinstance(receipts, dict):
        raise ValueError('candidate_reviews.json must map candidate IDs to review records')
    gaps, tasks = [], []
    for row in candidates:
        cid = row.get('candidate_id', '')
        disposition = row.get('disposition')
        if disposition == 'unresolved':
            tasks.append({'candidate_id': cid, 'candidate_sha256': row_hash(row),
                          'priority': 'verify_event_before_enriching_context',
                          'query': ' '.join((row.get('company', ''), row.get('reported_date', ''),
                                             row.get('affected_scope', ''), 'layoffs')),
                          'actions': ['Find a publicly accessible original or attributed syndication',
                                      'Find another outlet quoting the issuer or a regulator notice',
                                      'Verify the event even if its exact count remains unresolved'],
                          'stop': 'After two distinct fallback searches and checking accessible hits, record remaining blocker'})
            continue
        receipt = receipts.get(cid, {})
        if not isinstance(receipt, dict):
            receipt = {}
        problems = []
        if receipt.get('candidate_sha256') != row_hash(row):
            problems.append('missing or stale disposition review')
        if not receipt.get('reviewer_id') or not receipt.get('criterion_application'):
            problems.append('missing substantive review')
        checks = receipt.get('checks', {})
        if not isinstance(checks, dict):
            checks = {}
        if not all(isinstance(checks.get(key), str) and checks[key].strip() for key in
                   ('entity', 'date_basis', 'action', 'credibility', 'count_scope')):
            problems.append('entity/date/action/credibility/count checks incomplete')
        if disposition == 'merged' and not checks.get('plan_link'):
            problems.append('merge requires a specific plan-link explanation')
        if disposition == 'excluded' and receipt.get('exclusion_code') not in EXCLUSIONS:
            problems.append('exclusion needs a supported reason; access failure requires unresolved')
        evidence = receipt.get('evidence', [])
        if not isinstance(evidence, list) or not evidence:
            problems.append('no exact disposition evidence')
            evidence = []
        valid_event_source = False
        for span in evidence:
            if not isinstance(span, dict):
                problems.append('invalid evidence object')
                continue
            source = sources.get(span.get('source_id'), {})
            try:
                if source.get('status') != 'ready' or span.get('text_sha256') != source.get('text_sha256'):
                    raise ValueError('unready or stale source')
                if not span.get('row_sha256') or span.get('row_sha256') != source.get('row_sha256'):
                    raise ValueError('source metadata changed; repeat disposition review')
                start, quote = span.get('char_start'), span.get('quote')
                text = get_text(span['source_id'])
                if type(start) is not int or start < 0 or not isinstance(quote, str) or not quote.strip():
                    raise ValueError('invalid evidence span')
                if text[start:start + len(quote)] != quote:
                    raise ValueError('source quote mismatch')
                if disposition in {'included', 'merged'}:
                    entity = entities.get(row.get('plan_id'), {})
                    if (source.get('company_id') != entity.get('company_id')
                            or source.get('plan_id') != row.get('plan_id')):
                        raise ValueError('source is bound to another entity or plan')
                valid_event_source |= is_event_source(source)
            except (KeyError, TypeError, ValueError, OSError) as exc:
                problems.append(str(exc))
        if disposition in {'included', 'merged'} and not valid_event_source:
            problems.append('no ready event source in disposition review')
        for problem in problems:
            gaps.append({'candidate_id': cid, 'reason': problem})
    return {'gaps': gaps, 'tasks': tasks, 'candidates': len(candidates),
            'boundary': 'Source binding checks do not independently judge the truth of semantic review'}


def prepare(work, cfg, sources):
    """Create small receipt tasks without loading source bodies or re-reading documents."""
    from .workflow import save
    work = Path(work)
    with (work / 'event_candidate_review.csv').open(encoding='utf-8-sig', newline='') as handle:
        candidates = list(csv.DictReader(handle))
    path = work / 'candidate_reviews.json'
    receipts = json.loads(path.read_text()) if path.is_file() else {}
    tasks = []
    for row in candidates:
        cid = row['candidate_id']
        receipt = receipts.get(cid, {})
        if (isinstance(receipt, dict) and receipt.get('candidate_sha256') == row_hash(row)
                and isinstance(receipt.get('evidence'), list) and receipt['evidence']
                and all(sources.get(e.get('source_id'), {}).get('row_sha256') == e.get('row_sha256')
                        for e in receipt.get('evidence', []) if isinstance(e, dict))):
            continue
        matching = [source for source in sources.values()
                    if source.get('status') == 'ready'
                    and source.get('source_url') in {row.get('source_url'), row.get('evidence_url')}]
        tasks.append({'candidate': row, 'candidate_sha256': row_hash(row),
                      'source_bindings': [{key: source.get(key) for key in
                                          ('source_id', 'row_sha256', 'text_sha256', 'text_path')}
                                         for source in matching],
                      'required_checks': ['entity', 'date_basis', 'action', 'credibility', 'count_scope', 'plan_link']})
    save(work / 'review/candidate-tasks.json', tasks)
    return {'tasks': len(tasks), 'output': str(work / 'review/candidate-tasks.json')}
