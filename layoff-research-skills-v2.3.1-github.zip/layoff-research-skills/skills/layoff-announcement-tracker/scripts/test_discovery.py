"""Regression checks for unaccounted search hits and stale local captures."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from researchcore import discovery


class DiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.work = Path(self.temporary.name)
        self.cfg = {"event_start": "2024-03-01", "event_end": "2024-12-31",
                    "roster": [{"company_id": "a", "company": "Example Corporation",
                                "aliases": "Old Example;Example Brand"}]}
        discovery.plan(self.work, self.cfg)
        self.tasks = json.loads((self.work / "discovery/plan.json").read_text())["tasks"]
        (self.work / "capture.txt").write_text("Actual saved search results\n")

    def payload(self, task, url="https://example.com/news"):
        return {"task_id": task["task_id"], "query": task["query"],
                "executed_at": "2026-11-07", "outcome": "completed",
                "stop_basis": "The returned results were inspected through the requested period.",
                "result_path": "capture.txt",
                "hits": [{"url": url, "title": "Reported staff reduction", "relevant": True}]}

    def submit(self, rows):
        path = self.work / "batch.json"
        path.write_text(json.dumps(rows))
        return discovery.import_results(self.work, self.cfg, path)

    def test_aliases_and_clipped_period(self):
        self.assertEqual(len(self.tasks), 2)
        for task in self.tasks:
            self.assertIn('"Old Example"', task["query"])
            self.assertIn('"Example Brand"', task["query"])
            self.assertEqual(task["window_start"], "2024-03-01")

    def test_hit_ledger_and_idempotent_import(self):
        rows = [self.payload(task) for task in self.tasks]
        self.submit(rows)
        original = (self.work / "discovery/receipts.json").read_bytes()
        result = self.submit(rows)
        self.assertEqual(original, (self.work / "discovery/receipts.json").read_bytes())
        self.assertTrue(any(gap["reason"] == "search_hit_unaccounted" for gap in result["gaps"]))
        cid = discovery.candidate_id("a", "https://example.com/news")
        result = discovery.status(self.work, self.cfg, [{"candidate_id": cid,
                                  "company": "Example Corporation",
                                  "source_url": "https://example.com/news"}])
        self.assertTrue(result["pass"])
        self.assertEqual(result["unique_relevant_hits"], 1)
        self.assertNotEqual(cid, discovery.candidate_id("b", "https://example.com/news"))

    def test_capture_change_and_receipt_edit(self):
        self.submit([self.payload(task) for task in self.tasks])
        (self.work / "capture.txt").write_text("Changed result capture")
        result = discovery.status(self.work, self.cfg, [])
        self.assertTrue(any(gap["reason"] == "search_capture_changed" for gap in result["gaps"]))
        path = self.work / "discovery/receipts.json"
        receipts = json.loads(path.read_text())
        receipts[self.tasks[0]["task_id"]]["stop_basis"] = "Edited receipt"
        path.write_text(json.dumps(receipts))
        result = discovery.status(self.work, self.cfg, [])
        self.assertTrue(any(gap["reason"] == "search_receipt_changed" for gap in result["gaps"]))

    def test_failed_batch_does_not_write_receipts(self):
        row = self.payload(self.tasks[0])
        row["hits"][0]["relevant"] = "true"
        with self.assertRaises(ValueError):
            self.submit([row])
        self.assertFalse((self.work / "discovery/receipts.json").exists())

    def test_blocked_and_missing_are_named_gaps(self):
        row = self.payload(self.tasks[0])
        row["outcome"] = "blocked"
        row["hits"] = []
        result = self.submit([row])
        reasons = {gap["reason"] for gap in result["gaps"]}
        self.assertIn("search_blocked", reasons)
        self.assertIn("search_not_executed", reasons)

    def test_reject_known_event_query_and_escape_path(self):
        row = self.payload(self.tasks[0])
        row["query"] = "Example layoffs October 16 2024"
        with self.assertRaises(ValueError):
            self.submit([row])
        row = self.payload(self.tasks[0])
        row["result_path"] = "../outside.txt"
        with self.assertRaises(ValueError):
            self.submit([row])


if __name__ == "__main__":
    unittest.main()
