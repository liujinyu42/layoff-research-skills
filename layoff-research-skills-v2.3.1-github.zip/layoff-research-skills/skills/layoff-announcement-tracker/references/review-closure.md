# Source review closure (v1.5.3)

Read this before source decisions and again before final export. These rules apply without prior chat history.

## Close the review, not the blanks
Run next-actions and resolve each pending position against the applicable full sections, statement notes and incorporated compensation disclosures. Group work by company, year and source to reuse reading. Record searched documents/sections and the result. An empty numeric value may be separately undisclosed, unavailable, inapplicable, conflicting or unfinished; never replace it with a proxy or zero. A disclosure flag is 0 only after a completed source-supported negative review. Do not copy a prior run's reviewed_absent status without checking its scope. Export genuine PARTIAL with the generated review queue when sources or judgments remain unavailable; do not stop merely because tasks were dispatched.

## Events and numbers
For each candidate plan, compare scope, initial authorization, incremental headcount and implementation dates against existing plans. Common acquisition context alone does not prove one plan; a different news date alone does not prove a new plan. Populate plan_relationship and related_plan_id only with supported judgments. Separate M&A/leadership background from company-stated reasons. Complete the declared issuer and other search channels before not_found_after_search.

Preserve numerical_claim_raw. Fewer than/under is an exclusive upper bound, not a point. Nearly implies a below-threshold approximation: retain its wording and resolve conflicting reports, rather than silently treating it as an exact or symmetric estimate. Keep source-specific claims when sources disagree. Never require a particular number of nonempty bound fields.

Separate first public announcement, report date and effective date; keep month/interval precision when a day is unverified. For event workforce denominators check both fact date and publication date. Use the latest appropriate observation publicly available before the event when constructing a pre-event measure; a fiscal-year label alone is insufficient. Do not replace an early-year denominator with a later year-end figure or expand the requested years silently.

## Annual constructs and evidence
Trace current-year versus comparative columns, totals versus components, actual costs versus commitments/policies, and actual awards versus future incentives. Preserve those distinctions in decision evidence and review notes. AI-specific amounts cannot be inferred from R&D, cloud capex, SBC or total executive pay.

Established cloud use may meet new_tech_adoption under the bundled definition but is not AI or first adoption. Distinguish GAI, other AI, automation and cloud; plan/pilot/deployed; internal use/customer products in the technology sidecar. MD&A expense composition is weaker evidence of HR strategy than an explicit action: describe what is actually supported. Same text may support multiple constructs and recur across annual filings; verify each occurrence and deduplicate real projects for capability counts. Do not create separate project identities solely because variable names differ.

## Deliver and interpret
Preserve the single English Results sheet and bundled columns. Deliver original sources, measurement records, review queue, sidecar index and audit together. Recompute derived records after upgrade; layered-v4 invalidates old algorithm records, not original source files. Verify the audit workbook hash before comparing runs. Separate runtime, schema and contract versions.

Local pre-event evidence is a descriptive prerequisite. A full RQ2 contrast also requires verified reason groups, eligible event-level joins, comparable measures and an appropriate analysis design. No causal conclusion follows from completeness or audit success. Profit changes after layoffs are not proof layoffs caused the changes. The historical corpus size is not a mandatory run quota; job-skill pairing remains a separate next step. Require independent human annotations before human reliability claims.
