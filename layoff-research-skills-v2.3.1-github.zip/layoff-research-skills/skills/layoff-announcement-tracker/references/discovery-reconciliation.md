# Discovery and candidate reconciliation

Use this procedure before company-profile enrichment and the per-field coding loop. It applies to any input company. Company names, former names, countries and business units come from the verified roster and discovered evidence.

## Execute and preserve searches

Run `discovery-plan --work W` after verifying the roster. Add verified historical and common names in the roster's `aliases` field, separated by semicolons, before planning. The planner combines these aliases into two broad query families per company and year. The commands create tasks and compact queues. The host's Google/search/browser tools execute the actual queries.

For each query, save the actual search tool result or browser result capture inside the workspace. Record the returned URLs and titles, with a boolean relevance judgment and a reason for each rejected hit. Save all inspected hits, including repeats and potentially relevant small rounds. Save the full inspected search result capture before filtering. Specific known dates and large counts belong in supplementary queries. Finding one event does not finish an annual search. Mark truncated, capped or unfinished searches `partial`. Search uncovered months, quarters, units or locations before declaring the bounded sweep finished. Record the actual stopping basis and access limitations.

Import one JSON array of completed query records in a batch. This example illustrates the data shape. Replace every example value with the actual task, execution result and saved path.

```json
[
  {
    "task_id": "task ID from discovery/plan.json",
    "query": "exact planned query",
    "executed_at": "2026-11-07",
    "outcome": "completed",
    "stop_basis": "Actual bounded search coverage and stopping explanation",
    "result_path": "discovery/captures/search-result.json",
    "hits": [
      {"url": "https://example.org/article", "title": "Article title", "relevant": true}
    ]
  }
]
```

```bash
python "$S/scripts/research.py" discovery-import --work "$W" --file "$W/discovery/batch.json"
python "$S/scripts/research.py" discovery-status --work "$W"
```

`discovery/inbox.csv` preserves deduplicated company-and-URL candidates with stable IDs. Transfer those IDs to `event_candidate_review.csv` before coding dispositions. Distinct URLs remain distinct candidates even when they later prove to describe one plan. The audit checks every relevant imported hit against the candidate ledger. Supplied reference lists and bulk tracker snapshots also enter the candidate ledger. Do not replace inaccessible records with a claim of no events.

Existing search-log imports now take `search_scope=event_lookup` or `window_sweep`. Old rows default to event lookups and cannot certify a whole-year search. The snapshot-backed discovery gate is separate from the search-coverage contract.

## Resolve blocked candidates before enriching profiles

Use the exact headline, company, unit and month to find public syndication or original reporting from another publisher. Then check a company statement, regulator notice or direct spokesperson attribution where available. Try two distinct fallback queries and inspect accessible hits before retaining an access blocker. Licensed copies of the same wire story preserve its authorship and do not count as independent corroboration. No access-control bypass is required. A credible original report can establish an event without an issuer-hosted announcement. A count may stay null while the event is verified.

Verified regulatory notices can support local event rows without a second issuer announcement. Use notice date, effective date, actual employer and population. If a parent plan is unknown, retain `plan_identity_verified=0` and explain the unresolved relationship in the decision metadata. Keep local counts non-additive to possible parent-wide counts until overlap is resolved. Register distinct notices individually as candidates. Merge facilities or dates into a plan only when evidence supports the link.

## Bind disposition reviews

Run `candidate-review-prepare --work W` to write compact tasks with row hashes and existing source bindings. Write `candidate_reviews.json` as a map from candidate ID to a review. Preserve the ledger row hash, source text hash, source metadata hash and exact span. Record substantive checks for entity, date basis, action, source credibility and count scope. Merged candidates also need a plan-link explanation. Example shape follows.

```json
{
  "candidate ID": {
    "candidate_sha256": "hash supplied by candidate-review-prepare",
    "reviewer_id": "actual reviewer identifier",
    "criterion_application": "Explain how the cited source supports the disposition",
    "checks": {
      "entity": "Entity and employment scope established from the source",
      "date_basis": "Announcement, notice, publication or effective date and evidence",
      "action": "Confirmed workforce reduction or evidence-supported exclusion",
      "credibility": "Publisher, attribution and provenance assessment",
      "count_scope": "Population, qualifier, component/total and numerical limitations",
      "plan_link": "Evidence of the link when merged"
    },
    "evidence": [
      {
        "source_id": "registered source ID",
        "text_sha256": "current text hash",
        "row_sha256": "current source metadata hash",
        "char_start": 0,
        "quote": "Exact normalized source quotation at this offset"
      }
    ]
  }
}
```

Excluded candidates also need `exclusion_code` chosen from `outside_window`, `wrong_entity`, `duplicate_candidate`, `no_workforce_reduction`, `voluntary_only`, `contractor_only`, `speculation_only`, or `context_document`. Access failure, an unknown count or no issuer-hosted announcement require unresolved follow-up rather than a factual exclusion.

The audit saves `qa/candidate-review.json` and `review/fallback-tasks.json`. Content changes invalidate the corresponding receipt. These deterministic checks verify review coverage and source binding. The host must still judge the source's meaning. Search receipts document the observed search process and do not establish exhaustive worldwide event recall.

## Efficient execution

Batch independent queries through the host's supported search tool. Cache actual result captures and source bodies. Process unresolved event candidates before spending tokens on their company history and financial context. Read one source once for its event, dates, counts and attribution. Write the candidate receipt during that same reading. Reuse profile evidence across dates only when its fact period remains applicable. Report unique URLs, candidates, unresolved candidates, resulting plans and accessible-source failures separately.
