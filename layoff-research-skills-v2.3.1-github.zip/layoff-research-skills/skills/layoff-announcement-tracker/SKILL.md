---
name: layoff-announcement-tracker
description: Discover and verify layoff events for any company using public trackers, Google-searchable pages, regulatory notices and original reporting. Reconcile search hits and blocked sources, deduplicate plans, extract proposal company context, and export English source-linked Excel results.
---

# Layoff announcements and proposal-required company context

Implement proposal Part 1 for any company: listed, private, delisted, US or elsewhere. No historical dataset, original template, fixed company list or CIK is required. The proposal's existing 5,000+/2,952/610 counts are background, not a new collection obligation. Default event window 2020-01-01 through 2026-09-30 is user-overridable.

Read [workflow.md](references/workflow.md), [announcement-coding.md](references/announcement-coding.md) and the optional [first-use prompt](references/first-run.md). Templates, definitions and runtime are inside this skill.

Runtime 2.3.1. Before discovery, read [discovery and candidate reconciliation](references/discovery-reconciliation.md). Execute the snapshot-backed discovery plan and reconcile the result inbox. Review blocked event candidates using alternative public reporting before the profile-enrichment loop. A regulator notice or credible attributed news report can establish an event without a separate issuer announcement. Preserve uncertain plan relationships and counts explicitly. Always export a cited verification URL for an included event.

## Fixed output

Google-discoverable pages are eligible discovery leads. Apply the final source credibility review in the workflow before using a page to support a published event. A verified secondary report can support inclusion without an issuer-hosted URL. Reconcile individual regulatory notices and keep inaccessible leads visible as coverage gaps.

Before registering plans, reconcile every supplied reference lead and every discovered candidate in an English `event_candidate_review.csv` sidecar. Use columns `candidate_id,company,reported_date,source_url,affected_scope,disposition,plan_id,evidence_url,reason`. Use dispositions `included,merged,excluded,unresolved`. Verify announcement date, affected entity and qualifying workforce action from the source. Record the surviving plan ID and positive linkage evidence for each merge. A dead link requires alternate-source discovery or an unresolved disposition. Search each company and calendar year, including local-language sources and operating units when relevant. An unresolved material candidate requires PARTIAL.

Require evidence of an announced or implemented involuntary workforce reduction for admission to the layoff workbook. Keep hiring pauses, automation forecasts, generic restructuring, and stand-alone voluntary offers in the candidate sidecar. A mixed program may qualify when involuntary cuts are supported, but its voluntary or projected counts must not become layoff counts. Keep parent-wide counts at parent scope and preserve source-supported qualifiers and bounds. Before delivery, reconcile every exported plan to the candidate ledger and ensure all supplied leads have dispositions.

Preserve the nine substantive Part 1 fields: stated layoff reason, M&A activity, leadership transition, company history, event-time firm size, founding year, product/service, business model, known affected parties. Essential event identity, dates, counts/percentages and their qualifiers, listing identifiers, source/attribution and plan links make 43 business fields, plus three row identifiers and four provenance/status fields (50 base columns).

Fixed eight reason-category codes, industry/sector, duplicate other-reason and generic event-note columns are omitted. Do not restore them through full; both profile names select the same closed set. Present the company-stated reason in English with exact English source evidence or a reviewed English translation linked to the unchanged native original. Preserve attribution; do not decide that AI is an excuse or true driver.

Start with tracker seeding, then run independent search and source verification as specified in [workflow.md](references/workflow.md). Keep executed searches in the bundled search log and candidate decisions in the workspace-root ledger. Use a header-only ledger when there were no candidates. For included or merged rows, cite the exact ready manifest URL assigned to the surviving plan. Keep failed or inaccessible channels visible in the coverage log. Batch repeated coverage around the same plan and reuse the existing source cache.

## Measurement contracts

Seven versioned contracts decide what may be *claimed* from those same 50 columns, without adding one. `strict` (default) enforces them; `baseline` preserves pre-1.5 behaviour for historical workspaces.

- [Reason coding](references/reason-coding.md): nine categories, four attribution levels, one evidence span per label. AI, cost and restructuring in one statement are three labels, not a choice.
- [Search coverage](references/search-coverage.md): executed searches are recorded separately from discovered events, so a zero-row table cannot be read as "no layoffs".
- [Pre-event linkage](references/pre-event-linkage.md): a fiscal year earlier than an event is not evidence that was public before it.
- [Human validation](references/human-validation.md): blind annotation of a held-out split is the only route to a reliability claim.
- [Market routes and registry](references/market-routes-and-registry.md): which documents a market publishes, which legal entity a row is, and whether two years may be divided.

```bash
python "$S/scripts/research.py" contracts-status    --work "$W"
python "$S/scripts/research.py" contracts-scorecard --work "$W"
python "$S/scripts/research.py" readiness           --work "$W"
python "$S/scripts/research.py" next-actions        --work "$W"
```

`readiness` answers five named comparisons rather than one composite score: `reason_description`, `financial_contrast`, `pre_event_capability`, `longitudinal_performance` and `job_skill_pairing`. Each is `measurable`, `partially_measurable` or `not_measurable` with its own sample size and blockers; a contract that is present but has no usable units cannot make a comparison measurable.

`next-actions` turns every open gap into an ordered work list: deterministic repairs first (they settle what is missing, never what a value is), then the semantic comparisons that need reading and judgment. Use it instead of deciding by hand which of seven contracts to run next.

`audit` reports `measurement_contracts_pass`, `contract_gaps`, `research_readiness` (RQ1–RQ3), `comparisons` and `weakest_link` separately from evidence integrity, and COMPLETE now requires no contract gap. Sidecars are content-addressed against the contract asset, the schema version and the upstream files they were derived from, so editing a contract — or a decision the codes were read from — invalidates existing records with a named `stale_record` instead of leaving a stale claim.

## Discovery and extraction

Build a roster from names or use the supplied CSV template; verify brands, subsidiaries and legal companies. Discover candidates from an authorized existing event list, trackers, company announcements, regulatory filings and reliable news. Trace originals where available and record unsuccessful searches/access limits. A news story is not automatically a new plan. No SEC filing does not mean no layoff. The tool snapshots explicit URLs/files; host discovery is needed for dynamic trackers and local sources.

```bash
python "$S/scripts/research.py" init --work "$W" --company "Company name"
python "$S/scripts/research.py" source-plan --work "$W"
python "$S/scripts/research.py" discovery-plan --work "$W"
```

Company-profile collection is a separate stage, supporting the nine requested fields with event-time evidence. Do not discard required history/founding/product/business-model variables to shorten source review. Context sources do not enter unrelated reason-reading scopes. Distinguish the named employing entity from its parent; current business/size must not replace historical information. Later retrospective sources need explicit timing/basis.

Execute the workflow's finite reading, decision and substantive self-review loops. Distinguish voluntary exits, forced layoffs and mixed programs; preserve date precision, numeric bounds and denominators. Verify same-plan/update/implementation relationships using actual evidence, not dates or equal counts. Export 1_layoff_announcements.xlsx: one plan/event per row, only one Results sheet, no unrequested business columns. Actual blockers stay explicit PARTIAL; source integrity errors cannot be bypassed.

## English presentation

All worksheet names, company display names, values, summaries, reasons, missing-data explanations and review metadata must be English. The only worksheet is `Results`. Read [English output and semantic checks](references/english-and-measurement.md) before writing decisions. A non-English company input is allowed: verify an English name or transliteration and set `company_en` in the roster, retaining the original legal name in the source archive. Use stable ASCII IDs. Non-English exact source quotations stay unchanged in the canonical archive; provide separately reviewed English translations for the workbook. Never label a translation as a verbatim original. The exporter rejects non-Latin authored/output strings; the reader must also check actual English meaning because this guard is not a language classifier.

Read [measurement maintenance](references/review-v152.md) when upgrading or interpreting research outputs.

Before coding and final delivery, read [source review closure](references/review-closure.md). Export also writes a review queue and sidecar index; include both with the evidence archive.
