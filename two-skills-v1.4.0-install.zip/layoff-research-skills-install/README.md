# Layoff Research Skills

Version **1.4.0**, Python 3.10+.

Reusable collection skills for any identified company. They obtain and refresh the requested information when invoked; they do not require the researcher's existing dataset or recreate its historical sample size.

| Skill | Fixed research output | Grain |
|---|---|---|
| layoff-announcement-tracker | Proposal Part 1's nine substantive variables plus essential event identity, size, dates and provenance (43 business fields) | Event/plan |
| listed-filing-extractor | Only the requested HR, AI/new-technology and financial categories (42 business fields) | Company/fiscal year |

The second identifier is retained for installation compatibility, and supports nonlisted, delisted and non-US companies too. Supply names directly or a roster; CIK/ticker are optional. Resolve legal entity, country and official identity. `source-plan` provides the SEC/official-local/issuer route; generic HTML/TXT/PDF imports cover actual authorized reports. Host search/browser discovery is required outside the native SEC route. Private or otherwise undisclosed data cannot be manufactured; preserve unavailable company-years and specific null reasons.

## Install

Extract either release archive and run from its root:

```bash
python3 -m pip install -r requirements.txt && python3 install.py --target workbuddy
```

Use --target workbuddy-ai or --target codex as needed. Existing same-name skills require --force after active tasks finish; they are backed up. --dry-run previews only. Manual copying must use the self-contained folders in the installation archive. Installation starts no collection/schedule. The source archive is ready for a GitHub repository; this release does not modify a live remote repository.

## Use

With S set to the desired skill folder and W a new workspace:

```bash
python "$S/scripts/research.py" init --work "$W" --company "Company name" --years 2019:2025
python "$S/scripts/research.py" source-plan --work "$W"
```

Follow each skill's workflow through real discovery, sync, finite reading/decision batches, supplementary sources, semantic self-review and export. The host agent performs judgments; scripts validate and retain them. Copy the [first-use prompt](prompts/first-run.en.md). Each installed skill contains its own prompt, codebook, blank input/output templates and runtime. No original author's files or chat memory are needed.

Both profiles select the same fixed set. Annual output: 15 texts + 15 disclosure flags + 12 numeric fields; no unrelated balance-sheet, cash-flow, leverage or ordinary CEO-pay extensions. Announcement output retains history/founding/products/business model as explicitly confirmed, but removes fixed eight reason codes and other unrequested extensions. Every workbook has exactly one Results sheet, 48 annual or 49 announcement base columns including identity/status/evidence, with lossless __partN continuations only when needed.

Disclosure codes, text and money are distinct. Zero disclosure needs complete applicable-source review; missing numbers never become zero. Keep original units, currency, fiscal periods, signs, locale separators, totals/components and event-time context. AI-linked compensation needs an explicit AI relation and recipient scope, not ordinary executive pay. A hash/offset pass is not semantic accuracy or human reliability. Incomplete/failed/conflicted work stays explicit PARTIAL. The complete actual variable list is in [OUTPUT_SCOPE.md](docs/OUTPUT_SCOPE.md); validation scope is in docs/validation.json.


## English output and v1.4 measurement fixes

All presented cells, including JSON explanations, use English. Native source evidence remains unchanged in a separate canonical archive; only reviewed translations appear in the English workbook and they are labeled translations. A verified English company display name can be supplied via `company_en`. Output validation rejects non-Latin authored text and checks every displayed cell; the reader still verifies English meaning. The worksheet name is Results.

The annual field pair labor_risk_discussion / labor_risk_discussion_disclosed is replaced by mdna_hr_discussion / mdna_hr_discussion_disclosed, retaining 42 business fields. MD&A personnel-cost narratives qualify without being recoded as labor risk. Established operational cloud/automation use may qualify as new-tech adoption without an invented first-use year. Explicit R&D notes and mixed technology functional costs remain distinct measures. The queues supply small cached source-linked leads for missed R&D/new-tech evidence; they never auto-code a finding. Event audits reject point-valued censored thresholds and bounds invented from approximate counts. Event-time M&A and leadership context can use reliable attributed reporting and requires checking intervening updates.

Use a new v1.4 workspace; do not silently carry old definitions or self-review approvals forward. See [CHANGELOG](CHANGELOG.md), the [fixed output scope](docs/OUTPUT_SCOPE.md) and [validation scope](docs/validation.json). Same-model self-review does not guarantee that all semantic errors are absent. This release does not publish to GitHub or change installed skills automatically.
