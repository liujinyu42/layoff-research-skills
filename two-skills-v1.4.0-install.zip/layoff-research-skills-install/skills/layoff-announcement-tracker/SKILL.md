---
name: layoff-announcement-tracker
description: Collect layoff or voluntary-exit announcements for any company, extract stated reasons and the company context required by proposal Part 1, and maintain deduplicated evidence-linked event records.
---

# Layoff announcements and proposal-required company context

Implement proposal Part 1 for any company: listed, private, delisted, US or elsewhere. No historical dataset, original template, fixed company list or CIK is required. The proposal's existing 5,000+/2,952/610 counts are background, not a new collection obligation. Default event window 2020-01-01 through 2026-09-30 is user-overridable.

Read [workflow.md](references/workflow.md), [announcement-coding.md](references/announcement-coding.md) and the optional [first-use prompt](references/first-run.md). Templates, definitions and runtime are inside this skill.

## Fixed output

Preserve the nine substantive Part 1 fields: stated layoff reason, M&A activity, leadership transition, company history, event-time firm size, founding year, product/service, business model, known affected parties. Essential event identity, dates, counts/percentages and their qualifiers, listing identifiers, source/attribution and plan links make 43 business fields, plus three row identifiers and three status/evidence fields (49 base columns).

Fixed eight reason-category codes, industry/sector, duplicate other-reason and generic event-note columns are omitted. Do not restore them through full; both profile names select the same closed set. Present the company-stated reason in English with exact English source evidence or a reviewed English translation linked to the unchanged native original. Preserve attribution; do not decide that AI is an excuse or true driver.

## Discovery and extraction

Build a roster from names or use the supplied CSV template; verify brands, subsidiaries and legal companies. Discover candidates from an authorized existing event list, trackers, company announcements, regulatory filings and reliable news. Trace originals where available and record unsuccessful searches/access limits. A news story is not automatically a new plan. No SEC filing does not mean no layoff. The tool snapshots explicit URLs/files; host discovery is needed for dynamic trackers and local sources.

```bash
python "$S/scripts/research.py" init --work "$W" --company "Company name"
python "$S/scripts/research.py" source-plan --work "$W"
```

Company-profile collection is a separate stage, supporting the nine requested fields with event-time evidence. Do not discard required history/founding/product/business-model variables to shorten source review. Context sources do not enter unrelated reason-reading scopes. Distinguish the named employing entity from its parent; current business/size must not replace historical information. Later retrospective sources need explicit timing/basis.

Execute the workflow's finite reading, decision and substantive self-review loops. Distinguish voluntary exits, forced layoffs and mixed programs; preserve date precision, numeric bounds and denominators. Verify same-plan/update/implementation relationships using actual evidence, not dates or equal counts. Export 1_layoff_announcements.xlsx: one plan/event per row, only one Results sheet, no unrequested business columns. Actual blockers stay explicit PARTIAL; source integrity errors cannot be bypassed.

## English presentation

All worksheet names, company display names, values, summaries, reasons, missing-data explanations and review metadata must be English. The only worksheet is `Results`. Read [English output and semantic checks](references/english-and-measurement.md) before writing decisions. A non-English company input is allowed: verify an English name or transliteration and set `company_en` in the roster, retaining the original legal name in the source archive. Use stable ASCII IDs. Non-English exact source quotations stay unchanged in the canonical archive; provide separately reviewed English translations for the workbook. Never label a translation as a verbatim original. The exporter rejects non-Latin authored/output strings; the reader must also check actual English meaning because this guard is not a language classifier.
