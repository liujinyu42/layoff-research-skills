# Fixed research variables

The 42 business fields below are the complete output scope. Both profile names select the same set. Identity columns are company_id, company, fy. The only other columns are delivery_status, field_status_json and evidence_json, with lossless horizontal __partN continuations if needed. Each Excel has one Results worksheet. All presented content is English.

The field dictionary and schema include the source roles and full criteria. Read [English output and measurement checks](english-and-measurement.md) before deciding. Keep text, disclosure codes and numerical amounts distinct. Code 0 means complete applicable-source review found no qualifying disclosure. Null means the amount is not separately disclosed, inapplicable with evidence, unavailable or unresolved according to its recorded status. Missing numbers do not become zero.

| Field | Meaning | Type |
|---|---|---|
| headcount | Year-end workforce size | number |
| training_costs | Training and development cost disclosure | text |
| training_costs_disclosed | Training and development cost disclosure disclosed (0/1/null) | binary |
| training_costs_amount | Training and development expense amount | number |
| layoff_statement | Layoff or workforce-reduction disclosure | text |
| layoff_statement_disclosed | Layoff or workforce-reduction disclosure disclosed (0/1/null) | binary |
| mdna_hr_discussion | MD&A discussion of HR topics | text |
| mdna_hr_discussion_disclosed | MD&A discussion of HR topics disclosed (0/1/null) | binary |
| restructuring_narrative | Restructuring and cost-saving narrative | text |
| restructuring_narrative_disclosed | Restructuring and cost-saving narrative disclosed (0/1/null) | binary |
| labor_talent_risk | Labor and talent risk disclosure | text |
| labor_talent_risk_disclosed | Labor and talent risk disclosure disclosed (0/1/null) | binary |
| talent_competition_risk | Talent competition and hiring risk | text |
| talent_competition_risk_disclosed | Talent competition and hiring risk disclosed (0/1/null) | binary |
| ai_products | AI products and initiatives | text |
| ai_products_disclosed | AI products and initiatives disclosed (0/1/null) | binary |
| ai_integration | AI integration into operations | text |
| ai_integration_disclosed | AI integration into operations disclosed (0/1/null) | binary |
| ai_adoption | Actual AI technology adoption | text |
| ai_adoption_disclosed | Actual AI technology adoption disclosed (0/1/null) | binary |
| new_tech_adoption | Actual new-technology use or adoption | text |
| new_tech_adoption_disclosed | Actual new-technology use or adoption disclosed (0/1/null) | binary |
| ai_risk_disclosure | AI-related risk factors | text |
| ai_risk_disclosure_disclosed | AI-related risk factors disclosed (0/1/null) | binary |
| ai_investment_disclosure | AI investment disclosure | text |
| ai_investment_disclosure_disclosed | AI investment disclosure disclosed (0/1/null) | binary |
| ai_investment_amount | Explicit AI investment amount | number |
| ai_opex_amount | Explicit AI operating expense | number |
| tech_opex_amount | Reported technology operating expense | number |
| rd_expense | Explicit research and development expense | number |
| capitalized_software | Capitalized software development disclosure | text |
| capitalized_software_disclosed | Capitalized software development disclosure disclosed (0/1/null) | binary |
| capitalized_software_amount | Current-year capitalized software development additions | number |
| revenue | Revenue | number |
| operating_income | Operating income or loss | number |
| restructuring_charges | Recognized restructuring expense | number |
| total_comp_expense | Company-wide employee compensation expense | number |
| ai_exec_comp | AI-linked compensation including executive awards | text |
| ai_exec_comp_disclosed | AI-linked compensation including executive awards disclosed (0/1/null) | binary |
| ai_executive_comp_amount | Explicit AI-linked compensation amount | number |
| tech_opex_disclosure | Technology and infrastructure operating-cost narrative | text |
| tech_opex_disclosure_disclosed | Technology and infrastructure operating-cost narrative disclosed (0/1/null) | binary |

For events, preserve the nine substantive proposal Part 1 constructs, original-versus-news status, attribution, dates, populations, numeric qualifiers and verified plan relationships. M&A and leadership context do not require a causal layoff connection, but a reason claim does. For annual reports, restrict data to HR, AI/new technology and financial performance. MD&A must be actual management discussion or an equivalent section. Monetary observations retain literal numbers, units, currency, sign, period and total/component basis. AI-linked compensation needs explicit AI and recipient linkage. Genuine unavailable public data remain explicit, and the historical research corpus is not required.
