---
name: listed-filing-extractor
description: Collect HR, AI/new-technology and financial disclosures for any identified company from public annual, financial, compensation and issuer reports, using SEC when applicable or official local/company sources otherwise, with evidence-linked company-year output.
---

# Company HR, AI/technology and financial disclosures

This is the reusable collection capability in proposal Part 2. The historical skill identifier is retained for installation compatibility; listing, a US ticker, a CIK and inclusion in the author's layoff dataset are not prerequisites. The researcher's historical corpus is not supplied or required. Use the companies and years requested, default FY2019–2025.

Read [workflow.md](references/workflow.md) for execution, [filing-sources.md](references/filing-sources.md) for company/market routing, [filing-variables.md](references/filing-variables.md) for measurement. The entire codebook, output template, source/roster templates and [first-use prompt](references/first-run.md) are included; no chat memory or external template is needed.

## Fixed variable scope

The 42 business fields cover only:
- HR: workforce size; training/development costs (text and amount); layoff disclosure; labor/talent and hiring-competition risks; MD&A HR discussion and restructuring/cost-saving narratives.
- AI/new technology: products/initiatives, internal integration, actual AI/new-tech adoption, AI risks, AI investment text/amounts, technology/infrastructure operating-cost text/amounts (and explicitly AI-specific opex), R&D expense, capitalized software text/amount.
- Financial: revenue, operating income, restructuring expense, total employee compensation and explicitly AI-linked compensation (including executive awards).

Each of 15 text constructs has a nullable 0/1 disclosure companion; 12 numeric fields remain numeric. Identity/status/evidence add six base columns, yielding 48 before lossless continuation columns. Both proposal-core and full select this same set. No balance sheet, cash-flow, leverage, CEO total/pay ratio, five AI-risk subtype columns or other retired extensions appear, even as empty columns.

## Run to completion

With S=this folder and W=a dedicated v1.4 workspace:

```bash
python "$S/scripts/research.py" init --work "$W" --company "Company name" --years 2019:2025
python "$S/scripts/research.py" source-plan --work "$W"
```

Verify the legal entity and official sources. With a verified CIK use sec-prepare; otherwise find official issuer/local reports and sync their real URLs/files. Nonlisted or delisted companies remain eligible when public material exists. An unavailable report leaves a specific null dependency, not an invented amount or zero. Preserve native fiscal years, language, accounting basis and currency.

Follow next → actual source reading → actual decisions → apply → source supplementation/conflict resolution → next-second → actual self-review → audit/export. The host model performs judgments; scripts validate/store them. Do not treat dispatched tasks as results or send intermediate coding work to the user. Keep financial amounts, disclosure 0/1 and text separate. Financial/AI compensation values must identify period, recipient and scope; general R&D, data-center spending, SBC or CEO total cannot stand in for AI amounts or total compensation. Actual availability varies by company and industry.

Export 2_listed_company_filings.xlsx, one company/year row and one Results sheet, with only the fixed fields and basic trace metadata. No fixed sample-size quota, human-reliability claim, regression or synthetic macro data is part of this task.

## English presentation

All worksheet names, company display names, values, summaries, reasons, missing-data explanations and review metadata must be English. The only worksheet is `Results`. Read [English output and semantic checks](references/english-and-measurement.md) before writing decisions. A non-English company input is allowed: verify an English name or transliteration and set `company_en` in the roster, retaining the original legal name in the source archive. Use stable ASCII IDs. Non-English exact source quotations stay unchanged in the canonical archive; provide separately reviewed English translations for the workbook. Never label a translation as a verbatim original. The exporter rejects non-Latin authored/output strings; the reader must also check actual English meaning because this guard is not a language classifier.
