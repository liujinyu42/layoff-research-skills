# 官方报告来源与市场映射

| 市场 | 发现与原文 | 处理路径 |
| --- | --- | --- |
| NYSE/NASDAQ及其他SEC申报人 | SEC submissions历史索引、原文与文本EX99附件；CIK稳定匹配 | sec-prepare原生10-K/20-F、DEF14A候选，8-K/6-K事件候选留内部sec/events；非本年度原文不冒充目标年度 |
| 40-F | 40-F及其真正包含财务/MD&A的年报附件 | 官方报告清单导入，原生年报锚点未声称完整支持40-F |
| HKEX | HKEXnews及发行人投资者关系年度报告/公告 | 宿主发现确切URL或下载后sync；登记exchange=HKEX及真实fy |
| LSE | 发行人IR年度报告、官方公告/RNS材料 | 同上，保留报告名称、公布日、财年截止日 |
| ASX | ASX公告及发行人年度报告 | 同上，不把公告日当财年 |
| KRX | 韩国DART披露/发行人官方报告；KRX识别上市身份 | 同上，韩文原文保留；不以译文代原始证据 |
| Xetra | 德国发行人IR与正式披露平台年度报告 | 同上，交易场所不等于统一年报数据库 |

清单必须声明source_type=sec_filing/exchange_filing/company_annual_report，document_role=annual_report/annual_financials/proxy等，fy=真实目标年。公司背景报告只作profile不能代替年报覆盖。每份来源保存URL/出版日、原始文件/hash和标准正文/hash；当地章节、PDF页码、会计准则及报告币种应在字段判定理由与证据中登记。

非美来源发现由宿主可用搜索/浏览器完成，不调用未经验证的私有交易所接口、不绕过登录或把空结果当无披露。受限页面可导入用户有权取得的官方报告；缺报告继续留该公司年NA。

一个物理报告为比较年服务时，可用不同source_id/目标fy登记同文件，同时保留报告标称年度/出版日并逐值绑定period_fy；不可把文中所有数值映射为同一fy。DEF14A含SCT/CEO多年度表，识别人名、PEO及表头年度，不按 filed_year-1盲填。

上市史以company_id、exchange、listed_date、delisted_date、status_as_of保留在roster及自带listing_history_template.csv。当前ticker/当前SIC不能证明历史状态。一个发行人多市场交叉上市不自动重复计公司。
