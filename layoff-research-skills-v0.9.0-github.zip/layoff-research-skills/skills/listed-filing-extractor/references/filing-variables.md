# 三类变量与数值口径

assets/filing_schema.json是唯一字段定义源；88个原变量的定义完整内置。原21项需要质性判断的构念，其include/exclude/notes同时保留为coding_definition；本版把这些定义整合进年度技能，不需要第三个编码skill。

- HR与裁员：人员总量、构成/地域/职能、培训/开发、人才风险与招聘竞争、流失留任、劳动力风险和重组叙事，及相关费用。人数是实际本公司雇佣存量，FTE与员工不同，培训受益者/裁员岗位不能代替总数。
- AI/Tech：产品/项目、内部整合、采用、风险、投资/技术基础设施运营支出、R&D及资本化软件等。泛化technology不能填AI专项列；广告AI描述不自动视为内部采用。
- 财务：营收、营业利润、净利、资产负债、重组、薪酬及明确AI关联高管薪酬。保留相关扩充字段，避免删除原研究信息。CEO/NEO/SCT/CAP不互换，NEO均值需明确名单与算式，混合年份不可平均。

48个文本字段新增*_disclosed：1=符合该字段定义的披露，0=通读完整适用源并排除反证后未发现，null=无来源/未审/无法判断。风险类1表示披露了风险，不表示真实风险已发生；severance仍是金额，不能二元化。旧retention_rate/capitalized_software等原文字段保留；需要实际金额用伴随*_amount，不能把1当1元/1%。

六个专项金额：training_costs_amount、capitalized_software_amount、ai_investment_amount、ai_capex_amount、ai_opex_amount、ai_executive_comp_amount。必须明确本年、货币、倍率及对应总体；不相加成新指数。旧tech_opex_amount曾有million参考单位，本版所有currency_base金额统一基础货币并保留raw_value×scale；不可直接导入旧数字而不核单位。

遣散费区分公司合计与职能分项、当期费用与支付/余额、全年与季度、计划估计与实际。2088million必须是2088000000基础货币。年度归属、公司总额与费用性质由执行者回原文裁定；单位算术检查不认证其经济含义。

资产负债表只取同年末同币种同主体。债务总额须计不重叠短借/商业票据/长期债流动与非流动部分，无形资产排除商誉并区分总额与有限年限分项。若使用派生leverage等，在reason与证据记录公式及原始组成值；程序不会自动猜补缺失成分。

同源多个变量逐一判定，不能让同一泛化段落自动触发所有AI或风险列。无法实际观察的指标保留NA及具体缺失原因；proposal也不假设各公司一定披露每一项。
