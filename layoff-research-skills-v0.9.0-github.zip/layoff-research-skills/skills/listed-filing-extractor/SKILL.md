---
name: listed-filing-extractor
description: Collect listed-company annual filings and extract human-capital, AI/technology and financial disclosures into evidence-linked company-year panels, including non-US official report imports, source review and integrated binary disclosure coding.
---

# 上市公司年度披露采集

对应研究方案第二部分。先读[工作流程](references/workflow.md)；按市场读[来源映射](references/filing-sources.md)，测量时读[字段与口径](references/filing-variables.md)。单个skill自带SEC候选提取引擎、编码定义、自审、模板与导出器，不调用其他已安装技能。

## 范围

默认FY2019–FY2025，用户可显式修改。使用用户公告样本的上市公司名单；稳定company_id连接事件表，退市公司不删除。默认不纳入研究方案第三/四部分、薪酬网站、因果回归或合成控制数据。

```bash
python "$S/scripts/research.py" init --work "$W" --companies /input/listed-companies.csv --years 2019:2025
python "$S/scripts/research.py" sec-prepare --work "$W"
python "$S/scripts/research.py" prepare --work "$W"
```

S为本skill路径，W为显式工作区。SEC_USER_AGENT须由运行者提供真实ASCII联系人/邮箱，公开包不含作者邮箱。sec-prepare内置旧版已验证的SEC解析规则，仅生成候选与原文，不自动确认数字或编码。下载失败停止并留日志，之后可恢复；重用原缓存加--cache-only，合成离线数据用--offline目录。

HKEX/LSE/ASX/KRX/Xetra、40-F附件和SEC未覆盖材料，由执行者使用宿主浏览/搜索找到官方发行人/交易所报告，填assets/sources.csv后sync。通用HTML/TXT/PDF导入可执行，但不声称有各交易所全站自动发现API；扫描图像需真实视觉/OCR。非美国章节保留当地标题及准则/币种，不伪标为Item1/7/8。

## 数据和交付

原88变量全部保留，覆盖HR/裁员、AI/Tech、财务三类。文本披露增加48个*_disclosed的可空0/1伴随列，另加6项明确专项金额，共142字段。代码本包含原21构念正负例；关键词只找候选。原文、金额和披露码分别保存，未披露率/费用不能用0/1代替。一般R&D、基础设施支出不能自动改名AI专项投资。

按工作流程审查所有请求公司年×字段、正确年度/主体/金额倍率/币种/分项并执行实际二读。输出2_listed_company_filings.xlsx，每公司每财年一行，仅一张“结果”，含完整状态和证据续列。缺年报的公司年仍有空值行；未审/失败不变0。完整审查未通过仅显式PARTIAL，不能把任务派发成功当交付完成。

程序入口是research.py；内部vendor只复用候选解析库，不调用旧三技能run_pipeline，也无需安装旧qualitative或quantitative。模型实际阅读和判断仍需时间；同源只读一次/批量提交/读取摘要，定义或源实际改变才重核受影响字段。
