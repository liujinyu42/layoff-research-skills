---
name: layoff-announcement-tracker
description: Track layoff announcements and stated reasons across public, private and delisted companies, linking original announcements, SEC notices, news and tracker records to auditable event-level data and company context.
---

# 裁员公告与公司背景追踪

对应研究方案第一部分。先读[工作流程](references/workflow.md)；判断原因/计划身份时读[编码定义](references/announcement-coding.md)，完整字段在assets/event_schema.json。无需原作者模板、聊天记忆或其他已安装技能。

## 范围和输入

默认公告窗口2020-01-01至2026-09-30；用户可显式覆盖。用户提供或授权建立公司名单（company_id、company、上市史/CIK可选），执行者负责按范围发现候选并登记来源。proposal中已有记录/公司数量不是本次输入或已完成事实。上市、私人、已退市企业均保留，ticker不是永久身份。

先从用户既有事件清单或layoffs.fyi发现候选，再追溯公司原公告、SEC8-K/6-K及附件、交易所公告和可靠新闻；公司背景独立找证据。宿主搜索/浏览用于来源发现、动态页或受限站点，sync用于明确URL/已下载文件的快照与解析；本包未实现layoffs.fyi私有API全站枚举。没有浏览器会话时说明发现覆盖限制，继续处理可访问来源，不声称全站抓完。

```bash
python "$S/scripts/research.py" init --work "$W" --companies /input/companies.csv
python "$S/scripts/research.py" sync --work "$W" --manifest /input/sources.csv
python "$S/scripts/research.py" prepare --work "$W"
```

S为本skill路径，W为该任务工作区。来源清单包含明确plan_id与company_id、source_type、document_role、URL或本地路径。每个独立计划一行，多篇文章不重复计；计划合并须真实核查，plan_identity_verified=1需证据，不按人数相同自动合并。新增计划使用新ID，修订/实施材料链接原计划。

## 输出和编码

输出公告日期、生效期间、裁减人数/比例及范围、人群、公司所述原因原文及8个可空0/1原因码；并记录并购、领导变更、历史/成立年份、规模/口径/时点、产品服务、商业模式、受影响群体与事件时点上市状态。身份和字段均自带模板。

原因码表示公告归因，不预设AI是借口或真实驱动。AI产品提及、相邻收购或新CEO不能自动构成裁员理由。记者推断与公司陈述分开；信息时点不能用今天背景替代历史。需求材料对affected_parties短语不完整，只保存实际披露。

按工作流程完成真实首轮和二读，随后audit/export。输出1_layoff_announcements.xlsx，每独立计划一行，仅一张“结果”。没有原公告/访问失败、未知字段或未核实合并均保留，明确PARTIAL。安装不启动后台任务；持续运行仅按用户另行授权的时间表刷新，恢复缓存和已有效判断。
