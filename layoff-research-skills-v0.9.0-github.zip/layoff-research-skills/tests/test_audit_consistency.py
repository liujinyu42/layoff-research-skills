import json
import pytest
from test_proposal_workflow import setup_project,judgment,apply_rows,finish_second
from researchcore.workflow import audit,export
from researchcore.sources import text_for,read_sources

def test_observed_text_and_absence_flag_cannot_both_pass(tmp_path):
 sk,w,_=setup_project(tmp_path,[{'id':'hcm','type':'text'},{'id':'hcm_disclosed','type':'binary'}]);tx=text_for(w,read_sources(w)['s1'])
 first=judgment('hcm','Original HCM disclosure')
 zero=judgment('hcm_disclosed',0,evidence=False,scope_read=True,reviewed_scopes=[{'source_id':'s1','start':0,'end':len(tx)}])
 assert apply_rows(tmp_path,sk,w,[first,zero])['pass']
 r=audit(sk,w);assert not r['integrity_pass']and any('contradict'in e['error']for e in r['errors'])
 with pytest.raises(ValueError,match='Invalid source/decision'):export(sk,w,tmp_path/'bad.xlsx',partial=True)

def test_modified_second_review_never_counts_as_valid(tmp_path):
 sk,w,_=setup_project(tmp_path,[{'id':'hcm','type':'text'}]);assert apply_rows(tmp_path,sk,w,[judgment('hcm','Some source disclosure')])['pass'];finish_second(tmp_path,sk,w);assert audit(sk,w)['complete']
 p=w/'second.json';d=json.loads(p.read_text());d['a:2023|hcm']['criterion_application']='';p.write_text(json.dumps(d));r=audit(sk,w);assert not r['integrity_pass']and not r['complete']

def test_stock_period_end_must_be_actual_iso_date(tmp_path):
 sk,w,_=setup_project(tmp_path,[{'id':'headcount','type':'number','unit':'persons','measure_kind':'stock'}])
 r=apply_rows(tmp_path,sk,w,[judgment('headcount',1200,period_fy=2023,period_end='not-a-date')]);assert not r['pass']

def test_unused_but_registered_source_corruption_blocks_partial(tmp_path):
 sk,w,_=setup_project(tmp_path,[{'id':'text','type':'text'}]);source=read_sources(w)['s1'];(w/source['raw_path']).write_text('modified')
 r=audit(sk,w);assert not r['integrity_pass']and any('Raw source changed'in e['error']for e in r['errors'])
 with pytest.raises(ValueError,match='Invalid source/decision'):export(sk,w,tmp_path/'bad-unused.xlsx',partial=True)
