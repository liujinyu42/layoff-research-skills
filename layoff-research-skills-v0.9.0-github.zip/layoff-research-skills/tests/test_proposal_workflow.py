"""Offline behavior tests of the two-entry proposal workflow, using small real schemas."""
import json
from pathlib import Path

import pytest
from openpyxl import load_workbook
from researchcore.sources import ingest, read_sources, text_for
from researchcore.workflow import (
    init, prepare, apply, audit, export, second_tasks, apply_second, load,
)


def write_rows(path, rows):
    path.write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in rows))
    return path


def setup_project(tmp_path, fields, *, mode='filings', years='2023:2023', companies=None, sources=None, text=None):
    skill = tmp_path / ('listed-filing-extractor' if mode == 'filings' else 'layoff-announcement-tracker')
    (skill / 'assets').mkdir(parents=True)
    (skill / 'assets' / ('filing_schema.json' if mode == 'filings' else 'event_schema.json')).write_text(json.dumps({'version': 'test', 'fields': fields}))
    work = tmp_path / 'work'; companies = companies or [{'company_id': 'a', 'company': 'Alpha', 'listing_status': 'delisted'}]
    roster = write_rows(tmp_path / 'companies.jsonl', companies)
    init(skill, work, roster, years, '2020-01-01', '2026-09-30')
    (tmp_path / 'source.txt').write_text(text or 'The company announced layoffs on 2023-01-20. In millions USD, severance was 2,088. This is a complete announcement.')
    if sources is None:
        sources = [{'source_id': 's1', 'company_id': 'a', 'source_type': 'sec_filing', 'document_role': 'annual_report', 'fy': 2023, 'local_path': 'source.txt'}]
    manifest = write_rows(tmp_path / 'sources.jsonl', sources)
    ingest(work, manifest, offline=True)
    return skill, work, manifest


def judgment(variable, value, *, entity='a:2023', evidence=True, **extra):
    d = dict(entity_id=entity, variable=variable, status='observed', value=value,
             reason='Actual source states this value', criterion_application='Read source against the definition',
             reviewer_id='A', reviewer_kind='model')
    if evidence:
        d['evidence'] = [{'source_id': 's1', 'quote': 'severance was 2,088'}]
    d.update(extra)
    return d


def apply_rows(tmp_path, skill, work, rows, filename='judgments.jsonl'):
    return apply(skill, work, write_rows(tmp_path / filename, rows))


def finish_second(tmp_path, skill, work):
    second_tasks(skill, work)
    tasks = load(work / 'review/second-tasks.json')
    rr = [{**task, 'reviewed_again': True, 'criterion_application': 'Read original source again and verified this criterion',
           'reviewer_id': 'A', 'reviewer_kind': 'model'} for task in tasks]
    report = apply_second(skill, work, write_rows(tmp_path / 'second.jsonl', rr))
    assert report['pass'], report


def test_requested_company_years_preserved_even_without_sources(tmp_path):
    fields = [{'id': 'headcount', 'type': 'integer', 'unit': 'persons'}]
    skill, work, _ = setup_project(tmp_path, fields, years='2023:2024',
                                  companies=[{'company_id': 'a', 'company': 'Alpha', 'listing_status': 'delisted'},
                                             {'company_id': 'b', 'company': 'Beta'}])
    status = prepare(skill, work)
    assert status['entities'] == 4 and status['tasks'] == 4
    result = export(skill, work, tmp_path / 'partial.xlsx', partial=True)
    assert result['rows'] == 4
    vals = list(load_workbook(tmp_path / 'partial.xlsx').active.values)
    assert {(row[0], row[2]) for row in vals[1:]} == {('a', 2023), ('a', 2024), ('b', 2023), ('b', 2024)}
    assert all(row[3] is None for row in vals[1:])
    assert len(audit(skill, work)['coverage_gaps']) == 3


def test_binary_zero_requires_complete_explicitly_read_scopes(tmp_path):
    skill, work, _ = setup_project(tmp_path, [{'id': 'ai_adoption', 'type': 'binary'}])
    text = text_for(work, read_sources(work)['s1'])
    d = judgment('ai_adoption', 0, evidence=False)
    report = apply_rows(tmp_path, skill, work, [d])
    assert not report['pass'] and 'full reading' in report['errors'][0]['error']
    d.update(scope_read=True, reviewed_scopes=[{'source_id': 's1', 'start': 0, 'end': len(text) - 1}])
    report = apply_rows(tmp_path, skill, work, [d])
    assert not report['pass'] and 'complete registered source' in report['errors'][0]['error']
    d['reviewed_scopes'][0]['end'] = len(text)
    assert apply_rows(tmp_path, skill, work, [d])['pass']
    assert audit(skill, work)['second_pending'] == 1
    finish_second(tmp_path, skill, work)
    assert audit(skill, work)['complete']


def test_money_table_scale_preserved_and_wrong_base_value_rejected(tmp_path):
    fields = [{'id': 'severance', 'type': 'number', 'unit': 'currency_base', 'measure_kind': 'annual_flow'}]
    skill, work, _ = setup_project(tmp_path, fields)
    d = judgment('severance', 2088, period_fy=2023, measurement_scope='company_total',
                 amount={'raw_value': 2088, 'scale': 1000000, 'currency': 'USD', 'unit_quote': 'In millions USD'})
    report = apply_rows(tmp_path, skill, work, [d])
    assert not report['pass'] and 'raw_value * scale' in report['errors'][0]['error']
    d['value'] = 2088000000
    assert apply_rows(tmp_path, skill, work, [d])['pass']
    finish_second(tmp_path, skill, work)
    assert audit(skill, work)['complete']
    export(skill, work, tmp_path / 'money.xlsx')
    assert load_workbook(tmp_path / 'money.xlsx').active.cell(2, 4).value == 2088000000


@pytest.mark.parametrize('change', ['source_text', 'source_role'])
def test_two_round_bindings_invalidated_by_source_or_metadata_change(tmp_path, change):
    skill, work, manifest = setup_project(tmp_path, [{'id': 'disclosure', 'type': 'text'}])
    assert apply_rows(tmp_path, skill, work, [judgment('disclosure', 'An actual disclosure')])['pass']
    finish_second(tmp_path, skill, work)
    assert audit(skill, work)['complete']
    if change == 'source_text':
        local = tmp_path / 'source.txt'; local.write_text(local.read_text() + ' An important later amendment.')
    else:
        rows = [json.loads(line) for line in manifest.read_text().splitlines()]
        rows[0]['document_role'] = 'annual_financials'
        write_rows(manifest, rows)
    ingest(work, manifest, offline=True)
    result = audit(skill, work)
    assert not result['integrity_pass'] and not result['complete']
    assert any('changed since submission' in item['error'] for item in result['errors'])
    with pytest.raises(ValueError, match='Invalid source/decision'):
        export(skill, work, tmp_path / 'stale.xlsx', partial=True)


def test_partial_is_explicit_single_sheet_and_zero_null_formula_text_survive(tmp_path):
    fields = [{'id': 'binary', 'type': 'binary'}, {'id': 'unread', 'type': 'text'}, {'id': 'literal_text', 'type': 'text'}]
    skill, work, _ = setup_project(tmp_path, fields)
    tx = text_for(work, read_sources(work)['s1'])
    zero = judgment('binary', 0, evidence=False, scope_read=True,
                    reviewed_scopes=[{'source_id': 's1', 'start': 0, 'end': len(tx)}])
    literal = judgment('literal_text', '=2+3', reason='Original detailed review. ' + '原文😀' * 30000)
    assert apply_rows(tmp_path, skill, work, [zero, literal])['pass']
    with pytest.raises(ValueError, match='Incomplete work'):
        export(skill, work, tmp_path / 'not_complete.xlsx')
    result = export(skill, work, tmp_path / 'inspection.xlsx', partial=True)
    assert result['status'] == 'PARTIAL'
    book = load_workbook(tmp_path / 'inspection.xlsx', data_only=False)
    assert book.sheetnames == ['结果']
    sheet = book.active; headers = [c.value for c in sheet[1]]
    assert sheet.cell(2, headers.index('binary') + 1).value == 0
    assert sheet.cell(2, headers.index('unread') + 1).value is None
    cell = sheet.cell(2, headers.index('literal_text') + 1)
    assert cell.value == '=2+3' and cell.data_type == 's'
    assert all(c.data_type != 'f' for c in sheet[2])
    evidence_parts = [sheet.cell(2, i + 1).value or '' for i, h in enumerate(headers) if h == 'evidence_json' or h.startswith('evidence_json__part')]
    reconstructed = json.loads(''.join(evidence_parts))
    assert reconstructed['literal_text']['reason'] == literal['reason']
    assert len(evidence_parts) > 1 and sheet.max_row == 2


def test_multiple_sources_same_plan_and_distinct_plans_are_not_count_deduplicated(tmp_path):
    fields = [{'id': 'announcement_date', 'type': 'date'}, {'id': 'plan_identity_verified', 'type': 'binary'}]
    sources = [dict(source_id='s1', company_id='a', source_type='company_announcement', document_role='layoff_announcement', plan_id='p1', local_path='source.txt'),
               dict(source_id='n1', company_id='a', source_type='news', document_role='news_report', plan_id='p1', local_path='source.txt'),
               dict(source_id='s2', company_id='a', source_type='company_announcement', document_role='layoff_announcement', plan_id='p2', local_path='source.txt')]
    skill, work, _ = setup_project(tmp_path, fields, mode='events', sources=sources)
    status = prepare(skill, work)
    assert status['entities'] == 2 and status['tasks'] == 4
    groups = load(work / 'review/reading_groups.json')
    assert {g['entity_id']: len(g['sources']) for g in groups} == {'p1': 2, 'p2': 1}
    submitted = []
    for plan, sid in [('p1', 's1'), ('p2', 's2')]:
        for var, value in [('announcement_date', '2023-01-20'), ('plan_identity_verified', 1)]:
            d = judgment(var, value, entity=plan, evidence=False)
            d['evidence'] = [{'source_id': sid, 'quote': 'The company announced layoffs on 2023-01-20.'}]
            submitted.append(d)
    assert apply_rows(tmp_path, skill, work, submitted)['pass']
    finish_second(tmp_path, skill, work)
    assert audit(skill, work)['complete']
    result = export(skill, work, tmp_path / 'events.xlsx')
    assert result['rows'] == 2
    sheet = load_workbook(tmp_path / 'events.xlsx').active
    assert {sheet.cell(2, 1).value, sheet.cell(3, 1).value} == {'p1', 'p2'}
