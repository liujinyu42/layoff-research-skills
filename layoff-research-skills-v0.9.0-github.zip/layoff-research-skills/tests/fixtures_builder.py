#!/usr/bin/env python3
"""生成完全合成的离线 fixtures（不含任何真实公司数据）。

用途：让整条链路可以在无网络、无密钥的情况下跑通并回归测试。
所有公司名、CIK、数字均为虚构，仅用于验证管线行为。
"""

from __future__ import annotations

import json
import random
import shutil
from pathlib import Path

OUT = Path(__file__).resolve().parent / "fixtures"
YEARS = [2021, 2022, 2023, 2024, 2025]

COMPANIES = [
    # cid, name, ticker, cik, base_headcount, base_revenue_musd, treat_fy, layoff
    (1, "Northwind Systems", "NWND", "1000001", 12400, 8200, 2023, 1200),
    (2, "Cobalt Analytics", "CBLT", "1000002", 5600, 3100, 2023, 420),
    (3, "Harbor Logistics Tech", "HRBR", "1000003", 18800, 12400, 2024, 900),
    (4, "Pinewood Software", "PNWD", "1000004", 3100, 1450, 2023, 260),
    (5, "Meridian Cloud", "MRDN", "1000005", 9400, 6100, 2024, 780),
    (6, "Vantage Robotics", "VNTR", "1000006", 4200, 2900, 2023, 350),
    (7, "Alder Health Tech", "ALDR", "1000007", 7600, 5200, None, 0),
    (8, "Bayline Retail Systems", "BAYL", "1000008", 15300, 9800, None, 0),
    (9, "Cedar Payments", "CDRP", "1000009", 2800, 1900, None, 0),
    (10, "Delta Semiconductor", "DLTA", "1000010", 11200, 8700, None, 0),
    (11, "Evergreen Data", "EVRD", "1000011", 3900, 2400, None, 0),
    (12, "Foundry Interactive", "FNDR", "1000012", 6100, 3600, None, 0),
]

TENK_TMPL = """<html><head><title>{company} 10-K</title></head><body>
<h1>UNITED STATES SECURITIES AND EXCHANGE COMMISSION</h1>
<p>FORM 10-K</p>
<p>{company} (Exact name of registrant as specified in its charter)</p>

<p>ITEM 1. BUSINESS</p>
<p>{company} provides {sector} products and services to enterprise customers in North America
and Europe. We employed approximately {headcount:,} full-time employees as of December 31, {fy},
across 14 countries. We also engage contractors on a project basis.</p>

<p>Human Capital Resources</p>
<p>Our people are our most important asset. We invest in talent acquisition and retention
programs, competitive compensation and benefits, and flexible work arrangements, including
remote work for eligible roles. Approximately {union_pct}% of our employees are covered by
collective bargaining agreements. Our voluntary turnover rate was {turnover:.1f}% for fiscal {fy}.
We track diversity, equity and inclusion metrics and publish them annually in our sustainability
report.</p>

<p>Artificial Intelligence</p>
<p>We integrate artificial intelligence and machine learning into our products and internal
operations. Our AI products help customers automate document review and forecasting. We
continue to invest in research and development in AI, and we adopt AI in our software
development workflow. Machine learning models are deployed across our platform.{ai_extra}</p>

<p>ITEM 1A. RISK FACTORS</p>
<p>We face intense competition for engineering and AI talent, which may increase compensation
costs. Regulatory requirements relating to artificial intelligence are evolving and may impose
compliance costs. Cybersecurity and privacy risks relating to AI systems could harm our
reputation. Competitors are investing heavily in artificial intelligence, and our competitive
position depends on continued innovation. Ethical concerns and bias in AI models create
reputational risk. Operational failures of AI systems could disrupt our services.</p>
<p>We have previously undertaken restructuring activities, and workforce reduction efforts may
result in impairment charges. Union organizing activity could affect labor costs.</p>

<p>ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS</p>
<p>Revenue for fiscal {fy} was ${revenue:,} million. We continue to invest in technology and
infrastructure to support growth. {restructuring_text}</p>

<p>ITEM 8. FINANCIAL STATEMENTS AND SUPPLEMENTARY DATA</p>
<p>Salaries, wages, and payroll taxes were ${salaries:,} million for fiscal {fy}.
{severance_text}</p>
<p>See accompanying notes to consolidated financial statements.</p>
</body></html>
"""

TENK_RESTRUCTURE = (
    "During fiscal {fy}, we implemented a restructuring plan that reduced our workforce by "
    "approximately {layoff:,} employees, or {pct:.0f}% of our global workforce. "
    "We recognized severance costs of ${severance:,} million in connection with this plan."
)
TENK_STEADY = (
    "We did not undertake a restructuring plan during fiscal {fy}; headcount grew in line with "
    "revenue."
)
TENK_SEVERANCE = (
    "Employee severance and termination benefits of ${severance:,} million were recorded within "
    "restructuring charges during fiscal {fy}."
)

AI_EXTRA = [
    " Our AI copilot generates draft responses for customer support agents.",
    " Machine learning models also forecast demand for our logistics customers.",
    " We have begun piloting generative AI features inside our workflow tools.",
    " Our AI models help customers detect anomalies in financial transactions.",
]

EIGHTK_TMPL = """<html><head><title>{company} 8-K</title></head><body>
<p>FORM 8-K</p>
<p>CURRENT REPORT</p>
<p>Item 2.05 Costs Associated with Exit or Disposal Activities.</p>
<p>On March 3, {fy}, the Company approved a restructuring plan that reduces its workforce by
approximately {layoff:,} employees, or {pct:.0f}% of its global workforce. The Company expects to
record severance costs of approximately ${severance} million in the second quarter of {fy},
with the remainder recorded through the end of the fiscal year. The restructuring is expected to
be substantially complete by the end of {nextfy}.</p>
<p>Item 9.01 Financial Statements and Exhibits.</p>
</body></html>
"""

EIGHTK_TRAP = """<html><head><title>{company} 8-K</title></head><body>
<p>FORM 8-K</p>
<p>Item 2.02 Results of Operations and Financial Condition.</p>
<p>The Company employs approximately {headcount:,} employees worldwide and serves more than
2,400 customers. Total revenue for the quarter was ${revenue} million.</p>
<p>Item 9.01 Financial Statements and Exhibits.</p>
</body></html>
"""

EXHIBIT_TMPL = """<html><head><title>{company} press release</title></head><body>
<h1>{company} Announces Restructuring to Focus on AI Priorities</h1>
<p>{city}, March 3, {fy} — {company} today announced a restructuring plan that reduces its
workforce by approximately {layoff:,} employees, representing {pct:.0f}% of its global workforce.
The Company expects to incur severance costs of approximately ${severance} million.</p>
</body></html>
"""


def _doc_name(ticker: str, fy: int, suffix: str) -> str:
    return f"{ticker.lower()}-{fy}{suffix}.htm"


def _accession(cik: str, seq: int) -> str:
    return f"{cik.zfill(10)}-{23 + seq % 3:02d}-{seq:06d}"


def build() -> Path:
    if OUT.exists():
        shutil.rmtree(OUT)
    (OUT / "docs").mkdir(parents=True)
    (OUT / "facts").mkdir(parents=True)
    (OUT / "warn").mkdir(parents=True)

    rows = [{"cid": c[0], "company": c[1], "ticker": c[2], "cik": c[3].zfill(10),
             "market": "NASDAQ", "note": "synthetic demo"} for c in COMPANIES]
    with (OUT / "companies.csv").open("w", encoding="utf-8") as fh:
        fh.write("cid,company,ticker,cik,market,note\n")
        for r in rows:
            fh.write(f"{r['cid']},{r['company']},{r['ticker']},{r['cik']},{r['market']},{r['note']}\n")

    seq = 1
    for cid, name, ticker, cik, base_hc, base_rev, treat_fy, layoff in COMPANIES:
        filings = []
        facts: dict[str, list[dict]] = {}
        headcount_now = base_hc
        rng = random.Random(9000 + cid)

        for i, fy in enumerate(YEARS):
            growth = 0.05 if treat_fy is None else (0.05 if fy < treat_fy else -0.06)
            headcount_now = int(headcount_now * (1 + growth))
            revenue = int(base_rev * (1.06 ** i))
            if treat_fy and fy >= treat_fy:
                revenue = int(revenue * 0.96)
            # 加噪：让数据不像教科书，估计量才有抽样波动
            revenue = int(revenue * (1 + rng.gauss(0, 0.02)))
            headcount_obs = int(headcount_now * (1 + rng.gauss(0, 0.012)))
            turnover = 12.5 + (cid % 3) + (fy - 2021) * 0.15 + rng.gauss(0, 0.5)
            ai_extra = "".join(AI_EXTRA[: (fy - 2021) + (cid % 2)])

            acc = _accession(cik, seq)
            seq += 1
            doc = _doc_name(ticker, fy, "10k")
            is_treat = treat_fy is not None and fy == treat_fy
            severance = round(layoff * 0.04, 1) if is_treat else 0.0
            pct = (layoff / max(headcount_obs, 1)) * 100

            html = TENK_TMPL.format(
                company=name, sector="enterprise software", fy=fy, headcount=headcount_obs,
                union_pct=8 if cid % 2 else 0, turnover=turnover, ai_extra=ai_extra,
                revenue=revenue, salaries=int(revenue * 0.38),
                restructuring_text=(
                    TENK_RESTRUCTURE.format(fy=fy, layoff=layoff, pct=pct,
                                            severance=int(severance))
                    if is_treat else TENK_STEADY.format(fy=fy)
                ),
                severance_text=(
                    TENK_SEVERANCE.format(severance=int(severance), fy=fy)
                    if is_treat else "No severance was recorded during the period."
                ),
            )
            folder = OUT / "docs" / acc.replace("-", "")
            folder.mkdir(parents=True, exist_ok=True)
            (folder / doc).write_text(html, encoding="utf-8")

            filings.append({
                "accession": acc, "form": "10-K", "filed": f"{fy + 1}-02-15",
                "period": f"{fy}-12-31", "primary_doc": doc,
            })

            for tag, val in [
                ("Revenues", revenue * 1_000_000),
                ("OperatingIncomeLoss", int(revenue * 0.18 * 1_000_000)),
                ("NetIncomeLoss", int(revenue * 0.12 * 1_000_000)),
                ("Assets", int(revenue * 2.4 * 1_000_000)),
                ("Liabilities", int(revenue * 1.1 * 1_000_000)),
                ("ResearchAndDevelopmentExpense", int(revenue * 0.15 * 1_000_000)),
                ("PaymentsToAcquirePropertyPlantAndEquipment", int(revenue * 0.07 * 1_000_000)),
                ("ShareBasedCompensation", int(revenue * 0.05 * 1_000_000)),
            ]:
                facts.setdefault(tag, []).append({
                    "start": f"{fy}-01-01", "end": f"{fy}-12-31", "val": val,
                    "fy": fy, "fp": "FY", "form": "10-K", "accn": acc,
                })
            if is_treat:
                facts.setdefault("RestructuringCharges", []).append({
                    "start": f"{fy}-01-01", "end": f"{fy}-12-31",
                    "val": int(severance * 1_000_000 * 1.4),
                    "fy": fy, "fp": "FY", "form": "10-K", "accn": acc,
                })

            if is_treat:
                acc8 = _accession(cik, seq)
                seq += 1
                doc8 = _doc_name(ticker, fy, "8k")
                folder8 = OUT / "docs" / acc8.replace("-", "")
                folder8.mkdir(parents=True, exist_ok=True)
                (folder8 / doc8).write_text(
                    EIGHTK_TMPL.format(company=name, fy=fy, layoff=layoff, pct=pct,
                                       severance=int(severance), nextfy=fy + 1),
                    encoding="utf-8",
                )
                (folder8 / "ex99-1.htm").write_text(
                    EXHIBIT_TMPL.format(company=name, city="Seattle", fy=fy, layoff=layoff,
                                        pct=pct, severance=int(severance)),
                    encoding="utf-8",
                )
                filings.append({
                    "accession": acc8, "form": "8-K", "filed": f"{fy}-03-05",
                    "period": f"{fy}-03-03", "primary_doc": doc8,
                })

        # 一份"陷阱"8-K：只有员工总数与客户数，不含裁员动作
        acc_trap = _accession(cik, seq)
        seq += 1
        doc_trap = _doc_name(ticker, 2024, "8kq")
        folder_trap = OUT / "docs" / acc_trap.replace("-", "")
        folder_trap.mkdir(parents=True, exist_ok=True)
        (folder_trap / doc_trap).write_text(
            EIGHTK_TRAP.format(company=name, headcount=headcount_obs, revenue=base_rev),
            encoding="utf-8",
        )
        filings.append({
            "accession": acc_trap, "form": "8-K", "filed": "2024-11-01",
            "period": "2024-10-30", "primary_doc": doc_trap,
        })

        (OUT / f"submissions_{cik}.json").write_text(
            json.dumps({"cik": cik.zfill(10), "company": name, "filings": filings},
                       ensure_ascii=False, indent=1),
            encoding="utf-8",
        )
        payload = {
            "cik": cik.zfill(10),
            "entityName": name,
            "facts": {
                "us-gaap": {
                    tag: {"label": tag, "units": {"USD": entries}}
                    for tag, entries in facts.items()
                }
            },
        }
        (OUT / "facts" / f"facts_{cik}.json").write_text(
            json.dumps(payload, ensure_ascii=False), encoding="utf-8"
        )

    warn_rows = [
        ("Northwind Systems", "WA", "2023-01-12", "2023-03-15", 1200, "Seattle", "King"),
        ("Cobalt Analytics", "CA", "2023-02-01", "2023-04-01", 420, "San Jose", "Santa Clara"),
        ("Pinewood Software", "CA", "2023-02-10", "2023-04-10", 260, "Oakland", "Alameda"),
        ("Vantage Robotics", "TX", "2023-03-01", "2023-05-01", 350, "Austin", "Travis"),
        ("Unlisted Fabrication Co", "OH", "2023-03-15", "2023-05-15", 180, "Akron", "Summit"),
        ("Harbor Logistics Tech", "IL", "2024-01-20", "2024-03-20", 900, "Chicago", "Cook"),
        ("Meridian Cloud", "NY", "2024-02-05", "2024-04-05", 780, "New York", "New York"),
    ]
    with (OUT / "warn" / "warn_2023_2024.csv").open("w", encoding="utf-8") as fh:
        fh.write("employer,state,notice_date,effective_date,employees_affected,city,county\n")
        for row in warn_rows:
            fh.write(",".join(str(x) for x in row) + "\n")

    return OUT


if __name__ == "__main__":
    path = build()
    n_docs = len(list((path / "docs").glob("*/*.htm")))
    print(f"fixtures 已生成: {path}")
    print(f"公司 12 家 / 文档 {n_docs} 份 / 年份 {YEARS[0]}-{YEARS[-1]}")
