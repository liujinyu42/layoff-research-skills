# Layoff research skills v0.9.0

按研究方案前两部分重构的两技能包，基于v0.8.3的候选解析与审查经验。入口只有：

| Skill | 工作内容 | 默认输出 |
| --- | --- | --- |
| layoff-announcement-tracker | 多源裁员公告、公司所述原因及事件时点背景 | 独立计划一行，1_layoff_announcements.xlsx |
| listed-filing-extractor | 上市公司FY2019–2025的HR、AI/Tech、财务披露与内置0/1编码 | 公司×财年一行，2_listed_company_filings.xlsx |

两份结果各一张“结果”表。所有输出模板、字段册、来源清单、定义、实际审查接口与首次提示词内置。不要求作者的Excel或记忆。不含岗位薪酬抓取、回归、合成宏观面板或未提供的人工金标准。

## 安装

Python>=3.10；在所选虚拟环境运行pip install -r requirements.txt，然后：

```bash
python install.py --target workbuddy
# 可选workbuddy-ai或codex，或--dest自定义目录
```

便携安装包亦含install.py、requirements.txt和两个自包含目录。只想手动安装时，把skills下的两个目录复制到宿主skills目录。升级显式--force，安装器保留旧目录备份；不删除原四技能，不替换运行中的任务，不自动启动爬取。新名字避免破坏旧工程，旧工作区不直接改模式，需建立新工作区显式迁移。

## 第一次运行

复制[prompts/first-run.zh-CN.md](prompts/first-run.zh-CN.md)，替换名单与输出路径。assets有公司/来源/上市史/输出空模板；无需用户逐字段填JSON，执行代理应完成实际发现、阅读、决策和两轮审查。

SEC有原生历史索引/原文/数值候选引擎；layoffs.fyi与其他交易所用宿主搜索/浏览发现原始URL，再用包内HTML/TXT/PDF增量快照。不是各站点无需登录的全站API。未获得的来源和扫描报告待审保持PARTIAL。所有结果的COMPLETE只在注册范围的实际审查和覆盖通过时成立，不证明全世界事件穷尽或独立人工信度。

## 研究口径

公告保留多标签公司所述原因，不预设AI是借口或真实因果。上市、私人、已退市企业身份稳定；公司历史按事件时点解释。原88个年报变量保留，48个文本披露编码及6专项金额新增，数值/原文/0/1分别保存。金额以基础货币保存并核倍率，缺失不填0。研究进展数字、初步结论、人工标注样本和合成数据不打入公开包充作已采结果。

[更新日志](CHANGELOG.md)及docs/validation.json给出本版验证范围；测试使用合成离线材料，不代表已完成5,000条公告或610家公司实采。
