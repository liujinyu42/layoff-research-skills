"""Two proposal workflows. Metadata binding never substitutes for substantive reading."""
from pathlib import Path
import argparse,csv,json,hashlib,math,datetime,sys,os,subprocess
csv.field_size_limit(max(csv.field_size_limit(),2**31-1))

def digest(obj):return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def load(path,default=None):return json.loads(Path(path).read_text())if Path(path).is_file()else default
def save(path,obj):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');temp.replace(p)
def rows(path):
 p=Path(path)
 if p.suffix=='.csv':
  with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
 text=p.read_text(encoding='utf-8-sig');return json.loads(text)if text.lstrip().startswith('[')else[json.loads(l)for l in text.splitlines()if l.strip()]
def schema(skill):return load(skill/'assets'/('event_schema.json'if skill.name=='layoff-announcement-tracker'else'filing_schema.json'))
def mode(skill):return 'events'if skill.name=='layoff-announcement-tracker'else'filings'
def context(work):
 from .sources import read_sources,text_for
 w=Path(work);cfg=load(w/'config.json');sources={k:v for k,v in read_sources(w).items()if v.get('active',True)};texts={}
 def text(sid):
  if sid not in sources:raise ValueError('Unknown/retired source '+sid)
  if sid not in texts:texts[sid]=text_for(w,sources[sid])
  return texts[sid]
 return cfg,sources,text

def entities(cfg,sources):
 roster={r['company_id']:r for r in cfg['roster']}
 if cfg['mode']=='filings':return {c+':'+str(y):{'entity_id':c+':'+str(y),'company_id':c,'company':r['company'],'fy':y,'exchange':r.get('exchange',''),'listing_status':r.get('listing_status','unknown')}for c,r in roster.items()for y in range(cfg['year_start'],cfg['year_end']+1)}
 out={}
 for src in sources.values():
  plan=src.get('plan_id');cid=src['company_id']
  if not plan:continue
  if plan in out and out[plan]['company_id']!=cid:raise ValueError('plan_id assigned to different companies')
  out[plan]={'entity_id':plan,'plan_id':plan,'company_id':cid,'company':roster[cid]['company']}
 return out

def suitable(src,entity,cfg):
 if src['company_id']!=entity['company_id']:return False
 if cfg['mode']=='filings':return str(src.get('fy',''))==str(entity['fy'])
 return src.get('plan_id')==entity['plan_id']or src.get('document_role')=='company_profile'

def init(skill,work,companies,years,start,end):
 w=Path(work);roster=rows(companies)
 if not roster:raise ValueError('Explicit nonempty company roster required; proposal sample counts are not input data')
 seen=set()
 for r in roster:
  if not r.get('company_id')or not r.get('company'):raise ValueError('company_id/company required')
  if r['company_id']in seen:raise ValueError('Duplicate company_id')
  seen.add(r['company_id'])
  if r.get('cik'):
   if not r['cik'].isdigit()or len(r['cik'])>10:raise ValueError('Invalid CIK')
   r['cik']=r['cik'].zfill(10)
 m=mode(skill);lo,hi=map(int,years.split(':'))
 if lo>hi:raise ValueError('Reversed fiscal years')
 datetime.date.fromisoformat(start);datetime.date.fromisoformat(end)
 if start>end:raise ValueError('Reversed announcement dates')
 cfg={'version':'0.9.0','mode':m,'roster':roster,'year_start':lo,'year_end':hi,'event_start':start,'event_end':end,'schema_sha256':digest(schema(skill))}
 prior=load(w/'config.json')
 if prior and prior!=cfg:raise ValueError('Scope/schema changed: use a new workspace or explicitly reconcile before changing config')
 save(w/'config.json',cfg);return {'companies':len(roster),'mode':m,'status':'initialized','schedule_started':False}

def taskset(skill,work):
 cfg,sources,text=context(work);book=schema(skill)
 if cfg['schema_sha256']!=digest(book):raise ValueError('Schema changed; explicitly migrate or use a new workspace')
 ents=entities(cfg,sources)
 if cfg['mode']=='events':
  prior=load(Path(work)/'entities.json',{})
  for eid,en in prior.items():
   if eid in ents and ents[eid]['company_id']!=en['company_id']:raise ValueError('Plan identity changed')
  prior.update(ents);ents=prior;save(Path(work)/'entities.json',ents)
 tasks=[]
 for eid,entity in ents.items():
  candidates=[s['source_id']for s in sources.values()if suitable(s,entity,cfg)]
  for field in book['fields']:tasks.append({'entity_id':eid,'company_id':entity['company_id'],'fy':entity.get('fy'),'variable':field['id'],'definition_sha256':digest(field),'source_ids':candidates})
 return cfg,sources,text,book,ents,tasks

def normalize(d,cfg,sources,text,fields,ents):
 eid=d['entity_id'];var=d['variable'];entity=ents[eid];field=fields[var];status=d.get('status');v=d.get('value')
 if status not in {'observed','reviewed_absent','not_separate','unresolved'}:raise ValueError('Invalid status')
 if not d.get('reason')or not d.get('criterion_application')or d.get('reviewer_kind')not in {'human','model'}or not d.get('reviewer_id'):raise ValueError('Specific reason/criterion/reviewer required')
 if status=='observed':
  if v is None:raise ValueError('Observed needs value')
  typ=field['type']
  if typ=='binary'and(type(v)is not int or v not in [0,1]):raise ValueError('Binary is integer0/1; missing is null')
  if typ in {'number','integer'}and(type(v)not in [int,float]or not math.isfinite(v)):raise ValueError('Finite numeric value required')
  if (typ=='integer'or field.get('unit')=='persons')and int(v)!=v:raise ValueError('Integer required')
  if typ in {'text','date'}and not isinstance(v,str):raise ValueError('String required')
  if typ=='date':datetime.date.fromisoformat(v)
  if field.get('codes')and v not in field['codes']:raise ValueError('Value outside declared codes')
  if field.get('unit')=='percent'and not 0<=v<=100:raise ValueError('Percent must be0:100, preserve denominator')
  if typ in {'number','integer'}and(field.get('unit')in {'persons_or_roles','persons_or_fte','persons'}or var=='founding_year')and v<0:raise ValueError('Negative count/year')
  if field.get('unit')in {'fraction','ratio_0_1'}and not 0<=v<=1:raise ValueError('Rate must be fraction0:1')
  if field.get('unit')=='currency_base':
   amount=d.get('amount')or{}
   if not isinstance(amount.get('raw_value'),(int,float))or not isinstance(amount.get('scale'),(int,float))or amount['scale']<=0:raise ValueError('Money needs numeric raw_value and positive scale from source')
   if not amount.get('currency')or len(amount['currency'])!=3 or amount['currency']=='UNK':raise ValueError('Explicit ISO currency required; no assumed USD')
   expected=amount['raw_value']*amount['scale']
   if not math.isclose(v,expected,rel_tol=1e-12,abs_tol=1e-8):raise ValueError('Base currency amount != raw_value * scale')
   if not amount.get('unit_quote'):raise ValueError('Exact header/sentence unit_quote required')
   if field.get('measure_kind')=='annual_flow'and d.get('measurement_scope')!='company_total':raise ValueError('Annual flow must identify company_total; component/mixed/plan amounts remain separate or unresolved')
  if cfg['mode']=='filings'and field.get('measure_kind')=='executive_compensation':
   if not d.get('executive_name')or not d.get('compensation_basis'):raise ValueError('Executive amount requires identified name and SCT/CAP/NEO basis')
  if cfg['mode']=='filings'and field.get('measure_kind')=='stock'and not d.get('period_end'):raise ValueError('Stock requires actual fiscal period_end')
  if cfg['mode']=='filings'and typ in {'number','integer'}and int(d.get('period_fy',-1))!=entity['fy']:raise ValueError('Numeric period_fy must match target fiscal year')
 elif v is not None:raise ValueError('Missing/unresolved value must be null, never0')
 for date_field in ['period_end','information_as_of']:
  if d.get(date_field):datetime.date.fromisoformat(d[date_field])
 evidence=[];bindings={};scopes=[]
 for e in d.get('evidence',[]):
  sid=e['source_id'];src=sources[sid]
  if not suitable(src,entity,cfg):raise ValueError('Evidence outside company/year/plan')
  tx=text(sid);q=e['quote'];start=e.get('char_start')
  if not isinstance(q,str)or len(q.strip())<10:raise ValueError('Actual source quotation required')
  if start is None:
   if tx.count(q)!=1:raise ValueError('Quote missing/ambiguous: provide exact char_start')
   start=tx.index(q)
  if type(start)is not int or tx[start:start+len(q)]!=q:raise ValueError('Quote/absolute offset mismatch')
  if field.get('unit')=='currency_base'and(d.get('amount')or{}).get('unit_quote')not in tx:raise ValueError('Unit quote does not occur in evidence source')
  bindings[sid]={'text_sha256':src['text_sha256'],'row_sha256':src['row_sha256']};evidence.append({**e,'char_start':start,'char_end':start+len(q),'text_sha256':src['text_sha256'],'content_sha256':src['content_sha256'],'source_url':src.get('source_url','')})
 negative=status in {'reviewed_absent','not_separate'}or(status=='observed'and field['type']=='binary'and v==0)
 for scope in d.get('reviewed_scopes',[]):
  sid=scope['source_id'];tx=text(sid)
  if not suitable(sources[sid],entity,cfg):raise ValueError('Negative scope outside entity')
  lo,hi=scope['start'],scope['end']
  if lo!=0 or hi!=len(tx):raise ValueError('Absence requires complete registered source; snippets cannot establish0')
  scopes.append({'source_id':sid,'start':lo,'end':hi,'scope_sha256':hashlib.sha256(tx.encode()).hexdigest()});bindings[sid]={'text_sha256':sources[sid]['text_sha256'],'row_sha256':sources[sid]['row_sha256']}
 if negative:
  if any(suitable(src,entity,cfg)and src.get('status')!='ready'for src in sources.values()):raise ValueError('Incomplete sources cannot establish an absence or0')
  expected={sid for sid,src in sources.items()if suitable(src,entity,cfg)and src.get('status')=='ready'}
  if not expected or {s['source_id']for s in scopes}!=expected or d.get('scope_read')is not True:raise ValueError('Actual full reading of all entity sources required for negative/missing finding')
 if status=='observed'and not negative and not evidence:raise ValueError('Observed value needs source evidence')
 if cfg['mode']=='events'and var in {'firm_size','firm_size_at_event','leadership_transition','ma_activity','listing_status_at_event','listed_at_event','company_history','products_services','business_model'}and status=='observed'and not d.get('information_as_of'):raise ValueError('Event-time company context requires information_as_of')
 out={**d,'evidence':evidence,'reviewed_scopes':scopes,'source_bindings':bindings,'definition_sha256':digest(field)};out.pop('decision_sha256',None);out['decision_sha256']=digest(out);return out

def check_decisions(skill,work,submitted=None):
 cfg,sources,text,book,ents,tasks=taskset(skill,work);fields={f['id']:f for f in book['fields']};accepted={};errors=[]
 existing=load(Path(work)/'decisions.json',{});items=list(existing.values())if submitted is None else submitted
 for i,d in enumerate(items,1):
  try:
   key=d['entity_id']+'|'+d['variable']
   if key in accepted:raise ValueError('Duplicate field decision')
   out=normalize(d,cfg,sources,text,fields,ents)
   if submitted is None and d.get('decision_sha256')!=out['decision_sha256']:raise ValueError('Decision/source/definition changed since submission')
   accepted[key]=out
  except (ValueError,KeyError,TypeError,OSError)as ex:errors.append({'row':i,'entity_id':d.get('entity_id'),'variable':d.get('variable'),'error':str(ex)})
 return accepted,errors,(cfg,sources,book,ents,tasks)

def prepare(skill,work):
 accepted,errors,(cfg,sources,book,ents,tasks)=check_decisions(skill,work);w=Path(work);folder=w/'review';folder.mkdir(exist_ok=True)
 unresolved=[t for t in tasks if t['entity_id']+'|'+t['variable']not in accepted or accepted[t['entity_id']+'|'+t['variable']]['status']=='unresolved']
 (folder/'tasks.jsonl').write_text(''.join(json.dumps(t,ensure_ascii=False)+'\n'for t in unresolved));save(folder/'definitions.json',{f['id']:f for f in book['fields']})
 groups=[]
 for eid,entity in ents.items():
  group=[s for s in sources.values()if suitable(s,entity,cfg)];groups.append({'entity_id':eid,'fields':[t['variable']for t in unresolved if t['entity_id']==eid],'sources':[{k:s.get(k)for k in ['source_id','source_type','document_role','text_path','text_sha256','n_chars','status']}for s in group]})
 save(folder/'reading_groups.json',groups);save(folder/'decision-example.json',{'entity_id':'company-id:2023'if cfg['mode']=='filings'else'plan-id','variable':'headcount'if cfg['mode']=='filings'else'stated_reason_text','status':'observed','value':None,'reason':'Write actual source-based reason','criterion_application':'Apply definition to actual context','reviewer_id':'A','reviewer_kind':'model','evidence':[{'source_id':'id','quote':'Copy exact original text'}]})
 return {'entities':len(ents),'tasks':len(tasks),'remaining':len(unresolved),'invalid_saved_decisions':len(errors),'reading_groups':str(folder/'reading_groups.json'),'next':'Read each source once per group, decide each field; apply JSONL then prepare-second; no automatic semantic judgments.'}

def apply(skill,work,path):
 incoming=rows(path);accepted,errors,_=check_decisions(skill,work,incoming);w=Path(work);report={'pass':not errors,'errors':errors,'accepted':len(accepted),'semantic_judgments_generated':False};save(w/'qa/apply-preflight.json',report)
 if errors:return report
 prior=load(w/'decisions.json',{})
 if prior:save(w/'history'/('decisions-'+digest(prior)+'.json'),prior)
 prior.update(accepted);save(w/'decisions.json',prior);return report

def second_tasks(skill,work):
 accepted,errors,_=check_decisions(skill,work)
 if errors:raise ValueError('Repair invalid decisions before second reading')
 tasks=[{'entity_id':r['entity_id'],'variable':r['variable'],'decision_sha256':r['decision_sha256'],'definition_sha256':r['definition_sha256'],'source_bindings':r['source_bindings']}for r in accepted.values()if r['status']!='unresolved'];save(Path(work)/'review/second-tasks.json',tasks);return {'tasks':len(tasks),'path':str(Path(work)/'review/second-tasks.json'),'next':'Actually read original sources again, return same bindings + reviewed_again:true + specific criterion_application + reviewer_id/kind; apply-second. Same model review is not human reliability.'}

def apply_second(skill,work,path):
 accepted,errors,_=check_decisions(skill,work);result={};seen=set()
 for n,r in enumerate(rows(path),1):
  try:
   k=r['entity_id']+'|'+r['variable'];d=accepted[k]
   if k in seen:raise ValueError('Duplicate second judgment')
   seen.add(k)
   if r.get('reviewed_again')is not True or not r.get('criterion_application')or not r.get('reviewer_id')or r.get('reviewer_kind')not in {'human','model'}:raise ValueError('Actual second source reading and specific criterion required')
   for name in ['decision_sha256','definition_sha256','source_bindings']:
    if r.get(name)!=d[name]:raise ValueError('Second-review binding changed: '+name)
   out=dict(r);out.pop('second_review_sha256',None);out['second_review_sha256']=digest(out);result[k]=out
  except(KeyError,ValueError,TypeError)as e:errors.append({'row':n,'error':str(e)})
 report={'pass':not errors,'errors':errors,'second_reviews':len(result)};save(Path(work)/'qa/second-preflight.json',report)
 if not errors:
  prior=load(Path(work)/'second.json',{});prior.update(result);save(Path(work)/'second.json',prior)
 return report

def audit(skill,work):
 accepted,errors,(cfg,sources,book,ents,tasks)=check_decisions(skill,work);second=load(Path(work)/'second.json',{});pending=[];needs_second=[];coverage=[]
 from .sources import text_for
 for src in sources.values():
  if src.get('status')=='ready':
   try:text_for(Path(work),src)
   except (ValueError,OSError)as e:errors.append({'source_id':src['source_id'],'error':str(e)})
 for pf in ['apply-preflight.json','second-preflight.json']:
  pr=load(Path(work)/'qa'/pf,{})
  if pr.get('pass')is False:errors.append({'error':'Latest submission failed: '+pf})
 for t in tasks:
  k=t['entity_id']+'|'+t['variable'];d=accepted.get(k)
  if not d or d['status']=='unresolved':pending.append(k);continue
  sr=second.get(k,{})
  if sr:
   unsigned={name:value for name,value in sr.items()if name!='second_review_sha256'}
   if sr.get('second_review_sha256')!=digest(unsigned)or not sr.get('criterion_application')or not sr.get('reviewer_id')or sr.get('reviewer_kind')not in {'human','model'}:errors.append({'entity_id':t['entity_id'],'variable':t['variable'],'error':'Second-review content changed or substantive review fields missing'})
  if any(sr.get(x)!=d[x]for x in ['decision_sha256','definition_sha256','source_bindings'])or sr.get('reviewed_again')is not True:needs_second.append(k)
 for eid,en in ents.items():
  if cfg['mode']=='filings':
   for f in book['fields']:
    if not f['id'].endswith('_disclosed'):continue
    base=accepted.get(eid+'|'+f['id'].removesuffix('_disclosed'));code=accepted.get(eid+'|'+f['id'])
    if base and code and code.get('status')=='observed':
     conflict=code['value']==0 and base['status']=='observed'and base['value']not in [None,'']or code['value']==1 and base['status']in {'reviewed_absent','not_separate'}
     if conflict:errors.append({'entity_id':eid,'variable':f['id'],'error':'Text disclosure and binary code contradict each other'})
  ready=[s for s in sources.values()if suitable(s,en,cfg)and s.get('status')=='ready']
  valid=any(s.get('document_role')in {'annual_report','annual_financials'}and s.get('source_type')in {'sec_filing','exchange_filing','company_annual_report'}for s in ready)if cfg['mode']=='filings'else any(s.get('source_type')in {'company_announcement','sec_filing','exchange_filing'}and s.get('document_role')in {'layoff_announcement','event_filing'}for s in ready)
  if not valid:coverage.append({'entity_id':eid,'reason':'annual/original announcement source missing; news/tracker is not original'})
 if cfg['mode']=='events':
  represented={en['company_id']for en in ents.values()}
  coverage.extend({'company_id':r['company_id'],'reason':'no registered plan; cannot conclude no layoffs'}for r in cfg['roster']if r['company_id']not in represented)
  for eid,en in ents.items():
   date=accepted.get(eid+'|announcement_date',{}).get('value')
   if not date or not cfg['event_start']<=date<=cfg['event_end']:coverage.append({'entity_id':eid,'reason':'announcement_date missing/outside requested window'})
 if cfg['mode']=='events':
  for eid,en in ents.items():
   vals={v:accepted.get(eid+'|'+v,{}).get('value')for v in [f['id']for f in book['fields']]}
   if vals.get('plan_identity_verified')!=1:coverage.append({'entity_id':eid,'reason':'plan identity has not been verified'})
   for base in ['layoff_count','layoff_percentage']:
    lo=vals.get(base+'_lower');hi=vals.get(base+'_upper')
    if lo is not None and hi is not None and lo>hi:errors.append({'entity_id':eid,'error':base+' reversed bounds'})
   if any(vals.get(v)==1 for v in vals if v.startswith('reason_')and v!='reason_attribution')and vals.get('reason_attribution')not in {'company_direct','company_quote_in_news'}:errors.append({'entity_id':eid,'error':'Reason codes require company attribution'})
 bad=[s['source_id']for s in sources.values()if s.get('status')!='ready'];report={'version':'0.9.0','integrity_pass':not errors,'complete':not(errors or pending or needs_second or coverage or bad),'entities':len(ents),'fields_per_entity':len(book['fields']),'positions':len(tasks),'pending':len(pending),'second_pending':len(needs_second),'coverage_gaps':coverage,'source_failures':bad,'errors':errors,'pending_positions':pending,'second_pending_positions':needs_second,'reliability':None,'note':'Same-model two readings are self-review, not independent human agreement.'};save(Path(work)/'qa/audit.json',report);return report

def export(skill,work,output,partial=False):
 report=audit(skill,work)
 if not report['integrity_pass']:raise ValueError('Invalid source/decision blocks export; see qa/audit.json')
 if not report['complete']and not partial:raise ValueError('Incomplete work; resolve tasks or explicitly export --allow-partial')
 accepted,_,(cfg,sources,book,ents,tasks)=check_decisions(skill,work);fields=[f['id']for f in book['fields']];columns=['company_id','company','fy']if cfg['mode']=='filings'else['plan_id','company_id','company']
 columns+=fields+['delivery_status','field_status_json','evidence_json'];data=[]
 for eid,en in ents.items():
  rr={k:en.get(k)for k in columns[:3]};proof={};statuses={}
  for var in fields:
   d=accepted.get(eid+'|'+var);rr[var]=d['value']if d else None;statuses[var]=d['status']if d else'not_reviewed'
   if d:proof[var]=d
  rr.update(delivery_status='COMPLETE'if report['complete']else'PARTIAL',field_status_json=json.dumps(statuses,ensure_ascii=False),evidence_json=json.dumps(proof,ensure_ascii=False));data.append(rr)
 # Long strings continue horizontally; never silently truncate or add company-year rows.
 for col in list(columns):
  extra=1
  for rr in data:
   if not isinstance(rr.get(col),str):continue
   chunks=[];chunk='';size=0
   for ch in rr[col]:
    width=len(ch.encode('utf-16-le'))//2
    if size+width>30000:chunks.append(chunk);chunk='';size=0
    chunk+=ch;size+=width
   chunks.append(chunk);rr[col]=chunks[0];extra=max(extra,len(chunks))
   for n,value in enumerate(chunks[1:],2):rr[col+'__part'+str(n)]=value
  columns += [col+'__part'+str(n)for n in range(2,extra+1)]
 from openpyxl import Workbook,load_workbook
 from openpyxl.styles import Font,PatternFill,Alignment
 from openpyxl.utils import get_column_letter
 template=skill/'assets/output_template.xlsx';contract=load(skill/'assets/output_contract.json')
 if template.is_file():
  if not contract or contract['template_sha256']!=hashlib.sha256(template.read_bytes()).hexdigest()or contract['schema_sha256']!=digest(book):raise ValueError('Built-in template/schema binding changed')
  wb=load_workbook(template);ws=wb.active
  if wb.sheetnames!=['结果']or [c.value for c in ws[1]]!=contract['columns']:raise ValueError('Template header mismatch')
  if columns[:len(contract['columns'])]!=contract['columns']:raise ValueError('Output columns diverged from template')
  if len(columns)>len(contract['columns']):
   for j,k in enumerate(columns,1):ws.cell(1,j,k)
 else:
  wb=Workbook();ws=wb.active;ws.title='结果';ws.append(columns)
 for rr in data:
  ws.append([rr.get(k)for k in columns])
  for cell in ws[ws.max_row]:
   if isinstance(cell.value,str):cell.data_type='s'
 for cell in ws[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='17365D');cell.alignment=Alignment(wrap_text=True,vertical='center')
 ws.row_dimensions[1].height=42;ws.freeze_panes='D2';ws.auto_filter.ref=ws.dimensions
 for n in range(1,len(columns)+1):ws.column_dimensions[get_column_letter(n)].width=24
 p=Path(output);p.parent.mkdir(parents=True,exist_ok=True);wb.save(p);saved=load_workbook(p,data_only=False);assert saved.sheetnames==['结果'];actual=list(saved.active.values)
 if list(actual[0])!=columns or len(actual)!=len(data)+1:raise ValueError('Saved shape mismatch')
 for i,rr in enumerate(data,1):
  for j,k in enumerate(columns):
   expected=rr.get(k);got=actual[i][j]
   if expected==''and got is None:continue
   if isinstance(expected,(int,float))and isinstance(got,(int,float)):
    if not math.isclose(expected,got,rel_tol=1e-14,abs_tol=0):raise ValueError('Saved numeric mismatch')
   elif expected!=got:raise ValueError('Saved cell mismatch')
 summary={'output':str(p),'rows':len(data),'columns':len(columns),'worksheet_count':1,'status':'COMPLETE'if report['complete']else'PARTIAL','saved_cells_checked':len(actual)*len(columns),'source_audit':report};save(p.with_suffix('.audit.json'),summary);return {k:v for k,v in summary.items()if k!='source_audit'}

def main(skill,argv=None):
 skill=Path(skill).resolve();p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
 a=sub.add_parser('init');a.add_argument('--work',required=True);a.add_argument('--companies',required=True);a.add_argument('--years',default='2019:2025');a.add_argument('--start',default='2020-01-01');a.add_argument('--end',default='2026-09-30')
 a=sub.add_parser('sync');a.add_argument('--work',required=True);a.add_argument('--manifest',required=True);a.add_argument('--offline',action='store_true');a.add_argument('--refresh',action='store_true')
 for command in ['prepare','prepare-second','audit']:
  a=sub.add_parser(command);a.add_argument('--work',required=True)
 for command in ['apply','apply-second']:
  a=sub.add_parser(command);a.add_argument('--work',required=True);a.add_argument('--decisions',required=True)
 a=sub.add_parser('export');a.add_argument('--work',required=True);a.add_argument('--output',required=True);a.add_argument('--allow-partial',action='store_true')
 a=sub.add_parser('read');a.add_argument('--work',required=True);a.add_argument('--source',required=True);a.add_argument('--offset',type=int,default=0);a.add_argument('--limit',type=int,default=16000)
 a=sub.add_parser('sec-prepare');a.add_argument('--work',required=True);a.add_argument('--offline');a.add_argument('--cache-only',action='store_true')
 a=p.parse_args(argv)
 try:
  if a.command=='init':result=init(skill,a.work,a.companies,a.years,a.start,a.end)
  elif a.command=='sync':
   from .sources import ingest
   ss=ingest(Path(a.work),Path(a.manifest),a.offline,a.refresh);result={'sources':len(ss),'statuses':{s:sum(r['status']==s for r in ss)for s in {r['status']for r in ss}},'next':'prepare'}
  elif a.command=='read':
   cfg,ss,get_text=context(a.work);tx=get_text(a.source)
   if not 0<=a.offset<len(tx)or not 1<=a.limit<=24000:raise ValueError('Invalid source offset/page size')
   stop=min(a.offset+a.limit,len(tx));result={'source_id':a.source,'start':a.offset,'end':stop,'total':len(tx),'next_offset':stop if stop<len(tx)else None,'text':tx[a.offset:stop],'not_a_semantic_judgment':True}
  elif a.command=='prepare':result=prepare(skill,a.work)
  elif a.command=='apply':result=apply(skill,a.work,a.decisions)
  elif a.command=='prepare-second':result=second_tasks(skill,a.work)
  elif a.command=='apply-second':result=apply_second(skill,a.work,a.decisions)
  elif a.command=='audit':result=audit(skill,a.work);result={k:v for k,v in result.items()if k not in ['pending_positions','second_pending_positions']}
  elif a.command=='sec-prepare':
   from .sec_bridge import sec_prepare
   result=sec_prepare(skill,Path(a.work),a.offline,a.cache_only)
  else:result=export(skill,a.work,a.output,a.allow_partial)
  print(json.dumps(result,ensure_ascii=False,indent=2));return 2 if result.get('pass')is False or a.command=='audit'and not result.get('complete')else 0
 except (ValueError,KeyError,OSError,TypeError)as ex:
  print(json.dumps({'error':str(ex)},ensure_ascii=False));return 2
