"""Reuse proven SEC parsing as candidates; no dependency on other installed skills."""
from pathlib import Path
import csv,json,sqlite3,subprocess,sys,os
from .workflow import load,save,rows

def engine_root(skill):
 for path in [skill/'scripts/vendor',skill.parents[1]/'engine']:
  if(path/'skills/layoff-hcm-tracker/scripts/track.py').is_file():return path
 raise ValueError('Bundled SEC engine missing; reinstall this skill (no third installed skill is required)')

def sec_prepare(skill,work,offline=None,cache_only=False):
 cfg=load(work/'config.json')
 if cfg['mode']!='filings':raise ValueError('SEC annual candidate extraction belongs to listed-filing-extractor; event source URLs use sync')
 if offline and cache_only:raise ValueError('Choose offline fixture discovery or cache-only existing workspace')
 roster=[r for r in cfg['roster']if r.get('cik')];excluded=[r['company_id']for r in cfg['roster']if not r.get('cik')]
 if not roster:raise ValueError('No CIKs; use official report source manifests for non-SEC issuers')
 if len({r['cik']for r in roster})!=len(roster):raise ValueError('Multiple company IDs share a CIK; reconcile identities first')
 engine=engine_root(skill);t=engine/'skills/layoff-hcm-tracker/scripts';w=work/'sec';inp=work/'input';inp.mkdir(exist_ok=True)
 companies=inp/'sec-companies.csv'
 with companies.open('w',newline='')as f:
  writer=csv.DictWriter(f,fieldnames=['cid','cik','company','ticker']);writer.writeheader();writer.writerows({'cid':i,'cik':r['cik'],'company':r['company'],'ticker':r.get('ticker','')}for i,r in enumerate(roster,1))
 commands=[]
 if not(w/'config/companies.csv').is_file():commands.append([str(t/'track.py'),'init','--work',str(w),'--companies',str(companies)])
 years=str(cfg['year_start'])+':'+str(cfg['year_end'])
 if not cache_only:
  commands.append([str(t/'track.py'),'fetch','--work',str(w),'--years',years]+(['--offline',str(Path(offline).resolve())]if offline else[]))
 commands.extend([[str(t/'track.py'),'extract','--work',str(w)],[str(t/'track.py'),'build','--work',str(w),'--years',years],[str(t/'track.py'),'verify','--work',str(w)],[str(t/'review.py'),'--work',str(w)]])
 logs=work/'qa/sec-logs';logs.mkdir(parents=True,exist_ok=True)
 for i,cmd in enumerate(commands):
  target=logs/(str(i)+'-'+Path(cmd[0]).stem+'.log')
  # Only child process ignores a host-injected PYTHONPATH; files/stdlib stay intact.
  env=dict(os.environ);env.pop('PYTHONPATH',None)
  with target.open('w')as f:result=subprocess.run([sys.executable,*cmd],stdout=f,stderr=subprocess.STDOUT,env=env)
  if result.returncode:save(work/'qa/sec-status.json',{'status':'failed','log':str(target),'exit_code':result.returncode});raise ValueError('SEC collection/extraction incomplete; see '+str(target))
 cik_to_id={r['cik']:r['company_id']for r in roster};meta=load(w/'panel/panel_meta.json',{});selected={(str(r['cik']),int(r['fy']),r['accession'])for r in meta.get('company_periods',[])}
 for ev in rows(w/'panel/evidence_long.csv'):
  if ev.get('is_primary','').lower()in {'true','1'}:selected.add((str(ev['cik']),int(ev['fy']),ev['accession']))
 db=sqlite3.connect(w/'state/state.db');db.row_factory=sqlite3.Row;filings={r['accession']:dict(r)for r in db.execute('select * from filings')};db.close();manifest=[]
 for cik,fy,acc in sorted(selected):
  f=filings.get(acc)
  if not f or cik not in cik_to_id:continue
  role='proxy'if f['form'].startswith('DEF')else'annual_report'
  manifest.append({'source_id':'sec-'+acc+'-'+str(fy),'company_id':cik_to_id[cik],'source_type':'sec_filing','document_role':role,'fy':fy,'form':f['form'],'source_url':f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace('-','')}/{f['primary_doc']}",'local_path':str((w/f['path']).resolve())if f.get('path')else'','publication_date':f['filed'],'exchange':'SEC'})
 # Preserve separately registered non-SEC/profiles. New SEC selection replaces only its own sources.
 from .sources import read_sources,ingest
 all_manifest=[{k:v for k,v in s.items()if k in ['source_id','company_id','source_type','source_url','local_path','document_role','fy','plan_id','publication_date','source_date','exchange','form']}for s in read_sources(work).values()if s.get('active',True)and not s['source_id'].startswith('sec-')]+manifest
 path=inp/'sec-source-manifest.json';save(path,all_manifest);ingest(work,path,offline=True)
 candidates=rows(w/'review/research_long.csv')if(w/'review/research_long.csv').is_file()else rows(w/'panel/panel_long.csv');save(work/'review/sec-candidates.json',{'status':'candidates_only_not_reviewed','rows':candidates,'note':'Never adopt a value without quote/period/unit/source review. Proxy belongs to its target fiscal year, not publication year.'})
 save(work/'qa/sec-status.json',{'status':'candidates_ready','filing_sources':len(manifest),'companies_without_cik':excluded,'native_forms':['10-K','20-F','DEF 14A','8-K','6-K'],'40_F':'use explicit official source manifest; native annual anchoring is not claimed','engine_version':'0.8.3'})
 return {'sources':len(manifest),'candidates':len(candidates),'companies_without_cik':excluded,'next':'prepare; read review/sec-candidates.json only for current group; candidates never auto-complete field review'}
