#!/usr/bin/env python3
"""layoff-hcm-tracker —— 持续获取、增量追踪、证据留痕。

子命令
    init        初始化工作区（目录、配置副本、状态库）
    fetch       枚举申报并下载原文（支持离线 fixtures）
    extract     解析原文，产出证据包与裁员事件
    ingest-warn 归一化州 WARN 备案
    build       构建面板（长表/宽表/证据表/元数据）并记录快照
    diff        对比最近两次快照，产出修订日志
    status      查看状态、覆盖率与最近运行
    retry       把失败任务重置为待处理
    verify      校验证据可复现性与状态完整性

示例
    python track.py init --work work --companies assets/companies.csv
    python track.py fetch --work work --years 2019:2025 --offline ../examples/fixtures
    python track.py extract --work work
    python track.py build --work work
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve()
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT / "shared"))  # 仓库布局：<repo>/shared
sys.path.insert(0, str(HERE.parent))     # 安装后布局：<skill>/scripts/layoffcore
sys.path.insert(0, str(HERE.parent))

from layoffcore import sec as sec_mod  # noqa: E402
from layoffcore.evidence import evidence_id  # noqa: E402
from layoffcore.io import read_csv, sha256_file, sha256_text, write_json  # noqa: E402
from layoffcore.manifest import Run  # noqa: E402
from layoffcore.schema import EVENT_COLUMNS, WORK_DIRS, TaskStatus  # noqa: E402
from layoffcore.state import StateDB  # noqa: E402
from layoffcore.textutil import html_to_text  # noqa: E402

from lib import events as events_mod  # noqa: E402
from lib import extract10k, layoff8k, panel as panel_mod  # noqa: E402
from lib import diff as diff_mod  # noqa: E402
from lib import verify as verify_mod  # noqa: E402
from lib import warn as warn_mod  # noqa: E402
from lib.rules import load_varspec  # noqa: E402

ASSETS = HERE.parents[1] / "assets"

TARGET_FORMS = set(sec_mod.ANNUAL_FORMS) | set(sec_mod.EVENT_FORMS) | set(sec_mod.PROXY_FORMS)


# ---------------------------------------------------------------- 工具

def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_years(spec: str) -> tuple[int, int]:
    if not spec:
        raise SystemExit("必须提供 --years，例如 2019:2025")
    if ":" in spec:
        a, b = spec.split(":", 1)
        bounds = int(a), int(b)
        if bounds[0] > bounds[1]:
            raise SystemExit("起始年必须小于等于结束年")
        return bounds
    if "," in spec:
        parts = [int(x) for x in spec.split(",")]
        return min(parts), max(parts)
    y = int(spec)
    return y, y


def _in_window(fy: int, filed: str, y0: int, y1: int) -> bool:
    if fy and y0 <= fy <= y1:
        return True
    if filed[:4].isdigit():
        return y0 <= int(filed[:4]) <= y1
    return False


def _capture_window(filing: dict, y0: int, y1: int) -> bool:
    if _in_window(filing["fy"], filing["filed"], y0, y1):
        return True
    # Calendar-year filers disclose the final year's compensation in next year's proxy.
    return filing.get("form") in sec_mod.PROXY_FORMS and filing.get("filed", "")[:4] == str(y1 + 1)


def _load_var_book(work: Path) -> list[dict]:
    rows = read_csv(work / "config" / "variable_book.csv")
    if not rows:
        raise SystemExit("缺少 config/variable_book.csv，请先运行 init")
    return rows


def _client(args) -> sec_mod.SecClient:
    offline = Path(args.offline).resolve() if getattr(args, "offline", None) else None
    return sec_mod.SecClient(
        user_agent=os.environ.get("SEC_USER_AGENT", ""),
        offline_dir=offline,
        cache_dir=Path(args.work) / "cache",
        rate_per_sec=float(os.environ.get("SEC_RATE_LIMIT", "5")),
    )


# ---------------------------------------------------------------- init

def cmd_init(args) -> int:
    work = Path(args.work)
    for d in WORK_DIRS:
        (work / d).mkdir(parents=True, exist_ok=True)

    with Run(work, "init", {"companies": str(args.companies)}) as run:
        cfg = work / "config"
        src_companies = Path(args.companies)
        if not src_companies.is_file():
            raise SystemExit(f"公司清单不存在: {src_companies}")
        if (work / "state" / "state.db").exists():
            with StateDB(work / "state" / "state.db") as existing:
                if existing.companies():
                    raise SystemExit("工作区已有公司清单；请复用 refresh，换样本请新建工作区")
        shutil.copyfile(src_companies, cfg / "companies.csv")
        shutil.copyfile(ASSETS / "variable_book.csv", cfg / "variable_book.csv")
        if (ASSETS / "varspec.yaml").exists():
            shutil.copyfile(ASSETS / "varspec.yaml", cfg / "varspec.yaml")

        rows = read_csv(cfg / "companies.csv")
        seen_ciks, seen_cids = set(), set()
        for r in rows:
            cik = str(r.get("cik", ""))
            if cik and (not cik.isdigit() or len(cik) > 10 or int(cik) == 0):
                raise SystemExit(f"非法 CIK: {cik}")
            cid = int(r["cid"])
            if cid in seen_cids or (cik and cik.zfill(10) in seen_ciks):
                raise SystemExit("公司清单含重复 cid 或 CIK")
            seen_cids.add(cid)
            if cik:
                seen_ciks.add(cik.zfill(10))
        with StateDB(work / "state" / "state.db") as db:
            for r in rows:
                db.upsert_company(
                    cid=int(r["cid"]),
                    company=r["company"],
                    ticker=r.get("ticker", ""),
                    cik=str(r.get("cik", "")).zfill(10) if r.get("cik") else "",
                    market=r.get("market", ""),
                    note=r.get("note", ""),
                )
        run.counts["n_companies"] = len(rows)
        run.add_output("config/companies.csv")
        run.add_output("config/variable_book.csv")
    print(f"工作区已初始化: {work.resolve()}")
    print(f"公司数: {len(rows)}  变量数: {len(_load_var_book(work))}")
    return 0


# ---------------------------------------------------------------- fetch

def cmd_fetch(args) -> int:
    work = Path(args.work)
    y0, y1 = _parse_years(args.years)
    client = _client(args)
    client.validate_ua()

    with Run(work, "fetch", {"years": f"{y0}:{y1}", "offline": bool(args.offline)}) as run:
        db = StateDB(work / "state" / "state.db")
        companies = db.companies()
        n_disc = n_dl = n_fail = 0
        discovery_errors = []
        run.add_input("config/companies.csv")

        # 离线模式：facts 快照随 fixtures 一起提供，复制进工作区以便 XBRL 取数
        if args.offline:
            src_facts = Path(args.offline) / "facts"
            if src_facts.exists():
                dst = work / "raw" / "facts"
                dst.mkdir(parents=True, exist_ok=True)
                for f in src_facts.glob("*.json"):
                    shutil.copyfile(f, dst / f.name)

        for comp in companies:
            cik = (comp.get("cik") or "").zfill(10)
            if not cik.strip("0"):
                continue
            try:
                payload = client.submissions(cik)
                history = client.submission_history(payload, y0, y1)
                facts = client.companyfacts(cik)
                write_json(work / "raw" / "facts" / f"facts_{cik}.json", facts)
            except Exception as exc:  # noqa: BLE001
                print(f"  [skip] {comp['company']}: {exc}")
                n_fail += 1
                discovery_errors.append({"cik": cik, "error": str(exc)[:400]})
                continue

            records = sec_mod.parse_submissions(payload, int(comp["cid"]))
            for page in history:
                records.extend(sec_mod.parse_submissions(page, int(comp["cid"])))
            records = list({r["accession"]: r for r in records}.values())
            for rec in records:
                if rec["form"] not in TARGET_FORMS:
                    continue
                if not _capture_window(rec, y0, y1):
                    continue
                db.upsert_filing(
                    accession=rec["accession"], cid=int(comp["cid"]), cik=cik,
                    form=rec["form"], filed=rec["filed"], period=rec["period"],
                    fy=rec["fy"] or int(rec["filed"][:4] or 0),
                    primary_doc=rec["primary_doc"],
                )
                n_disc += 1

        pending = db.filings(status=TaskStatus.PENDING)
        if args.force:
            pending = [f for f in db.filings() if f["status"] != TaskStatus.SKIPPED.value]
        pending = [f for f in pending if _capture_window(f, y0, y1)]
        for f in pending:
            if not f["primary_doc"]:
                db.mark(f["accession"], TaskStatus.SKIPPED, error="缺少 primary_doc")
                continue
            rel = Path("raw") / "docs" / f["accession"].replace("-", "") / f["primary_doc"]
            target = work / rel
            try:
                html = client.document(f["cik"], f["accession"], f["primary_doc"])
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(html, encoding="utf-8")
                _save_exhibits(client, work, f)
                db.mark(f["accession"], TaskStatus.DOWNLOADED, path=str(rel),
                        sha256=sha256_file(target))
                n_dl += 1
            except Exception as exc:  # noqa: BLE001
                db.mark(f["accession"], TaskStatus.FAILED, error=str(exc)[:400],
                        count_attempt=True)
                n_fail += 1
                print(f"  [fail] {f['accession']}: {exc}")

        run.counts.update({"filings": n_disc, "downloaded": n_dl, "failed": n_fail,
                           "status": db.counts()})
        db.set_kv("discovery_errors", discovery_errors)
        if n_fail:
            run.status = "failed"
        db.close()
        run.add_output("state/state.db")
    print(f"枚举 {n_disc} 份申报，下载 {n_dl} 份，失败 {n_fail}")
    return 1 if n_fail else 0


def _save_exhibits(client: sec_mod.SecClient, work: Path, filing: dict) -> None:
    """附件（EX-99.1 等）单独落盘，裁员数字常在附件里。"""
    if filing["form"] not in sec_mod.EVENT_FORMS:
        return
    texts = client.exhibit_texts(filing["cik"], filing["accession"])
    selection=getattr(client,"last_exhibit_selection",None)
    if selection:write_json(work/"qa"/"exhibit_selection"/(filing["accession"]+".json"),selection)
    folder = work / "raw" / "docs" / filing["accession"].replace("-", "")
    for old in folder.glob("exhibit_*.htm"):
        old.unlink()
    for i, txt in enumerate(texts):
        (folder / f"exhibit_{i}.htm").write_text(txt, encoding="utf-8")


# ---------------------------------------------------------------- extract

def cmd_extract(args) -> int:
    work = Path(args.work)
    var_book = _load_var_book(work)
    spec = load_varspec(work / "config" / "varspec.yaml")
    missing = [v["var_id"] for v in var_book
               if v["source_type"] == "rule" and v["var_id"] not in spec]
    if missing:
        print(f"  [warn] 以下 rule 变量缺少抽取规格，将记为未单列: {', '.join(missing)}")

    with Run(work, "extract", {}) as run:
        db = StateDB(work / "state" / "state.db")
        targets = [f for f in db.filings() if f["status"] in
                   {TaskStatus.DOWNLOADED.value, TaskStatus.PARSED.value}]
        sec_events: list[dict] = []
        processed_events = set()
        for rel in ("config/variable_book.csv", "config/varspec.yaml"):
            run.add_input(rel)
        n_ok = n_fail = n_events = 0

        for f in targets:
            raw_path = work / (f["path"] or "")
            if not f["path"] or not raw_path.exists():
                db.mark(f["accession"], TaskStatus.FAILED, error="原文缺失")
                n_fail += 1
                continue
            html = raw_path.read_text(encoding="utf-8", errors="replace")
            try:
                if f["form"] in sec_mod.ANNUAL_FORMS or f["form"] in sec_mod.PROXY_FORMS:
                    facts = _load_facts(work, f["cik"])
                    package = extract10k.extract(
                        html=html, form=f["form"], cid=int(f["cid"]), cik=f["cik"],
                        fy=int(f["fy"]), accession=f["accession"],
                        var_book=var_book, spec=spec, facts=facts, period=f["period"],
                    )
                    pkg = extract10k.save_package(work, package)
                    db.mark(f["accession"], TaskStatus.PARSED,
                            package_path=str(pkg[1].relative_to(work)))
                    n_ok += 1
                elif f["form"] in sec_mod.EVENT_FORMS:
                    ev = _extract_event(work, f, html)
                    if ev:
                        sec_events.append(ev)
                        n_events += 1
                    processed_events.add(f["accession"])
                    db.mark(f["accession"], TaskStatus.PARSED)
                    n_ok += 1
                else:
                    db.mark(f["accession"], TaskStatus.SKIPPED, error="非目标表单")
            except Exception as exc:  # noqa: BLE001
                db.mark(f["accession"], TaskStatus.FAILED, error=str(exc)[:400],
                        count_attempt=True)
                n_fail += 1
                print(f"  [fail] {f['accession']}: {exc}")

        if processed_events:
            existing = [r for r in events_mod.load(work / "events" / "sec_events.csv")
                        if r["accession"] not in processed_events]
            events_mod.save(work / "events" / "sec_events.csv", existing + sec_events)
        merged = events_mod.merge(work)

        run.counts.update({"parsed": n_ok, "failed": n_fail, "new_events": n_events,
                           "events": merged, "status": db.counts()})
        if n_fail:
            run.status = "failed"
        db.close()
        for rel in ("events/sec_events.csv", "events/layoff_disclosures.csv"):
            run.add_output(rel)
    print(f"解析成功 {n_ok} 份，失败 {n_fail} 份，新增裁员披露 {n_events} 条")
    return 1 if n_fail else 0


def _load_facts(work: Path, cik: str) -> dict:
    for cand in (work / "raw" / "facts" / f"facts_{cik}.json",
                 work / "raw" / "facts" / f"facts_{str(cik).lstrip('0')}.json"):
        if cand.exists():
            return json.loads(cand.read_text(encoding="utf-8"))
    return {}


def _extract_event(work: Path, filing: dict, html: str) -> dict | None:
    text = html_to_text(html)
    folder = work / "raw" / "docs" / filing["accession"].replace("-", "")
    for ex in sorted(folder.glob("exhibit_*.htm")):
        text = text + "\n\n" + html_to_text(ex.read_text(encoding="utf-8", errors="replace"))

    period = filing["period"] or filing["filed"]
    try:
        period_year = int(str(period)[:4])
    except (TypeError, ValueError):
        period_year = None
    res = layoff8k.extract(text, period_year=period_year)
    if not res["is_layoff"]:
        return None

    txt_dir = work / "derived" / "texts"
    txt_dir.mkdir(parents=True, exist_ok=True)
    txt_path = txt_dir / f"{filing['cik']}_{filing['accession']}_8k.txt"
    txt_path.write_text(text, encoding="utf-8")

    evid = evidence_id(filing["cik"], filing["accession"], "layoff",
                       res["char_start"], res["char_end"], "layoff8k")
    return {
        "event_id": f"sec-{filing['accession']}",
        "source": "sec_6k" if filing["form"].startswith("6-K") else "sec_8k",
        "cid": filing["cid"],
        "cik": filing["cik"],
        "company": "",
        "ticker": "",
        "accession": filing["accession"],
        "form": filing["form"],
        "filed": filing["filed"],
        "event_date": filing["period"] or filing["filed"],
        "item_codes": "|".join(res["item_codes"]),
        "layoff_count_num": res["layoff_count_num"],
        "layoff_pct_num": res["layoff_pct_num"],
        "severance_amount": res["severance_amount"],
        "severance_currency": res["severance_currency"],
        "severance_usd": res["severance_usd"],
        "severance_raw": res["severance_raw"],
        "evidence_id": evid,
        "evidence": res["evidence"],
        "char_start": res["char_start"],
        "char_end": res["char_end"],
        "text_sha256": sha256_text(text),
        "confidence": res["confidence"],
        "extractor_version": "layoff8k-0.4",
        "measurement_evidence": json.dumps(res["measurement_evidence"], ensure_ascii=False),
        "event_date_basis": "filing_report_period_or_filed_proxy",
        "text_path": str(txt_path.relative_to(work)),
    }


# ---------------------------------------------------------------- WARN

def cmd_ingest_warn(args) -> int:
    work = Path(args.work)
    with Run(work, "ingest-warn", {"path": str(args.warn)}) as run:
        source = Path(args.warn)
        sources = sorted(source.glob("*.csv")) if source.is_dir() else [source]
        if not sources:
            raise SystemExit("WARN目录没有CSV文件")
        archived = work / "raw" / "warn"
        archived.mkdir(parents=True, exist_ok=True)
        rows = []
        for source_file in sources:
            target = archived / f"{sha256_file(source_file)[:12]}_{source_file.name}"
            if source_file.resolve() != target.resolve():
                shutil.copyfile(source_file, target)
            part = warn_mod.load_warn(target, state_hint=args.state or "")
            for row in part:
                row["source_file"] = str(target.relative_to(work))
            rows.extend(part)
            run.add_input(str(target.relative_to(work)))
        identities = {}
        for row in rows:
            prior = identities.setdefault(row["event_id"], row["content_sha256"])
            if prior != row["content_sha256"]:
                raise ValueError(f"不同 WARN 文件中的身份冲突: {row['event_id']}；请指定一致的当前快照")
        db = StateDB(work / "state" / "state.db")
        stats = warn_mod.crosswalk(rows, db.companies())
        db.close()
        n = events_mod.save(work / "events" / "warn_raw.csv", rows)
        merged = events_mod.merge(work)
        run.counts.update({"n_warn": n, "crosswalk": stats, "merged": merged})
        run.add_output("events/warn_raw.csv")
    print(f"WARN 记录 {n} 条，对齐研究名单 {stats['matched']} 条（未对齐 {stats['unmatched']}）")
    return 0


# ---------------------------------------------------------------- build

def cmd_build(args) -> int:
    work = Path(args.work)
    var_book = _load_var_book(work)
    years_arg = getattr(args, "years", "") or ""
    fy_window = _parse_years(years_arg) if years_arg else None
    with Run(work, "build", {"years": years_arg}) as run:
        db = StateDB(work / "state" / "state.db")
        companies = db.companies()
        filed_map = {f["accession"]: f["filed"] for f in db.filings(status=TaskStatus.PARSED)}
        stats = panel_mod.build(work, companies, var_book, filed_map, fy_window=fy_window)

        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        snap_dir = work / "panel" / "snapshots"
        snap_dir.mkdir(parents=True, exist_ok=True)
        snap = snap_dir / f"{stamp}.csv"
        shutil.copyfile(work / "panel" / "panel_wide.csv", snap)
        db.record_snapshot(
            snapshot_id=stamp,
            panel_path=str(snap.relative_to(work)),
            sha256=sha256_file(snap),
            n_rows=stats["n_wide_rows"],
        )
        db.set_kv("last_build", {"snapshot": stamp, "at": _now(), **stats})
        db.close()

        merged = events_mod.merge(work)
        run.counts.update(stats)
        for rel in ("config/companies.csv", "config/variable_book.csv", "config/varspec.yaml"):
            run.add_input(rel)
        run.counts["events"] = merged
        for rel in ("panel/panel_long.csv", "panel/panel_wide.csv",
                    "panel/evidence_long.csv", "panel/panel_meta.json"):
            run.add_output(rel)
    print(
        f"面板：{stats['n_wide_rows']} 个公司-年度观测，"
        f"{stats['n_evidence']} 条证据，快照 {stamp}"
    )
    return 0


def cmd_diff(args) -> int:
    work = Path(args.work)
    with Run(work, "diff", {}) as run:
        db = StateDB(work / "state" / "state.db")
        latest, prev = db.latest_snapshot(verified_only=True), db.previous_snapshot(verified_only=True)
        db.close()
        if not latest or not prev:
            print("快照不足两份，无法对比。请先多次运行 build（数据变化后）。")
            return 0
        revisions, summary = diff_mod.diff(work / prev["panel_path"], work / latest["panel_path"])
        out = diff_mod.write_revisions(work, revisions)
        run.counts.update({"n_revisions": len(revisions), "by_type": summary})
        run.add_output(str(out.relative_to(work)))
    print(f"修订 {len(revisions)} 处 {summary} -> {out.relative_to(work)}")
    return 0


def cmd_status(args) -> int:
    work = Path(args.work)
    db = StateDB(work / "state" / "state.db")
    counts = db.counts()
    snap = db.latest_snapshot()
    n_companies = len(db.companies())
    db.close()

    print(f"工作区: {work.resolve()}")
    print(f"公司数: {n_companies}")
    print("申报状态: " + (", ".join(f"{k}={v}" for k, v in counts.items()) or "尚无申报"))
    if snap:
        print(f"最新快照: {snap['snapshot_id']}  行数={snap['n_rows']}  {snap['panel_path']}")

    meta_path = work / "panel" / "panel_meta.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        print(f"面板覆盖: {meta['n_companies']} 家公司 / 年份 {meta['years']}")
        top = sorted(meta["var_stats"].items(), key=lambda kv: -kv[1]["fill_rate"])[:5]
        print("填充率最高的变量: " + ", ".join(f"{k}={v['fill_rate']:.0%}" for k, v in top))
        low = [k for k, v in meta["var_stats"].items() if v["fill_rate"] == 0]
        if low:
            print(f"完全未填充变量 {len(low)} 个（多为需质性编码项）")

    runs = sorted((work / "state" / "runs").glob("*.json"), reverse=True)[:5]
    if runs:
        print("最近运行:")
        for r in runs:
            payload = json.loads(r.read_text(encoding="utf-8"))
            print(f"  {payload['run_id']}  {payload['status']}  {payload.get('counts')}")
    return 0


def cmd_retry(args) -> int:
    work = Path(args.work)
    with StateDB(work / "state" / "state.db") as db:
        n = db.retry_failed()
    print(f"已重置 {n} 个失败任务为 pending")
    return 0


def cmd_verify(args) -> int:
    work = Path(args.work)
    with Run(work, "verify", {}) as run:
        report = verify_mod.verify(work, years=_parse_years(args.years) if args.years else None)
        out = work / "qa" / "qa_report.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        write_json(out, report)
        run.counts.update(report["summary"])
        if report["summary"].get("error"):
            run.status = "failed"
        elif (work / "panel" / "panel_wide.csv").is_file():
            with StateDB(work / "state" / "state.db") as db:
                db.verify_latest_snapshot(sha256_file(work / "panel" / "panel_wide.csv"))
        run.add_output("qa/qa_report.json")
    print(verify_mod.render(report))
    return 1 if report["summary"].get("error") else 0


def cmd_refresh(args) -> int:
    """One scheduler-safe update; never reinitialize or silently continue after failures."""
    import subprocess
    lock = Path(args.work) / "state" / "refresh.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        lock.mkdir()
    except FileExistsError:
        raise SystemExit(f"已有刷新任务或上次中断留下锁: {lock}；确认无任务运行后删除该空目录")
    try:
        commands = [["retry"], ["fetch", "--years", args.years], ["extract"],
                ["build", "--years", args.years], ["verify", "--years", args.years], ["diff"], ["audit", "--feature-only"]]
        if args.offline:
            commands[1] += ["--offline", args.offline]
        if args.force:
            commands[1].append("--force")
        for command in commands:
            result = subprocess.run([sys.executable, str(HERE), "--work", args.work] + command)
            if result.returncode:
                return result.returncode
        return 0
    finally:
        lock.rmdir()


def cmd_audit(args) -> int:
    from audit import main as audit_main
    options = ["--work", args.work]
    if args.feature_only:
        options.append("--feature-only")
    if args.research_dir:
        options += ["--research-dir", args.research_dir]
    return audit_main(options)


# ---------------------------------------------------------------- CLI

def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--work", default=argparse.SUPPRESS,
                        help="工作区目录（默认 ./work）")

    p = argparse.ArgumentParser(description="裁员与人力资本披露追踪")
    p.add_argument("--work", default="work", help="工作区目录（默认 ./work）")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init", parents=[common], help="初始化工作区")
    s.add_argument("--companies", default=str(ASSETS / "companies.csv"))
    s.set_defaults(func=cmd_init)

    s = sub.add_parser("fetch", parents=[common], help="枚举并下载申报")
    s.add_argument("--years", required=True, help="如 2019:2025")
    s.add_argument("--offline", help="离线 fixtures 目录")
    s.add_argument("--force", action="store_true",
                   help="重下已有原文及附件；索引和 facts 每次均刷新")
    s.set_defaults(func=cmd_fetch)

    s = sub.add_parser("refresh", parents=[common], help="增量抓取→抽取→构建→校验→差异，供调度器重复调用")
    s.add_argument("--years", required=True)
    s.add_argument("--offline")
    s.add_argument("--force", action="store_true")
    s.set_defaults(func=cmd_refresh)

    s = sub.add_parser("extract", parents=[common], help="解析原文并产出证据包")
    s.set_defaults(func=cmd_extract)

    s = sub.add_parser("ingest-warn", parents=[common], help="导入州 WARN 备案")
    s.add_argument("--warn", required=True, help="WARN CSV 文件或目录")
    s.add_argument("--state", default="", help="文件名未含州名时指定州代码")
    s.set_defaults(func=cmd_ingest_warn)

    s = sub.add_parser("build", parents=[common], help="构建面板与快照")
    s.add_argument("--years", default="", help="财年窗口，如 2019:2025；省略则使用全部已解析证据包")
    s.set_defaults(func=cmd_build)

    s = sub.add_parser("diff", parents=[common], help="对比最近两次快照")
    s.set_defaults(func=cmd_diff)

    s = sub.add_parser("status", parents=[common], help="查看状态")
    s.set_defaults(func=cmd_status)

    s = sub.add_parser("retry", parents=[common], help="重试失败任务")
    s.set_defaults(func=cmd_retry)

    s = sub.add_parser("verify", parents=[common], help="校验证据与状态")
    s.add_argument("--years", default="", help="财年窗口，如 2019:2025")
    s.set_defaults(func=cmd_verify)

    s = sub.add_parser("audit", parents=[common], help="检查要求变量、原文表示、未决事项和来源，完整性不足非零退出")
    s.add_argument("--feature-only", action="store_true", help="只检查旧特征视图；不宣称全部研究变量已提取")
    s.add_argument("--research-dir", help="review.py输出目录；默认work/review")
    s.set_defaults(func=cmd_audit)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not hasattr(args, "work"):
        args.work = "work"
    Path(args.work).mkdir(parents=True, exist_ok=True)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
