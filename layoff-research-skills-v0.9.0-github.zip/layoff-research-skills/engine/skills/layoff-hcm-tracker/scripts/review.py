#!/usr/bin/env python3
"""Review required variables against supplied reference workbooks and recover disclosures."""
from pathlib import Path
import argparse
import json
import hashlib
import sys
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parents[3] / "shared"))
sys.path.insert(0, str(HERE.parent))
from lib.reference_review import review

def main(argv=None):
    p = argparse.ArgumentParser(description="以参考工作簿审查变量、恢复原文与缺失字段，保留冲突和来源")
    p.add_argument("--work", required=True)
    p.add_argument("--references", nargs="*", default=[])
    p.add_argument("--result", help="要审查的现有结果xlsx；默认读取工作区panel_wide.csv")
    p.add_argument("--out", help="默认work/review，不改原结果工作簿或原面板")
    p.add_argument("--extra-documents", help="额外已下载申报的JSON清单，不自行联网")
    p.add_argument("--contract", default=str(HERE.parents[1] / "assets/research_contract.json"))
    p.add_argument("--strict", action="store_true", help="仍有待审候选、源缺失或未映射变量时非零退出")
    p.add_argument("--decisions", help="针对待审候选的JSON复核决定，绑定原始来源哈希")
    p.add_argument("--events-references", nargs="*", default=[], help="另行对账的新闻/人工事件工作簿，来源不冒充SEC")
    p.add_argument('--coder',help='从已审查编码回接原文证据；多编码者必须明确选择，单编码者可自动选择')
    a = p.parse_args(argv)
    if a.decisions:
        binding=Path(a.decisions).with_suffix('.preflight.json')
        if binding.is_file():
            proof=json.loads(binding.read_text())
            if not proof.get('pass')or proof.get('output_sha256')!=hashlib.sha256(Path(a.decisions).read_bytes()).hexdigest():
                raise ValueError('Decision binding failed or output changed; rerun decision_tools bind-source before review')
    contract = json.loads(Path(a.contract).read_text())
    extras = json.loads(Path(a.extra_documents).read_text()) if a.extra_documents else []
    decisions = json.loads(Path(a.decisions).read_text()) if a.decisions else []
    summary, *_ = review(a.work, a.out or str(Path(a.work) / "review"), contract,
        references=a.references, result=a.result, extras=extras, strict=a.strict, decisions=decisions,
        events_references=a.events_references, coding_coder=a.coder)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 2 if a.strict and not summary["strict_release_pass"] else 0

if __name__ == "__main__":
    raise SystemExit(main())
