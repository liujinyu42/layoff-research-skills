"""Read explicit-year SCT rows; never infer the CEO from row order or amount."""
import re
from datetime import date
from bs4 import BeautifulSoup

HEADERS = [(r"^salary", "salary"), (r"^bonus", "bonus"),
           (r"^stock awards", "stock_awards"), (r"^option awards", "option_awards"),
           (r"^non.equity", "non_equity"), (r"^(?:change in )?pension", "pension_change"),
           (r"^all other", "all_other"), (r"^total\b", "total")]

def clean(text):
    return re.sub(r"\s+", " ", text.replace("\u200b", "")).strip()

def amount(text):
    text = re.sub(r"\s*\(\d+\)\s*$", "", text).strip().replace("$", "").strip()
    if text in {"—", "–", "-"}:
        return 0.0  # A dash in an explicitly labelled SCT amount cell.
    if re.fullmatch(r"\(?-?\d[\d,]*(?:\.\d+)?\)?", text):
        return float(text.strip("()").replace(",", "")) * (-1 if text.startswith("(") else 1)
    return None

def extract_sct(html, fy):
    soup=BeautifulSoup(html,'lxml')
    for node in soup.find_all('sup'):node.decompose()
    for table in soup.find_all('table'):
        table_text=clean(table.get_text(' ',strip=True))
        if len(table_text)>30000 or not all(re.search(p,table_text,re.I)for p in [r'salary',r'stock awards',r'\byear\b',r'\btotal\b']):continue
        headers=[];groups=[];group=None
        role_start=r'(?i)^(?:former\s+)?(?:(?:co[- ]?)?chief\s+(?:executive|financial|operating|technology|engineering|legal|customer|people)|chair|president|vice\s+(?:president|chair)|executive\s+vice\s+president|(?:co[- ]?)?CEO\b|CFO\b|director\b)'
        for tr in table.find_all('tr'):
            cells=[clean(td.get_text(' ',strip=True))for td in tr.find_all(['th','td'],recursive=False)]
            cells=[c for c in cells if c and c!='$']
            if not headers:
                candidate=[key for cell in cells for pattern,key in HEADERS if re.search(pattern,cell,re.I)]
                if {'salary','stock_awards','total'}<=set(candidate)and len(candidate)==len(set(candidate)):headers=candidate
                continue
            year_at=next((i for i,c in enumerate(cells)if re.fullmatch(r'20\d{2}(?:\s*\(\d+\))?',c)),None)
            if year_at is None:
                label=clean(' '.join(cells))
                # Names and title continuations can occupy separate table rows.
                if label and len(label)<160 and not re.search(r'\d',label):
                    if re.match(role_start,label)and group is not None:
                        if label not in group['identity']:group['identity'].append(label)
                    elif re.fullmatch(r"[A-Z][A-Za-z.'’ -]+",label)and len(label.split())in range(2,7):
                        group={'identity':[label],'rows':[]};groups.append(group)
                continue
            label=clean(' '.join(cells[:year_at]))
            title_fragment=bool(re.match(role_start,label))
            if label:
                if group is None or not title_fragment:
                    group={'identity':[label],'rows':[]};groups.append(group)
                elif label not in group['identity']:group['identity'].append(label)
            if group is None:continue
            year=int(cells[year_at][:4]);values=[amount(c)for c in cells[year_at+1:]]
            if len(values)!=len(headers)or any(v is None for v in values):continue
            record={'fy':year,**dict(zip(headers,values))}
            record['component_sum']=sum(record.get(k,0)for _,k in HEADERS if k!='total')
            record['arithmetic_pass']=abs(record['component_sum']-record['total'])<=2
            record['quote']=clean(' '.join(cells));group['rows'].append(record)
        rows=[{**record,'name_title':clean(' '.join(g['identity']))}for g in groups for record in g['rows']if record['fy']==int(fy)]
        if rows:return {'rows':rows,'table_text':table_text}
    return {'rows':[],'table_text':''}


def identified_ceos(rows):
    # Identity is independent from the accounting-sum QA. A rejected current CEO
    # must not cause the former CEO to become the sole eligible observation.
    return [r for r in rows if re.search(r'chief executive|\bCEO\b',r['name_title'],re.I)]

def pay_ratio(text, fy):
    """CEO-to-median employee ratio, bound to an explicit compensation year."""
    found=[]
    headings=list(re.finditer(r"(?:CEO\s+)?Pay\s+Ratio(?:\s+Disclosure)?",text,re.I))
    for heading in headings:
        lo=heading.end(); scope=text[lo:lo+6000]
        patterns=[r"(?<![\d.,])([\d,]+(?:\.\d+)?)\s*(?:to|:|[-–—])\s*1(?!\d)(?!\.\d)",
                  r"(?<![\d.,])1\s*[- ]to[- ]\s*([\d,]+(?:\.\d+)?)(?!\d)(?!\.\d)"]
        for pattern in patterns:
            for match in re.finditer(pattern,scope,re.I):
                a=max(0,match.start()-1000); context=scope[a:match.end()]
                flat=clean(context)
                if not re.search(r"CEO|chief executive",flat,re.I) or not re.search(r"median\b.{0,250}\bemployees?\b",flat,re.I):
                    continue
                years=list(re.finditer(r"\b20\d{2}\b",context))
                if not years or int(years[-1].group())!=int(fy):continue
                value=float(match.group(1).replace(',',''))
                if value<=0:continue
                found.append({'value':value,'quote':context,'char_start':lo+a,'char_end':lo+match.end(),'reported_year':int(fy)})
    values={r['value']for r in found}
    return found[0]if len(values)==1 else{}

def proxy_metric(html,text,fy,var_id):
    """Typed proxy measures. A generic dollar or X:1 match is never a CEO fact."""
    if var_id=='pay_ratio':return pay_ratio(text,fy)
    if var_id!='ceo_total_comp':return{}
    from .inline_facts import numeric_facts
    identities=identified_ceos(extract_sct(html,fy)['rows'])
    if len(identities)>1:return {}
    facts=[f for f in numeric_facts(html)if f['tag'].lower()=='ecd:peototalcompamt'
           and f['end'][:4]==str(fy) and f.get('start') and 300 <= (date.fromisoformat(f['end'])-date.fromisoformat(f['start'])).days <= 430]
    values={f['value']for f in facts}
    if len(values)==1:
        value=next(iter(values));token=f'{value:,.0f}';pos=text.find(token)
        if pos>=0:return{'value':value,'quote':text[pos:pos+len(token)],'char_start':pos,'char_end':pos+len(token),'reported_year':int(fy),'tag':'ecd:PeoTotalCompAmt'}
    # Older proxies can be used only when the row itself identifies the chief executive.
    rows=extract_sct(html,fy)['rows'];ceo=identified_ceos(rows)
    if len(ceo)==1 and ceo[0]['arithmetic_pass']:
        value=ceo[0]['total'];token=f'{value:,.0f}';pos=text.find(token)
        if pos>=0:return{'value':value,'quote':text[pos:pos+len(token)],'char_start':pos,'char_end':pos+len(token),'reported_year':int(fy),'tag':'explicit CEO SCT row'}
    return{}

def ceo_amount_from_ratio(text,fy):
    proof=pay_ratio(text,fy)
    if not proof:return{}
    values={float(m.group(1).replace(',',''))for m in re.finditer(r'(?:annual\s+)?total\s+compensation\s+of\s+our\s+CEO\s+was\s*\$\s*([\d,]+)',proof['quote'],re.I)}
    if len(values)!=1 or re.search(r'annualiz|pro.forma',proof['quote'],re.I):return{}
    return {**proof,'value':next(iter(values))}
