"""年报（10-K / 20-F / DEF 14A）解析：文本落盘 → 章节定位 → 规则取数 → 单元格。

产出的 JSON 是"单份申报的证据包"：文本哈希、章节区间、每个单元格的取值与出处。
面板构建只读这些证据包，不重新解析原文。
"""

from __future__ import annotations

from pathlib import Path

from layoffcore.io import sha256_text
from layoffcore.schema import NA, VarSource
from layoffcore.textutil import SECTION_PATTERNS, html_to_text, locate_sections

from . import xbrl
from .rules import RuleSpec, apply_rule

FORM_ALIAS = {"10-K/A": "10-K", "20-F/A": "20-F", "DEF 14A/A": "DEF 14A"}


def normalize_form(form: str) -> str:
    return FORM_ALIAS.get(form, form)


def extract(
    *,
    html: str,
    form: str,
    cid: int,
    cik: str,
    fy: int,
    accession: str,
    var_book: list[dict],
    spec: dict[str, RuleSpec],
    facts: dict | None = None,
    period: str = "",
) -> dict:
    from bs4 import BeautifulSoup
    # Prefer the registrant's explicit fiscal label over a calendar heuristic.
    soup = BeautifulSoup(html, "html.parser")
    for node in soup.find_all(attrs={"name": True}):
        name = str(node.get("name", "")).lower()
        if name == "dei:documentfiscalyearfocus" and node.get_text(strip=True).isdigit():
            fy = int(node.get_text(strip=True))
        elif name == "dei:documentperiodenddate":
            candidate = node.get_text(strip=True)
            if len(candidate) == 10 and candidate[4] == "-":
                period = candidate
    base_form = normalize_form(form)
    text = html_to_text(html)
    sections = locate_sections(text, base_form)
    known_sections = set(SECTION_PATTERNS.get(base_form, {}).keys())
    xbrl_cells = xbrl.derive_cells(facts or {}, fy, accession=accession, period=period)

    cells: list[dict] = []
    for var in var_book:
        var_id = var["var_id"]
        source = var["source_type"]

        if source == VarSource.XBRL.value:
            xc = xbrl_cells.get(var_id)
            if xc is None:
                cells.append(_cell(var_id, None, "num", NA.NOT_SEPARATE.value, "", source))
                continue
            cells.append(
                {
                    "var_id": var_id,
                    "value": xc["value"],
                    "value_type": "num",
                    "unit": xc["unit"],
                    "currency": xbrl.unit_currency(xc["unit"]),
                    "na_code": xc["na_code"],
                    "source_type": "xbrl",
                    "section": "8",
                    "char_start": None,
                    "char_end": None,
                    "quote": xc["tag"],
                    "value_raw": xc["tag"],
                    "confidence": xc["confidence"],
                    "extractor": "xbrl",
                    "evidence_accession": xc["accession"] or accession,
                }
            )
            continue

        if source == VarSource.CODE.value:
            cells.append(_cell(var_id, None, "code", NA.REQUIRES_CODING.value, "", source))
            continue

        if var_id not in spec:
            # 声明为 rule 但没有对应规格：这是配置缺口，不是"未披露"
            cells.append(_cell(var_id, None, "num", NA.EXTRACTION_ERROR.value, "", source))
            continue

        if var_id in {'ceo_total_comp','pay_ratio'}:
            from .compensation_tables import proxy_metric
            metric=proxy_metric(html,text,fy,var_id) if base_form=='DEF 14A' else {}
            if metric:
                cells.append({**_cell(var_id,metric['value'],'num','','11','text'),
                    'unit':'ratio' if var_id=='pay_ratio' else 'USD',
                    'currency':'UNKNOWN' if var_id=='pay_ratio' else 'USD',
                    'quote':metric['quote'],'char_start':metric['char_start'],'char_end':metric['char_end'],
                    'value_raw':metric.get('tag','CEO/median explicit-year ratio'),'confidence':'high',
                    'extractor':'typed_proxy_explicit_year','value_detail':'ratio' if var_id=='pay_ratio' else 'amount'})
            else:
                cells.append(_cell(var_id,None,'num',NA.NOT_CHECKED.value,'11','text'))
            continue
        rule = spec[var_id]
        res = apply_rule(rule, sections, text, known_sections, fy=fy)
        value_type = "flag" if rule.type in ("flag", "hits") else "num"
        cells.append(
            {
                "var_id": var_id,
                "value": res.value,
                "value_type": value_type,
                "unit": res.unit,
                "currency": res.currency,
                "na_code": res.na_code,
                "source_type": "text",
                "section": res.section,
                "char_start": res.char_start,
                "char_end": res.char_end,
                "quote": res.quote,
                "value_raw": res.value_raw,
                "confidence": res.confidence,
                "extractor": rule.extractor,
                "value_detail": rule.type,
            }
        )

    return {
        "accession": accession,
        "cid": cid,
        "cik": cik,
        "fy": fy,
        "period": period,
        "form": form,
        "base_form": base_form,
        "text": text,
        "text_sha256": sha256_text(text),
        "sections": {k: [s.start, s.end] for k, s in sections.items()},
        "section_titles": {k: s.title for k, s in sections.items()},
        "cells": cells,
        "n_chars": len(text),
        "n_sections": len(sections),
    }


def _cell(var_id: str, value, value_type: str, na_code: str, section: str, source: str) -> dict:
    return {
        "var_id": var_id,
        "value": value,
        "value_type": value_type,
        "unit": "",
        "currency": "UNKNOWN",
        "na_code": na_code,
        "source_type": source,
        "section": section,
        "char_start": None,
        "char_end": None,
        "quote": "",
        "value_raw": "",
        "confidence": "low",
        "extractor": "none",
    }


def save_package(work: Path, package: dict) -> tuple[Path, Path]:
    """落盘：纯文本 + 证据包。文本单独存，保证偏移可复现。"""
    from layoffcore.io import write_json

    text_dir = work / "derived" / "texts"
    text_dir.mkdir(parents=True, exist_ok=True)
    text_path = text_dir / f"{package['cik']}_{package['fy']}_{package['accession']}.txt"
    text_path.write_text(package["text"], encoding="utf-8")

    pkg = dict(package)
    pkg.pop("text", None)
    pkg["text_path"] = str(text_path.relative_to(work))

    cells_dir = work / "derived" / "cells"
    cells_dir.mkdir(parents=True, exist_ok=True)
    cell_path = cells_dir / f"{package['accession']}.json"
    write_json(cell_path, pkg)
    return text_path, cell_path
