"""事件存储：SEC 披露事件与 WARN 通知分开存放，合并时保留 source 区分。

不合并的理由：两者粒度不同（accession vs 州通知）、覆盖总体不同（上市公司 vs 全部雇主），
一旦混在一张表里，任何"事件数"都会被重复计数污染。
"""

from __future__ import annotations

from pathlib import Path

from layoffcore.io import read_csv, write_csv
from layoffcore.schema import EVENT_COLUMNS

EXTRA_COLUMNS = [
    "char_start", "char_end", "text_sha256", "content_sha256", "source_row", "notice_id", "address",
    "text_path",
    "state",
    "city",
    "county",
    "notice_type",
    "source_url",
    "source_file",
    "match_confidence",
    "measurement_evidence",
    "event_date_basis",
]
ALL_COLUMNS = EVENT_COLUMNS + EXTRA_COLUMNS


def save(path: Path, rows: list[dict]) -> int:
    seen: dict[str, dict] = {}
    for r in rows:
        seen[r["event_id"]] = r
    ordered = sorted(seen.values(), key=lambda r: (r.get("source", ""), r.get("filed") or ""))
    write_csv(path, ordered, ALL_COLUMNS)
    return len(ordered)


def load(path: Path) -> list[dict]:
    return read_csv(path)


def merge(work: Path) -> dict:
    """合并两个来源，写出对外事件表。"""
    sec_rows = load(work / "events" / "sec_events.csv")
    warn_rows = load(work / "events" / "warn_raw.csv")
    total = save(work / "events" / "layoff_disclosures.csv", sec_rows + warn_rows)
    return {
        "n_sec": len(sec_rows),
        "n_warn": len(warn_rows),
        "n_total": total,
    }
