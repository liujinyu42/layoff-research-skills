"""Explicit accounting compositions and statement rows; no nearest-tag fills."""
import datetime as dt
import json
import re

from bs4 import BeautifulSoup
from . import xbrl


def debt_total(facts, fy, accession, period):
    def fact(tag):
        v, u, a, t = xbrl.value_for_year(facts, [tag], fy, accession=accession, period=period)
        return None if v is None else {'tag': tag, 'value': v, 'unit': u}
    current, noncurrent = fact('LongTermDebtCurrent'), fact('LongTermDebtNoncurrent')
    if current is None or noncurrent is None:
        return {}
    short, paper = fact('ShortTermBorrowings'), fact('CommercialPaper')
    # ShortTermBorrowings is an aggregate: never add its CommercialPaper component again.
    if short is not None:
        if paper is not None and (paper['unit'] != short['unit'] or paper['value'] > short['value']):
            return {}
        short_component = short
    elif paper is not None:
        short_component = paper
    else:
        return {}  # Missing short-term facts are not proof of zero short-term debt.
    parts = [current, noncurrent, short_component]
    if len({x['unit'] for x in parts}) != 1 or any(x['value'] < 0 for x in parts):
        return {}
    return {'value': sum(x['value'] for x in parts), 'unit': parts[0]['unit'],
            'accession': accession, 'period': period,
            'tag': '+'.join(x['tag'] for x in parts),
            'components': json.dumps(parts, sort_keys=True),
            'measurement_scope': 'interest-bearing current and noncurrent debt plus short-term borrowings; leases excluded',
            'method': 'same_context_debt_components_including_short_term'}


def statement_intangibles(html, fy, expected_total_assets=None):
    """Only the explicit net-intangibles statement total, with year and scale."""
    soup = BeautifulSoup(html, 'lxml')
    for table in soup.find_all('table'):
        text = table.get_text(' ', strip=True)
        if not (re.search(r'(?i)total\s+assets', text) and re.search(r'(?i)liabilit', text)):
            continue
        scale_text = text[:1200]
        if not re.search(r'(?i)in\s+millions', scale_text):
            previous = table.find_previous(['p', 'div'])
            scale_text = (previous.get_text(' ', strip=True)[-300:] if previous else '') + scale_text
        scale = 1e6 if re.search(r'(?i)in\s+millions', scale_text) else 1e3 if re.search(r'(?i)in\s+thousands', scale_text) else None
        # When the print unit is outside the table, establish it only by
        # reconciling this exact statement/year Total assets to the same-accession fact.
        scale_basis='explicit_printed_unit' if scale is not None else ''
        if scale is None and expected_total_assets is not None:
            preceding=[]
            for tr in table.find_all('tr'):
                line=tr.get_text(' ',strip=True)
                if re.match(r'(?i)^total\s+assets\b',line):
                    years=list(dict.fromkeys(re.findall(r'\b20\d{2}\b',' '.join(preceding[:12]))))
                    tokens=re.findall(r'\d[\d,]*(?:\.\d+)?',re.sub(r'(?i)^total\s+assets\b','',' '.join(line.split())))
                    if str(fy)in years and len(tokens)==len(years):
                        raw=float(tokens[years.index(str(fy))].replace(',',''))
                        possible=[m for m in [1,1e3,1e6] if raw and abs(raw*m-float(expected_total_assets))<=max(.01,abs(float(expected_total_assets))*1e-10)]
                        if len(possible)==1:scale=possible[0];scale_basis='same_accession_year_total_assets_reconciliation'
                    break
                preceding.append(line)
        if scale is None:continue
        headers = []
        for tr in table.find_all('tr'):
            line = tr.get_text(' ', strip=True)
            if re.match(r'(?i)^intangible\s+assets,?\s+net\b', line):
                years = list(dict.fromkeys(re.findall(r'\b20\d{2}\b', ' '.join(headers))))
                numbers = re.findall(r'\(?\d[\d,]*(?:\.\d+)?\)?|[—–]', re.sub(r'(?i)^intangible\s+assets,?\s+net\b', '', line))
                if str(fy) not in years or len(numbers) != len(years):
                    continue
                token = numbers[years.index(str(fy))]
                if token in {'—', '–'}:
                    continue
                value = float(token.replace(',', '').strip('()')) * (-1 if token.startswith('(') else 1) * scale
                if value < 0:
                    continue
                return {'value': value, 'tag': 'balance_sheet:Intangible assets, net',
                        'quote': line, 'table_header': ' '.join(headers)[-600:],
                        'measurement_scope': 'balance sheet net intangible assets excluding separately stated goodwill',
                        'scale_basis':scale_basis, 'method': 'balance_sheet_total_explicit_year_and_scale'}
            headers.append(line)
    return {}


def severance_records(text, fy, fiscal_end, section_start=0, section_end=None):
    """Reported expenses, including subperiods; never silently annualize a quarter."""
    section_end = section_end or len(text)
    amount = r'(?:US\$|\$)\s*(\d[\d,.]*)\s*(million|billion|thousand)'
    rx = re.compile(amount + r'\s+(?:of\s+)?employee\s+severance\s+(?:expenses?|costs?)', re.I)
    rows = []
    for m in rx.finditer(text, section_start, section_end):
        start = max(section_start, text.rfind('.', max(section_start, m.start()-650), m.start())+1)
        end = text.find('.', m.end(), min(section_end, m.end()+400))
        end = end+1 if end >= 0 else min(section_end, m.end()+220)
        quote = text[start:end].strip(); start = text.find(quote, start, end)
        before = text[max(section_start, start-180):m.start()]
        if not re.search(r'(?i)recorded|recognized|incurred|charge|expense',before):
            continue  # Cash settlements and payments are not expense recognition.
        dates = list(re.finditer(r'(?i)(?:three|six|nine|twelve)\s+months\s+ended\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),?\s+(20\d{2})', before))
        period = ''; scope = 'period_binding_required'; status = 'numeric_period_needs_review'
        if dates:
            d = dates[-1]
            period = dt.datetime.strptime(' '.join(d.groups()), '%B %d %Y').date().isoformat()
            end_date = dt.date.fromisoformat(fiscal_end)
            try: lower = end_date.replace(year=end_date.year-1)
            except ValueError: lower = end_date.replace(year=end_date.year-1, day=28)
            if not lower < dt.date.fromisoformat(period) <= end_date:
                continue
            scope = 'reported subperiod expense in fiscal year; not certified annual total'
        elif re.search(rf'(?i)(?:fiscal\s+year|year\s+ended).{{0,45}}\b{fy}\b', before):
            period = fiscal_end; scope = 'explicit annual expense'; status = 'primary_source_verified'
        else:
            continue
        value = float(m[1].replace(',', '')) * {'thousand':1e3, 'million':1e6, 'billion':1e9}[m[2].lower()]
        rows.append({'value': value, 'unit': 'USD', 'period': period, 'fy': fy,
                     'quote': quote, 'char_start': start, 'char_end': start+len(quote),
                     'expense_nature': 'employee_severance_expense', 'measurement_scope': scope,
                     'status': status, 'method': 'explicit_severance_expense_with_period'})
    return rows
