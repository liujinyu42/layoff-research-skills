"""规则引擎：把 varspec.yaml 施加到章节文本上，产出带证据的单元格。

取值口径（重要，写在契约里）：
- ``flag`` / ``hits``：章节存在即视为观测成功，未命中记 0，不记缺失；
- ``count`` / ``pct`` / ``amount`` / ``ratio``：未命中记 ``not_disclosed``；
- 章节全部缺失：记 ``extraction_error``，绝不当作"未披露"；
- 同一变量出现多个不同候选：取首个，置信度降为 low，原文留在 ``value_raw``。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from functools import lru_cache
from bisect import bisect_left

import yaml

from layoffcore.numbers import parse_amount, parse_count, parse_pct
from layoffcore.schema import NA
from layoffcore.textutil import Section

MAX_QUOTE = 600
CONTEXT_WINDOW = 200


@dataclass
class RuleSpec:
    var_id: str
    type: str
    sections: list[str] = field(default_factory=list)
    patterns: list[str] = field(default_factory=list)
    any: list[str] = field(default_factory=list)
    reject: list[str] = field(default_factory=list)
    # 连续量取值时的优先语境：命中这些模式的候选排在前（仍按位置取首个）
    prefer_context: list[str] = field(default_factory=list)
    # v0.3.1：句级否决。reject 用 ±200 字符窗口，容易误伤同段落的正确候选；
    # reject_sentence 只在候选所在句内匹配，用于"分项金额"这类需要精确语境的排除。
    reject_sentence: list[str] = field(default_factory=list)
    # v0.3.1：更宽的否决窗口（±320 字符）。用于"遣散费只是某条费用科目的变动
    # 动因"这类跨越较长从句的表述，句子本身常因超长被截断而匹配不到。
    reject_near: list[str] = field(default_factory=list)
    # v0.3.1：期间感知。开启后，候选句若出现与当前财年不同的四位年份即否决，
    # 含当前财年年份的候选提优先级。用于杜绝"把上年比较数记入本年"。
    period_aware: bool = False
    bounds: list[float] | None = None
    extractor: str = "rule"

    @property
    def patterns_all(self) -> list[str]:
        return list(self.patterns) + list(self.any)


@dataclass
class CellResult:
    var_id: str
    value: Any
    na_code: str
    section: str = ""
    char_start: int | None = None
    char_end: int | None = None
    quote: str = ""
    value_raw: str = ""
    unit: str = ""
    currency: str = "UNKNOWN"
    confidence: str = "high"


def load_varspec(path: str | Path) -> dict[str, RuleSpec]:
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
    out: dict[str, RuleSpec] = {}
    for var_id, cfg in (payload.get("vars") or {}).items():
        out[var_id] = RuleSpec(
            var_id=var_id,
            type=cfg.get("type", "flag"),
            sections=[str(s) for s in cfg.get("sections", [])],
            patterns=cfg.get("patterns", []) or [],
            any=cfg.get("any", []) or [],
            reject=cfg.get("reject", []) or [],
            prefer_context=cfg.get("prefer_context", []) or [],
            reject_sentence=cfg.get("reject_sentence", []) or [],
            reject_near=cfg.get("reject_near", []) or [],
            period_aware=bool(cfg.get("period_aware", False)),
            bounds=cfg.get("bounds"),
            extractor=cfg.get("extractor", "rule"),
        )
    return out


@lru_cache(maxsize=4)
def _boundaries(text):
    import re
    return tuple(m.start() for m in re.finditer(r"(?<!\d)[.!?](?=\s|$)|(?<=\d)[.!?](?!\d)(?=\s|$)", text))


def _sentence_span(text: str, pos: int) -> tuple[int, int]:
    # A decimal point inside $1.20 is not a sentence boundary.
    boundaries = _boundaries(text)
    index = bisect_left(boundaries, pos)
    start = boundaries[index - 1] if index else -1
    start = 0 if start == -1 else start + 1
    end = boundaries[index] if index < len(boundaries) else -1
    end = len(text) if end == -1 else end + 1
    if end - start > MAX_QUOTE:
        start = max(start, pos - MAX_QUOTE // 2)
        end = min(end, pos + MAX_QUOTE // 2)
    while start < pos and text[start] in " \n\t":
        start += 1
    return start, end


def _rejected(text: str, pos: int, rejects: list[str], width: int | None = None) -> bool:
    import re

    w = width or CONTEXT_WINDOW
    lo = max(0, pos - w)
    hi = min(len(text), pos + w)
    window = text[lo:hi]
    return any(re.search(rx, window, re.I) for rx in rejects)


def _in_bounds(value: float, bounds: list[float] | None) -> bool:
    if bounds is None:
        return True
    return bounds[0] <= value <= bounds[1]


YEAR_RX = r"\b(?:19|20)\d{2}\b"


def _years_in(sentence: str) -> set[int]:
    import re

    return {int(y) for y in re.findall(YEAR_RX, sentence)}


# v0.3.1：明确的期间短语，如 "In the year ended December 31, 2023"、
# "for the second quarter of 2023"、"for fiscal 2022"。
_PERIOD_PHRASE_RX = (
    r"(?:(?:in|for|during|of)\s+(?:the\s+)?(?:fiscal\s+)?"
    r"(?:(?:first|second|third|fourth|[1-4](?:st|nd|rd|th))\s+)?"
    r"(?:year|years|quarter|quarters|three\s+months|six\s+months|nine\s+months|"
    r"twelve\s+months|period)\b[^.;]{0,80}?"
    r"|(?:the\s+)?same\s+(?:period|quarter|year)[^.;]{0,20}?)"
    r"((?:19|20)\d{2})"
)


def _period_year_near(text: str, pos: int, sentence: str) -> int | None:
    """判断数值属于哪个期间。

    不能只看整句：年报的表格文本没有句号，"Years ended December 31, 2024 2023
    2022 ... (3) In the year ended December 31, 2023, we had $148 million ..."
    会被当成一句，句中出现本期年份就把上年比较数当成本期数。

    因此先看数值前 220 字符内最近的期间短语，只有找不到时才退回"整句仅含一个
    年份"的情形。
    """
    import re

    boundaries = _boundaries(text)
    index = bisect_left(boundaries, pos)
    start = boundaries[index - 1] + 1 if index else 0
    end = boundaries[index] + 1 if index < len(boundaries) else len(text)
    current = text[start:end]
    hits = [(m.start() + start, m) for m in re.finditer(_PERIOD_PHRASE_RX, current, re.I)]
    if hits:
        _, best = min(hits, key=lambda h: abs(h[0] - pos))
        return int(best.group(1))
    years = _years_in(current)
    if len(years) == 1:
        return next(iter(years))
    if len(years) > 1:
        return None
    # Anaphoric expense sentences inherit the preceding action's period only.
    # Never attach the next paragraph's year to a prior comparative amount.
    if re.match(r'\s*(?:As a result|In connection with|This (?:restructuring|reduction|action)|These (?:actions|expenses|costs))\b', current, re.I):
        before = text[max(0, start - 320):start]
        prior = list(re.finditer(_PERIOD_PHRASE_RX, before, re.I))
        if prior:
            return int(prior[-1].group(1))
    return None



def apply_rule(spec: RuleSpec, sections: dict[str, Section], text: str,
               known_sections: set[str] | None = None,
               fy: int | None = None) -> CellResult:
    import re

    if not spec.sections:
        return CellResult(spec.var_id, None, NA.NOT_SEPARATE.value)

    # 该表单根本不定义这个章节（例如 10-K 没有 Item 11）→ 未单列，不是提取失败
    if known_sections is not None and not (set(spec.sections) & known_sections):
        return CellResult(spec.var_id, None, NA.NOT_SEPARATE.value)

    present = [(k, sections[k]) for k in spec.sections if k in sections]
    if not present:
        return CellResult(spec.var_id, None, NA.EXTRACTION_ERROR.value)

    if spec.type in ("flag", "hits"):
        total = 0
        first_span: tuple[str, int, int] | None = None
        for key, sec in present:
            seen: set[int] = set()
            for rx in spec.patterns_all:
                for m in re.finditer(rx, sec.text, re.I):
                    if m.start() in seen:
                        continue
                    seen.add(m.start())
                    abs_pos = sec.start + m.start()
                    if _rejected(text, abs_pos, spec.reject):
                        continue
                    if spec.reject_sentence:
                        _s, _e = _sentence_span(text, abs_pos)
                        if any(re.search(rx, text[_s:_e], re.I) for rx in spec.reject_sentence):
                            continue
                    total += 1
                    if first_span is None:
                        s, e = _sentence_span(text, abs_pos)
                        first_span = (key, s, e)
                if spec.type == "flag" and total:
                    break
            if spec.type == "flag" and total:
                break

        value = 1 if spec.type == "flag" and total else (total if spec.type == "hits" else 0)
        if spec.type == "hits":
            value = min(total, 50)
        if first_span is None:
            # Zero means no rule match in the scanned sections, not semantic absence.
            # The span records the searched source scope and is reproducible even for zero.
            key, sec = present[0]
            return CellResult(spec.var_id, value, "", section=key, confidence="medium",
                              char_start=sec.start, char_end=sec.end,
                              quote=text[sec.start:sec.end][:MAX_QUOTE],
                              value_raw="no rule match; scanned sections=" + "|".join(k for k, _ in present))
        key, s, e = first_span
        return CellResult(
            spec.var_id, value, "", section=key, char_start=s, char_end=e,
            quote=text[s:e], value_raw=text[s:e][:120], confidence="high",
        )

    if spec.var_id == 'headcount':
        for key,sec in present:
            stock=re.search(r'(?is)workforce,?\s*(?:which\s+)?(?:was|is)\s+(?:comprised|composed)\s+of\s*(\d[\d,]*)\s*(?:\n+\d{1,2}\s*\n+)?(?:people|employees)\s+as\s+of\s+\w+\s+\d{1,2},\s*(20\d{2})',sec.text)
            if stock and (fy is None or int(stock.group(2))==fy):
                value=int(stock.group(1).replace(',',''))
                if _in_bounds(value,spec.bounds):
                    start=sec.start+stock.start();end=sec.start+stock.end()
                    return CellResult(spec.var_id,value,'',unit='employees',section=key,char_start=start,char_end=end,quote=text[start:end],value_raw=stock.group(1),confidence='high')
            table=re.search(r'(?is)employees\s+are\s+summarized\s+as\s+follows.{0,1500}',sec.text)
            if not table: continue
            fragment=table.group(0)
            years=set(re.findall(r'\b20\d{2}\b',fragment[:160]))
            totals=list(re.finditer(r'(?im)^Total\s*\n+\s*([\d,]+)\b',fragment))
            values={int(m.group(1).replace(',','')) for m in totals}
            if len(values)==1 and (fy is None or years=={str(fy)}):
                value=next(iter(values))
                if _in_bounds(value,spec.bounds):
                    start=sec.start+table.start();end=start+totals[0].end()
                    return CellResult(spec.var_id,value,'',unit='employees',section=key,char_start=start,char_end=end,quote=text[start:end],value_raw=totals[0].group(0),confidence='high')

    # ---------------- 连续量 ----------------
    # rank: 0 = 句子命中 prefer_context（如 "we employed …"），1 = 其余
    candidates: list[tuple[int, float, str, int, int, str, str, str]] = []
    rejected_period: list[str] = []
    rejected_component: list[str] = []
    rejected_ambiguous: list[str] = []
    for key, sec in present:
        for rx in spec.patterns_all:
            for m in re.finditer(rx, sec.text, re.I):
                abs_pos = sec.start + m.start()
                if _rejected(text, abs_pos, spec.reject):
                    continue
                span = m.group(0)
                if spec.var_id == "severance":
                    money = re.search(r'(?:US\$|\$|€|£)\s*\d[\d,.]*\s*(?:million|billion|thousand)', span, re.I)
                    if money:
                        tail = text[abs_pos + money.end():abs_pos + money.end() + 150]
                        if re.match(r'\s*(?:(?:of|in)\s+)?(?:pre[-\s]?tax\s+)?(?:severance(?:\s+and\s+related\s+personnel)?(?:\s+(?:costs?|expenses?|charges?))?\s+)?(?:in|for|allocated\s+to|included\s+in)\s+(?:sales|marketing|research|general|cost\s+of)', tail, re.I):
                            rejected_component.append(tail)
                            continue
                value, unit, currency, raw = _parse_by_type(spec.type, span)
                if value is None or not _in_bounds(value, spec.bounds):
                    continue
                s, e = _sentence_span(text, abs_pos)
                sentence = text[s:e]
                if spec.reject_sentence and any(
                    re.search(rx, sentence, re.I) for rx in spec.reject_sentence
                ):
                    rejected_component.append(sentence[:160])
                    continue
                if spec.reject_near and _rejected(text, abs_pos, spec.reject_near, width=420):
                    # 宽窗否决同属"只找到分项/动因金额"，写进同一类缺失原因，
                    # 不冒充 not_disclosed。
                    rejected_component.append(sentence[:160])
                    continue
                # A workforce percentage or change is never the stock of employees.
                if spec.var_id == 'headcount':
                    numeric=re.search(r"\d[\d,]*(?:\.\d+)?",span)
                    tail=text[abs_pos+numeric.end():abs_pos+numeric.end()+30] if numeric else ''
                    if re.match(r"\s*(?:%|percent\b)",tail,re.I):continue
                # Headcount is the registrant's employed stock, not people trained/served.
                if spec.var_id == 'headcount':
                    if re.search(r'(?:sales\s+and\s+marketing|research\s+and\s+development|engineering|customer\s+support)\s+(?:functions?|teams?|staff|personnel)',sentence,re.I):
                        rejected_component.append(sentence[:160]);continue
                    at = sec.start + m.start()
                    prefix = text[max(sec.start, at - 110):at]
                    external = re.search(r'(?:help(?:ed|ing)?|train(?:ed|ing)?|reach(?:ed|ing)?|serv(?:ed|ing)|support(?:ed|ing)?|educat(?:ed|ing)|empower(?:ed|ing))\b', prefix, re.I)
                    employed = re.search(r'\b(?:we\s+(?:had|have|employ(?:ed)?|currently\s+employ)|our\s+(?:global\s+)?workforce|employee\s+headcount|full[- ]time\s+equivalent\s+employees)', sentence, re.I)
                    if external and not employed:
                        continue
                rank = 1
                if spec.period_aware and fy is not None:
                    py = _period_year_near(text, abs_pos, sentence)
                    if py is not None and py != fy:
                        # 数值属于更早的期间（典型：年报中的上年比较列）。
                        rejected_period.append(sentence[:160])
                        continue
                    if py is None and len(_years_in(sentence)) > 1:
                        rejected_ambiguous.append(sentence[:160])
                        continue
                    if py == fy:
                        rank = -1
                if spec.prefer_context:
                    if any(re.search(rx2, sentence, re.I) for rx2 in spec.prefer_context):
                        rank = min(rank, 0)
                if spec.var_id == 'headcount' and employed:
                    rank -= 10  # Ownership/employment outranks a date-only target population.
                candidates.append((rank, value, key, s, e, span, unit, currency))
        if candidates:
            break

    if not candidates:
        # v0.3.1：把"为什么空"写清楚，避免期间错配/分项金额被误读成"未披露"
        if rejected_period:
            return CellResult(spec.var_id, None, NA.PERIOD_MISMATCH.value,
                              section=present[0][0], confidence="low",
                              value_raw="only candidates from other fiscal years: "
                                        + rejected_period[0])
        if rejected_component:
            return CellResult(spec.var_id, None, NA.COMPONENT_ONLY.value,
                              section=present[0][0], confidence="low",
                              value_raw="only component-level amounts: " + rejected_component[0])
        if rejected_ambiguous:
            return CellResult(spec.var_id, None, NA.AMBIGUOUS_PERIOD.value,
                              section=present[0][0], confidence="low",
                              value_raw="multiple years without amount-column binding: " + rejected_ambiguous[0])
        return CellResult(spec.var_id, None, NA.NOT_DISCLOSED.value, section=present[0][0])

    # 先按语境优先，再按出现位置；不因后面出现不同数字而改选更晚的候选
    candidates.sort(key=lambda c: (c[0], c[3]))
    rank, value, key, s, e, span, unit, currency = candidates[0]
    distinct = {round(c[1], 6) for c in candidates}
    confidence = "high" if len(distinct) == 1 else "low"
    raw = span if len(distinct) == 1 else " | ".join(c[5] for c in candidates[:3])
    return CellResult(
        spec.var_id, _clean(value), "", section=key, char_start=s, char_end=e,
        quote=text[s:e], value_raw=raw[:MAX_QUOTE], unit=unit, currency=currency,
        confidence=confidence,
    )


def _parse_by_type(kind: str, span: str) -> tuple[float | None, str, str, str]:
    if kind == "count":
        v, raw = parse_count(span)
        import re
        count_unit = "FTE" if re.search(r"full[-\s]?time\s+equivalent", span, re.I) else "employees"
        if v is None:
            # 2026-10-26 本地补丁：某些期末人数表述把名词放在数字之前，
            # 例如 "Headcount was 86,482 as of December 31, 2022" 或
            # "our full-time count ... was 70,757"。parse_count 要求
            # "数字+员工名词" 同现，会把这类正确候选丢弃，回退到
            # 次优候选（如裁员公告人数）。此处仅在片段含人数语境词时
            # 取第一个数字，仍受 bounds 与 reject 约束。
            import re as _re

            if _re.search(r"headcount|workforce|full[-\s]?time\s+count|"
                          r"employee\s+count|employees|associates", span, _re.I):
                m = _re.search(r"(\d[\d,]*(?:\.\d+)?)", span)
                if m:
                    return float(m.group(1).replace(",", "")), count_unit, "UNKNOWN", m.group(0)
        return (float(v) if v is not None else None), count_unit, "UNKNOWN", raw
    if kind == "pct":
        v, raw = parse_pct(span)
        if v is None:
            import re

            m = re.search(r"([\d.]+)\s*(?:%|percent)", span)
            v = float(m.group(1)) if m else None
            raw = m.group(0) if m else ""
        return v, "percent", "UNKNOWN", raw
    if kind == "amount":
        v, ccy, raw = parse_amount(span)
        return v, "currency", ccy, raw
    if kind == "ratio":
        import re

        m = re.search(r"([\d,]+(?:\.\d+)?)\s*(?:to|:)\s*1", span)
        if not m:
            return None, "ratio", "UNKNOWN", ""
        return float(m.group(1).replace(",", "")), "ratio", "UNKNOWN", m.group(0)
    return None, "", "UNKNOWN", ""


def _clean(value: float) -> float | int:
    return int(value) if float(value).is_integer() else round(float(value), 4)
