"""Reference-led variable coverage review and evidence-preserving recovery.

The 71-feature view is not a full disclosure dataset.  This module retains the
reference's text/value representation and never substitutes keyword counts for it.
Provided references are inputs, not instructions, and conflicting values remain visible.
"""
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime, timezone
import csv
import hashlib
import json
import math
import re
import sqlite3
import unicodedata

from layoffcore.schema import TOOL_VERSION
from layoffcore.io import read_csv, write_csv, write_json
from layoffcore.textutil import html_to_text, locate_sections
from . import xbrl
from .inline_facts import numeric_facts
from .compensation_tables import extract_sct, pay_ratio

EXTRA_TAGS = {
    "interest_expense": ["InterestExpenseNonOperating", "InterestAndDebtExpense", "InterestExpenseDebt", "InterestExpense"],
    "tax_expense": ["IncomeTaxExpenseBenefit"],
    "total_equity": ["StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"],
    "cash_and_equivalents": ["CashAndCashEquivalentsAtCarryingValue"],
    "receivables": ["AccountsReceivableNetCurrent", "AccountsNotesAndOtherReceivablesNetCurrent", "AccountsReceivableNet"],
    "ppe_net": ["PropertyPlantAndEquipmentNet"], "goodwill": ["Goodwill"],
    "operating_cash_flow": ["NetCashProvidedByUsedInOperatingActivities"],
    "investing_cash_flow": ["NetCashProvidedByUsedInInvestingActivities"],
    "financing_cash_flow": ["NetCashProvidedByUsedInFinancingActivities"],
    "accrued_restructuring_liability": ["RestructuringReserve", "RestructuringReserveCurrent"],
    "inventories": ["InventoryNet"], "short_term_investments": ["ShortTermInvestments"],
    "defined_contribution_plan_cost": ["DefinedContributionPlanCostRecognized"],
    "capex": ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"],
    "intangibles": ["IntangibleAssetsNetExcludingGoodwill"],
}
PROXY_TAGS = {"ceo_total_comp": "ecd:PeoTotalCompAmt", "cap": "ecd:PeoActuallyPaidCompAmt",
              "neo_avg_total_comp": "ecd:NonPeoNeoAvgTotalCompAmt"}
META = {"company", "ticker", "cik", "fy", "currency", "proxy_filing_year", "peo_name", "filing_date"}
AUXILIARY_SHEETS = {
    "company_metadata": ["公司-财年元数据", "公司状态"],
    "executive_compensation": ["高管薪酬"],
    "neo_details": ["DEF14A_NEO明细"],
    "keyword_summary": ["关键词汇总"],
    "section_evidence": ["章节相关内容"],
    "employee_compensation_metrics": ["员工与薪酬指标"],
    "proxy_policy_details": ["DEF14A额外扩充内容"],
}

def missing(value):
    return value is None or (isinstance(value, str) and value.strip().lower() in
        {"", "na", "n/a", "n.a.", "-", "—", "未披露", "未单列/不适用"})

def number(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, str) and re.fullmatch(r"-?[\d,]+(?:\.\d+)?", value.strip()):
        return float(value.replace(",", ""))
    return None

def name_key(value):
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())

def canonical_cik(value):
    text = str(value or "").strip()
    if text.endswith(".0"):
        text = text[:-2]
    return text.zfill(10) if text.isdigit() else ""

def _year(row):
    value = row.get("fy", row.get("year", row.get("财年", row.get("Year"))))
    if isinstance(value, str) and re.fullmatch(r"FY\s*\d{4}", value.strip(), re.I):
        value = re.sub(r"^FY\s*", "", value.strip(), flags=re.I)
    numeric = number(value)
    return int(numeric) if numeric is not None and numeric.is_integer() else None

def workbook_rows(path):
    import openpyxl
    book = openpyxl.load_workbook(path, read_only=True, data_only=True)
    try:
        for sheet in book:
            iterator = sheet.iter_rows(values_only=True)
            header = next(iterator, ())
            columns = [str(x).strip() if x is not None else "" for x in header]
            for row_number, values in enumerate(iterator, 2):
                if any(x is not None for x in values):
                    yield sheet.title, row_number, dict(zip(columns, values))
    finally:
        book.close()

def load_current(work, result=None):
    if result is None:
        rows = read_csv(Path(work) / "panel/panel_wide.csv")
    else:
        rows = [{**r, "_result_row": row_number} for sheet, row_number, r in workbook_rows(result) if sheet == "面板宽表"]
    clean = {}
    for row in rows:
        cik, fy = canonical_cik(row.get("cik")), _year(row)
        if not cik or fy is None:
            continue
        key = (cik, fy)
        if key in clean:
            raise ValueError(f"重复公司财年: {key}")
        clean[key] = {**row, "cik": cik, "fy": fy}
    if not clean:
        raise ValueError("没有可审查的公司财年行")
    return clean

def load_references(paths, current, contract):
    names = {name_key(v["name"]): v["var_id"] for v in contract["variables"]}
    ids = {v["var_id"] for v in contract["variables"]}
    aliases = contract["aliases"]
    entities = {}
    for cik, fy in current:
        r = current[(cik, fy)]
        for value in [r.get("company"), r.get("ticker")]:
            if value:
                entities[name_key(value)] = cik
    observed_names = {r.get("ticker"): r["cik"] for r in current.values()}
    refs, auxiliary = defaultdict(list), defaultdict(list)
    unknown = []
    # Metadata resolves the reference's own company names, never its unrelated local CID.
    material = []
    for path in paths:
        path = Path(path)
        for sheet, row_number, row in workbook_rows(path):
            material.append((path.name, sheet, row_number, row))
            cik = canonical_cik(row.get("cik", row.get("CIK")))
            ticker = str(row.get("ticker") or "").strip()
            if cik and ticker in observed_names and cik == observed_names[ticker]:
                entities[name_key(row.get("company"))] = cik
    used_tables = Counter()
    for filename, sheet, row_number, row in material:
        cik = canonical_cik(row.get("cik", row.get("CIK"))) or entities.get(name_key(row.get("ticker"))) or entities.get(name_key(row.get("company")))
        fy = _year(row)
        if (cik, fy) not in current:
            continue
        provenance = {"reference_file": filename, "reference_sheet": sheet, "reference_row": row_number}
        auxiliary[sheet].append({**row, **provenance, "cik": cik, "fy": fy})
        used_tables[sheet] += 1
        if sheet in {"全变量长表", "最终变量面板"} or ("变量" in row and any(k in row for k in ["值/原文", "数值"])):
            vid = names.get(name_key(row.get("变量")))
            if vid is None:
                unknown.append({**provenance, "name": row.get("变量"), "reason": "unmapped_reference_variable"})
                continue
            refs[(cik, fy, vid)].append({**provenance, "value": row.get("值/原文", row.get("数值")),
                "status": row.get("状态"), "section": row.get("章节"), "accession": row.get("Accession"),
                "source_url": row.get("SEC URL"), "note": row.get("提取备注", ""), "reference_name": row.get("变量")})
        elif sheet in {"财务面板", "高管薪酬"} or len(set(row) & (ids | set(aliases))) >= 3:
            for field, value in row.items():
                if field in META or field in {"cid", "CID", "CIK", "year", "Year", "财年", "SIC", "sic", "SIC行业", "form", "accession", "source_url", "QA警告", "qa_warnings", "note"}:
                    continue
                vid = aliases.get(field, field)
                if vid not in ids:
                    unknown.append({**provenance, "name": field, "reason": "unmapped_reference_field"})
                    continue
                refs[(cik, fy, vid)].append({**provenance, "value": value, "reference_name": field,
                    "source_url": "", "accession": "", "note": ""})
    if paths and not used_tables:
        raise ValueError("参考表没有匹配的公司财年；不得把零重叠解释为审查通过")
    if paths and not refs:
        raise ValueError("只匹配到元数据，未取得可映射的参考变量；不能声称参考审查通过")
    return refs, auxiliary, unknown

def fold(text):
    output, positions = [], []
    for index, char in enumerate(text):
        chars = unicodedata.normalize("NFKC", char).lower()
        for value in chars:
            if unicodedata.category(value) == "Pd":
                value = "-"
            if value.isspace():
                if output and output[-1] != " ":
                    output.append(" "); positions.append(index)
            else:
                output.append(value); positions.append(index)
    return "".join(output), positions

class Sources:
    def __init__(self, work, extras=(), coding_coder=None):
        self.work = Path(work).resolve()
        self.facts = {}
        self.packages = {}
        self.text_cache = {}
        self.fold_cache = {}
        self.proxy_facts = defaultdict(list)
        self.compensation_cache = {}
        self.coding_rows=read_csv(self.work/'coding/codes.csv')
        coders={r.get('coder_id')for r in self.coding_rows}
        self.coding_coder=coding_coder if coding_coder is not None else next(iter(coders))if len(coders)==1 else None
        self.coding_rows=[r for r in self.coding_rows if r.get('coder_id')==self.coding_coder]
        self.coding_import_issues=[]

        self.filings = []
        db_path = self.work / "state/state.db"
        if db_path.exists():
            db = sqlite3.connect(db_path); db.row_factory = sqlite3.Row
            self.filings = [dict(r) for r in db.execute("SELECT * FROM filings WHERE status='parsed'")]
            db.close()
        self.filings.extend(extras)
        for path in sorted((self.work / "derived/cells").glob("*.json")):
            p = json.loads(path.read_text())
            if p.get("form") in {"10-K", "20-F", "40-F"}:
                text, _ = self.text(p["accession"])
                if text:
                    checked = locate_sections(text, p["form"])
                    p["sections"] = {k: [v.start, v.end] for k, v in checked.items()}
                self.packages[(p["cik"], int(p["fy"]))] = p
        self.periods = {(cik, fy): p.get("period") for (cik, fy), p in self.packages.items()}
        for filing in self.filings:
            if not str(filing.get("form", "")).startswith("DEF"):
                continue
            path = Path(filing["path"])
            if not path.is_absolute():
                path = self.work / path
            if not path.is_file():
                continue
            html = path.read_text(encoding="utf-8", errors="replace")
            for fact in numeric_facts(html):
                if fact["tag"].lower() not in {x.lower() for x in PROXY_TAGS.values()}:
                    continue
                self.proxy_facts[filing["cik"]].append({**fact, "accession": filing["accession"],
                    "filed": filing.get("filed", ""), "source_path": str(path)})

    def text(self, accession):
        if accession not in self.text_cache:
            filing = next((f for f in self.filings if f["accession"] == accession), None)
            if filing is None:
                return "", ""
            path = Path(filing["path"])
            if not path.is_absolute():
                path = self.work / path
            if not path.is_file():
                return "", ""
            text = html_to_text(path.read_text(encoding="utf-8", errors="replace"))
            self.text_cache[accession] = (text, str(path))
        return self.text_cache[accession]

    def quote(self, accession, value):
        text, path = self.text(accession)
        if not text or not isinstance(value, str):
            return {}
        if accession not in self.fold_cache:
            self.fold_cache[accession] = fold(text)
        flat, positions = self.fold_cache[accession]
        pieces = [p.strip() for p in re.split(r"\n\n|\[[^\]]+\]", value) if len(p.strip()) >= 45]
        for piece in pieces[:8]:
            query, _ = fold(piece[:240])
            query = query.strip()
            at = flat.find(query)
            if at >= 0:
                start, end = positions[at], positions[at + len(query) - 1] + 1
                return {"quote": text[start:end], "char_start": start, "char_end": end,
                        "source_path": path, "source_sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest()}
        return {}

    def financial(self, cik, fy, vid):
        if vid=="ceo_total_comp":
            from .compensation_tables import identified_ceos
            if len(identified_ceos(self.compensation(cik,fy).get("rows",[])))>1:return {}
        p = self.packages.get((cik, fy))
        if not p:
            return {}
        if cik not in self.facts:
            path = self.work / "raw/facts" / f"facts_{cik}.json"
            self.facts[cik] = json.loads(path.read_text()) if path.is_file() else {}
        payload = self.facts[cik]
        if vid == 'debt_total':
            from .financial_totals import debt_total
            total = debt_total(payload, fy, p['accession'], p.get('period', ''))
            if total:
                total['source_path'] = str(self.work / 'raw/facts' / f'facts_{cik}.json')
            return total
        if vid == "pay_ratio":
            compensation = self.compensation(cik, fy)
            if compensation.get("pay_ratio"):
                return {**compensation["provenance"], **compensation["pay_ratio"], "unit": "ratio",
                        "method": "proxy_pay_ratio_explicit_year"}
        tags = EXTRA_TAGS.get(vid, xbrl.TAG_MAP.get(vid, []))
        value, unit, accession, tag = xbrl.value_for_year(payload, tags, fy,
            accession=p["accession"], period=p.get("period", ""))
        if value is not None:
            return {"value": value, "unit": unit, "accession": accession, "tag": tag,
                    "source_path": str(self.work / "raw/facts" / f"facts_{cik}.json"),
                    "period": p.get("period", ""), "method": "xbrl_same_accession_period"}
        if vid in {'intangibles', 'severance'}:
            filing = next((f for f in getattr(self, 'filings', []) if f['accession'] == p['accession']), None)
            if filing:
                path = Path(filing['path'])
                if not path.is_absolute(): path = self.work / path
                # Currency is established from this filing's primary financial statement.
                asset_total, currency, _, _ = xbrl.value_for_year(payload, ['Assets'], fy, accession=p['accession'], period=p.get('period', ''))
                if path.is_file() and currency == 'USD':
                    from .financial_totals import statement_intangibles, severance_records
                    if vid == 'intangibles':
                        result = statement_intangibles(path.read_text(errors='replace'), fy, expected_total_assets=asset_total)
                    else:
                        text, _ = self.text(p['accession'])
                        start, end = p.get('sections', {}).get('8', [0, 0])
                        candidates = severance_records(text, fy, p.get('period', ''), start, end) if end else []
                        unique = {(r['value'], r['period'], r['measurement_scope']): r for r in candidates}
                        result = next(iter(unique.values())) if len(unique) == 1 else {}
                    if result:
                        return {**result, 'accession': p['accession'], 'unit': currency,
                                'source_path': str(path), 'period': result.get('period') or p.get('period')}
        if vid == 'leverage':
            assets=self.financial(cik,fy,'total_assets');liabilities=self.financial(cik,fy,'total_liabilities')
            if assets and liabilities and assets['unit']==liabilities['unit']and assets['value']>0:
                return {**assets,'value':liabilities['value']/assets['value'],'tag':'Liabilities/Assets','unit':'ratio',
                        'components':json.dumps({'numerator':liabilities['value'],'denominator':assets['value']},sort_keys=True),
                        'measurement_scope':'total liabilities divided by total assets; parent equity is not the numerator complement',
                        'method':'derived_from_same_context_liabilities_and_assets'}
        if vid in PROXY_TAGS:
            candidates = [f for f in self.proxy_facts[cik] if f["tag"].lower() == PROXY_TAGS[vid].lower()
                          and f["end"] == p.get("period")]
            if candidates:
                latest = max(f["filed"] for f in candidates)
                candidates = [f for f in candidates if f["filed"] == latest]
                if len({f["value"] for f in candidates}) == 1:
                    return {**candidates[0], "unit": "USD", "period": p.get("period"),
                            "method": "proxy_ixbrl_explicit_period_latest_available"}
        if vid == 'ceo_total_comp':
            data=self.compensation(cik,fy)
            from .compensation_tables import identified_ceos
            ceo=identified_ceos(data.get('rows',[]))
            if len(ceo)==1 and ceo[0].get('arithmetic_pass'):
                row=ceo[0];proof=self.quote(data['provenance']['accession'],row['quote'])
                return {**data['provenance'],**proof,'value':row['total'],'unit':'USD','period':p.get('period'),
                        'tag':'SCT explicit CEO identity and year','method':'proxy_sct_explicit_ceo_year_arithmetic'}
            if not ceo and data.get('provenance'):
                from .compensation_tables import ceo_amount_from_ratio
                text,_=self.text(data['provenance']['accession']);proof=ceo_amount_from_ratio(text,fy)
                if proof:return {**data['provenance'],**proof,'unit':'USD','method':'proxy_explicit_year_CEO_amount_in_pay_ratio_section'}
        if vid == "tech_opex_amount":
            from bs4 import BeautifulSoup
            filing = next((f for f in self.filings if f["accession"] == p["accession"]), None)
            if filing:
                path = Path(filing["path"])
                if not path.is_absolute():
                    path = self.work / path
                soup = BeautifulSoup(path.read_text(errors="replace"), "lxml")
                for table in soup.find_all("table"):
                    rows = [" ".join(tr.stripped_strings) for tr in table.find_all("tr")]
                    for i, line in enumerate(rows):
                        if not re.search(r"^Technology and (?:content|infrastructure)\b", line, re.I):
                            continue
                        years = []
                        for header in rows[:i]:
                            found = re.findall(r"\b20\d{2}\b", header)
                            if len(set(found)) >= 2:
                                years = list(dict.fromkeys(found))
                        numbers = re.findall(r"(?<![A-Za-z\d])\(?\d[\d,]*(?:\.\d+)?\)?", line)
                        values = [float(n.replace(",", "").strip("()")) * (-1 if n.startswith("(") else 1) for n in numbers]
                        if str(fy) in years and len(values) == len(years):
                            return {"value": values[years.index(str(fy))] * 1_000_000, "unit": "USD",
                                "accession": p["accession"], "tag": "Technology and content/infrastructure annual table (millions)",
                                "quote": line, "period": p.get("period"), "source_path": str(path),
                                "method": "annual_table_explicit_year_millions_to_base"}
        return {}

    def coding_narrative(self,cik,fy,definition):
        matches=[r for r in self.coding_rows if r['cik']==cik and str(r['fy'])==str(fy)and r['var_id']==definition['var_id']and str(r.get('value'))=='1']
        if not matches:return{}
        if len(matches)!=1:return{'coding_unverified':True}
        row=matches[0];audit_path=self.work/'coding/code_audit.json';book_path=self.work/'coding/codebook.yaml';code_path=self.work/'coding/codes.csv'
        audit=json.loads(audit_path.read_text())if audit_path.exists()else{}
        valid=((audit.get('pass')or audit.get('integrity_pass'))and audit.get('coder')==self.coding_coder and audit.get('codes_file_sha256')==hashlib.sha256(code_path.read_bytes()).hexdigest()and book_path.is_file()and audit.get('codebook_file_sha256')==hashlib.sha256(book_path.read_bytes()).hexdigest())
        text,path=self.text(row.get('accession',''))
        try:
            start,end=int(row['char_start']),int(row['char_end']);lo,hi=int(row['scope_start']),int(row['scope_end'])
            valid=valid and hashlib.sha256(text.encode('utf-8')).hexdigest()==row.get('text_sha256')and lo<=start<end<=hi and text[start:end].strip()==str(row.get('quote','')).strip()and str(row.get('section'))==str(definition.get('section'))
        except(ValueError,KeyError,TypeError):valid=False
        if not valid:
            self.coding_import_issues.append({'cik':cik,'fy':fy,'var_id':definition['var_id'],'issue':'positive_coding_quote_not_currently_verified'})
            return{'coding_unverified':True}
        # Expand to surrounding paragraph boundaries without modifying canonical text.
        previous=text.rfind('\n\n',lo,start);following=text.find('\n\n',end,hi)
        start=previous+2 if previous>=lo else lo;end=following if following>=0 else hi
        quote=text[start:end]
        return{'value':quote,'quote':quote[:600],'char_start':start,'char_end':start+min(600,len(quote)),
            'source_spans':json.dumps([[start,end]]),'source_path':path,'accession':row['accession'],
            'coding_coder_id':self.coding_coder,'coding_code_id':row['code_id'],
            'method':'source_bound_positive_coding_quote_candidate','source_checked':True}

    def compensation(self, cik, fy):
        key = (cik, fy)
        if key not in self.compensation_cache:
            period = self.periods.get(key, "")
            later = [end for (c, y), end in self.periods.items() if c == cik and y > fy and end]
            filings = [f for f in self.filings if f["cik"] == cik and f.get("form") == "DEF 14A"
                       and period and f.get("filed", "") >= period
                       and (not later or f.get("filed", "") < min(later))]
            result = {}
            if filings:
                filing = min(filings, key=lambda f: f["filed"])
                text, path = self.text(filing["accession"])
                if path:
                    result = extract_sct(Path(path).read_text(errors="replace"), fy)
                    result["pay_ratio"] = pay_ratio(text, fy)
                    result["provenance"] = {"cik": cik, "fy": fy, "accession": filing["accession"],
                        "source_path": path, "filed": filing.get("filed"), "period": period,
                        "source_sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                        "source_url": f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{filing['accession'].replace('-', '')}/{filing.get('primary_doc') or Path(path).name}"}
            self.compensation_cache[key] = result
        return self.compensation_cache[key]

    def compensation_text(self, cik, fy, vid):
        data = self.compensation(cik, fy)
        if not data.get("rows"):
            return {}
        if vid == "sct":
            value = data["table_text"]
        else:
            field = {"non_equity_incentive": "non_equity", "all_other_comp": "all_other"}[vid]
            rows = [f"{r['name_title']}: {r[field]:,.0f} USD" for r in data["rows"] if field in r]
            if not rows:
                return {}
            value = "\n".join(rows)
        return {**data["provenance"], "value": value, "quote": data["table_text"],
                "method": "proxy_summary_compensation_table_explicit_year"}

    def narrative(self, cik, fy, definition):
        p = self.packages.get((cik, fy))
        if not p:
            return {}
        accession = p["accession"]
        # Map proxies to the most recent ended annual period, not py-1.
        if str(definition.get("section")) == "11" or definition["var_id"] == "deferred_comp":
            period = p.get("period", "")
            candidates = [f for f in self.filings if f["cik"] == cik and f.get("form") == "DEF 14A"
                          and period and f.get("filed", "") >= period]
            next_ends = [v for (c, y), v in self.periods.items() if c == cik and y > fy and v]
            if next_ends:
                candidates = [f for f in candidates if f["filed"] < min(next_ends)]
            if not candidates:
                return {}
            accession = min(candidates, key=lambda f: f["filed"])["accession"]
        text, path = self.text(accession)
        if not text:
            return {}
        lo, hi = p.get("sections", {}).get(str(definition.get("section")), [0, len(text)])
        if accession != p["accession"]:
            lo, hi = 0, len(text)
        scope = text[lo:hi]
        if definition["var_id"] == "equity_grants":
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(Path(path).read_text(errors="replace"), "lxml")
            tables = []
            for table in soup.find_all("table"):
                content = table.get_text("\n", strip=True)
                if (re.search(r"\bGranted\b", content, re.I) and
                    re.search(r"unvested|nonvested|outstanding", content, re.I) and
                    re.search(r"shares|units|stock|awards", content, re.I) and len(content) < 25000):
                    tables.append(content)
            if tables:
                value = min(tables, key=len)
                quote = self.quote(accession, value)
                return {"value": value, "accession": accession, "source_path": path, **quote,
                    "source_checked": True, "method": "complete_stock_grant_activity_table"}
        if definition["var_id"] == "hcm_disclosure":
            headings = list(re.finditer(r"(?:^|\n)\s*Human Capital (?:Management|Resources)\s*\n", scope, re.I))
            if headings:
                start = lo + headings[-1].start()
                boundary = re.search(r"\n\s*(?:Available Information|Information About Our Executive Officers|Our Executive Officers)\s*\n", text[start:hi], re.I)
                end = start + boundary.start() if boundary else hi
                return {"value": text[start:end].strip(), "accession": accession,
                    "quote": text[start:min(end, start+600)], "char_start": start, "char_end": min(end, start+600),
                    "source_path": path, "source_checked": True, "method": "complete_human_capital_subsection"}
        snippets = []
        keywords = list(definition.get("keywords", []))
        if definition["var_id"] == "headcount_by_segment":
            keywords = [r"(?:employees|associates|people|employed)[^.\n]{0,150}(?:U\.S\.|international|operations|research|United States)"] + keywords
        if definition["var_id"] == "ai_impact":
            keywords = [r"(?:AI|artificial intelligence)[^.\n]{0,180}(?:products?|services?|Copilot|Azure|Bing|solutions?)",
                        r"(?:Copilot|Azure|Bing|products?|services?)[^.\n]{0,180}(?:AI|artificial intelligence)"]
        if definition["var_id"] == "ai_operational_risk":
            keywords = [r"AI (?:algorithms|systems|models|training methodologies)[^.]{0,180}(?:flaw|fail|error|harmful|unintended)"] + keywords
        if definition["var_id"] == "equity_grants":
            keywords = [r"\bGranted\b"] + keywords
        for keyword in keywords:
            try:
                found = re.finditer(keyword, scope, re.I)
                for match in found:
                    radius_before, radius_after = (700, 900) if definition["var_id"] == "equity_grants" else (180, 420)
                    start = max(lo, lo + match.start() - radius_before)
                    end = min(hi, lo + match.end() + radius_after)
                    if definition["var_id"] == "ai_operational_risk" and re.match(r"AI\s+(?:algorithms|systems|models|training)", match.group(0), re.I):
                        start = lo + match.start()
                        stop = text.find(".", lo + match.end(), hi)
                        end = stop + 1 if stop >= 0 else min(hi, lo + match.end() + 180)
                    quote = text[start:end]
                    if any(re.search(pattern, quote, re.I) for pattern in definition.get("exclude", [])):
                        continue
                    if not valid_context(definition["var_id"], quote):
                        continue
                    if not any(abs(start - a) < 160 for a, _, _ in snippets):
                        snippets.append((start, end, quote))
                    if len(snippets) >= 6:
                        break
            except re.error:
                raise ValueError(f"非法检索规则: {definition['var_id']}")
            if len(snippets) >= 6:
                break
        if not snippets:
            return {"source_checked": True, "accession": accession, "source_path": path,
                    "scope_start": lo, "scope_end": hi}
        merged=[]
        for start,end,_ in sorted(snippets):
            if merged and start<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],end)
            else:merged.append([start,end])
        start,end=merged[0];quote=text[start:min(end,start+600)]
        return {"value": "\n\n".join(text[a:b]for a,b in merged), "accession": accession,
                "quote": quote, "char_start": start, "char_end": start+len(quote), "source_path": path,
                "source_spans":json.dumps(merged),
                "source_checked": True, "method": "merged_nonoverlapping_disclosure_candidates"}

def valid_context(vid, quote):
    def has(pattern):
        return bool(re.search(pattern, quote, re.I))
    ai = r"artificial intelligence|machine learning|\bAI\b"
    if vid.startswith("ai_") and not has(ai):
        return False
    risk = {"ai_regulatory_risk": r"regulat|legislat|\blaws?\b|legal|compliance", "ai_cyber_risk": r"cyber|privacy|security|data protection",
            "ai_competitive_risk": r"competit|market share", "ai_ethical_risk": r"ethic|bias|reputation|discriminat",
            "ai_operational_risk": r"error|fail|flaw|unreliable|harmful|inaccura|unintended"}
    if vid in risk and not has(risk[vid]):
        return False
    if vid == "ai_rd" and not has(r"research|development|R\s*&\s*D"):
        return False
    if vid == "equity_grants" and not has(r"stock|shares|units|options|RSU"):
        return False
    if vid == "ai_impact" and (not has(r"products?|services?|Copilot|Azure|Bing|solutions?") or has(r"grant challenge|train the next generation|empower workers globally")):
        return False
    if vid == "ai_forward_looking" and not has(r"will|expect|anticipat|intend|future|forward.looking"):
        return False
    if vid == "ai_known_trends" and not has(r"trend|uncertain|evolv|demand|shift|chang"):
        return False
    if vid == "headcount_by_segment" and not (has(r"\d[\d,.]*") and has(r"employees|associates|people|employed") and has(r"U\.S\.|United States|international|operations|research|geograph|region")):
        return False
    if vid in {"turnover_rate", "retention_rate"} and not (has(r"%|percent") and has(r"turnover|attrition|retention")):
        return False
    if vid == "training_costs" and not (has(r"\$|million|billion") and has(r"train|learning|tuition") and has(r"cost|spent|expense|invested")):
        return False
    if vid == "engagement_survey" and not has(r"survey|listening|feedback|score"):
        return False
    if vid == "dei_metrics" and not (has(r"%|percent|\$1\.") and has(r"women|gender|ethni|minority|racial|diversity|underrepresented")):
        return False
    if vid == "workforce_restructuring_risk" and not (has(r"workforce|employees|staff|personnel|workers") and has(r"restructur|layoff|reduction|termination")):
        return False
    if vid == "union_risk" and not has(r"\bunion|collective bargaining|labor dispute|labor strike|workforce unrest"):
        return False
    if vid == "talent_competition_risk" and not (has(r"competition|competitive") and has(r"talent|employees|personnel|staff|labor")):
        return False
    if vid == "deferred_comp" and has(r"Exhibit Description|Incorporated by Reference"):
        return False
    if vid == "ai_exec_comp" and not (has(r"compensation|bonus|incentive|award") and has(r"performance goal|performance metric|tied to|based on|incentive")):
        return False
    return True

def _reference_value(reference, definition):
    value = reference.get("value")
    numeric = number(value)
    if numeric is not None and definition.get("reference_unit") == "million" and reference.get("reference_sheet") == "全变量长表":
        return numeric * 1_000_000
    return value

def compare_value(old, reference, definition):
    target = _reference_value(reference, definition)
    a, b = number(old), number(target)
    if missing(target):
        return "both_missing" if missing(old) else "reference_missing_current_needs_review"
    if missing(old):
        return "missing_extraction"
    if definition["kind"] == "text" and a is not None and b is None:
        return "text_replaced_by_feature"
    if a is not None and b is not None:
        tolerance = 0.00005 if definition["var_id"] == "leverage" else 0.000001
        return "same_value" if math.isclose(a, b, rel_tol=1e-10, abs_tol=tolerance) else "different_value"
    return "same_text" if str(old).strip() == str(target).strip() else "different_text"

def external_events(work, paths, current, sources, out):
    def company_base(value):
        value = name_key(value)
        previous = None
        while value != previous:
            previous = value
            value = re.sub(r"(?:corporation|incorporated|corp|inc|com)$", "", value)
        return value
    entities = {}
    for r in current.values():
        entities[company_base(r.get("company"))] = (r["cik"], r.get("company"), r.get("ticker"))
    from layoffcore.entities import EntityIndex
    index=EntityIndex(current.values())
    years = {fy for _, fy in current}
    sec = [r for r in read_csv(Path(work) / "events/layoff_disclosures.csv") if str(r.get("source", "")).startswith("sec_")]
    rows = []; unmatched=[]
    for path in paths:
        for sheet, row_number, r in workbook_rows(path):
            resolved=index.resolve(r.get('CIK',r.get('cik')),r.get('Ticker',r.get('ticker')),r.get('Company'))
            entity=(resolved['cik'],resolved.get('company'),resolved.get('ticker')) if resolved else None
            if entity is None:
                unmatched.append({'reference_file':Path(path).name,'reference_row':row_number,'company':r.get('Company'),'reason':'not_matched_to_selected_CIK_scope'})
                continue
            if _year(r) not in years:
                continue
            cik, company, ticker = entity
            date = str(r.get("Date") or "")[:10]
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
                continue
            ending = sorted((period, fy) for (c, fy), period in sources.periods.items() if c == cik and period)
            fy = next((y for end, y in ending if date <= end), None)
            basis = "annual_period_end"
            if fy is None and ending:
                fy = ending[-1][1] + 1
                basis = "after_last_period_inferred_next_fy"
            count = number(r.get("# Laid Off"))
            matched = [e for e in sec if e.get("cik") == cik and str(e.get("event_date", ""))[:10] == date
                       and (count is None or number(e.get("layoff_count_num")) == count)]
            rows.append({"reference_file": Path(path).name, "reference_sheet": sheet, "reference_row": row_number,
                "reference_item_id": r.get("ItemID"), "cik": cik, "company": company, "ticker": ticker,
                "calendar_year": _year(r), "mapped_fy": fy, "date": date, "layoff_count": count,
                "percentage_raw": r.get("%"), "source": "provided_news_reference", "source_url": r.get("Source"),
                "source_verification": "provided_reference_not_independent_news_verification",
                "fy_basis": basis, "in_requested_fy_window": fy in years,
                "comparison": "matched_sec_date_and_count" if matched else "external_reference_only",
                "matched_accession": matched[0].get("accession") if matched else ""})
    if rows:
        write_csv(Path(out) / "external_events.csv", rows, list(rows[0]))
    write_csv(Path(out)/'external_unmatched_companies.csv',unmatched,['reference_file','reference_row','company','reason'])
    return {"rows": len(rows), "in_requested_fy_window": sum(r["in_requested_fy_window"] for r in rows),
        "matched_sec": sum(r["comparison"] == "matched_sec_date_and_count" for r in rows),
        "source": "provided_news_reference", "independently_verified": False}

def review(work, out, contract, references=(), result=None, extras=(), strict=False, decisions=(), events_references=(), coding_coder=None):
    work, out = Path(work), Path(out)
    variable_ids = [v["var_id"] for v in contract["variables"]]
    if len(variable_ids) != len(set(variable_ids)):
        raise ValueError("变量契约含重复 var_id")
    if any(v.get("kind") not in {"number", "text", "flag"} for v in contract["variables"]):
        raise ValueError("变量契约的表示类型不受支持")
    current = load_current(work, result)
    refs, auxiliary, unknown = load_references(references, current, contract)
    sources = Sources(work, extras, coding_coder=coding_coder)
    definitions = {v["var_id"]: v for v in contract["variables"]}
    comparisons, completed, issues = [], [], []
    for (cik, fy), row in sorted(current.items()):
        for vid, definition in definitions.items():
            candidates = refs.get((cik, fy, vid), [])
            for candidate in candidates:
                comparisons.append({"cik": cik, "ticker": row.get("ticker"), "fy": fy, "var_id": vid,
                    "old_value": row.get(vid), "reference_value": candidate["value"],
                    "normalized_reference_value": _reference_value(candidate, definition),
                    "comparison": "variable_not_in_panel" if vid not in row else compare_value(row.get(vid), candidate, definition),
                    **{k: candidate.get(k, "") for k in ["reference_file", "reference_sheet", "reference_row", "accession", "source_url"]}})
            record = {"cik": cik, "company": row.get("company", ""), "ticker": row.get("ticker", ""),
                "fy": fy, "var_id": vid, "name": definition["name"], "name_cn": definition["name_cn"],
                "kind": definition["kind"], "value": None, "status": "not_checked", "method": "",
                "reference_file": "", "reference_sheet": "", "reference_row": "",
                "accession": "", "quote": "", "source_path": "", "source_url": "", "note": ""}
            financial = sources.financial(cik, fy, vid) if definition["kind"] == "number" else (
                sources.compensation_text(cik, fy, vid) if vid in {"sct", "non_equity_incentive", "all_other_comp"} else {})
            present = [r for r in candidates if not missing(r["value"])]
            distinct = {str(_reference_value(r, definition)) for r in present}
            if len(distinct) > 1:
                issues.append({"cik": cik, "fy": fy, "var_id": vid, "issue": "reference_conflict",
                    "resolution": "primary_source_selected" if financial else "reference_variants_retained",
                    "values": list(distinct)})
            if financial:
                record.update(financial)
                record["status"] = financial.get('status', 'primary_source_verified')
                if present and any(compare_value(financial["value"], r, definition) == "different_value" for r in present):
                    record["note"] = "参考取值与本次原始来源不一致；保留来源版本、单位或定义差异，不静默覆盖。"
            elif len(distinct) > 1:
                record.update(status="reference_conflict_needs_review", method="conflicting_reference_values_quarantined",
                    reference_file=" | ".join(sorted({c["reference_file"] for c in present})),
                    note="参考表存在不同取值且没有独立原始来源裁定，不能交叉补值或按文件顺序选取。")
                package = sources.packages.get((cik, fy))
                if package:
                    _, source_path = sources.text(package["accession"])
                    record.update(source_path=source_path, accession=package["accession"])
            elif present:
                # Prefer the narrative reference for textual constructs, summary fields for numbers.
                preferred = sorted(present, key=lambda r: (r["reference_sheet"] != ("全变量长表" if definition["kind"] == "text" else "财务面板"), r["reference_file"]))[0]
                record.update({k: preferred.get(k, "") for k in ["reference_file", "reference_sheet", "reference_row", "accession", "source_url", "note"]})
                value = _reference_value(preferred, definition)
                record.update(value=value, status="reference_recovered", method="provided_reference_with_cell_provenance")
                # Pension contributions must never be relabelled as health/insurance benefits.
                if vid == "benefits_expense" and any("DefinedContribution" in str(c.get("note", "")) for c in present):
                    record.update(value=None, status="not_separately_reported", method="definition_conflict_rejected",
                                  note="参考数值来自设定提存退休计划，不能作为医疗/保险福利费用；另列 defined_contribution_plan_cost。")
                    issues.append({"cik": cik, "fy": fy, "var_id": vid, "issue": "reference_definition_mismatch", "resolution": "kept_separate"})
                elif definition["kind"] == "text":
                    quote = sources.quote(str(preferred.get("accession") or ""), str(value))
                    if quote:
                        record.update(quote)
                        record.update(status="reference_text_located", method="reference_text_with_primary_excerpt")
            else:
                evidence = sources.narrative(cik, fy, definition) if definition["kind"] == "text" else {}
                if definition['kind']=='text' and not evidence.get('value'):evidence=sources.coding_narrative(cik,fy,definition)or evidence
                if evidence.get("value"):
                    record.update(evidence)
                    record["status"] = "text_candidate_needs_review"
                elif evidence.get('coding_unverified'):
                    record.update(status='not_checked',method='positive_coding_quote_requires_current_audit',note='已有阳性编码但引文/来源/编码本未通过当前核验，不能声明未披露。')
                elif definition["kind"] == "flag" and number(row.get(vid)) is not None:
                    old_path = Path(result).resolve() if result else (work/"panel/panel_wide.csv").resolve()
                    record.update(value=number(row[vid]), status="existing_flag", method="existing_feature_not_narrative",
                        source_path=str(old_path), reference_file=old_path.name,
                        reference_sheet="面板宽表" if result else "panel_wide.csv", reference_row=row.get("_result_row", ""),
                        note="保留原特征及输入位置；不等于重新验证了原文语义，完整披露另见ft_pt_split。")
                elif vid == "headcount":
                    package=sources.packages.get((cik,fy),{})
                    text,path=sources.text(package.get('accession',''))
                    from .rules import load_varspec,apply_rule
                    rule_path=work/'config/varspec.yaml'
                    if not rule_path.exists():rule_path=Path(__file__).resolve().parents[2]/'assets/varspec.yaml'
                    spec=load_varspec(rule_path).get('headcount')
                    sections=locate_sections(text,package.get('form','10-K'))
                    fresh=apply_rule(spec,sections,text,fy=fy)if spec and sections else None
                    if fresh and fresh.value is not None:
                        record.update(value=fresh.value,status='primary_source_verified',method='headcount_reextracted_current_scope_and_measure',
                            accession=package['accession'],source_path=path,quote=fresh.quote,char_start=fresh.char_start,char_end=fresh.char_end,
                            unit=fresh.unit or 'employees',period=package.get('period',''))
                        if number(row.get(vid))!=number(fresh.value):record['note']='旧人数与当前源重新提取不同；新值优先，派生增长和强度须重算。'
                    else:record.update(status='numeric_source_unresolved',note='旧员工数不能仅凭引文存在认证；当前类型/期间/雇佣存量验证未通过。')
                else:
                    record.update(status="not_disclosed_in_available_sources", method="searched_available_sources",
                        note="原始披露未取得同口径值；保留缺失，不以零、近似标签或无关金额填充。")
                    package = sources.packages.get((cik, fy))
                    if not package:
                        record["status"] = "source_missing"
                    else:
                        _, path = sources.text(package["accession"])
                        record.update(accession=package["accession"], source_path=path)
            if definition['kind']=='number' and record['status']=='not_disclosed_in_available_sources':
                record.update(status='numeric_source_unresolved',method='no_supported_numeric_match',
                    note='支持的标签或解析器未取得同口径值；尚未完成语义否定审查，不代表原文未披露。')
            if definition["kind"] == "number" and record["value"] is not None and number(record["value"]) is None:
                record["note"] = str(record.get("note", "")) + " | 参考为定性文本，不能作为数值直接进入回归。"
                record["kind"] = "text_partial"
            filing=next((f for f in sources.filings if f['accession']==record.get('accession')),{})
            record['form']=filing.get('form','')
            if not record.get('filed'):record['filed']=filing.get('filed','')
            record['currency']=record.get('unit')if record.get('unit')in {'USD','EUR','GBP','CAD','JPY'}else'UNKNOWN'
            completed.append(record)

    hashes = {}
    for cell in completed:
        source_path = cell.get("source_path")
        if source_path and Path(source_path).is_file():
            if source_path not in hashes:
                hashes[source_path] = hashlib.sha256(Path(source_path).read_bytes()).hexdigest()
            cell["source_sha256"] = hashes[source_path]
        if cell.get("accession") and not cell.get("source_url"):
            filing = next((f for f in sources.filings if f["accession"] == cell["accession"]), {})
            document = filing.get("primary_doc") or Path(filing.get("path", "")).name
            if document:
                cell["source_url"] = f"https://www.sec.gov/Archives/edgar/data/{int(cell['cik'])}/{cell['accession'].replace('-', '')}/{document}"
        elif source_path and str(source_path).endswith(".json") and not cell.get("source_url"):
            cell["source_url"] = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cell['cik']}.json"

    decision_map = {}
    for decision in decisions:
        key = (canonical_cik(decision.get("cik")), int(decision["fy"]), decision["var_id"])
        if key in decision_map:
            raise ValueError(f"重复复核决定: {key}")
        if not decision.get("reason") or decision.get("decision") not in {"accept", "reject", "resolve"}:
            raise ValueError("复核决定需要accept/reject/resolve及具体理由")
        decision_map[key] = decision
    used_decisions = set(); decision_texts={}; decision_sections={}
    for cell in completed:
        key = (cell["cik"], cell["fy"], cell["var_id"])
        decision = decision_map.get(key)
        if decision is None:
            continue
        if cell["status"] not in {"text_candidate_needs_review", "source_located_pending_semantic_review", "scoped_search_only_pending_semantic_review", "reference_conflict_needs_review", "numeric_source_unresolved", "numeric_period_needs_review", "not_disclosed_in_available_sources", "reference_recovered", "reference_text_located"}:
            raise ValueError(f"复核决定与当前候选状态不一致: {key}")
        source = Path(cell["source_path"])
        if not decision.get("source_sha256") or hashlib.sha256(source.read_bytes()).hexdigest() != decision["source_sha256"]:
            raise ValueError(f"复核来源已经变化或未提供哈希: {key}")
        if str(source)not in decision_texts:decision_texts[str(source)]=html_to_text(source.read_text(encoding='utf-8',errors='replace'))
        if decision['decision']=='reject':
            source_text=decision_texts[str(source)]
            if str(source)not in decision_sections:decision_sections[str(source)]=locate_sections(source_text,cell.get('form')or'10-K')
            sections=decision_sections[str(source)];section=sections.get(str(definitions[cell['var_id']].get('section')))
            lo,hi=(section.start,section.end)if section and not str(cell.get('form','')).startswith('DEF')else(0,len(source_text))
            if decision.get('reviewed_scope')!=[lo,hi]or decision.get('scope_sha256')!=hashlib.sha256(source_text[lo:hi].encode()).hexdigest():
                raise ValueError('negative source review needs current complete scope/hash; see review_tasks.py: '+str(key))
        supplied=decision.get('support_quote')
        if supplied and (len(supplied)<30 or supplied not in decision_texts[str(source)]):raise ValueError('复核引文不在当前原始来源')
        if decision['decision']=='accept' and missing(cell.get('value'))and not supplied:raise ValueError('cannot accept an empty narrative; provide actual support_quote or review a scoped absence')
        used_decisions.add(key)
        semantic=decision.get('semantic_review')or{}
        definition_hash=hashlib.sha256(json.dumps(definitions[cell['var_id']],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
        semantic_bound=(semantic.get('definition_sha256')==definition_hash and semantic.get('basis')=='source_context_and_definition' and bool(str(semantic.get('criterion_application','')).strip()))
        if not semantic_bound:
            # Source location and scope hashing alone are not semantic acceptance or absence.
            if decision['decision']=='reject':
                cell.update(value=None,status='scoped_search_only_pending_semantic_review',method='mechanical_scope_proof_only',note='范围/hash已核对，但缺按当前定义的实质判定；不能把自动未命中批量清为已确认未披露。')
            else:
                cell.update(status='source_located_pending_semantic_review',method='mechanical_source_location_only',note='引文定位不等于定义适用判断；补semantic_review中的定义hash和criterion_application。')
            continue
        cell["note"] = "本次模型复核：" + decision["reason"]
        if decision["decision"] == "resolve":
            if cell["status"] not in {"reference_conflict_needs_review","numeric_source_unresolved", "numeric_period_needs_review"} or not decision.get("support_quote") or missing(decision.get("value")):
                raise ValueError("参考冲突裁定需要明确value与原始support_quote")
            source_text = html_to_text(source.read_text(encoding="utf-8", errors="replace"))
            start = source_text.find(decision["support_quote"])
            if start < 0 or len(decision["support_quote"]) < 30:
                raise ValueError("冲突裁定引文不在原始来源")
            if cell["kind"] in {"number", "flag"} and number(decision["value"]) is None:
                raise ValueError("数值冲突不能用任意文字填充")
            if cell['status'] in {'numeric_source_unresolved','numeric_period_needs_review'} and (not decision.get('unit') or not decision.get('period')):
                raise ValueError('新增数值裁定必须明确unit和period，不猜单位或年份')
            if decision.get('unit'):cell['unit']=decision['unit']
            if decision.get('period'):cell['period']=decision['period']
            cell.update(value=decision["value"], status="reviewed_reference_resolution", method="source_bound_conflict_resolution",
                quote=decision["support_quote"], char_start=start, char_end=start+len(decision["support_quote"]))
        elif decision["decision"] == "accept":
            if cell["status"] in {"reference_conflict_needs_review","numeric_source_unresolved", "numeric_period_needs_review"}:
                raise ValueError("数值或参考冲突必须用resolve明确裁定取值；确认缺失用reject并说明范围")
            if missing(cell.get('value')) and not decision.get('support_quote'):
                raise ValueError('cannot accept an empty narrative; provide actual support_quote or review a scoped absence')
            cell["status"] = "reviewed_text_evidence"
            cell["method"] = "explicit_review_of_source_bound_candidates"
            if decision.get("support_quote"):
                current_text = html_to_text(source.read_text(encoding="utf-8", errors="replace"))
                start = current_text.find(decision["support_quote"])
                if start < 0 or len(decision["support_quote"]) < 30:
                    raise ValueError(f"复核引文不在当前来源中: {key}")
                cell.update(quote=decision["support_quote"], char_start=start, char_end=start+len(decision["support_quote"]))
                if missing(cell.get('value')):cell['value']=decision['support_quote']
        else:
            cell["value"] = None
            cell["status"] = "not_disclosed_scoped"
            cell["method"] = "candidate_rejected_against_variable_definition"
    if used_decisions != set(decision_map):
        raise ValueError("复核决定含当前审查中不存在的公司财年变量")
    out.mkdir(parents=True, exist_ok=True)
    columns = ["cik", "company", "ticker", "fy", "var_id", "name", "name_cn", "kind", "value", "status", "method",
               "unit", "currency", "period", "tag", "context", "form", "accession", "filed", "source_path", "source_sha256", "source_url", "quote", "char_start", "char_end",
               "html_start", "html_end", "source_spans", "components", "measurement_scope", "expense_nature", "table_header", "coding_coder_id", "coding_code_id", "reference_file", "reference_sheet", "reference_row", "note"]
    write_csv(out / "research_long.csv", completed, columns)
    comparison_columns = ["cik", "ticker", "fy", "var_id", "old_value", "reference_value", "normalized_reference_value",
                          "comparison", "reference_file", "reference_sheet", "reference_row", "accession", "source_url"]
    write_csv(out / "reference_comparison.csv", comparisons, comparison_columns)
    numeric = []
    for key, row in sorted(current.items()):
        target = {k: row.get(k, "") for k in ["cid", "cik", "company", "ticker", "fy"]}
        for cell in completed:
            if (cell["cik"], cell["fy"]) == key:
                target[cell["var_id"]] = number(cell["value"]) if cell["kind"] in {"number", "flag"} else None
        numeric.append(target)
    write_csv(out / "research_numeric.csv", numeric, ["cid", "cik", "company", "ticker", "fy", *definitions])
    features = []
    for key, row in sorted(current.items()):
        feature = {**row}
        for cell in completed:
            if (cell["cik"], cell["fy"]) == key and cell["kind"] in {"number", "flag"}:
                feature[cell["var_id"]] = number(cell["value"])
        features.append(feature)
    write_csv(out / "analysis_features.csv", features, ["cid", "cik", "company", "ticker", "fy", *definitions])
    neo_rows, neo_comparison = [], []
    detail_fields = {"Salary ($)": "salary", "Bonus ($)": "bonus", "Stock Awards ($)": "stock_awards",
                    "Option Awards ($)": "option_awards", "Non-Equity ($)": "non_equity",
                    "Pension Change ($)": "pension_change", "All Other ($)": "all_other", "Total ($)": "total"}
    for cik, fy in sorted(current):
        data = sources.compensation(cik, fy)
        for r in data.get("rows", []):
            neo_rows.append({**data["provenance"], **r, "status": "primary_source_table_verified"})
    for r in auxiliary.get("DEF14A_NEO明细", []):
        name = name_key(r.get("姓名"))
        matches = [n for n in neo_rows if n["cik"] == r["cik"] and n["fy"] == r["fy"]
                   and name_key(n["name_title"]).startswith(name)]
        changed = [field for field, key in detail_fields.items() if matches and not missing(r.get(field))
                   and (key not in matches[0] or number(r[field]) != matches[0][key])]
        neo_comparison.append({"cik": r["cik"], "fy": r["fy"], "reference_name": r.get("姓名"),
            "reference_total": r.get("Total ($)"), "corrected_total": matches[0].get("total") if len(matches) == 1 else None,
            "status": "corrected_against_primary" if changed else "same_as_primary" if len(matches) == 1 else "source_match_pending",
            "changed_fields": ";".join(changed), "reference_file": r["reference_file"], "reference_row": r["reference_row"],
            "source_url": matches[0]["source_url"] if len(matches) == 1 else ""})
    if neo_rows:
        write_csv(out / "neo_verified.csv", neo_rows, list(dict.fromkeys(k for r in neo_rows for k in r)))
    if neo_comparison:
        write_csv(out / "neo_comparison.csv", neo_comparison, list(neo_comparison[0]))
    auxiliary_pending = sum(r["status"] == "source_match_pending" for r in neo_comparison) + sum(not r["arithmetic_pass"] for r in neo_rows)
    for sheet, rows in auxiliary.items():
        fields = list(dict.fromkeys(k for row in rows for k in row))
        write_csv(out / "reference_details" / (re.sub(r"[^\w-]", "_", sheet) + ".csv"), rows, fields)
    event_summary = external_events(work, events_references, current, sources, out)
    metadata=[]
    for (cik,fy),row in sorted(current.items()):
        pkg=sources.packages.get((cik,fy),{});cache=sources.work/'cache'/f'submissions_{cik}.json'
        submission=json.loads(cache.read_text())if cache.is_file()else{}
        revenue=sources.financial(cik,fy,'revenue')
        metadata.append({'cik':cik,'ticker':row.get('ticker'),'company':row.get('company'),'fy':fy,
            'sic':submission.get('sic'),'sic_industry':submission.get('sicDescription'),'sic_time_basis':'current submissions snapshot; not historical annual SIC',
            'form':pkg.get('form'),'accession':pkg.get('accession'),'period':pkg.get('period'),
            'currency':revenue.get('unit','UNKNOWN'),'metadata_source_sha256':hashlib.sha256(cache.read_bytes()).hexdigest()if cache.is_file()else'',
            'source_url':f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{pkg.get('accession','').replace('-','')}/{pkg.get('accession','')}-index.html"})
    if metadata:write_csv(out/'company_year_metadata.csv',metadata,list(metadata[0]))
    auxiliary_coverage = {name: {"source_sheets": sheets, "rows_preserved": sum(len(auxiliary.get(s, [])) for s in sheets),
        "required_fields": contract.get("auxiliary_tables", {}).get(name, [])}
        for name, sheets in AUXILIARY_SHEETS.items()}
    auxiliary_coverage['company_metadata']['primary_rows']=len(metadata)
    auxiliary_coverage['neo_details']['primary_rows']=len(neo_rows)
    write_json(out/'coding_research_crosscheck.json',{'selected_coder':sources.coding_coder,'source_quote_candidates_recovered':sum(c.get('method')=='source_bound_positive_coding_quote_candidate'for c in completed),'unverified_positive_quotes':sources.coding_import_issues,'semantic_truth_automatically_certified':False})
    variable_audit = []
    for vid, definition in definitions.items():
        cells = [c for c in completed if c["var_id"] == vid]
        variable_audit.append({"var_id": vid, "name": definition["name"], "kind": definition["kind"],
            "expected_rows": len(current), "actual_rows": len(cells), "filled": sum(not missing(c["value"]) for c in cells),
            "status_counts": dict(Counter(c["status"] for c in cells))})
    pending = [c for c in completed if c["status"] in {"not_checked", "source_missing", "text_candidate_needs_review", "source_located_pending_semantic_review", "scoped_search_only_pending_semantic_review", "reference_conflict_needs_review", "numeric_source_unresolved", "numeric_period_needs_review", "not_disclosed_in_available_sources", "reference_recovered", "reference_text_located"}]
    summary = {"tool_version": TOOL_VERSION, "contract_version": contract["version"],
        "contract_sha256": hashlib.sha256(json.dumps(contract, ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
        "company_years": len(current), "required_variables": len(definitions),
        "expected_cells": len(current) * len(definitions), "actual_cells": len(completed),
        "unrepresented_variables": [], "unknown_reference_fields": unknown,
        "variables_missing_from_original_panel": sorted(v for v in definitions if not all(v in r for r in current.values())),
        "primary_reference_overlap_company_years": len({(k[0], k[1]) for k in refs}),
        "comparison_counts": dict(Counter(c["comparison"] for c in comparisons)),
        "status_counts": dict(Counter(c["status"] for c in completed)), "pending_review_cells": len(pending),
        "all_values_extracted": not pending and all(not missing(c["value"]) for c in completed),
        "structural_coverage_pass": len(completed) == len(current) * len(definitions) and not unknown,
        "strict_release_pass": not pending and not unknown and not auxiliary_pending,
        "auxiliary_pending": auxiliary_pending,
        "neo_review": {"primary_rows": len(neo_rows), "reference_rows": len(neo_comparison),
                       "comparison_counts": dict(Counter(r["status"] for r in neo_comparison)), "arithmetic_pass": all(r["arithmetic_pass"] for r in neo_rows)},
        "external_events": event_summary,
        "auxiliary_coverage": auxiliary_coverage,
        "inputs": [{"file": Path(p).name, "sha256": hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in references],
        "output_hashes": {name: hashlib.sha256((out / name).read_bytes()).hexdigest()
                          for name in ["research_long.csv", "research_numeric.csv", "analysis_features.csv", "neo_verified.csv", "neo_comparison.csv"] if (out / name).is_file()},
        "created_at": datetime.now(timezone.utc).isoformat()}
    write_json(out / "review_summary.json", summary)
    write_json(out / "variable_audit.json", variable_audit)
    write_json(out / "reference_issues.json", issues)
    return summary, completed, comparisons, auxiliary, issues
