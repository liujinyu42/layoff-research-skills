"""版本对比：把两次构建的宽表逐格比较，产出可审计的修订日志。

这是"追踪"的核心。没有它，重跑只会覆盖旧结果，无法回答"上次是多少、为什么变了"。
"""

from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path

from layoffcore.io import write_csv

KEY = ["cid", "fy"]
REVISION_COLUMNS = ["cid", "cik", "fy", "var_id", "old_value", "new_value", "change_type", "detected_at"]


def _read(path: Path) -> tuple[list[str], dict[tuple, dict]]:
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        fields = reader.fieldnames or []
        rows = {}
        for r in reader:
            key = (r.get("cik") or r.get("cid"), r.get("fy"))
            if key in rows:
                raise ValueError(f"快照主键重复: {key}")
            rows[key] = r
    return fields, rows


def diff(prev: Path, cur: Path) -> tuple[list[dict], dict]:
    prev_fields, prev_rows = _read(prev)
    cur_fields, cur_rows = _read(cur)
    var_cols = [f for f in dict.fromkeys(prev_fields + cur_fields) if f not in {"cid", "cik", "company", "ticker", "fy"}]
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    revisions: list[dict] = []
    for key, new_row in cur_rows.items():
        old_row = prev_rows.get(key, {})
        for var in var_cols:
            old_v = (old_row.get(var) or "").strip()
            new_v = (new_row.get(var) or "").strip()
            if old_v == new_v:
                continue
            if not old_v and new_v:
                kind = "filled"
            elif old_v and not new_v:
                kind = "removed"
            else:
                kind = "changed"
            revisions.append(
                {
                    "cid": new_row.get("cid"),
                    "cik": new_row.get("cik"),
                    "fy": new_row.get("fy"),
                    "var_id": var,
                    "old_value": old_v,
                    "new_value": new_v,
                    "change_type": kind,
                    "detected_at": ts,
                }
            )
    for key, old_row in prev_rows.items():
        if key in cur_rows:
            continue
        for var in var_cols:
            old_v = (old_row.get(var) or "").strip()
            if old_v:
                revisions.append(
                    {
                        "cid": old_row.get("cid"),
                        "cik": old_row.get("cik"),
                        "fy": old_row.get("fy"),
                        "var_id": var,
                        "old_value": old_v,
                        "new_value": "",
                        "change_type": "dropped_entity",
                        "detected_at": ts,
                    }
                )

    summary: dict[str, int] = {}
    for r in revisions:
        summary[r["change_type"]] = summary.get(r["change_type"], 0) + 1
    return revisions, summary


def write_revisions(work: Path, revisions: list[dict]) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    out = work / "revisions" / f"revisions_{stamp}.csv"
    write_csv(out, revisions, REVISION_COLUMNS)
    return out
