"""完整性校验：证据可核验、状态可解释、键唯一。

校验失败不阻断数据生成，但必须阻断"把结果当已验证"的结论。
"""

from __future__ import annotations

import json
from pathlib import Path

from layoffcore.evidence import quote_matches
from layoffcore.schema import NA

SEVERITY_ORDER = {"error": 0, "warn": 1, "info": 2}


def _issue(kind: str, severity: str, message: str, **ctx) -> dict:
    return {"check": kind, "severity": severity, "message": message, **ctx}


def verify(work: Path, *, years: tuple[int, int] | None = None,
           max_report: int = 50) -> dict:
    issues: list[dict] = []

    pkg_dir = work / "derived" / "cells"
    packages: dict[str, dict] = {}
    for p in sorted(pkg_dir.glob("*.json")):
        pkg = json.loads(p.read_text(encoding="utf-8"))
        packages[pkg["accession"]] = pkg

    # 1) 证据引用必须能在落盘文本中复现
    ev_path = work / "panel" / "evidence_long.csv"
    text_cache: dict[str, str] = {}
    evidence_by_id = {}
    if ev_path.exists():
        import csv

        with ev_path.open("r", encoding="utf-8-sig", newline="") as fh:
            for row in csv.DictReader(fh):
                eid = row.get("evidence_id")
                if not eid or eid in evidence_by_id:
                    issues.append(_issue("evidence.duplicate_id", "error", f"证据ID缺失或重复: {eid}"))
                evidence_by_id[eid] = row
                if row.get("source_type") == "xbrl":
                    fp = work / (row.get("source_path") or f"raw/facts/facts_{row['cik']}.json")
                    if not fp.is_file():
                        issues.append(_issue("evidence.facts_missing", "error", str(fp)))
                        continue
                    payload = json.loads(fp.read_text(encoding="utf-8"))
                    from .xbrl import _facts_for_tag
                    candidates = _facts_for_tag(payload, row.get("quote", ""))
                    matches = [r for r in candidates if r.get("accn") == row.get("accession")
                               and r.get("_unit") == row.get("unit")
                               and str(r.get("end", "")) == row.get("period", "")
                               and float(r.get("val", "nan")) == float(row["value_num"])]
                    if not matches:
                        issues.append(_issue("evidence.fact_mismatch", "error", f"XBRL来源不匹配: {eid}"))
                    continue
                tp = row.get("text_path") or ""
                if not tp:
                    issues.append(_issue("evidence.text_missing", "error", f"无文本路径: {eid}"))
                    continue
                if tp not in text_cache:
                    fp = work / tp
                    text_cache[tp] = fp.read_text(encoding="utf-8") if fp.exists() else ""
                text = text_cache[tp]
                if not text:
                    issues.append(_issue("evidence.text_missing", "error",
                                         f"证据文本不存在: {tp}", accession=row.get("accession")))
                    continue
                if row.get("char_start") in ("", None) or row.get("char_end") in ("", None) or not row.get("quote"):
                    issues.append(_issue("evidence.span_missing", "error", f"文本证据无引用区间: {eid}"))
                    continue
                ok = quote_matches(text, int(row["char_start"]), int(row["char_end"]),
                                   row.get("quote", ""))
                if not ok:
                    issues.append(
                        _issue(
                            "evidence.quote_mismatch",
                            "error",
                            f"引用与原文不一致: {row.get('accession')} {row.get('var_id')}",
                            accession=row.get("accession"),
                            var_id=row.get("var_id"),
                        )
                    )
    else:
        issues.append(_issue("evidence.missing", "error", "缺少 evidence_long.csv"))

    # 2) 文本哈希与证据包一致
    for acc, pkg in packages.items():
        tp = pkg.get("text_path")
        if not tp:
            continue
        fp = work / tp
        if not fp.exists():
            issues.append(_issue("package.text_missing", "error", f"文本缺失: {tp}", accession=acc))
            continue
        from layoffcore.io import sha256_text

        if sha256_text(fp.read_text(encoding="utf-8")) != pkg.get("text_sha256"):
            issues.append(_issue("package.hash_mismatch", "error",
                                 f"文本哈希不一致: {tp}", accession=acc))

    # 3) 长表：缺失码必须合法，且 (cid,fy,var) 唯一
    long_path = work / "panel" / "panel_long.csv"
    valid_na = {n.value for n in NA}
    if long_path.exists():
        import csv

        seen: set[tuple] = set()
        with long_path.open("r", encoding="utf-8-sig", newline="") as fh:
            for row in csv.DictReader(fh):
                key = (row["cik"], row["fy"], row["var_id"])
                if key in seen:
                    issues.append(_issue("panel.duplicate_key", "error", f"重复键: {key}"))
                seen.add(key)
                na = (row.get("na_code") or "").strip()
                val = (row.get("value") or "").strip()
                if na and na not in valid_na:
                    issues.append(_issue("panel.bad_na_code", "error",
                                         f"非法缺失码: {na}", var_id=row["var_id"]))
                if not na and not val:
                    issues.append(_issue("panel.silent_blank", "error",
                                         f"既无取值也无缺失码: {key}"))
                if na and val:
                    issues.append(_issue("panel.value_and_na", "error", f"有值也有缺失码: {key}"))
                if val and row.get("evidence_id") not in evidence_by_id:
                    issues.append(_issue("panel.orphan_evidence", "error", f"取值无有效证据: {key}"))
                if years and na == NA.NOT_CHECKED.value:
                    issues.append(_issue("panel.not_checked", "warn",
                                         f"存在未查询单元格: {key}"))
    else:
        issues.append(_issue("panel.missing", "error", "缺少 panel_long.csv"))

    # SEC event quotes and WARN archived rows use their own source coordinates.
    from layoffcore.io import read_csv, sha256_text
    for row in read_csv(work / "events" / "layoff_disclosures.csv"):
        if row.get("source", "").startswith("sec_"):
            fp = work / (row.get("text_path") or "__missing__")
            if not fp.is_file():
                issues.append(_issue("event.text_missing", "error", row.get("event_id", "")))
                continue
            text = fp.read_text(encoding="utf-8")
            if sha256_text(text) != row.get("text_sha256"):
                issues.append(_issue("event.hash_mismatch", "error", row.get("event_id", "")))
            try:
                start, end = int(row["char_start"]), int(row["char_end"])
                valid = bool(row.get("evidence")) and 0 <= start < end <= len(text)
                valid = valid and quote_matches(text, start, end, row["evidence"])
            except (KeyError, TypeError, ValueError):
                valid = False
            if not valid:
                issues.append(_issue("event.quote_mismatch", "error", row.get("event_id", "")))
            if row.get("measurement_evidence"):
                from .layoff8k import _count_in, _pct_in
                from layoffcore.numbers import parse_amount
                try:
                    measurements = json.loads(row["measurement_evidence"])
                    for field, parser in [("layoff_count_num", _count_in), ("layoff_pct_num", _pct_in), ("severance_amount", parse_amount)]:
                        if row.get(field) in (None, ""):
                            continue
                        m = measurements[field]
                        s, e = int(m["char_start"]), int(m["char_end"])
                        source_ok = 0 <= s < e <= len(text) and text[s:e] == m["quote"] and m["raw"] in m["quote"]
                        parsed = parser(m["raw"])[0] if field == "severance_amount" else parser(m["quote"])[0]
                        if not source_ok or parsed is None or float(parsed) != float(row[field]):
                            issues.append(_issue("event.measurement_source_mismatch", "error", f"{row.get('event_id')}:{field}"))
                except (KeyError, ValueError, TypeError):
                    issues.append(_issue("event.measurement_proof_invalid", "error", row.get("event_id", "")))
        elif row.get("source") == "warn":
            fp = work / (row.get("source_file") or "__missing__")
            valid = False
            if fp.is_file():
                source_rows = read_csv(fp)
                try:
                    source_row = source_rows[int(row["source_row"]) - 2]
                    import hashlib
                    digest = hashlib.sha256(json.dumps(source_row, sort_keys=True).encode()).hexdigest()
                    valid = digest == row.get("content_sha256")
                except (KeyError, ValueError, IndexError):
                    pass
            if not valid:
                issues.append(_issue("event.warn_source_mismatch", "error", row.get("event_id", "")))

    # 4) 状态库：失败状态必须显式
    db_path = work / "state" / "state.db"
    if db_path.exists():
        from layoffcore.state import StateDB

        with StateDB(db_path) as db:
            counts = db.counts()
            for status, n in counts.items():
                if status not in {"parsed", "skipped"} and n:
                    issues.append(_issue("state.unresolved", "error",
                                         f"{status} 状态 {n} 个，未进入正式面板", status=status))
            for err in db.get_kv("discovery_errors", []):
                issues.append(_issue("state.discovery_failed", "error", str(err)))
            from layoffcore.io import sha256_file
            for filing in db.filings():
                if filing["status"] != "parsed":
                    continue
                source = work / (filing.get("path") or "__missing__")
                if not source.is_file() or sha256_file(source) != filing.get("sha256"):
                    issues.append(_issue("state.raw_hash_mismatch", "error",
                                         filing["accession"]))

    summary = {"error": 0, "warn": 0, "info": 0}
    for i in issues:
        summary[i["severity"]] = summary.get(i["severity"], 0) + 1
    issues.sort(key=lambda i: SEVERITY_ORDER.get(i["severity"], 9))
    return {
        "n_issues": len(issues),
        "summary": summary,
        "issues": issues[:max_report],
        "truncated": max(0, len(issues) - max_report),
        "packages": len(packages),
    }


def render(report: dict) -> str:
    lines = [
        f"校验结果：error={report['summary'].get('error', 0)} "
        f"warn={report['summary'].get('warn', 0)} "
        f"（证据包 {report['packages']} 份）"
    ]
    for i in report["issues"]:
        lines.append(f"  [{i['severity']}] {i['check']}: {i['message']}")
    if report["truncated"]:
        lines.append(f"  ... 另有 {report['truncated']} 条未显示")
    return "\n".join(lines)
