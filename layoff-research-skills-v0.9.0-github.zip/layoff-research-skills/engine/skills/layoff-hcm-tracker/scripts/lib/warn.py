"""州 WARN 备案归一化。

WARN 与 SEC 披露是两个体系：前者覆盖非上市公司、由州机构发布、以"通知"为单位；
后者是发行人自愿披露、以 accession 为单位。两者**不合并**，只在事件表中以 source 区分。
"""

from __future__ import annotations

import csv
import hashlib
import re
import json
from datetime import date
from pathlib import Path

# 列名别名。只做精确匹配（不区分大小写、去空白），不做模糊猜测。
ALIASES: dict[str, list[str]] = {
    "notice_id": ["notice_id", "record_id", "warn_id"],
    "address": ["address", "street_address", "site_address"],
    "company": ["company", "employer", "employer_name", "business_name", "name", "company_name"],
    "state": ["state", "state_code", "location_state"],
    "city": ["city", "location_city", "municipality"],
    "county": ["county", "location_county"],
    "notice_date": ["notice_date", "date", "filed_date", "warn_date", "received_date"],
    "effective_date": ["effective_date", "layoff_date", "separation_date", "start_date"],
    "employees": [
        "employees", "employees_affected", "number_of_employees", "num_employees",
        "affected_employees", "count", "workers", "total_employees",
    ],
    "notice_type": ["notice_type", "type", "layoff_type", "event_type"],
    "source_url": ["source_url", "url", "link"],
}


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (s or "").strip().lower()).strip("_")


def _build_map(fieldnames: list[str]) -> dict[str, str]:
    normalized = {_norm(f): f for f in fieldnames}
    mapping: dict[str, str] = {}
    for target, alias_list in ALIASES.items():
        for alias in alias_list:
            key = _norm(alias)
            if key in normalized:
                mapping[target] = normalized[key]
                break
    return mapping


def _to_int(v: str) -> int | None:
    if v is None:
        return None
    raw = str(v).strip().replace(",", "")
    return int(raw) if raw.isdigit() else None


def _to_iso(v: str) -> str:
    """只接受可识别的日期形态，其余原样保留（不做臆测转换）。"""
    s = (v or "").strip()
    m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    m = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})$", s)
    if m:
        return f"{m.group(3)}-{int(m.group(1)):02d}-{int(m.group(2)):02d}"
    return s


def event_id(source: str, *parts: object) -> str:
    raw = "|".join([source] + [str(p) for p in parts])
    return source[:3] + "-" + hashlib.sha256(raw.encode()).hexdigest()[:14]


def load_warn(path: str | Path, *, state_hint: str = "") -> list[dict]:
    """读取一份或多份州 WARN 文件（CSV），输出统一事件行。"""
    p = Path(path)
    files = sorted(p.glob("*.csv")) if p.is_dir() else [p]
    rows: list[dict] = []
    identities = {}
    for f in files:
        with f.open("r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            mapping = _build_map(reader.fieldnames or [])
            missing = {"company", "employees"} - set(mapping)
            if missing:
                raise ValueError(f"{f.name} 缺少必需列 {sorted(missing)}；实际列: {reader.fieldnames}")
            for row_number, rec in enumerate(reader, start=2):
                company = (rec.get(mapping["company"]) or "").strip()
                if not company:
                    continue
                state = (rec.get(mapping.get("state", ""), "") or state_hint or "").strip().upper()
                employees = _to_int(rec.get(mapping["employees"], ""))
                notice_date = _to_iso(rec.get(mapping.get("notice_date", ""), ""))
                effective = _to_iso(rec.get(mapping.get("effective_date", ""), ""))
                city = (rec.get(mapping.get("city", ""), "") or "").strip()
                address = (rec.get(mapping.get("address", ""), "") or "").strip()
                native_id = (rec.get(mapping.get("notice_id", ""), "") or "").strip()
                identity = event_id("warn", state, native_id) if native_id else event_id(
                    "warn", _norm(company), state, notice_date, effective, _norm(city), _norm(address))
                payload_hash = hashlib.sha256(json.dumps(rec, sort_keys=True).encode()).hexdigest()
                if identity in identities and identities[identity] != payload_hash:
                    raise ValueError(f"WARN身份冲突 {identity}；请提供官方 notice_id 或拆分地点")
                identities[identity] = payload_hash
                rows.append(
                    {
                        "event_id": identity,
                        "content_sha256": payload_hash,
                        "source_row": row_number,
                        "notice_id": native_id,
                        "address": address,
                        "source": "warn",
                        "cid": None,
                        "cik": None,
                        "company": company,
                        "ticker": None,
                        "accession": None,
                        "form": "WARN",
                        "filed": notice_date,
                        "event_date": effective or notice_date,
                        "item_codes": "",
                        "layoff_count_num": employees,
                        "layoff_pct_num": None,
                        "severance_amount": None,
                        "severance_currency": "UNKNOWN",
                        "severance_usd": None,
                        "severance_raw": "",
                        "evidence_id": None,
                        "evidence": f"{state} WARN: {company}",
                        "confidence": "high" if employees else "low",
                        "extractor_version": "warn-normalize",
                        "state": state,
                        "city": (rec.get(mapping.get("city", ""), "") or "").strip(),
                        "county": (rec.get(mapping.get("county", ""), "") or "").strip(),
                        "notice_type": (rec.get(mapping.get("notice_type", ""), "") or "").strip(),
                        "source_url": (rec.get(mapping.get("source_url", ""), "") or "").strip(),
                        "source_file": f.name,
                        "match_confidence": "unmatched",
                    }
                )
    return rows


def crosswalk(events: list[dict], companies: list[dict]) -> dict[str, int]:
    """把 WARN 记录按公司名/股票代码对齐到研究名单。

    只做规范化后的精确匹配，不做模糊匹配——错误对齐比不对齐更难发现。
    """
    by_name = {_norm(c["company"]): c for c in companies}
    by_ticker = {(c.get("ticker") or "").upper(): c for c in companies if c.get("ticker")}
    matched = 0
    for ev in events:
        key = _norm(ev["company"])
        target = by_name.get(key)
        conf = "exact_name"
        if target is None:
            target = by_ticker.get((ev["company"] or "").upper())
            conf = "ticker" if target else "unmatched"
        if target:
            ev["cid"] = target["cid"]
            ev["cik"] = target.get("cik") or None
            ev["ticker"] = target.get("ticker") or None
            ev["match_confidence"] = conf
            matched += 1
    return {"matched": matched, "unmatched": len(events) - matched}
