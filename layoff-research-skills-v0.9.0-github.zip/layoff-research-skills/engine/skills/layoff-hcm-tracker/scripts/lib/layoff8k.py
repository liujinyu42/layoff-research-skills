"""8-K / 6-K 裁员披露抽取（v0.3.1 修订版）。

保守优于完备：宁可留空，也不把员工总数、门店数或重组总费用写进裁员人数与遣散费。
本模块不合并重复披露——同一计划可能被多份申报重复披露，合并由 dedupe_events.py 负责。

v0.3.1 修复的三类已证实漏检/误检（Meta 2022-11-09 8-K 为回归基准）：
1. 触发词不认 "reduce the size of our team by about 13%" 与
   "let more than 11,000 of our talented employees go"，整条事件被判为无数值；
2. parse_count 要求"数字+员工名词"紧邻，无法识别 "11,000 of our talented employees"；
   parse_pct 只接受 "13% of workforce"，无法识别 "reduce ... by about 13%"；
3. 遣散费模式把 "$85"、"$3" 这类无单位残片当成金额，量级失真。
   现要求金额必须带 thousand/million/billion 单位，并排除每股/每人金额。
4. 同一句里合计与分项并存时取到分项（Shopify 2022 6-K：合计 $30.5M，却取了
   "with $10.9 million in sales and marketing"）。现按金额尾随的职能科目识别
   分项并剔除，优先取带 total/aggregate 的合计。
5. 遣散费是唯一数值时，引文仍停在触发词所在句，金额无处可核。现改取金额所在句。

取值顺序：先触发词所在句，再回退到 ±420 字符窗口；句内命中优先，避免抓到
同段落中无关的人数或增长率。
"""

from __future__ import annotations

import re

from layoffcore.numbers import parse_amount, parse_count, parse_pct

TRIGGERS = [
    r"reduction\s+in\s+(?:its\s+|our\s+)?(?:global\s+|total\s+)?(?:workforce|force|headcount)",
    r"reduce\s+(?:its\s+|our\s+)?(?:global\s+|total\s+)?(?:workforce|headcount)\s+by",
    r"workforce\s+reduction",
    r"\blayoffs?\b",
    r"\blaid\s+off\b",
    r"eliminat(?:e|ing)\s+(?:approximately\s+)?[\d,]+\s+(?:positions?|roles?|jobs?)",
    r"position\s+eliminations?",
    r"restructuring\s+(?:plan|initiative|program)\s+(?:that|which|designed)",
    r"reduc(?:e|ing)\s+(?:approximately\s+)?[\d,]+\s+(?:positions?|roles?|jobs?)",
    # --- v0.3.1 新增：真实公告中的其他高频写法 ---
    r"reduc(?:e|ing)\s+the\s+size\s+of\s+(?:our|its)\s+(?:team|workforce)",
    r"reduc(?:e|ing)\s+(?:our|its)\s+team\s+size",
    r"reduc(?:e|ing)\s+(?:our|its)\s+(?:company|team|workforce)\s+size\s+by",
    r"let\s+(?:more\s+than\s+|approximately\s+|about\s+|around\s+)?[\d,]+\s+[^.]{0,80}?\s+go\b",
    r"lay\s+off\s+(?:approximately\s+|about\s+|around\s+)?[\d,]+",
    r"cut\s+(?:approximately\s+|about\s+|around\s+)?[\d,]+\s+(?:jobs?|positions?|roles?)",
    r"(?:job|position|role)\s+cuts?\b",
]

# 一旦窗口出现这些表述，其中的数字不能当作裁员人数
REJECT_COUNT = [
    r"total\s+(?:number\s+of\s+)?employees",
    r"employees\s+(?:worldwide|globally|in\s+total)",
    r"we\s+employ\b",
    r"employs\s+(?:approximately\s+)?[\d,]{3,}\s+(?:employees|people)",
    r"headcount\s+of\s+[\d,]{3,}",
    r"customers",
    r"square\s+(?:feet|meters)",
    r"revenue",
]

REJECT_SEVERANCE = [
    r"total\s+restructuring\s+(?:charges?|costs?|expense)",
    r"expected\s+to\s+result\s+in\s+(?:total\s+)?(?:charges|costs)\s+of",
    r"per\s+(?:share|employee|person|hour)",
    # v0.3.1：遣散费"减少/冲回"不是遣散费支出。Shopify 2024-11-12 6-K 的
    # "offset by a decrease in severance related costs of $28 million associated
    # with the reduction in workforce in the second quarter of 2023" 被当成当年的
    # 遣散费入表。
    r"decrease\s+in\s+(?:severance|termination)",
    r"reversal\s+of\s+(?:severance|termination)",
]

# v0.3.1：金额后紧跟职能科目时，它是按职能拆分的分项，不是合计。
# Shopify 2022 6-K 原文："$30.5 million of severance related costs ... with
# $10.9 million in sales and marketing, $8.4 million in research and development
# and $11.2 million in general and administrative"——取到分项会让 severance 只有
# 合计的三分之一，且分项之和恰好等于合计，事后很难发现。
_COMPONENT_TAIL = re.compile(
    r"^\s*(?:,|and|or)?\s*(?:in|for|of|to)\s+(?:"
    r"sales\s+and\s+marketing|research\s+and\s+development|"
    r"general\s+and\s+administrative|cost\s+of\s+revenues?|"
    r"stock[-\s]based\s+compensation"
    r")\b",
    re.I,
)

# v0.3.1：金额被标注为重组总成本时同样不是遣散费。Meta 2023-07-26 8-K 原文：
# "approximately $4 billion of restructuring costs related to facilities consolidation
# charges and severance and other personnel costs"——$4B 含关店与减值，不能当遣散费。
_NOT_SEVERANCE_TAIL = re.compile(
    r"^\s*(?:,|and|or)?\s*(?:in|for|of|to)\s+(?:"
    r"restructuring|facilit(?:y|ies)\s+consolidation|impairment|exit\s+charges|office\s+space|real\s+estate"
    r")\b",
    re.I,
)

# v0.3.1：合计通常带 total/aggregate 字样，或写成 "$X million of severance"。
_TOTAL_HINT = re.compile(r"(?:total|aggregate)", re.I)

# 金额本身的位置。正则 2（"$X million ... severance"）的整个匹配跨越到 severance
# 之后，直接看 m.end() 后面的文字会看不到金额的紧跟修饰语，故单独定位金额。
_AMOUNT_RX = re.compile(
    r"(?:US\$|\$|€|£)\s*[\d.,]+\s*(?:million|billion|thousand)", re.I
)


def _amount_tail(text: str, m: re.Match) -> str:
    """返回金额之后 60 个字符，用于判断它属于哪个科目。"""
    am = _AMOUNT_RX.search(m.group(0))
    if not am:
        return ""
    end = m.start() + am.end()
    return text[end : end + 60]



# v0.3.1：金额必须带数量级单位。无单位的 "$85" 可能是表格残片、每股金额或
# 其他科目，写入面板会污染 severance_intensity（曾出现 1e-10 量级）。
SEVERANCE_PATTERNS = [
    r"(?:severance|termination\s+benefits?|one[-\s]time\s+termination)[^.]{0,90}?"
    r"(?:US\$|\$|€|£)\s*[\d.,]+\s*(?:million|billion|thousand)",
    # v0.3.1：金额与 severance 之间必须是 "of/in/for" 这类从属关系。
    # 原先允许 90 个任意字符，会把 "a reversal of ... liability of $55 million and
    # severance related costs of $18 million" 里的 $55M 当成遣散费。
    r"(?:US\$|\$|€|£)\s*[\d.,]+\s*(?:million|billion|thousand)\s+"
    r"(?:of|in|for)\s+(?:total\s+|aggregate\s+)?(?:severance|termination\s+benefits?)",
]

ITEM_CODES = [
    (r"item\s*2\.05", "2.05"),
    (r"item\s*2\.06", "2.06"),
    (r"item\s*5\.02", "5.02"),
]

# 裁员语境动词：只有同句含这些词，"by 13%" 才被解释为裁员比例
_LAYOFF_VERB = (
    r"reduc|cut|eliminat|lay\s*off|layoff|laid\s+off|let\s+[^.]{0,60}\s+go|"
    r"downsiz|rightsiz|restructur|sever|terminat"
)
# "11,000 of our talented employees"：数字与名词之间允许 of + 限定词 + 至多 4 个修饰词
_OF_COUNT = (
    r"(\d[\d,]*(?:\.\d+)?)\s+of\s+(?:our|its|the|their)\s+"
    r"(?:[\w'-]+\s+){0,4}?(?:employees|workers|people|staff|associates|team\s+members)"
)


def is_layoff_disclosure(text: str) -> bool:
    head = text[:20000]
    return any(re.search(rx, head, re.I) for rx in TRIGGERS)


def _sentences(text: str) -> list[tuple[int, int]]:
    spans: list[tuple[int, int]] = []
    cursor = 0
    for m in re.finditer(r"(?<=[.!?])\s+", text):
        spans.append((cursor, m.start()))
        cursor = m.end()
    spans.append((cursor, len(text)))
    return [(a, b) for a, b in spans if b > a]


def _window(text: str, pos: int, radius: int = 420) -> tuple[int, int]:
    return max(0, pos - radius), min(len(text), pos + radius)


def _has_reject(window: str, rejects: list[str]) -> bool:
    return any(re.search(rx, window, re.I) for rx in rejects)


def _sentence_at(spans: list[tuple[int, int]], pos: int, text: str) -> tuple[int, int]:
    for a, b in spans:
        if a <= pos <= b:
            return a, b
    return _window(text, pos, 200)


def _count_in(scope: str) -> tuple[int | None, str]:
    """裁员语境人数：先通用解析，再支持 "N of our ... employees" 句式。"""
    c, raw = parse_count(scope)
    if c is not None:
        return c, raw
    m = re.search(_OF_COUNT, scope, re.I)
    if m:
        return int(float(m.group(1).replace(",", ""))), m.group(0)
    return None, ""


def _pct_in(scope: str) -> tuple[float | None, str]:
    """裁员语境比例：支持 "13% of workforce" 与 "reduce ... by about 13%"。
    后者必须与裁员动词同句，避免把增长率/利润率当成裁员比例。"""
    p, raw = parse_pct(scope)
    if p is not None:
        return p, raw
    # "by 13%" 必须与裁员动词和员工基数词同句，否则 "reduce costs by 20%"
    # 这类成本削减表述会被误记为裁员比例。
    if re.search(_LAYOFF_VERB, scope, re.I) and re.search(
        r"team|workforce|employees?|staff|headcount|personnel|people", scope, re.I
    ):
        m = re.search(
            r"(?:by|of|from|approximately|about|around|nearly|more\s+than|over|up\s+to|equal\s+to)\s*"
            r"(?:approximately\s+|about\s+|around\s+|nearly\s+|more\s+than\s+|over\s+)?"
            r"(\d+(?:\.\d+)?)\s*(?:%|percent)",
            scope, re.I,
        )
        if m:
            return float(m.group(1)), m.group(0)
    return None, ""


def extract(text: str, period_year: int | None = None) -> dict:
    """返回单条披露记录。字段缺失即为 None，不做任何推断填充。

    period_year：本次申报所属期间的年份（event_date 的年份）。给定时用于剔除
    上一期间的比较数，未给定时不做期间判断。
    """
    triggers: list[tuple[int, int, str]] = []
    for rx in TRIGGERS:
        for m in re.finditer(rx, text, re.I):
            triggers.append((m.start(), m.end(), m.group(0)))
    triggers.sort()

    item_codes = sorted({code for rx, code in ITEM_CODES if re.search(rx, text, re.I)})
    sent_spans = _sentences(text)

    count_num = None
    count_span = ""
    count_scope = ""
    count_sent_pos: int | None = None
    count_sent_span: tuple[int, int] | None = None
    pct_num = None
    pct_span = ""
    pct_sent_span: tuple[int, int] | None = None
    event_pos: int | None = triggers[0][0] if triggers else None

    for t_start, t_end, _ in triggers:
        # 先句内：数字与触发词同句，语义最可靠
        s, e = _sentence_at(sent_spans, t_start, text)
        scopes = [("sentence", text[s:e])]
        lo, hi = _window(text, t_start)
        scopes.append(("window", text[lo:hi]))
        for scope_name, scope in scopes:
            if not scope.strip():
                continue
            if _has_reject(scope, REJECT_COUNT):
                continue
            c, raw = _count_in(scope)
            if c is None:
                continue
            count_num, count_span, count_scope = c, raw, scope_name
            count_sent_pos = s
            if scope_name == "sentence":
                count_sent_span = (s, e)
            else:
                # 人数是在 ±420 字符窗口里找到的，数字可能不在触发词所在句。
                # 引文要落在数字真正出现的那一句（Meta 2023-03-14 的
                # "we expect to announce restructurings and layoffs" 里没有人数）。
                idx = text.find(raw, lo, hi) if raw else -1
                if idx >= 0:
                    count_sent_span = _sentence_at(sent_spans, idx, text)
                    count_sent_pos = count_sent_span[0]
            event_pos = t_start
            break
        if count_num is not None:
            break

    # 比例：只在"含裁员动词或员工基数词"的句子中识别。
    # v0.3.0 的窗口回退会把同段落里的 "Revenue grew by 27%" 误当裁员比例，
    # 这里按句子逐一判断，并要求比例与裁员语境同句。
    # v0.3.1：不能用固定距离窗口。Meta 2022-11 的 8-K 正文只写
    # "layoff ... 11,000 employees"，而 "reduce the size of our team by about 13%"
    # 在后面的 Exhibit 99.1 公开信中，按 1500 字符过滤会漏掉比例。
    # 现改为扫描全文候选句，按与最近触发词的距离排序。
    trigger_positions = [tp[0] for tp in triggers] or [0]

    def _nearest(pos: int) -> int:
        return min(abs(pos - tp) for tp in trigger_positions)

    # 分档：tier 0 = 与人数同句；tier 1 = 与人数句相邻（≤600 字符）；
    # tier 2 = 其余。已知人数时只接受 0/1 两档——否则 Meta 2023-03 的信会
    # 把"去年我们 lay off 13% of our workforce"（2022-11 计划）贴到
    # 2023-03 的 10,000 人计划上。人数未知时才开放 tier 2（如 Shopify 23%）。
    pct_candidates: list[tuple[int, int, str, tuple[int, int]]] = []
    for a, b in sent_spans:
        seg = text[a:b]
        if not re.search(r"\d", seg):
            continue
        if not (re.search(_LAYOFF_VERB, seg, re.I) or parse_pct(seg)[0] is not None):
            continue
        tier = 2
        if count_num is not None and count_sent_pos is not None:
            c_here, _ = _count_in(seg)
            if c_here == count_num:
                tier = 0
            elif abs(a - count_sent_pos) <= 600:
                tier = 1
            else:
                continue
        pct_candidates.append((tier, _nearest(a), seg, (a, b)))
    pct_candidates.sort(key=lambda x: (x[0], x[1]))
    for _tier, _dist, scope, span in pct_candidates[:10]:
        if count_num is not None:
            # 比例必须与人数属于同一计划。Meta 2023-03 的 8-K 同时复述
            # 2022-11 计划（11,000 人 / 13%），若不看人数就会把 13% 错贴到
            # 2023-03 的 10,000 人计划上。
            other_count, _ = _count_in(scope)
            if other_count is not None and other_count != count_num:
                continue
        p, praw = _pct_in(scope)
        if p is not None:
            pct_num, pct_span, pct_sent_span = p, praw, span
            break

    sev_amount = None
    sev_ccy = "UNKNOWN"
    sev_raw = ""
    sev_pos: int | None = None
    # v0.3.1：不再"先命中先赢"。同一句里既有合计又有分项时，正则引擎会先碰到
    # 离 severance 更近的分项。这里收齐所有候选，先剔分项，再按"是否带 total/
    # aggregate 字样 → 出现位置"排序，取最可能是合计的那一个。
    sev_candidates: list[tuple[int, int, float, str, str]] = []
    for rx in SEVERANCE_PATTERNS:
        for m in re.finditer(rx, text, re.I):
            tail = _amount_tail(text, m)
            # Resolve the amount's own clause; a preceding personnel-cost list
            # cannot qualify a following office/property amount or range.
            if re.search(r'(?is)^\s*(?:to\s*\$?[\d.,]+\s*(?:million|billion)\s*)?(?:in\s+)?(?:exit\s+charges|office\s+space|real\s+estate)',tail):
                continue
            if _COMPONENT_TAIL.match(tail):
                continue
            if _NOT_SEVERANCE_TAIL.match(tail):
                continue
            lo, hi = _window(text, m.start(), 260)
            if _has_reject(text[lo:hi], REJECT_SEVERANCE):
                continue
            # v0.3.1：金额所在句明写的年份早于本次申报所属期间，说明这是上年
            # 比较数（Shopify 2024-05-08 6-K 复述 "In the second quarter of 2023,
            # we had $148 million of severance related costs"）。同一句也提到
            # 本期年份时保留，避免把跨期对照句一并删除。
            if period_year is not None:
                # 只看金额之前的 120 个字符：那里如果有明确的期间短语
                # （"In the second quarter of 2023, we had $148 million ..."），
                # 且年份早于本次申报期间，就是上年比较数。不用整句或大窗口判断，
                # 因为表格文本会把多个年度并排（"2024 2023 2024 2023"），
                # 只要窗口里出现本期年份就会被误判为当期。
                pre = text[max(0, m.start() - 120) : m.start()]
                pre_years = {int(y) for y in re.findall(r"\b(?:19|20)\d{2}\b", pre)}
                if pre_years and max(pre_years) < period_year:
                    continue
                from .rules import _period_year_near, _years_in
                a, b = _sentence_at(sent_spans, m.start(), text)
                py = _period_year_near(text, m.start(), text[a:b])
                if py is not None and py != period_year:
                    continue
                if py is None and len(_years_in(text[a:b])) > 1:
                    continue
            amount, ccy, raw = parse_amount(m.group(0))
            if amount is None or amount < 1000:
                continue
            hint = 0 if _TOTAL_HINT.search(text[max(0, m.start() - 120) : m.end()]) else 1
            sev_candidates.append((hint, m.start(), amount, ccy, raw))
    if sev_candidates:
        sev_candidates.sort(key=lambda c: (c[0], c[1]))
        _hint, sev_pos, sev_amount, sev_ccy, sev_raw = sev_candidates[0]

    if count_num is not None and pct_num is not None:
        confidence = "high" if count_scope == "sentence" else "medium"
    elif count_num is not None or pct_num is not None:
        confidence = "medium"
    else:
        confidence = "low"

    # 触发词本身不足以构成一次裁员披露：股东提案标题里也会出现 "layoff"
    # （Walmart 2023-05-31 的 8-K，Item 5.07，标题为 "racial and gender layoff
    # diversity report"）。因此要求同时具备以下之一才写入事件表：
    #   (a) 与触发词同句/同窗的人数、比例或遣散费数值；
    #   (b) 申报含 Item 2.05（退出/处置成本）或 Item 2.06（重大减值）。
    has_number = count_num is not None or pct_num is not None or sev_amount is not None
    has_layoff_item = any(code in ("2.05", "2.06") for code in item_codes)
    qualified = bool(triggers) and (has_number or has_layoff_item)

    # v0.3.1：引文要落在"能核对到数值"的那一句。原先固定在触发词所在句，
    # 会出现引文里没有数值、数值所在的句子又没被引用的情形（Shopify 2022 6-K
    # 引了股票期权没收的句子，而 10% 在另一句）。优先级：人数句 > 比例句 >
    # 金额句 > 触发词句。
    quote_span = (0, 0)
    anchor = event_pos if event_pos is not None else (triggers[0][0] if triggers else None)
    if count_sent_span is not None:
        quote_span = count_sent_span
    elif pct_sent_span is not None:
        quote_span = pct_sent_span
    elif sev_pos is not None:
        quote_span = _sentence_at(sent_spans, sev_pos, text)
    elif anchor is not None:
        quote_span = _sentence_at(sent_spans, anchor, text)

    measurements = {}
    for name, value, span, raw in [
            ("layoff_count_num", count_num, count_sent_span, count_span),
            ("layoff_pct_num", pct_num, pct_sent_span, pct_span),
            ("severance_amount", sev_amount, _sentence_at(sent_spans, sev_pos, text) if sev_pos is not None else None, sev_raw)]:
        if value is not None and span is not None:
            a, b = span
            from layoffcore.event_measures import measurement_context
            measurements[name] = {"value": value, "raw": raw, "char_start": a, "char_end": b, "quote": text[a:b], **measurement_context(text[a:b], raw)}
    if 'severance_amount' in measurements:
        m=measurements['severance_amount'];q=m['quote']
        m['expense_nature']='mixed_severance_and_personnel_costs'if re.search(r'(?i)and (?:related|other) personnel|employee benefits|share-based',q)else'candidate_severance'
        m['measurement_scope']='plan_estimate'if re.search(r'(?i)expect|estimat|anticipat',q)else'expense_period_review_required'
    other_plans = []
    for a, b in sent_spans:
        seg = text[a:b]
        candidate, raw = _count_in(seg)
        if candidate is not None and candidate != count_num and re.search(_LAYOFF_VERB, seg, re.I) and not _has_reject(seg, REJECT_COUNT):
            other_plans.append({"value": candidate, "raw": raw, "quote": seg, "char_start": a, "char_end": b, "status": "plan_identity_and_date_review_required"})
    if other_plans:
        measurements["additional_plan_candidates"] = other_plans
    return {
        "is_layoff": qualified,
        "skip_reason": "" if qualified or not triggers else
                       "触发词命中但无裁员数值、也无 Item 2.05/2.06",
        "item_codes": item_codes,
        "layoff_count_num": count_num,
        "layoff_pct_num": pct_num,
        "severance_amount": sev_amount,
        "severance_currency": sev_ccy,
        "severance_usd": sev_amount if sev_ccy == "USD" else None,
        "severance_raw": sev_raw,
        "char_start": quote_span[0],
        "char_end": quote_span[1],
        "evidence": text[quote_span[0] : quote_span[1]].strip()[:600],
        "confidence": confidence,
        "trigger": triggers[0][2] if triggers else "",
        "pct_raw": pct_span,
        "measurement_evidence": measurements,
    }
