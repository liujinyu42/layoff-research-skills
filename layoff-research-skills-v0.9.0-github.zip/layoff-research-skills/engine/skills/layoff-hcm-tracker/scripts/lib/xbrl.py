"""XBRL 取数：从 company facts 中按标签优先级取年度数值。

口径：
- 保留原始 unit 与 accession，不做单位换算；
- 同一标签有多个申报版本时取期间结束日最晚的一条；
- 字段名相同不代表跨发行人可比（金融/IFRS 尤其如此）。
"""

from __future__ import annotations

from pathlib import Path
from datetime import date
from typing import Any

from layoffcore.io import read_json
from layoffcore.schema import NA

TAG_MAP: dict[str, list[str]] = {
    "revenue": [
        "RevenueFromContractWithCustomerExcludingAssessedTax",
        "Revenues",
        "RevenueFromContractWithCustomerIncludingAssessedTax",
        "SalesRevenueNet",
    ],
    "operating_income": ["OperatingIncomeLoss"],
    "net_income": ["NetIncomeLoss"],
    "total_assets": ["Assets"],
    "total_liabilities": ["Liabilities", "DERIVED:Assets-TotalEquity"],
    "restructuring_charges": ["RestructuringCharges", "RestructuringSettlementAndImpairmentProvisions"],
    "total_comp_expense": ["EmployeeBenefitsAndShareBasedCompensation", "LaborAndRelatedExpense"],
    # Health/insurance benefits are not equivalent to postretirement expense.
    "benefits_expense": [],
    "sbc": ["ShareBasedCompensation"],
    # Option counts are not the value or complete set of RSU/PSU/option grants.
    "equity_grants": [],
    "pension": ["DefinedBenefitPlanNetPeriodicBenefitCost"],
    "rd_expense": ["ResearchAndDevelopmentExpense"],
    "capex": ["PaymentsToAcquirePropertyPlantAndEquipment"],
    "intangibles": ["IntangibleAssetsNetExcludingGoodwill"],
    "iprd": ["PaymentsToAcquireInProcessResearchAndDevelopment"],
}

ANNUAL_FORMS = {"10-K", "10-K/A", "20-F", "20-F/A"}


def load_facts(path: str | Path | None) -> dict:
    if not path:
        return {}
    return read_json(path, default={}) or {}


def _facts_for_tag(payload: dict, tag: str) -> list[dict]:
    if tag == "DERIVED:Assets-TotalEquity":
        # A disclosure of equity + liabilities is enough to reconstruct total
        # liabilities, but only within the SAME filing, period and currency.
        assets = _facts_for_tag(payload, "Assets")
        equity_tags = ["StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest",
                       "StockholdersEquity", "Equity"]
        result = []
        for asset in assets:
            if asset.get("start") or asset.get("val") is None:
                continue
            for equity_tag in equity_tags:
                matches = [e for e in _facts_for_tag(payload, equity_tag)
                    if not e.get("start") and e.get("accn") == asset.get("accn")
                    and e.get("end") == asset.get("end") and e.get("_unit") == asset.get("_unit")
                    and e.get("val") is not None]
                if not matches:
                    continue
                if len({e["val"] for e in matches}) != 1:
                    break
                # Parent-only equity cannot substitute for total equity where
                # non-controlling interests are separately reported.
                if equity_tag == "StockholdersEquity":
                    minority = [e for tag in ["MinorityInterest","NonredeemableNoncontrollingInterest"] for e in _facts_for_tag(payload, tag)
                        if e.get("accn") == asset.get("accn") and e.get("end") == asset.get("end")
                        and e.get("_unit") == asset.get("_unit") and e.get("val") not in (None, 0)]
                    if minority:
                        break
                def same_context(tag):
                    values={e['val'] for e in _facts_for_tag(payload,tag) if not e.get('start')and e.get('accn')==asset.get('accn')and e.get('end')==asset.get('end')and e.get('_unit')==asset.get('_unit')and e.get('val')is not None}
                    return next(iter(values))if len(values)==1 else None
                aggregate=same_context('TemporaryEquityCarryingAmountIncludingPortionAttributableToNoncontrollingInterests')
                temporary=aggregate if aggregate is not None else sum(same_context(tag)or 0 for tag in ['TemporaryEquityCarryingAmountAttributableToParent','RedeemableNoncontrollingInterestEquityCarryingAmount'])
                value = asset["val"] - matches[0]["val"] - temporary
                if value < 0:
                    break
                result.append({**asset, "val": value, "_tag": tag,
                               "_formula": f"Assets-{equity_tag}"+("-temporary_equity"if temporary else""),
                               "_inputs": [asset["val"], matches[0]["val"]]+([temporary]if temporary else[])})
                break
        return result
    for ns in ("us-gaap", "ifrs-full"):
        node = (payload.get("facts") or {}).get(ns, {}).get(tag)
        if node:
            rows: list[dict] = []
            for unit, entries in (node.get("units") or {}).items():
                for e in entries:
                    rec = dict(e)
                    rec["_unit"] = unit
                    rec["_tag"] = tag
                    rows.append(rec)
            return rows
    return []


def value_for_year(payload: dict, tags: list[str], fy: int, *, accession: str = "",
                   period: str = "") -> tuple[float | None, str, str, str]:
    """返回 (数值, 单位, accession, 标签)。找不到返回 (None, '', '', '')。"""
    for tag in tags:
        rows = _facts_for_tag(payload, tag)
        candidates = []
        for r in rows:
            if r.get("form") not in ANNUAL_FORMS:
                continue
            if accession and r.get("accn") != accession:
                continue
            end = str(r.get("end") or "")
            if period and end != period:
                continue
            if not period and end[:4] != str(fy):
                continue
            # fy describes the filing, not necessarily this fact's period. Exclude quarterly
            # and comparative facts from a later annual filing. Instant facts have no start.
            if r.get("start"):
                try:
                    days = (date.fromisoformat(end) - date.fromisoformat(r["start"])).days
                except ValueError:
                    continue
                if not 300 <= days <= 430:
                    continue
            if r.get("val") is None:
                continue
            candidates.append(r)
        if not candidates:
            continue
        candidates.sort(key=lambda r: (str(r.get("end") or ""), str(r.get("filed") or "")), reverse=True)
        best = candidates[0]
        same_context = [r for r in candidates if r.get("end") == best.get("end")
                        and r.get("filed") == best.get("filed")]
        if len({(r["val"], r.get("_unit")) for r in same_context}) > 1:
            # Conflicting units/values need explicit accounting review.
            continue
        return float(best["val"]), str(best.get("_unit") or ""), str(best.get("accn") or ""), tag
    return None, "", "", ""


def derive_cells(payload: dict, fy: int, *, require_any: bool = False,
                 accession: str = "", period: str = "") -> dict[str, dict]:
    """对每个映射变量返回 {value, unit, accession, tag, na_code, confidence}。"""
    out: dict[str, dict] = {}
    if not payload:
        for var in TAG_MAP:
            out[var] = {"value": None, "unit": "", "accession": "", "tag": "",
                        "na_code": NA.INCOMPLETE.value, "confidence": "low"}
        return out
    for var, tags in TAG_MAP.items():
        if not tags:
            out[var] = {"value": None, "unit": "", "accession": "", "tag": "",
                        "na_code": NA.NOT_SEPARATE.value, "confidence": "low"}
            continue
        value, unit, accn, tag = value_for_year(payload, tags, fy, accession=accession, period=period)
        if value is None:
            out[var] = {"value": None, "unit": "", "accession": "", "tag": "",
                        "na_code": NA.NOT_DISCLOSED.value, "confidence": "high"}
        else:
            out[var] = {"value": value, "unit": unit, "accession": accn, "tag": tag,
                        "na_code": "", "confidence": "high"}
    return out


def unit_currency(unit: str) -> str:
    u = (unit or "").upper()
    if u in {"USD", "EUR", "GBP", "CAD", "JPY"}:
        return u
    return "UNKNOWN"


def summarize(cells: dict[str, Any]) -> dict[str, int]:
    filled = sum(1 for c in cells.values() if c.get("value") is not None)
    return {"filled": filled, "total": len(cells)}
