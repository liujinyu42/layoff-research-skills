"""Read explicit-context iXBRL facts; never infer a compensation year from filing year.

Numeric normalization follows the reader in the user-provided panel v1.1.0 archive.
This version keeps context dates, dimensions and source offsets for audit.
"""
from decimal import Decimal, InvalidOperation
from html import unescape
import re

ATTR = re.compile(r'''([\w:.-]+)\s*=\s*(["'])(.*?)\2''', re.S)
CONTEXT = re.compile(r'<(?:[\w.-]+:)?context\b([^>]*)>(.*?)</(?:[\w.-]+:)?context\s*>', re.I | re.S)
PERIOD = re.compile(r'<(?:[\w.-]+:)?(instant|endDate|startDate)\b[^>]*>\s*(\d{4}-\d{2}-\d{2})\s*</(?:[\w.-]+:)?\1\s*>', re.I)
# Text-block nonNumeric facts may enclose the entire numeric compensation table.
# Matching those outer blocks would consume and silently hide all inner facts.
ELEMENT = re.compile(r'<ix:(nonFraction)\b([^>]*)>(.*?)</ix:\1\s*>', re.I | re.S)

def attrs(text):
    return {k.lower(): unescape(v) for k, _, v in ATTR.findall(text)}

def numeric_facts(html):
    contexts = {}
    for raw, body in CONTEXT.findall(html):
        attributes = attrs(raw)
        dates = {k.lower(): v for k, v in PERIOD.findall(body)}
        if attributes.get("id"):
            contexts[attributes["id"]] = {"start": dates.get("startdate", ""),
                "end": dates.get("enddate") or dates.get("instant", ""),
                "dimensions": re.findall(r'<[^>]*explicitMember\b[^>]*>(.*?)</[^>]*explicitMember>', body, re.I | re.S)}
    out = []
    for match in ELEMENT.finditer(html):
        a = attrs(match.group(2))
        if a.get("xsi:nil", "").lower() == "true":
            continue
        ctx = contexts.get(a.get("contextref", ""))
        if not ctx or not ctx["end"]:
            continue
        value = unescape(re.sub(r"<[^>]+>", "", match.group(3))).strip().replace("−", "-")
        value = re.sub(r"\s+", "", value).replace("$", "")
        transform = a.get("format", "").split(":")[-1].lower().replace("-", "")
        if transform in {"numcommadecimal", "numcommadecimalin"}:
            value = value.replace(".", "").replace(",", ".")
        elif transform in {"", "numdotdecimal", "numdotdecimalin", "numcommadot"}:
            value = value.replace(",", "")
        elif transform in {"numdash", "zerodash"} and value in {"-", "—", "–"}:
            value = "0"
        else:
            continue
        if value.startswith("(") and value.endswith(")"):
            value = "-" + value[1:-1]
        try:
            number = Decimal(value)
            scale = int(a.get("scale", "0"))
            if not number.is_finite() or not -100 <= scale <= 100:
                continue
            number *= Decimal(10) ** scale
            if a.get("sign") == "-":
                number = -abs(number)
            elif a.get("sign") not in {None, "", "+"}:
                continue
        except (InvalidOperation, ValueError):
            continue
        out.append({**ctx, "tag": a.get("name", ""), "context": a.get("contextref", ""),
                    "unit": a.get("unitref", ""), "value": float(number),
                    "html_start": match.start(), "html_end": match.end()})
    return out
