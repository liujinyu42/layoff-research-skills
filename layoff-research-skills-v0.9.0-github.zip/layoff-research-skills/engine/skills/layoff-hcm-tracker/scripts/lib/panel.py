"""面板构建：把证据包汇总成长表（唯一真相）/ 宽表（视图）/ 证据长表 / 元数据。

规则：
- 同一 (cik, fy) 有多份年报（如 10-K 与 10-K/A）时，取申报日期最晚的一份作为主源；
  所有包的证据都写入证据长表（``is_primary`` 区分），不丢弃非主源证据。
- 长表覆盖全部变量：有值写值，无值写缺失码。宽表只是长表的透视视图。
- 主源与非主源取值不一致时计入 ``conflicts``，不静默取其一。
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from layoffcore.evidence import make_evidence
from layoffcore.io import sha256_file, write_csv, write_json
from layoffcore.schema import (
    EVIDENCE_COLUMNS,
    NA,
    NA_EXPLAIN_ZH,
    PANEL_LONG_COLUMNS,
    TOOL_VERSION,
)

KEY_COLS = ["cid", "cik", "company", "ticker", "fy"]


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_packages(work: Path) -> list[dict]:
    cells_dir = work / "derived" / "cells"
    if not cells_dir.exists():
        return []
    return [json.loads(p.read_text(encoding="utf-8")) for p in sorted(cells_dir.glob("*.json"))]


def _pick_primary(packages: list[dict], filed_map: dict[str, str]) -> dict[tuple, str]:
    """Choose complete annual anchors, never proxy-only rows or partial amendments."""
    primary = {}
    for pkg in packages:
        if pkg["form"] not in {"10-K", "20-F"}:
            continue
        key = (str(pkg["cik"]), int(pkg["fy"]))
        cand = (filed_map.get(pkg["accession"], ""), pkg["accession"])
        best = primary.get(key)
        if best is None or cand > (filed_map.get(best, ""), best):
            primary[key] = pkg["accession"]
    return primary


def _cell_sources(packages, anchors, var_book, filed_map):
    """Annual amendment values overlay complete annuals; Item 11 may use a proxy.

    A missing value in a partial amendment must not erase a value in the full report.
    Retain all candidates in evidence_long; selection is per variable, not per document.
    """
    sources = {}
    for key, anchor in anchors.items():
        group = [p for p in packages if (str(p["cik"]), int(p["fy"])) == key]
        for var in var_book:
            vid = var["var_id"]
            candidates = []
            for pkg in group:
                is_proxy = pkg["form"].startswith("DEF")
                if is_proxy and str(var.get("section")) != "11":
                    continue
                cell = next((c for c in pkg["cells"] if c["var_id"] == vid), None)
                if cell is None:
                    continue
                # Code targets prefer a full source document over a section-less amendment.
                code_section = str(var.get("section", ""))
                has_section = code_section in pkg.get("sections", {})
                score = (cell.get("value") is not None,
                         bool(is_proxy) if code_section == "11" else False,
                         has_section, pkg["accession"] == anchor if cell.get("value") is None else False,
                         filed_map.get(pkg["accession"], ""), pkg["accession"])
                candidates.append((score, pkg["accession"]))
            if candidates:
                sources[key + (vid,)] = max(candidates)[1]
    return sources


def build(work: Path, companies: list[dict], var_book: list[dict],
          filed_map: dict[str, str], fy_window: tuple[int, int] | None = None) -> dict:
    packages = [p for p in load_packages(work) if p["accession"] in filed_map]
    if not packages:
        raise RuntimeError("没有可用的证据包，请先运行 extract")
    # 抓取按申报年份枚举，因此窗口首年之前一个财年的年报也可能被下载
    # （例如 2022 年 2 月申报的 FY2021 10-K）。财年窗口在这里截断，
    # 并在元数据里记录被排除的观测数，避免样本范围被静默放大。
    dropped_outside_window: list[dict] = []
    if fy_window:
        kept = []
        for p in packages:
            if fy_window[0] <= int(p["fy"]) <= fy_window[1]:
                kept.append(p)
            else:
                dropped_outside_window.append({"cik": str(p["cik"]), "fy": int(p["fy"]),
                                               "accession": p["accession"]})
        packages = kept
        if not packages:
            raise RuntimeError(f"财年窗口 {fy_window[0]}:{fy_window[1]} 内没有可用证据包")

    company_by_cid = {c["cid"]: c for c in companies}
    var_order = [v["var_id"] for v in var_book]
    primary = _pick_primary(packages, filed_map)
    if not primary:
        raise RuntimeError("缺少已解析的完整 10-K/20-F；代理声明或修正件不能单独制造年度观测")
    sources = _cell_sources(packages, primary, var_book, filed_map)

    long_rows: list[dict] = []
    ev_rows: list[dict] = []
    values_by_key: dict[tuple, float] = {}
    seen_keys: set[tuple] = set()
    conflicts = 0

    for pkg in packages:
        cid, cik, fy = int(pkg["cid"]), str(pkg["cik"]), int(pkg["fy"])
        if (cik, fy) not in primary:
            continue
        company = company_by_cid.get(cid, {})

        for cell in pkg["cells"]:
            var_id = cell["var_id"]
            key = (cik, fy, var_id)
            is_primary = sources.get(key) == pkg["accession"]
            value = cell.get("value")

            ev_id = ""
            if value is not None:
                ev = make_evidence(
                    cid=cid,
                    cik=cik,
                    fy=fy,
                    var_id=var_id,
                    value_raw=str(cell.get("value_raw", ""))[:200],
                    value_num=value,
                    unit=cell.get("unit", ""),
                    currency=cell.get("currency", "UNKNOWN"),
                    source_type=cell.get("source_type", "text"),
                    form=pkg["form"],
                    accession=cell.get("evidence_accession") or pkg["accession"],
                    section=cell.get("section", ""),
                    char_start=cell.get("char_start"),
                    char_end=cell.get("char_end"),
                    quote=cell.get("quote", ""),
                    confidence=cell.get("confidence", "high"),
                    extractor=cell.get("extractor", "rule"),
                    created_at=_now(),
                )
                ev["is_primary"] = 1 if is_primary else 0
                ev["text_path"] = pkg.get("text_path", "")
                ev["period"] = pkg.get("period", "")
                ev["source_path"] = f"raw/facts/facts_{cik}.json" if cell.get("source_type") == "xbrl" else pkg.get("text_path", "")
                ev_rows.append(ev)
                ev_id = ev["evidence_id"]

                if key in values_by_key and values_by_key[key] != value:
                    conflicts += 1
                values_by_key.setdefault(key, value)

            if not is_primary or key in seen_keys:
                continue
            seen_keys.add(key)
            long_rows.append(
                {
                    "cid": cid,
                    "cik": cik,
                    "company": company.get("company", ""),
                    "ticker": company.get("ticker", ""),
                    "fy": fy,
                    "var_id": var_id,
                    "value": value if value is not None else "",
                    "value_type": cell.get("value_type", ""),
                    "unit": cell.get("unit", ""),
                    "na_code": cell.get("na_code", "") if value is None else "",
                    "source_type": cell.get("source_type", ""),
                    "evidence_id": ev_id,
                    "form": pkg["form"],
                    "accession": pkg["accession"],
                    "period": pkg.get("period", ""),
                }
            )

    index = {v: i for i, v in enumerate(var_order)}
    long_rows.sort(key=lambda r: (r["cid"], r["fy"], index.get(r["var_id"], 999)))

    wide_rows = _pivot(long_rows, var_order)

    write_csv(work / "panel" / "panel_long.csv", long_rows, PANEL_LONG_COLUMNS)
    write_csv(work / "panel" / "panel_wide.csv", wide_rows, KEY_COLS + var_order)
    write_csv(work / "panel" / "evidence_long.csv", ev_rows,
              EVIDENCE_COLUMNS + ["is_primary", "text_path", "period", "source_path"])
    meta = _meta(long_rows, ev_rows, var_book, packages, conflicts)
    meta["fy_window"] = list(fy_window) if fy_window else None
    meta["headcount_measurements"] = [
        {"cik": r["cik"], "fy": r["fy"], "unit": r.get("unit"),
         "basis": "fte" if r.get("unit") == "FTE" else "employees" if r.get("unit") == "employees" else "unknown",
         "accession": r["accession"]} for r in long_rows if r["var_id"] == "headcount"]
    meta["dropped_outside_window"] = dropped_outside_window
    meta["company_periods"] = [
        {"cik": p["cik"], "fy": p["fy"], "period": p.get("period", ""), "accession": p["accession"]}
        for p in packages if primary.get((str(p["cik"]), int(p["fy"]))) == p["accession"]]
    meta["panel_sha256"] = sha256_file(work / "panel" / "panel_long.csv")
    write_json(work / "panel" / "panel_meta.json", meta)

    return {
        "n_long_rows": len(long_rows),
        "n_wide_rows": len(wide_rows),
        "n_evidence": len(ev_rows),
        "n_packages": len(packages),
        "conflicts": conflicts,
        "fy_window": list(fy_window) if fy_window else None,
        "dropped_outside_window": dropped_outside_window,
    }


def _pivot(long_rows: list[dict], var_order: list[str]) -> list[dict]:
    by_key: dict[tuple, dict] = {}
    for row in long_rows:
        key = (row["cik"], row["fy"])
        if key not in by_key:
            by_key[key] = {k: row[k] for k in KEY_COLS}
        if row["value"] != "" and row["value"] is not None:
            by_key[key][row["var_id"]] = row["value"]
    rows = sorted(by_key.values(), key=lambda r: (r["cid"], r["fy"]))
    for r in rows:
        for v in var_order:
            r.setdefault(v, "")
    return rows


def _meta(long_rows: list[dict], ev_rows: list[dict], var_book: list[dict],
          packages: list[dict], conflicts: int) -> dict:
    var_stats: dict[str, dict] = {}
    for v in var_book:
        rows = [r for r in long_rows if r["var_id"] == v["var_id"]]
        na_counts: dict[str, int] = {}
        filled = 0
        for r in rows:
            if r["value"] not in ("", None):
                filled += 1
            elif r["na_code"]:
                na_counts[r["na_code"]] = na_counts.get(r["na_code"], 0) + 1
        var_stats[v["var_id"]] = {
            "source_type": v["source_type"],
            "n_obs": len(rows),
            "n_filled": filled,
            "fill_rate": round(filled / len(rows), 4) if rows else 0.0,
            "na_composition": na_counts,
        }

    years = sorted({r["fy"] for r in long_rows})
    return {
        "tool_version": TOOL_VERSION,
        "built_at": _now(),
        "n_packages": len(packages),
        "forms": sorted({p["form"] for p in packages}),
        "years": years,
        "n_companies": len({r["cid"] for r in long_rows}),
        "n_evidence": len(ev_rows),
        "conflicts": conflicts,
        "na_legend": {n.value: NA_EXPLAIN_ZH[n] for n in NA},
        "var_stats": var_stats,
        "year_stats": {
            y: {
                "n_companies": len({r["cid"] for r in long_rows if r["fy"] == y}),
                "n_filled_cells": sum(1 for r in long_rows
                                      if r["fy"] == y and r["value"] not in ("", None)),
            }
            for y in years
        },
        "inputs": [
            {"accession": p["accession"], "form": p["form"], "fy": p["fy"],
             "text_sha256": p.get("text_sha256", "")}
            for p in packages
        ],
    }
