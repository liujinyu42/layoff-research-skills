"""Detect unresolved disclosure pairs without asserting they are one plan."""
from datetime import date
import math

def present(v):return v is not None and str(v).strip().lower()not in {'','nan','none'}
def number(v):
 try:
  n=float(v);return n if math.isfinite(n)else None
 except(ValueError,TypeError):return None

def possible_duplicate(a,b):
 if str(a.get('cik'))!=str(b.get('cik')):return False
 if present(a.get('plan_id'))and present(b.get('plan_id')):return False
 try:
  da=date.fromisoformat(str(a.get('event_date')or a.get('filed'))[:10]);db=date.fromisoformat(str(b.get('event_date')or b.get('filed'))[:10])
 except(ValueError,TypeError):return False
 if abs((da-db).days)>540:return False
 ca,cb=number(a.get('layoff_count_num')),number(b.get('layoff_count_num'));pa,pb=number(a.get('layoff_pct_num')),number(b.get('layoff_pct_num'))
 return(ca is not None and ca==cb)or(ca is None and cb is None and pa is not None and pa==pb)
