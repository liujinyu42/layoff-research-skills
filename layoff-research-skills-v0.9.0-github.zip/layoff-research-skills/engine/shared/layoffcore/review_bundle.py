"""Group source review by company-year/scope without changing judgment requirements."""
from pathlib import Path
import argparse,json,hashlib,re
from .io import read_json,read_csv,write_json
from .source_cache import SourceCache

def sha(text):return hashlib.sha256(text.encode()).hexdigest()
def jsonl(path):return [json.loads(line)for line in Path(path).read_text().splitlines()if line.strip()]if Path(path).is_file()else[]

def prepare(work,out,phase='first',include_completed=False,coder='A',review_task_files=()):
    w=Path(work).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    sources={};scopes={};definitions={};tasks=[];issues=[];documents=SourceCache();normal={};raw_scope_chars=0
    # Full task records stay in a sidecar. Human/model context uses references instead.
    import yaml,sqlite3
    book_path=w/'coding/codebook.yaml';book=yaml.safe_load(book_path.read_text())if book_path.is_file()else{};book=book.get('codes',book)or{}
    state_years={}
    dbpath=w/'state/state.db'
    if dbpath.is_file():
        db=sqlite3.connect(dbpath.as_uri()+'?mode=ro',uri=True);state_years={a:int(y)for a,y in db.execute("SELECT accession,fy FROM filings WHERE form IN ('10-K','20-F','40-F')")};db.close()
    coding=[]
    if phase=='first':
        for p in sorted((w/'coding/batches').glob('batch_*.jsonl')):coding.extend(jsonl(p))
        audit=read_json(w/'coding/code_audit.json',{})
        from .coding_dependencies import binding_issues
        fresh=audit.get('coder')==coder and(audit.get('pass')or audit.get('integrity_pass'))and bool(audit.get('source_bindings'))
        for rel,key in [('coding/codes.csv','codes_file_sha256'),('coding/codebook.yaml','codebook_file_sha256')]:
            path=w/rel;fresh=fresh and path.is_file()and hashlib.sha256(path.read_bytes()).hexdigest()==audit.get(key)
        fresh=fresh and not binding_issues(w,audit.get('source_bindings',[]))
        done={(r.get('code_id'),r.get('text_sha256'),r.get('codebook_sha256'))for r in read_csv(w/'coding/codes.csv')if fresh and r.get('coder_id')==coder and r.get('value')not in [None,'']}
        coding=[r for r in coding if include_completed or(r.get('code_id'),r.get('text_sha256'),r.get('codebook_sha256'))not in done]
        pending=[r for path in(review_task_files or[w/'review/review_tasks.jsonl'])for r in jsonl(path)]
        inputs=[('coding',r)for r in coding]+[('source_review',r)for r in pending]
    else:
        candidates=[w/'qa/semantic_review_tasks_qualitative.jsonl',w/'qa/semantic_review_tasks_tracker.jsonl']
        path=next((p for p in candidates if p.is_file()),candidates[0]);inputs=[('second_review',r)for r in jsonl(path)]
    seen=set()
    for category,r in inputs:
        identity=(r.get('cik'),str(r.get('fy')),r.get('var_id'));tid=category+':'+':'.join(map(str,identity))
        if tid in seen:raise ValueError('Duplicate task identity: '+tid)
        seen.add(tid)
        if r.get('accession')in state_years and state_years[r['accession']]!=int(identity[1]):
            issues.append({'task':tid,'check':'annual_fiscal_identity_conflict','source_fy':state_years[r['accession']],'task_fy':identity[1]});continue
        path=Path((r.get('text_path')or'')if category!='source_review'else r.get('source_path')or'')
        if not path.is_absolute():path=w/path
        if not path.is_file():issues.append({'task':tid,'check':'source_unavailable'});tasks.append({'id':tid,'category':category,'record':r,'scope_id':None});continue
        if not path.resolve().is_relative_to(w):raise ValueError('Task source must resolve inside the requested work directory')
        doc=documents.read(path)
        expected=r.get('source_sha256')if category=='source_review'else r.get('text_sha256')
        if not expected:issues.append({'task':tid,'check':'source_hash_missing'});continue
        if expected!=doc['sha256']:issues.append({'task':tid,'check':'source_hash_mismatch'});continue
        if category=='source_review':
            if str(path)not in normal:
                from .textutil import html_to_text
                normal[str(path)]=html_to_text(doc['text'])
            text=normal[str(path)];bounds=r.get('expected_reviewed_scope')
        else:text=doc['text'];bounds=[r.get('scope_start'),r.get('scope_end')]
        if not bounds or any(v is None for v in bounds):issues.append({'task':tid,'check':'scope_unavailable'});continue
        lo,hi=map(int,bounds)
        if not 0<=lo<hi<=len(text):issues.append({'task':tid,'check':'invalid_scope'});continue
        scope_hash=sha(text[lo:hi])
        if category=='source_review'and r.get('expected_scope_sha256')and r['expected_scope_sha256']!=scope_hash:issues.append({'task':tid,'check':'scope_hash_mismatch'});continue
        text_id=sha(text);scope_id=sha(json.dumps([str(identity[0]),identity[1],text_id,lo,hi]))[:24]
        sources.setdefault(text_id,{'text':text,'origin_paths':[],'origin_bindings':{}})['origin_paths'].append(str(path))
        sources[text_id]['origin_bindings'][str(path)]=doc['sha256']
        scope=scopes.setdefault(scope_id,{'id':scope_id,'cik':identity[0],'fy':int(identity[1]),'text_id':text_id,'start':lo,'end':hi,'scope_sha256':scope_hash,'task_ids':[]})
        scope['task_ids'].append(tid);raw_scope_chars+=hi-lo
        definition=book.get(r.get('var_id'))if category!='source_review'else r.get('definition');definition=definition or r.get('definition')or r.get('codebook_sha256')or r.get('expected_record_sha256')
        did=sha(json.dumps(definition,ensure_ascii=False,sort_keys=True))[:24]
        definitions.setdefault(did,definition)
        tasks.append({'id':tid,'category':category,'cik':identity[0],'fy':int(identity[1]),'var_id':identity[2],'definition_id':did,'scope_id':scope_id,'record':r})
    # Overlapping scopes share a reading segment; adjudication bounds stay per task.
    grouped={};reading_plan=[]
    for scope in scopes.values():grouped.setdefault((scope['cik'],scope['fy'],scope['text_id']),[]).append(scope)
    for key,items in grouped.items():
        merged=[]
        for scope in sorted(items,key=lambda r:(r['start'],r['end'])):
            if merged and scope['start']<=merged[-1]['end']:
                segment=merged[-1];segment['end']=max(segment['end'],scope['end']);segment['scope_ids'].append(scope['id']);segment['task_ids']+=scope['task_ids']
            else:merged.append({'cik':key[0],'fy':key[1],'text_id':key[2],'start':scope['start'],'end':scope['end'],'scope_ids':[scope['id']],'task_ids':list(scope['task_ids'])})
        for segment in merged:
            segment['id']=sha(json.dumps([*key,segment['start'],segment['end']]))[:24];segment['scope_sha256']=sha(sources[key[2]]['text'][segment['start']:segment['end']]);reading_plan.append(segment)
    (out/'sources').mkdir(exist_ok=True)
    for tid,source in sources.items():
        (out/'sources'/f'{tid}.txt').write_text(source.pop('text'));source['origin_paths']=sorted(set(source['origin_paths']))
        source['snapshot_path']='sources/'+tid+'.txt'
    write_json(out/'definitions.json',definitions)
    (out/'tasks.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in tasks))
    index={'version':'1.0','phase':phase,'requested_task_count':len(inputs),'task_count':len(tasks),'scope_count':len(scopes),'source_count':len(sources),'source_bytes_read':sum(x['bytes']for x in documents.entries.values()),'source_physical_reads':documents.reads,'task_scope_chars_if_read_separately':raw_scope_chars,'unique_scope_chars':sum(x['end']-x['start']for x in scopes.values()),'reading_segment_count':len(reading_plan),'union_source_chars':sum(x['end']-x['start']for x in reading_plan),'reading_plan':reading_plan,'input_bindings':{str(path):hashlib.sha256(path.read_bytes()).hexdigest()for path in [book_path,w/'coding/source_registry.json',w/'panel/panel_meta.json',*[Path(p)for p in review_task_files]]if path.is_file()},'sources':sources,'scopes':list(scopes.values()),'integrity_pass':not issues,'issues':issues,'semantic_review_completed':False,'meaning':'Shared source delivery only; every construct still needs its own actual judgment. First and second reviews remain distinct.'}
    index['codes_path']=str(w/'coding/codes.csv')
    index['second_record_bindings']={t['id']:{'code_id':t['record'].get('code_id'),'coder_id':t['record'].get('coder_id',coder),'record_sha256':t['record'].get('expected_record_sha256')}for t in tasks if t['category']=='second_review'}
    index['artifact_bindings']={name:hashlib.sha256((out/name).read_bytes()).hexdigest()for name in ['tasks.jsonl','definitions.json']}
    write_json(out/'index.json',index);return index

def record_hash(row):
    relevant={k:row.get(k)for k in ['code_id','cik','fy','var_id','coder_id','value','quote','text_sha256','codebook_sha256','accession','scope_start','scope_end']}
    return hashlib.sha256(json.dumps(relevant,ensure_ascii=False,sort_keys=True).encode()).hexdigest()

def check_second_records(index,task_ids):
    bindings=index.get('second_record_bindings',{})
    if not bindings:return
    current={(r.get('code_id'),r.get('coder_id')):r for r in read_csv(index['codes_path'])}
    for tid in task_ids:
        if tid not in bindings:continue
        b=bindings[tid];row=current.get((b['code_id'],b['coder_id']))
        if row is None or record_hash(row)!=b['record_sha256']:raise ValueError('This coding record changed; refresh this second-review task, not unrelated source groups: '+tid)


def show(bundle,scope_id=None,task_id=None,offset=0,limit=12000,segment_id=None):
    root=Path(bundle);index=read_json(root/'index.json')
    for name,expected in index.get('artifact_bindings',{}).items():
        if not(root/name).is_file()or hashlib.sha256((root/name).read_bytes()).hexdigest()!=expected:raise ValueError('Bundle task/definition material changed; prepare again')
    for input_path,expected in index.get('input_bindings',{}).items():
        if not Path(input_path).is_file()or hashlib.sha256(Path(input_path).read_bytes()).hexdigest()!=expected:raise ValueError('Bundle inputs changed; prepare a fresh bundle')
    if not index['integrity_pass']:raise ValueError('Repair bundle integrity issues before using review materials')
    if task_id:
        check_second_records(index,[task_id])
        task=next(r for r in jsonl(root/'tasks.jsonl')if r['id']==task_id);return json.dumps(task,ensure_ascii=False,indent=2)
    scope=next(s for s in(index['reading_plan']if segment_id else index['scopes'])if s['id']==(segment_id or scope_id));source=index['sources'][scope['text_id']];path=(root/source['snapshot_path']).resolve()
    if not path.is_relative_to(root.resolve()):raise ValueError('invalid bundle snapshot path')
    for origin,expected in source['origin_bindings'].items():
        if not Path(origin).is_file()or hashlib.sha256(Path(origin).read_bytes()).hexdigest()!=expected:raise ValueError('Original source changed; regenerate bundle and affected judgments')
    check_second_records(index,scope['task_ids'])
    text=path.read_text();lo,hi=scope['start'],scope['end']
    if sha(text)!=scope['text_id']or sha(text[lo:hi])!=scope['scope_sha256']:raise ValueError('Bundle source snapshot changed; prepare again')
    if not 0<=offset<hi-lo or not 1<=limit<=24000:raise ValueError('offset outside scope or limit outside1:24000')
    start=lo+offset;end=min(hi,start+limit)
    return json.dumps({'scope_id':scope_id,'absolute_start':start,'absolute_end':end,'next_offset':end-lo if end<hi else None,'scope_complete_in_this_page':start==lo and end==hi,'status':'source_delivered_not_a_semantic_judgment','text':text[start:end]},ensure_ascii=False)

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('prepare');a.add_argument('--work',required=True);a.add_argument('--out',required=True);a.add_argument('--phase',choices=['first','second'],default='first');a.add_argument('--include-completed',action='store_true');a.add_argument('--coder',default='A');a.add_argument('--review-task-files',nargs='*',default=[])
    a=sub.add_parser('show');a.add_argument('--bundle',required=True);g=a.add_mutually_exclusive_group(required=True);g.add_argument('--scope');g.add_argument('--segment');g.add_argument('--task');a.add_argument('--offset',type=int,default=0);a.add_argument('--limit',type=int,default=12000)
    a=sub.add_parser('list');a.add_argument('--bundle',required=True);a.add_argument('--fy',type=int);a.add_argument('--offset',type=int,default=0);a.add_argument('--limit',type=int,default=10)
    a=p.parse_args(argv)
    if a.command=='list':
        index=read_json(Path(a.bundle)/'index.json');items=[r for r in index['reading_plan']if a.fy is None or r['fy']==a.fy]
        print(json.dumps({'total_segments':len(items),'segments':[{k:r[k]for k in ['id','cik','fy','start','end']}|{'tasks':len(r['task_ids'])}for r in items[a.offset:a.offset+min(max(a.limit,1),30)]],'next_offset':a.offset+a.limit if a.offset+a.limit<len(items)else None},ensure_ascii=False));return 0
    if a.command=='show':print(show(a.bundle,a.scope,a.task,a.offset,a.limit,a.segment));return 0
    r=prepare(a.work,a.out,a.phase,a.include_completed,a.coder,a.review_task_files);summary={k:r[k]for k in ['phase','requested_task_count','task_count','scope_count','reading_segment_count','union_source_chars','source_count','source_physical_reads','task_scope_chars_if_read_separately','unique_scope_chars','integrity_pass','semantic_review_completed']};summary.update(index=str(Path(a.out)/'index.json'),issues=r['issues'][:5]);print(json.dumps(summary,ensure_ascii=False,indent=2));return 0 if r['integrity_pass']else 2
