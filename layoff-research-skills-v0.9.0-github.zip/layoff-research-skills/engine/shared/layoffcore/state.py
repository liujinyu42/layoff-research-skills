"""状态库：SQLite 单文件，记录每个采集单元的状态与尝试次数。

为什么用状态库而不是只看文件存在：文件存在 ≠ 解析成功，解析失败也不该在续跑时被当作完成。
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .schema import TaskStatus

SCHEMA = """
CREATE TABLE IF NOT EXISTS companies (
    cid      INTEGER PRIMARY KEY,
    company  TEXT NOT NULL,
    ticker   TEXT,
    cik      TEXT,
    market   TEXT,
    note     TEXT
);
CREATE TABLE IF NOT EXISTS filings (
    accession   TEXT PRIMARY KEY,
    cid         INTEGER,
    cik         TEXT,
    form        TEXT,
    filed       TEXT,
    period      TEXT,
    fy          INTEGER,
    primary_doc TEXT,
    path        TEXT,
    package_path TEXT,
    sha256      TEXT,
    status      TEXT NOT NULL,
    attempts    INTEGER NOT NULL DEFAULT 0,
    last_error  TEXT,
    updated_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_filings_cik_fy ON filings(cik, fy);
CREATE INDEX IF NOT EXISTS idx_filings_status ON filings(status);
CREATE TABLE IF NOT EXISTS snapshots (
    snapshot_id TEXT PRIMARY KEY,
    built_at    TEXT,
    panel_path  TEXT,
    sha256      TEXT,
    n_rows      INTEGER
);
CREATE TABLE IF NOT EXISTS kv (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class StateDB:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self._migrate()
        self.conn.commit()

    def _migrate(self) -> None:
        cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(filings)")}
        if "package_path" not in cols:
            self.conn.execute("ALTER TABLE filings ADD COLUMN package_path TEXT")
        snapshot_cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(snapshots)")}
        if "verified" not in snapshot_cols:
            self.conn.execute("ALTER TABLE snapshots ADD COLUMN verified INTEGER NOT NULL DEFAULT 0")

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "StateDB":
        return self

    def __exit__(self, *exc) -> bool:
        self.close()
        return False

    # ---------------------------------------------------------- 公司
    def upsert_company(self, cid: int, company: str, ticker: str = "", cik: str = "",
                       market: str = "", note: str = "") -> None:
        self.conn.execute(
            """INSERT INTO companies(cid,company,ticker,cik,market,note)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(cid) DO UPDATE SET
                 company=excluded.company, ticker=excluded.ticker,
                 cik=excluded.cik, market=excluded.market, note=excluded.note""",
            (cid, company, ticker, cik, market, note),
        )
        self.conn.commit()

    def companies(self) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM companies ORDER BY cid").fetchall()
        return [dict(r) for r in rows]

    # ---------------------------------------------------------- 申报
    def upsert_filing(self, *, accession: str, cid: int, cik: str, form: str,
                      filed: str, period: str, fy: int, primary_doc: str,
                      status: TaskStatus = TaskStatus.PENDING) -> None:
        self.conn.execute(
            """INSERT INTO filings(accession,cid,cik,form,filed,period,fy,primary_doc,status,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(accession) DO UPDATE SET
                 form=excluded.form, filed=excluded.filed, period=excluded.period,
                 fy=excluded.fy, primary_doc=excluded.primary_doc, updated_at=excluded.updated_at""",
            (accession, cid, cik, form, filed, period, fy, primary_doc, status.value, _now()),
        )
        self.conn.commit()

    def mark(self, accession: str, status: TaskStatus, *, path: str | None = None,
             package_path: str | None = None, sha256: str | None = None,
             error: str | None = None, count_attempt: bool = False) -> None:
        sets = ["status=?", "updated_at=?", "last_error=?"]
        args: list = [status.value, _now(), error]
        if path is not None:
            sets.append("path=?")
            args.append(path)
        if package_path is not None:
            sets.append("package_path=?")
            args.append(package_path)
        if sha256 is not None:
            sets.append("sha256=?")
            args.append(sha256)
        if count_attempt:
            sets.append("attempts=attempts+1")
        args.append(accession)
        self.conn.execute(f"UPDATE filings SET {', '.join(sets)} WHERE accession=?", args)
        self.conn.commit()

    def filings(self, *, status: TaskStatus | None = None, form: str | None = None,
                fy: int | None = None) -> list[dict]:
        sql = "SELECT * FROM filings WHERE 1=1"
        args: list = []
        if status is not None:
            sql += " AND status=?"
            args.append(status.value)
        if form is not None:
            sql += " AND form=?"
            args.append(form)
        if fy is not None:
            sql += " AND fy=?"
            args.append(fy)
        sql += " ORDER BY cik, fy, filed"
        return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def counts(self) -> dict[str, int]:
        rows = self.conn.execute(
            "SELECT status, COUNT(*) AS n FROM filings GROUP BY status ORDER BY status"
        ).fetchall()
        return {r["status"]: r["n"] for r in rows}

    def retry_failed(self) -> int:
        cur = self.conn.execute(
            "UPDATE filings SET status=?, last_error=NULL, updated_at=? WHERE status IN (?,?,?)",
            (TaskStatus.PENDING.value, _now(), TaskStatus.FAILED.value, TaskStatus.QA_FAILED.value,
             TaskStatus.INCOMPLETE.value),
        )
        self.conn.commit()
        return cur.rowcount

    # ---------------------------------------------------------- 快照
    def record_snapshot(self, snapshot_id: str, panel_path: str, sha256: str, n_rows: int) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO snapshots(snapshot_id,built_at,panel_path,sha256,n_rows)"
            " VALUES(?,?,?,?,?)",
            (snapshot_id, _now(), panel_path, sha256, n_rows),
        )
        self.conn.commit()

    def verify_latest_snapshot(self, sha256: str) -> None:
        latest = self.latest_snapshot()
        if latest and latest["sha256"] == sha256:
            self.conn.execute("UPDATE snapshots SET verified=1 WHERE snapshot_id=?", (latest["snapshot_id"],))
            self.conn.commit()

    def latest_snapshot(self, *, verified_only: bool = False) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM snapshots " + ("WHERE verified=1 " if verified_only else "") +
            "ORDER BY built_at DESC, snapshot_id DESC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None

    def previous_snapshot(self, *, verified_only: bool = False) -> dict | None:
        rows = self.conn.execute(
            "SELECT * FROM snapshots " + ("WHERE verified=1 " if verified_only else "") +
            "ORDER BY built_at DESC, snapshot_id DESC LIMIT 2"
        ).fetchall()
        return dict(rows[1]) if len(rows) > 1 else None

    # ---------------------------------------------------------- KV
    def set_kv(self, key: str, value) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO kv(key,value) VALUES(?,?)",
            (key, json.dumps(value, ensure_ascii=False)),
        )
        self.conn.commit()

    def get_kv(self, key: str, default=None):
        row = self.conn.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return json.loads(row["value"]) if row else default
