"""Keep all expected coding slots visible, including draft and missing constructs."""
from .io import read_csv,write_csv

def coding_coverage(work,book,coder,codes):
    panel=read_csv(work/'panel/panel_wide.csv'); variables=read_csv(work/'config/variable_book.csv')
    required={r['var_id']for r in variables if r.get('source_type')=='code'}|set(book)
    keyed={(r['cik'],str(r['fy']),r['var_id']):r for r in codes if r.get('coder_id')==coder}
    result=[]
    from .requested_coverage import requested_periods
    for p in requested_periods(work,panel):
        for var in sorted(required):
            spec=book.get(var,{});record=keyed.get((p['cik'],str(p['fy']),var));state=spec.get('status','not_in_codebook')
            if record:status='abstained'if record.get('value')in ['',None]else'coded'
            elif p.get('source_coverage_status'):status='source_unavailable_not_coded'
            elif state=='ready':status='missing_code'
            elif state=='excluded'and spec.get('exclusion_reason'):status='explicitly_excluded'
            else:status='draft_not_dispatched'if state=='draft'else'not_in_codebook'
            result.append({'code_id':f"{p['cik']}-{p['fy']}-{var}",'cik':p['cik'],'fy':p['fy'],'company':p.get('company',''),'var_id':var,'coder_id':coder,'value':record.get('value')if record else None,'coverage_status':status,'codebook_status':state,'time_basis':spec.get('time_basis','unspecified'),'reason':spec.get('exclusion_reason','')if status=='explicitly_excluded'else'not a completed judgment'if status not in {'coded','abstained'}else''})
    fields=['code_id','cik','fy','company','var_id','coder_id','value','coverage_status','codebook_status','time_basis','reason'];write_csv(work/'coding/coverage.csv',result,fields)
    return {'expected_constructs':len(required),'ready_constructs':sum(book.get(v,{}).get('status')=='ready'for v in required),'expected_company_year_codes':len(result),'observed_nonmissing':sum(r['coverage_status']=='coded'for r in result),'abstentions':sum(r['coverage_status']=='abstained'for r in result),'deferred_or_missing':sum(r['coverage_status']not in {'coded','abstained','explicitly_excluded'}for r in result),'full_codebook_complete':all(r['coverage_status']in {'coded','explicitly_excluded'}for r in result),'unprepared_constructs':sorted(v for v in required if book.get(v,{}).get('status')not in {'ready','excluded'})}
