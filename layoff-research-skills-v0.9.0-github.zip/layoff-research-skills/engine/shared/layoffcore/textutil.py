"""文本层：HTML 转纯文本、章节定位、句子切分、证据窗口。

设计约束：
1. 所有字符偏移都相对于**落盘的纯文本**（``derived/texts/{cik}_{fy}.txt``），
   而不是原始 HTML。这样证据引用在再次运行时可复现。
2. 章节定位先剔除目录（TOC）条目，再取该章节覆盖正文最长的候选标题。
   真实申报里同一标题会出现三次以上：目录、正文标题、正文内的交叉引用；
   目录条目的后续紧跟页码行，正文标题的后续是段落，据此区分。
3. 标题词允许被版式在词内折断（如 ``ITEM 1. B`` / ``USINESS``），
   因此标题模式在匹配时对字母间空白宽容；这对纯段落文本无副作用。
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path

# 块级标签 → 换行，保证标题独立成行
_BLOCK_TAGS = (
    "p|div|br|tr|td|th|li|ul|ol|h1|h2|h3|h4|h5|h6|table|section|article|"
    "header|footer|hr|dt|dd|blockquote|pre"
)

# 各表单的章节标题模式（均为行首锚定，大小写不敏感）
SECTION_PATTERNS: dict[str, dict[str, str]] = {
    "10-K": {
        "1": r"item\s*1\s*[:.]?\s*business\b",
        "1A": r"item\s*1a\s*[:.]?\s*risk\s*factors\b",
        "7": r"item\s*7\s*[:.]?\s*management.{0,3}s\s*discussion",
        "8": r"item\s*8\s*[:.]?\s*financial\s*statements",
    },
    "20-F": {
        "3": r"item\s*3\.?\s*key\s*information",
        "4": r"item\s*4\.?\s*information\s*on\s*the\s*company",
        "5": r"item\s*5\.?\s*operating\s*and\s*financial\s*review",
        "6": r"item\s*6\.?\s*directors",
    },
    "DEF 14A": {
        "CD&A": r"compensation\s*discussion\s*(?:and|&)\s*analysis",
        "SCT": r"summary\s*compensation\s*table",
        "POT": r"potential\s*payments\s*upon\s*(?:termination|change)",
        "11": r"executive\s*compensation|summary\s*compensation\s*table",
    },
}

_HEADING_MAX_LEN = 120
_TOC_LEADER = re.compile(r"\.\s*\.\s*\.|\.{4,}")
_TRAILING_PAGENO = re.compile(r"\s\d{1,3}\s*$")
# 目录条目后紧跟的页码行（独立成行、仅含 1-3 位数字）
_PAGENO_LINE = re.compile(r"^\d{1,3}$")


def _flex_letters(pattern: str) -> str:
    """在字母之间插入 ``\\s*``，容忍标题词被版式折断。

    转义序列（``\\s``、``\\.``、``\\b`` 等）原样保留，不参与插入。
    """
    out: list[str] = []
    i = 0
    while i < len(pattern):
        ch = pattern[i]
        if ch == "\\" and i + 1 < len(pattern):
            out.append(pattern[i : i + 2])
            i += 2
            continue
        if ch.isascii() and ch.isalpha():
            out.append(ch + r"\s*")
        else:
            out.append(ch)
        i += 1
    return "".join(out)


def _next_nonempty_lines(text: str, pos: int, limit: int = 3) -> list[str]:
    """返回 ``pos`` 之后的若干非空行（用于识别目录页码）。"""
    out: list[str] = []
    for line in text[pos:].split("\n"):
        line = line.strip()
        if not line:
            continue
        out.append(line)
        if len(out) >= limit:
            break
    return out


def _looks_like_toc(text: str, line_end: int) -> bool:
    """标题行之后紧接页码行 → 该命中是目录条目，不是章节起点。"""
    return any(_PAGENO_LINE.match(line) for line in _next_nonempty_lines(text, line_end, 3))


def html_to_text(html: str) -> str:
    """把申报 HTML 转为规范纯文本。优先 bs4，缺失时退化为正则剥离。"""
    try:
        from bs4 import BeautifulSoup
    except ImportError:  # pragma: no cover - 仅在未装 bs4 时触发
        return _html_to_text_regex(html)

    soup = BeautifulSoup(html, "lxml" if _has_lxml() else "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    for tag in soup.find_all(re.compile(_BLOCK_TAGS, re.I)):
        tag.insert_before("\n")
        tag.insert_after("\n")
    raw = soup.get_text("\n")
    return normalize_text(raw)


def _has_lxml() -> bool:
    try:
        import lxml  # noqa: F401
    except ImportError:
        return False
    return True


def _html_to_text_regex(html: str) -> str:
    text = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
    text = re.sub(rf"(?i)</?({_BLOCK_TAGS})\b[^>]*>", "\n", text)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    import html as html_mod

    return normalize_text(html_mod.unescape(text))


def normalize_text(text: str) -> str:
    """统一空白，输出稳定文本。偏移以本函数结果为准。"""
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\xa0", " ").replace("\u200b", "")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = []
    for line in text.split("\n"):
        line = re.sub(r"[ \t\f\v]+", " ", line).strip()
        lines.append(line)
    text = "\n".join(lines)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


@dataclass(frozen=True)
class Section:
    key: str
    title: str
    start: int
    end: int
    text: str


def _heading_hits(text: str, form: str) -> list[tuple[int, str, str, bool]]:
    """返回 (偏移, 章节键, 标题行, 是否目录条目)。

    字母间空白被容忍（``ITEM 1. B`` / ``USINESS`` 这类版式折断）；
    目录条目通过"标题后紧跟页码行"识别，单独打标而不直接丢弃——
    若某章节只命中目录，则仍保留它，避免整段缺失。
    """
    patterns = SECTION_PATTERNS.get(form)
    if not patterns:
        return []
    hits: list[tuple[int, str, str, bool]] = []
    for key, pat in patterns.items():
        flex = _flex_letters(pat)
        for m in re.finditer(rf"(?im)^[ \t]*{flex}", text):
            # 匹配尾部可能吞掉换行（字母间 \s* 是贪婪的），先回退到标题字面末尾
            start, end = m.start(), m.end()
            while end > start and text[end - 1].isspace():
                end -= 1
            line_end = text.find("\n", end)
            line_end = len(text) if line_end == -1 else line_end
            line = text[start:line_end]
            before = text[max(0, start - 220):start].rstrip()
            after = text[line_end:].lstrip()
            # A separately formatted cross-reference can look like a heading after HTML
            # flattening. Quotation punctuation and explicit lead-ins identify it.
            if before[-1:] in {'"', '“', '‘'} or after[:1] in {'"', '”', '’'}:
                continue
            if re.search(r"\b(?:see|refer to|described in|discussed in|set forth in|contained in|under|in)\s*$", before, re.I):
                continue
            # A line-broken mention inside the forward-looking disclaimer is not
            # a section heading even when HTML made the item/title separate lines.
            if re.match(r"(?:[.,;:]|and other sections?\b|of this (?:Annual Report|Form)\b)",after,re.I):
                continue
            if len(line) > _HEADING_MAX_LEN:
                continue
            if _TOC_LEADER.search(line) or _TRAILING_PAGENO.search(line):
                continue
            hits.append((m.start(), key, line.strip(), _looks_like_toc(text, line_end)))
    hits.sort(key=lambda h: (h[0], h[1]))
    return hits


def nontraditional_narrative_scope(text: str, form: str):
    """A declared full-narrative fallback, never a fabricated numbered Item scope."""
    if form != '10-K': return None
    indexes=list(re.finditer(r'(?im)^FORM\s+10-K\s+CROSS-REFERENCE\s+INDEX\s*$',text))
    indexes=[m for m in indexes if re.search(r'(?is)Item\s+(?:Number|No[.])[^a-z0-9]{0,30}Item',text[m.end():m.end()+160])]
    if not indexes: return None
    end=indexes[-1].start()
    traditional=[h for h in _heading_hits(text[:end],form) if not h[3]]
    if any(h[1] in {'1','7','8'} for h in traditional): return None
    forwards=list(re.finditer(r'(?im)^FORWARD[- ]LOOKING STATEMENTS\s*$',text[:end]))
    if not forwards: return None
    start=forwards[0].start()
    if end-start<5000: return None
    return start,end


def locate_sections(text: str, form: str) -> dict[str, Section]:
    """定位所有已知章节。

    按申报的章节顺序（SECTION_PATTERNS 的键序）贪心取"目录之后的第一个正文标题"：
    先定 Item 1 起点，再在其后找 Item 1A，依此类推。这样既跳过目录，
    也跳过正文内的交叉引用——交叉引用通常出现在该章节之前的位置，
    且排在已经锚定的前一段之后。
    章节结束于下一个正文标题（忽略目录条目标记的命中）。
    """
    fallback=nontraditional_narrative_scope(text,form)
    if fallback:
        start,end=fallback
        return {key:Section(key=key,title='NONTRADITIONAL FULL ANNUAL NARRATIVE — NOT A NUMBERED ITEM',start=start,end=end,text=text[start:end]) for key in SECTION_PATTERNS[form]}
    hits = _heading_hits(text, form)
    if not hits:
        return {}
    order = [k for k in SECTION_PATTERNS.get(form, {}) if any(h[1] == k for h in hits)]
    body_positions = [h[0] for h in hits if not h[3]]
    out: dict[str, Section] = {}
    cursor = 0
    for key in order:
        cands = [h for h in hits if h[1] == key]
        pool = [h for h in cands if not h[3] and h[0] >= cursor] or \
               [h for h in cands if h[0] >= cursor] or cands
        if not pool:
            continue
        pos, _, title, _ = pool[0]
        later = [p for p in body_positions if p > pos] or \
                [h[0] for h in hits if h[0] > pos]
        end = min(later) if later else len(text)
        out[key] = Section(key=key, title=title, start=pos, end=end, text=text[pos:end])
        cursor = pos + 1
    # Selected section starts are authoritative even when the TOC heuristic was
    # uncertain.  End a preceding scope there instead of overlapping the next item.
    for key, section in list(out.items()):
        following = [v.start for v in out.values() if v.start > section.start]
        end = min([section.end, *following])
        if end != section.end:
            out[key] = Section(key=key, title=section.title, start=section.start,
                               end=end, text=text[section.start:end])
    return out


_SENT_BOUNDARY = re.compile(r"(?<=[.!?])[\s]+(?=[A-Z(\"'])")


def split_sentences(text: str, start: int = 0, end: int | None = None) -> list[tuple[int, int]]:
    """返回句子在全文中的 (start, end) 偏移。不做断词纠错。"""
    end = len(text) if end is None else end
    segment = text[start:end]
    spans: list[tuple[int, int]] = []
    cursor = 0
    for m in _SENT_BOUNDARY.finditer(segment):
        stop = m.start()
        if stop - cursor >= 3:
            spans.append((start + cursor, start + stop))
        cursor = m.end()
    if end - start - cursor >= 3:
        spans.append((start + cursor, end))
    return spans


def find_windows(
    text: str, keywords: list[str], start: int = 0, end: int | None = None, radius: int = 320
) -> list[tuple[int, int]]:
    """围绕关键词命中点取上下文窗口，合并重叠，供编码使用。"""
    end = len(text) if end is None else end
    hits: list[tuple[int, int]] = []
    for kw in keywords:
        for m in re.finditer(kw, text[start:end], re.I):
            a = max(start, start + m.start() - radius)
            b = min(end, start + m.end() + radius)
            hits.append((a, b))
    if not hits:
        return []
    hits.sort()
    merged = [list(hits[0])]
    for a, b in hits[1:]:
        if a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged]


def count_words(text: str) -> int:
    return len(re.findall(r"[A-Za-z][A-Za-z'\-]*", text))


def write_text(path: str | Path, text: str) -> Path:
    from .io import atomic_write_text

    return atomic_write_text(path, text)


def read_text(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8")
