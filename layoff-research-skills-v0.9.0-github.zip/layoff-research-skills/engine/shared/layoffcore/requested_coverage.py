"""Requested company-year slots stay visible even when an annual filing is unavailable."""
from pathlib import Path
import hashlib
from .io import read_csv,read_json,write_json

def requested_periods(work,panel=None):
    w=Path(work);panel=read_csv(w/'panel/panel_wide.csv')if panel is None else panel
    request=read_json(w/'research_request.json',{});years=request.get('years','')
    if not years:return panel
    first,last=map(int,years.split(':'));actual={(str(r['cik']).zfill(10),str(r['fy'])):r for r in panel};rows=[]
    for company in read_csv(w/'config/companies.csv'):
        cik=str(company.get('cik')or'').zfill(10)
        if not cik.isdigit()or not 0<int(cik)<10**10:continue
        for fy in range(first,last+1):
            key=(cik,str(fy));rows.append(actual.get(key)or{**company,'cik':cik,'fy':str(fy),'source_coverage_status':'annual_source_unavailable_or_unresolved'})
    return rows

def source_coverage(work):
    w=Path(work);panel=read_csv(w/'panel/panel_wide.csv');actual={(str(r['cik']).zfill(10),str(r['fy']))for r in panel};rows=[]
    for p in requested_periods(w,panel):
        c,y=str(p['cik']).zfill(10),str(p['fy']);available=(c,y)in actual
        row={k:p.get(k,'')for k in ['company','ticker','cid']};row.update(cik=c,fy=int(y),status='annual_anchor_available'if available else'annual_source_unavailable_or_unresolved',reason='')
        if not available:
            cache=w/'cache'/f'submissions_{c}.json';d=read_json(cache,{})
            recent=d.get('filings',{}).get('recent',{});events=[]
            for i,form in enumerate(recent.get('form',[])):
                if form.startswith(('15-','25-')):
                    date=recent.get('filingDate',['']*len(recent['form']))[i]
                    if date and int(date[:4])<=int(y):events.append({'form':form,'filed':date,'accession':recent.get('accessionNumber',['']*len(recent['form']))[i]})
            row['reporting_exit_index_evidence']=events
            row['reason']='Requested annual filing not observed; SEC index contains reporting-exit/delisting forms; confirm reporting boundary, do not fabricate annual values.'if events else'Requested annual source not located; check retrieval, filing history and issuer reporting status.'
            if cache.is_file():row.update(index_source=str(cache.relative_to(w)),index_sha256=hashlib.sha256(cache.read_bytes()).hexdigest())
        rows.append(row)
    write_json(w/'qa/requested_source_coverage.json',{'requested_company_years':len(rows),'annual_available':len(actual),'missing_annual_positions':sum(r['status']!='annual_anchor_available'for r in rows),'records':rows,'meaning':'source availability evidence, not an eligibility exclusion or proof of no real company activity'})
    return rows
