"""数值解析：人数、百分比、金额与币种判定。

原则（与 v1.1 项目一致）：
- 区间取上限，同时保留原文；
- 裸 ``$`` 不假定美元，标为 UNSPECIFIED_DOLLAR；
- 不做任何隐含汇率换算，仅在明确 USD 时写 severance_usd。
"""

from __future__ import annotations

import re

NUM = r"\d[\d,]*(?:\.\d+)?"
_SCALE_WORDS = {
    "thousand": 1e3,
    "thousands": 1e3,
    "million": 1e6,
    "millions": 1e6,
    "mn": 1e6,
    "billion": 1e9,
    "billions": 1e9,
    "bn": 1e9,
}
_COUNT_NOUN = r"(?:employee\s+roles|employees|workers|positions|roles|jobs|people|staff|associates|team\s+members)"
# 数量与名词之间允许的修饰语，例如 "12,400 full-time employees"、
# "1,525,000 full-time and part-time employees"（Amazon 的实际写法）
_COUNT_MOD = (
    r"(?:full[-\s]?time\s+equivalent\s+|(?:full[-\s]?time|part[-\s]?time)"
    r"(?:\s+and\s+(?:part[-\s]?time|full[-\s]?time))?\s+|total\s+|global\s+|hourly\s+)?"
)

USD_EXPLICIT = re.compile(r"(?:US\$|\bUSD\b|U\.S\.\s*dollars?|United\s+States\s+dollars?)", re.I)
DOLLAR_BARE = re.compile(r"\$")
OTHER_CCY = {
    "EUR": re.compile(r"(?:€|\bEUR\b|\beuros?\b)", re.I),
    "GBP": re.compile(r"(?:£|\bGBP\b)", re.I),
    "CAD": re.compile(r"(?:C\$|\bCAD\b)", re.I),
    "JPY": re.compile(r"(?:¥|\bJPY\b|\byen\b)", re.I),
}


def _to_float(token: str) -> float:
    return float(token.replace(",", ""))


def parse_count(text: str) -> tuple[int | None, str]:
    """从片段中解析人数。返回 (人数, 命中的原始片段)。"""
    t = text.replace("\u2013", "-").replace("\u2014", "-")

    # 区间：800-1,000 / between 800 and 1,000 → 取上限
    m = re.search(rf"{NUM}\s*(?:-|to|and)\s*({NUM})\s*{_COUNT_MOD}{_COUNT_NOUN}", t, re.I)
    if m:
        return int(_to_float(m.group(1))), m.group(0)

    # 带数量级：1.2 million employees
    m = re.search(
        rf"({NUM})\s*(thousand|thousands|million|millions|mn|billion|billions|bn)\s*"
        rf"{_COUNT_MOD}{_COUNT_NOUN}",
        t,
        re.I,
    )
    if m:
        value = _to_float(m.group(1)) * _SCALE_WORDS[m.group(2).lower()]
        return int(round(value)), m.group(0)

    # 普通整数：approximately 1,200 employees / 12,400 full-time employees
    m = re.search(rf"({NUM})\s*{_COUNT_MOD}{_COUNT_NOUN}", t, re.I)
    if m:
        return int(_to_float(m.group(1))), m.group(0)

    return None, ""


def parse_pct(text: str) -> tuple[float | None, str]:
    """解析"占 workforce 的百分比"。只接受与 workforce/员工基数绑定的表达。"""
    m = re.search(
        rf"({NUM})\s*(?:%|percent)\s*(?:of\s+(?:its\s+|the\s+|our\s+|total\s+)?"
        rf"(?:global\s+|total\s+|current\s+)?(?:workforce|employees|staff|headcount))",
        text,
        re.I,
    )
    if m:
        return _to_float(m.group(1)), m.group(0)
    return None, ""


def parse_amount(text: str) -> tuple[float | None, str, str]:
    """解析金额。返回 (数值, 币种码, 原始片段)。

    币种码：USD / EUR / GBP / CAD / JPY / UNSPECIFIED_DOLLAR / UNKNOWN
    """
    # Prefer an explicitly currency-marked amount over a preceding year/count.
    # "In 2023 severance was $148 million" must never parse as 2023 dollars.
    marked = re.search(rf"(?:US\$|C\$|\$|€|£|¥)\s*{NUM}\s*(?:thousand|thousands|million|millions|mn|billion|billions|bn)?\b", text, re.I)
    search_text = marked.group(0) if marked else text
    m = re.search(
        rf"((?:US\$|C\$|\$|€|£|¥)\s*)?({NUM})\s*"
        rf"(thousand|thousands|million|millions|mn|billion|billions|bn)?\b",
        search_text,
        re.I,
    )
    if not m:
        return None, "UNKNOWN", ""
    prefix = (m.group(1) or "").strip()
    value = _to_float(m.group(2))
    if m.group(3):
        value *= _SCALE_WORDS[m.group(3).lower()]

    if USD_EXPLICIT.search(m.group(0)) or ("US$" in prefix):
        return value, "USD", m.group(0)
    for code, pat in OTHER_CCY.items():
        if prefix and pat.search(prefix):
            return value, code, m.group(0)
    if prefix == "$" or DOLLAR_BARE.search(m.group(0)):
        return value, "UNSPECIFIED_DOLLAR", m.group(0)
    return value, "UNKNOWN", m.group(0)


def currency_from_context(window: str) -> str:
    """在更大上下文中判定裸 $ 的币种。仅当出现显式美元表述时升级为 USD。"""
    if USD_EXPLICIT.search(window):
        return "USD"
    return "UNSPECIFIED_DOLLAR"
