"""Necessary positive evidence conditions; passing is not semantic certification."""
import re

def validate_positive(definition,quote):
    for group in definition.get('positive_evidence_groups',[]):
        if not any(re.search(pattern,quote,re.I) for pattern in group['patterns']):
            raise ValueError('positive_evidence_missing:'+group['name'])
    return True

def negative_challenges(definition,text,lo,hi):
    found=[]
    for pattern in definition.get('negative_challenge_patterns',[]):
        for match in re.finditer(pattern,text[lo:hi],re.I):
            start,end=lo+match.start(),lo+match.end()
            a,b=max(lo,start-250),min(hi,end+750)
            found.append({'pattern':pattern,'char_start':start,'char_end':end,'context_start':a,'context_end':b,'quote':text[a:b]})
    return found

def validate_negative_challenges(definition,text,lo,hi,proof):
    resolutions=(proof or {}).get('challenge_resolutions',[])
    for challenge in negative_challenges(definition,text,lo,hi):
        matches=[r for r in resolutions if r.get('pattern')==challenge['pattern']and r.get('match_start')==challenge['char_start']]
        if len(matches)!=1:raise ValueError('negative_counterevidence_unresolved:'+str(challenge['char_start']))
        r=matches[0];start,end=r.get('char_start',-1),r.get('char_end',-1)
        if not(lo<=start<=challenge['char_start']<challenge['char_end']<=end<=hi)or text[start:end]!=r.get('quote')or not str(r.get('reason','')).strip()or r.get('decision')!='excluded_by_definition':
            raise ValueError('negative_counterevidence_resolution_invalid')
    return True
