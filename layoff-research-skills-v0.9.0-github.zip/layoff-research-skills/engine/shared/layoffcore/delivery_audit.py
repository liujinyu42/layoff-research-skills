"""Read a saved workbook and compare it to the current skill's typed result contract."""
import argparse,json,math,hashlib,datetime
from pathlib import Path
from .result_payload import prepare
from .io import write_json

def equivalent(actual,expected):
    if expected=='':expected=None
    if isinstance(actual,datetime.datetime)and isinstance(expected,str):
        try:
            parsed=datetime.datetime.fromisoformat(expected)
            if parsed.tzinfo is not None:parsed=parsed.astimezone(datetime.timezone.utc).replace(tzinfo=None)
            if actual.tzinfo is not None:actual=actual.astimezone(datetime.timezone.utc).replace(tzinfo=None)
            # JavaScript Date truncates sub-ms input; Excel serial export can lose another ms.
            return abs((actual-parsed).total_seconds())<=.002
        except ValueError:return False
    if isinstance(expected,bool):return actual==expected and isinstance(actual,bool)
    if isinstance(expected,(int,float)):return isinstance(actual,(int,float))and not isinstance(actual,bool)and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-8)
    if isinstance(expected,str)and expected.startswith('='):return actual in {expected,"'"+expected}
    return actual==expected

def audit(payload,excel):
    import openpyxl
    book=openpyxl.load_workbook(excel,data_only=True);issues=[];checked=0
    if book.sheetnames!=['结果']:return {'pass':False,'issues':[{'check':'exactly_one_result_sheet','actual':book.sheetnames}]}
    sheet=book['结果'];header=[c.value for c in sheet[1]];required=payload['columns']
    missing=sorted(set(required)-set(header))
    if missing:issues.append({'check':'missing_result_columns','columns':missing})
    if len(set(header))!=len(header):issues.append({'check':'duplicate_headers'})
    if sheet.max_row-1!=len(payload['rows']):issues.append({'check':'row_count','actual':sheet.max_row-1,'expected':len(payload['rows'])})
    if not missing:
        indexes=[header.index(k)for k in required]
        for n,(actual,expected)in enumerate(zip(sheet.iter_rows(min_row=2,values_only=True),payload['rows']),2):
            for j,e in enumerate(expected):
                checked+=1
                if not equivalent(actual[indexes[j]],e)and len(issues)<100:issues.append({'check':'saved_value_or_type','cell':sheet.cell(n,indexes[j]+1).coordinate,'field':required[j]})
    if payload.get('metadata',{}).get('result_layout')=='company_year_wide':
        if all(k in header for k in ['cik','fy']):
            positions=[header.index(k)for k in ['cik','fy']]
            keys=[tuple(r[i]for i in positions)for r in sheet.iter_rows(min_row=2,values_only=True)]
            if len(set(keys))!=len(keys):issues.append({'check':'duplicate_company_fiscal_year'})
        # Proof-column round trip includes every source field and full long text.
        try:
            from .company_year import restore
            restore([dict(zip(header,r))for r in sheet.iter_rows(min_row=2,values_only=True)],payload['metadata'])
        except(ValueError,KeyError,TypeError)as exc:issues.append({'check':'wide_record_round_trip','reason':str(exc)})
    return {'pass':not issues,'issues':issues,'compared_cells':checked,'worksheet_count':len(book.sheetnames),'logical_records':payload['metadata']['logical_records'],'physical_rows':len(payload['rows']),'excel_sha256':hashlib.sha256(Path(excel).read_bytes()).hexdigest(),'scope':'saved-file schema, values, types and complete result slots; semantic truth requires source review'}

def main(kind,argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work',required=True);p.add_argument('--excel',required=True);p.add_argument('--coder');p.add_argument('--allow-partial',action='store_true');p.add_argument('--out');p.add_argument('--layout',choices=['wide','long']);a=p.parse_args(argv)
    try:report=audit(prepare(kind,a.work,a.coder,a.allow_partial,a.layout),a.excel)
    except(ValueError,KeyError,OSError)as exc:report={'pass':False,'issues':[{'check':'current_result_contract','reason':str(exc)}]}
    target=Path(a.out)if a.out else Path(a.work)/'qa/delivery_audit.json';write_json(target,report);print(json.dumps(report,ensure_ascii=False,indent=2));return 0 if report['pass']else 2
