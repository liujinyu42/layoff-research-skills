// Uses the host's artifact-tool runtime; never installs a package or fetches data.
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash}from 'node:crypto';
import {createRequire}from 'node:module';
import {pathToFileURL}from 'node:url';
const args=process.argv.slice(2),get=k=>args[args.indexOf(k)+1];
if(!args.includes('--input')||!args.includes('--output'))throw new Error('usage: export_excel.mjs --input result.json --output result.xlsx [--preview preview.png]');
let library;
try{
 if(process.env.ARTIFACT_NODE_MODULES){
  const require=createRequire(path.join(path.dirname(process.env.ARTIFACT_NODE_MODULES),'artifact-loader.cjs'));
  library=await import(pathToFileURL(require.resolve('@oai/artifact-tool')).href);
 }else library=await import('@oai/artifact-tool');
}catch(error){throw new Error('The host artifact-tool runtime is unavailable. Use the platform spreadsheet tool with the typed payload, keep exactly one sheet, and verify saved values. No Excel was generated.');}
const {Workbook,SpreadsheetFile}=library,payload=JSON.parse(await fs.readFile(get('--input'),'utf8'));
for(const source of payload.source_files||[]){
 const bytes=await fs.readFile(source.path);if(createHash('sha256').update(bytes).digest('hex')!==source.sha256)throw new Error('result source changed; regenerate the payload');
}
if(!payload.columns?.length||!payload.rows?.length)throw new Error('no result table');
if(new Set(payload.columns).size!==payload.columns.length)throw new Error('duplicate column names');
const wb=Workbook.create(),sh=wb.worksheets.add('结果');sh.showGridLines=false;
const col=n=>{let s='';for(n++;n>0;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
const wide=payload.metadata?.result_layout==='company_year_wide';
const mainVars=new Set(payload.metadata?.variables||[]);
const n=payload.rows.length+1,last=col(payload.columns.length-1);
const rows=payload.rows.map(row=>row.map(v=>typeof v==='string'&&v.startsWith('=')?"'"+v:v));
sh.getRange(`A1:${last}${n}`).values=[payload.columns,...rows];
const all=sh.getRange(`A1:${last}${n}`);all.format.font={name:'Arial',size:10,color:'#26344A'};all.format.columnWidth=23;all.format.rowHeight=28;all.format.verticalAlignment='top';
const table=sh.tables.add(`A1:${last}${n}`,true,'SkillResult');table.showFilterButton=true;
sh.getRange(`A1:${last}1`).format={fill:'#253D5B',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:60,horizontalAlignment:'center',verticalAlignment:'center'};
for(let j=0;j<payload.columns.length;j++){
 const key=payload.columns[j],c=col(j),data=sh.getRange(`${c}2:${c}${n}`);
 const numeric=rows.some(r=>typeof r[j]==='number');
 if(numeric)data.setNumberFormat(rows.some(r=>typeof r[j]==='number'&&!Number.isInteger(r[j]))?'#,##0.00':'#,##0');
 if(['fy','year','cid','__text_part','__text_parts','__record_id'].includes(key))data.setNumberFormat('0');
 if(/cik|accession|_id$|sha256/i.test(key))data.setNumberFormat('@');
 if(['cik','fy','cid','ticker','level'].includes(key))sh.getRange(`${c}1:${c}${n}`).format.columnWidth={cik:16,fy:10,cid:8,ticker:12,level:12}[key];
 if(['code_id','var_id','posting_id','query_id'].includes(key)){sh.getRange(`${c}1:${c}${n}`).format.columnWidth=42;data.format.wrapText=true;}
 if(/quote|narrative|rationale|note|status|stage|negative_review|definition/.test(key)){
  sh.getRange(`${c}1:${c}${n}`).format.columnWidth=/quote|narrative/.test(key)?105:65;data.format.wrapText=true;data.format.verticalAlignment='top';
 }
 if(['position','dataset','value_label'].includes(key)){sh.getRange(`${c}1:${c}${n}`).format.columnWidth=key==='value_label'?40:55;data.format.wrapText=true;}
 if(['field_status','negative_review'].includes(key))sh.getRange(`${c}1:${c}${n}`).format.columnWidth=140;
 if(/growth|intensity/.test(key)&&numeric)data.setNumberFormat('0.0%');
 if(['retrieved_at','processed_at','created_at','filed','period','event_date','plan_date'].includes(key)){
  const values=rows.map(r=>r[j]).filter(v=>v!==null&&v!==undefined&&v!=='');
  if(values.length&&values.every(v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(v))){
   const timestamp=values.some(v=>v.includes('T'));data.values=rows.map(r=>[r[j]?new Date(r[j]):null]);
   data.setNumberFormat(timestamp?'yyyy-mm-dd hh:mm:ss" UTC"':'yyyy-mm-dd');sh.getRange(`${c}1:${c}${n}`).format.columnWidth=timestamp?30:18;
  }
 }
 if(wide){
  let width=key==='company'?30:key==='fy'?10:key==='cik'?16:key==='ticker'?12:mainVars.has(key)?(numeric?19:56):/evidence_json/.test(key)?72:/quote|rationale/.test(key)?70:/source_url/.test(key)?65:/status|reason/.test(key)?40:/unit/.test(key)?16:24;
  sh.getRange(`${c}1:${c}${n}`).format.columnWidth=width;data.format.wrapText=!numeric;
  if(numeric)data.setNumberFormat(rows.some(r=>typeof r[j]==='number'&&!Number.isInteger(r[j]))?'#,##0.########':'#,##0');
  if(key==='fy')data.setNumberFormat('0');if(key==='cik')data.setNumberFormat('@');
 }
 if(/status|stage/.test(key))for(const text of ['pending','unverified','abstain'])data.conditionalFormats.add('containsText',{text,format:{fill:'#FFF3CD',font:{color:'#855E14'}}});
}
for(let i=0;i<rows.length;i++){
 if(wide){sh.getRange(`A${i+2}:${last}${i+2}`).format.rowHeight=90;continue;}
 let lines=1;
 for(let j=0;j<payload.columns.length;j++)if(/quote|narrative|rationale|note|status|stage|negative_review|definition|code_id|var_id|posting_id|query_id|position|dataset|value_label/.test(payload.columns[j])){
  const key=payload.columns[j];
  const width=['position','dataset'].includes(key)?55:key==='value_label'?40:['code_id','var_id','posting_id','query_id'].includes(key)?42:['field_status','negative_review'].includes(payload.columns[j])?140:/quote|narrative/.test(payload.columns[j])?105:65;
  const count=String(rows[i][j]||'').split('\n').reduce((sum,s)=>sum+Math.max(1,Math.ceil([...s].reduce((sum,c)=>sum+(c.codePointAt(0)>255?2:1),0)/(width*.82))),0);lines=Math.max(lines,count);
 }
 sh.getRange(`A${i+2}:${last}${i+2}`).format.rowHeight=Math.min(395,Math.max(28,lines*15+12));
}
sh.freezePanes.freezeRows(1);const fyCol=payload.columns.indexOf('fy');sh.freezePanes.freezeColumns(Math.min(Math.max(4,fyCol>=0&&fyCol<8?fyCol+1:4),payload.columns.length-1));wb.recalculate();
console.log((await wb.inspect({kind:'table',range:`结果!A1:${col(Math.min(7,payload.columns.length-1))}${Math.min(5,n)}`,tableMaxRows:5,tableMaxCols:8,maxChars:1500})).ndjson);
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#SPILL!',options:{useRegex:true,maxResults:20},maxChars:1000})).ndjson);
if(args.includes('--preview')){const image=await wb.render({sheetName:'结果',range:`A1:${col(Math.min(7,payload.columns.length-1))}${Math.min(6,n)}`,scale:1,format:'png'});await fs.writeFile(get('--preview'),new Uint8Array(await image.arrayBuffer()));}
await fs.mkdir(path.dirname(path.resolve(get('--output'))),{recursive:true});const xlsx=await SpreadsheetFile.exportXlsx(wb);await xlsx.save(get('--output'));
console.log(JSON.stringify(args.includes('--verbose')?{output:get('--output'),sheets:1,tables:1,...payload.metadata}:{output:get('--output'),sheets:1,tables:1,rows:rows.length,columns:payload.columns.length,result_layout:payload.metadata?.result_layout,full_metadata:'stored in input payload'}));
