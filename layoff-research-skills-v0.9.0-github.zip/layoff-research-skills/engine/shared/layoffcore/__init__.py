"""layoffcore —— 三个 skill 共享的契约与底座（无第三方重依赖时可退化运行）。"""

from . import evidence, io, manifest, numbers, schema, sec, state, textutil

__all__ = ["evidence", "io", "manifest", "numbers", "schema", "sec", "state", "textutil"]
__version__ = schema.TOOL_VERSION
