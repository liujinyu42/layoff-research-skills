"""证据模型：每个非缺失单元格都必须能指回原文位置。

这是本仓库与普通爬虫的核心差别——数字不是"抓到的"，而是"可核验的"。
"""

from __future__ import annotations

import hashlib
from typing import Any

from .io import sha256_text
from .schema import EVIDENCE_COLUMNS, TOOL_VERSION

MAX_QUOTE_CHARS = 600


def evidence_id(*parts: Any) -> str:
    """稳定 ID：同一单元、同一位置、同一提取器版本 → 同一 ID。"""
    raw = "|".join(str(p) for p in parts)
    return "ev-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def make_evidence(
    *,
    cid: int,
    cik: str,
    fy: int,
    var_id: str,
    value_raw: str = "",
    value_num: float | int | None = None,
    unit: str = "",
    currency: str = "UNKNOWN",
    source_type: str = "text",
    form: str = "",
    accession: str = "",
    section: str = "",
    char_start: int | None = None,
    char_end: int | None = None,
    quote: str = "",
    confidence: str = "high",
    extractor: str = "rule",
    created_at: str = "",
) -> dict:
    quote = (quote or "")[:MAX_QUOTE_CHARS]
    return {
        "evidence_id": evidence_id(cik, fy, var_id, accession, char_start, char_end, extractor),
        "cid": cid,
        "cik": cik,
        "fy": fy,
        "var_id": var_id,
        "value_raw": value_raw,
        "value_num": value_num,
        "unit": unit,
        "currency": currency,
        "source_type": source_type,
        "form": form,
        "accession": accession,
        "section": section,
        "char_start": char_start,
        "char_end": char_end,
        "quote": quote,
        "confidence": confidence,
        "extractor": extractor,
        "extractor_version": TOOL_VERSION,
        "created_at": created_at,
    }


def quote_matches(text: str, char_start: int | None, char_end: int | None, quote: str) -> bool:
    """校验 quote 是否确实是该区间原文（允许首尾空白差异）。

    引文超过 MAX_QUOTE_CHARS 时会被截断——此时要求它是区间原文的**前缀**，
    不能只因为它变短了就放行任意内容。
    """
    if char_start is None or char_end is None or not quote:
        return True  # 非文本证据（XBRL/notice）不做区间校验
    try:
        span = text[int(char_start) : int(char_end)].strip()
    except (TypeError, ValueError):
        return False
    q = quote.strip()
    if span == q:
        return True
    # 截断判定用未去空白的原始长度：截断点可能正好落在空格上，
    # 去空白后 q 会短 1—2 个字符，用 len(q) 判断会漏掉这类合法前缀。
    return len(quote) >= MAX_QUOTE_CHARS and span.startswith(q)


def quote_hash(quote: str) -> str:
    return sha256_text(quote.strip())[:16]


def evidence_columns() -> list[str]:
    return list(EVIDENCE_COLUMNS)
