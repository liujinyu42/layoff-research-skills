"""Bind high-risk measurements to explicit, source-checked decisions before analysis."""
from pathlib import Path
import hashlib,json,math,re
from .numbers import parse_amount

HIGH_RISK={'severance','labor_talent_risk','workforce_restructuring_risk'}
EVENT_SEVERANCE={'severance_amount','severance_usd','severance_intensity'}
CONTRACT_PATH=Path(__file__).with_name('measurement_contract.json')

def value_hash(value):
 try:
  n=float(value)
  value=None if not math.isfinite(n)else n
 except (ValueError,TypeError):value=None if value in ('',None)else str(value)
 return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()

def file_hash(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def certify(work,panel,decisions,contract,*,collect_errors=False):
 import csv
 work=Path(work).resolve();panel=Path(panel).resolve();rows=list(csv.DictReader(panel.open(encoding='utf-8-sig')))
 current={(r['cik'].zfill(10),int(r['fy'])):r for r in rows};seen=set();accepted=[];issues=[]
 if len(current)!=len(rows):raise ValueError('面板公司财年重复，不能审查')
 errors=[]
 for n,d in enumerate(decisions,1):
  try:
   key=(str(d.get('cik','')).zfill(10),int(d['fy']),str(d['var_id']))
   if key in seen:raise ValueError('重复测量审查决定：'+str(key))
   seen.add(key)
   if key[:2]not in current or key[2]not in HIGH_RISK:raise ValueError('审查键不在当前面板/高风险变量中：'+str(key))
   if d.get('decision')not in {'accept','reject'}or not d.get('reason'):raise ValueError('决定需要accept/reject与具体理由')
   source=(work/d['source_path']).resolve()
   if not source.is_relative_to(work)or not source.is_file():raise ValueError('审查来源必须是工作区内可定位的原文')
   if d.get('source_sha256')!=file_hash(source):raise ValueError('原文已经变化或未提供SHA256')
   text=source.read_text(encoding='utf-8');quote=d.get('quote','')
   if len(quote)<30 or quote not in text:raise ValueError('复核引文不能在当前原文逐字定位')
   value=d.get('value')
   if d['decision']=='accept':
    if value is None or isinstance(value,bool)or not math.isfinite(float(value)):raise ValueError('接受决定需要有限数值')
    if key[2]=='severance':
     if int(d.get('source_year',0))!=key[1]or d.get('scope')!='company_total':raise ValueError('遣散费必须绑定本财年及公司总额，分项/累计/比较期不能接受')
     if d.get('period_basis')not in {'explicit_annual_period','bound_annual_table_column'}:raise ValueError('必须说明年度的原文或表头绑定依据')
     if float(value)<0:raise ValueError('负数调整不能作为支出总额；需要另列净调整变量')
     raw=d.get('amount_raw','')
     if not raw or raw not in quote:raise ValueError('遣散费决定需要引文内的amount_raw原始金额')
     at=quote.index(raw);lo=quote.rfind('.',0,at)+1;hi=quote.find('.',at+len(raw));sentence=quote[lo:hi if hi>=0 else len(quote)]
     if re.search(r'(?i)(?:three|six|nine)\s+months\s+ended|\bquarter\b',sentence)and not re.search(r'(?i)\b(?:fiscal\s+year|year\s+ended)\b',sentence):
      raise ValueError('季度/子期间费用不能仅凭自报period_basis改成年总额')
     parsed=parse_amount(raw)[0]
     if parsed is None or not math.isclose(parsed,float(value),rel_tol=1e-9):raise ValueError('金额与原始数量级单位不一致')
    elif float(value)not in {0,1}:raise ValueError('风险编码须为0/1')
   accepted.append({**d,'cik':key[0],'fy':key[1],'raw_value_sha256':value_hash(current[key[:2]].get(key[2])),
                    'char_start':text.index(quote),'char_end':text.index(quote)+len(quote)})
  except (KeyError,ValueError,TypeError,OSError)as exc:
   if not collect_errors:raise
   errors.append({'row':n,'reason':str(exc)})
 if errors:return {'pass':False,'errors':errors,'decisions':len(decisions)}
 return {'version':'0.4.0','panel_sha256':file_hash(panel),'contract_sha256':file_hash(contract),'decisions':accepted,
         'reviewer_note':'explicit source review, not automatically an independent human coding exercise'}

def load_approved(work,panel,contract,review_file=None):
 work=Path(work).resolve();review_file=Path(review_file)if review_file else work/'qa/measurement_review.json'
 if not review_file.is_absolute():review_file=work/review_file
 if not review_file.exists():return {},[]
 report=json.loads(review_file.read_text());issues=[]
 if report.get('panel_sha256')!=file_hash(panel):raise ValueError('测量审查的面板已变化，需要重审')
 if report.get('contract_sha256')!=file_hash(contract):raise ValueError('测量构念定义已变化，需要重审')
 rechecked=certify(work,panel,report.get('decisions',[]),contract)
 for old,new in zip(report.get('decisions',[]),rechecked['decisions']):
  if any(old.get(k)!=new.get(k)for k in ['raw_value_sha256','char_start','char_end']):raise ValueError('测量决定的值或引文绑定已被改动')
 approved={};seen=set()
 for d in report.get('decisions',[]):
  key=(str(d['cik']).zfill(10),int(d['fy']),d['var_id'])
  if key in seen:raise ValueError('测量审查清单含重复键')
  seen.add(key);source=(work/d['source_path']).resolve()
  if not source.is_relative_to(work)or not source.is_file()or file_hash(source)!=d.get('source_sha256'):raise ValueError('测量审查原文已变化')
  text=source.read_text();quote=d.get('quote','')
  if not quote or text[int(d['char_start']):int(d['char_end'])]!=quote:raise ValueError('测量审查的引文偏移已变化')
  approved[key]=d  # A source-reviewed rejection resolves the review, but retains a missing value.
 return approved,issues

def apply_policy(frame,work,panel,contract,review_file=None):
 import numpy as np
 import pandas as pd
 approved,_=load_approved(work,panel,contract,review_file);frame=frame.copy();ledger=[]
 for field in HIGH_RISK:
  if field not in frame:continue
  frame[field]=pd.to_numeric(frame[field],errors='coerce').astype(float)
  for i,row in frame.iterrows():
   key=(str(row['cik']).zfill(10),int(row['fy']),field);d=approved.get(key);raw=row[field]
   if d and value_hash(raw)!=d['raw_value_sha256']:raise ValueError('审查值与当前单元格不一致')
   if d and d['decision']=='accept':frame.at[i,field]=d['value'];status='reviewed'
   elif d:
    frame.at[i,field]=np.nan;status='reviewed_missing_or_definition_rejected'
    coded='coded_'+field
    if coded in frame:frame.at[i,coded]=np.nan
   else:
    frame.at[i,field]=np.nan;status='quarantined_unreviewed'
    coded='coded_'+field
    if coded in frame:frame.at[i,coded]=np.nan
   ledger.append({'cik':key[0],'fy':key[1],'var_id':field,'raw_value':raw,'analysis_value':d.get('value')if d and d['decision']=='accept'else None,'status':status})
 return frame,ledger
