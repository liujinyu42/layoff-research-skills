"""运行清单：记录参数、输入/输出哈希与计数，用于可复现与变更审计。"""

from __future__ import annotations

import platform
import secrets
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .io import ensure_dir, sha256_file, write_json
from .schema import TOOL_VERSION


def utcnow() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def new_run_id(command: str) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    return f"{command}-{stamp}-{secrets.token_hex(2)}"


class Run:
    """一次命令执行的清单记录器。

    用法::

        with Run(work, "build", {"years": "2019:2025"}) as run:
            run.add_output("panel/panel_wide.csv")
            run.counts["n_rows"] = 123
    """

    def __init__(self, work_dir: str | Path, command: str, params: dict | None = None):
        self.work_dir = Path(work_dir)
        self.command = command
        self.run_id = new_run_id(command)
        self.params = params or {}
        self.counts: dict[str, Any] = {}
        self.outputs: list[dict] = []
        self.inputs: list[dict] = []
        self.status = "running"
        self.started_at = utcnow()
        self.finished_at: str | None = None

    def add_output(self, rel_path: str) -> None:
        rel_path = str(rel_path)
        p = self.work_dir / rel_path
        if p.exists() and p.is_file():
            self.outputs.append(
                {"path": rel_path, "sha256": sha256_file(p), "bytes": p.stat().st_size}
            )

    def add_input(self, rel_path: str) -> None:
        rel_path = str(rel_path)
        p = self.work_dir / rel_path
        if p.exists() and p.is_file():
            self.inputs.append({"path": rel_path, "sha256": sha256_file(p)})

    def _payload(self) -> dict:
        return {
            "run_id": self.run_id,
            "command": self.command,
            "tool_version": TOOL_VERSION,
            "status": self.status,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "params": self.params,
            "counts": self.counts,
            "inputs": self.inputs,
            "outputs": self.outputs,
            "env": {
                "python": sys.version.split()[0],
                "platform": platform.platform(),
            },
        }

    def save(self) -> Path:
        self.finished_at = self.finished_at or utcnow()
        path = self.work_dir / "state" / "runs" / f"{self.run_id}.json"
        ensure_dir(path.parent)
        return write_json(path, self._payload())

    def __enter__(self) -> "Run":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        if exc_type is not None:
            self.status = "failed"
        elif self.status == "running":
            self.status = "success"
        if exc is not None:
            self.counts["error"] = f"{exc_type.__name__}: {exc}"
        self.save()
        return False
