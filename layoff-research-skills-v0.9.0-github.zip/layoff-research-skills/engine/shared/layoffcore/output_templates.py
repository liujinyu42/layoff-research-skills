"""Executable bundled output contracts, shared by preparation and portable skills."""
from pathlib import Path
import argparse,json,hashlib,shutil
NAMES={'salary':'comprehensive-salary-tracker','tracker':'layoff-hcm-tracker','qualitative':'layoff-hcm-qualitative','quantitative':'layoff-hcm-quantitative'}

def contract_path(kind):
 root=Path(__file__).resolve().parents[2]
 for path in [root/'skills'/NAMES[kind]/'assets/output_contract.json',root/'assets/output_contract.json']:
  if path.is_file():
   if json.loads(path.read_text())['kind']!=kind:continue
   return path
 raise ValueError('Bundled output contract missing for '+kind)

def bind(payload,kind):
 path=contract_path(kind);spec=json.loads(path.read_text());columns=payload['columns']
 payload['metadata']['output_contract']={'schema_version':spec['schema_version'],'kind':kind,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'worksheet':spec['worksheet'],'record_grain':spec['record_grain']}
 payload['source_files'].append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 if kind in {'tracker','qualitative'}and payload['metadata'].get('result_layout')!='company_year_wide':
  payload['metadata']['output_contract']['layout_exception']='explicit legacy long; wide header contract not applied'
  return payload
 ordered=spec['columns']+[k for k in columns if k not in spec['columns']]
 absent=[k for k in spec['columns']if k not in columns]
 payload['rows']=[[record.get(k)for k in ordered]for record in (dict(zip(columns,row))for row in payload['rows'])]
 payload['columns']=ordered
 payload['metadata']['output_contract']['unprepared_columns_kept_null']=absent
 return payload

def main(kind,argv=None):
 p=argparse.ArgumentParser(description='Inspect or copy this skill bundled output template; no research data needed')
 p.add_argument('--copy-to');p.add_argument('--show-columns',action='store_true');a=p.parse_args(argv)
 path=contract_path(kind);spec=json.loads(path.read_text())
 if a.copy_to:
  target=Path(a.copy_to);target.mkdir(parents=True,exist_ok=True)
  for name in ['output_contract.json','output_template.csv','output_fields.csv','output_template.xlsx']:
   source=path.parent/name
   if not source.is_file():raise ValueError('Bundled template resource missing: '+name)
   if source.resolve()!=(target/name).resolve():shutil.copyfile(source,target/name)
 summary={k:spec[k]for k in ['kind','worksheet','record_grain','key_columns','schema_version']};summary['columns']=spec['columns']if a.show_columns else len(spec['columns']);summary['needs_external_template']=False
 print(json.dumps(summary,ensure_ascii=False,indent=2));return 0
