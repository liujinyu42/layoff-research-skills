"""List evidence-bearing media without downloading decorative or investor-deck images."""
from pathlib import Path
import hashlib,re
from urllib.parse import urljoin
from .io import read_csv,read_json

def tasks(work):
 from bs4 import BeautifulSoup
 w=Path(work);seen=set();out=[];reviewed=read_json(w/"review/media_review.json",[])
 for r in read_csv(w/'review/research_long.csv'):
  path=Path(r.get('source_path')or'')
  if not path.is_absolute():path=w/path
  if path.suffix.lower()not in {'.htm','.html'}or str(path)in seen or not path.is_file():continue
  seen.add(str(path));soup=BeautifulSoup(path.read_text(errors='replace'),'lxml')
  for marker in soup.find_all(string=re.compile(r'categorized as follows|employees are (?:shown|summarized)',re.I)):
   for img in marker.parent.find_all_next('img',limit=2):
    previous=img.find_previous(string=lambda value:bool(str(value).strip()))
    if previous is not marker:continue
    src=img.get('src','');url=urljoin(r.get('source_url')or'',src)
    if not src:continue
    source_hash=hashlib.sha256(path.read_bytes()).hexdigest()
    valid=False
    for decision in reviewed:
     image=w/(decision.get('image_path')or'')
     if decision.get('media_url')==url and decision.get('source_sha256')==source_hash and image.is_file() and hashlib.sha256(image.read_bytes()).hexdigest()==decision.get('image_sha256') and decision.get('transcription') and decision.get('criterion_application'):
      valid=True;break
    if valid:continue
    out.append({'cik':r['cik'],'fy':r['fy'],'var_id':'headcount_by_segment','media_url':url,'source_path':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'status':'visual_source_review_required','reason':'Employee categorization references a figure; the HTML text alone does not contain its values.','action':'Read the exact image or a matching official accessible source; preserve image hash, OCR/visual transcription and source year. Do not infer missing counts from placeholders or alt filenames.'})
 return out
