"""SEC EDGAR 客户端：统一限速、缓存、离线回放。

两种模式共用同一条解析路径：
- 在线：data.sec.gov 与 www.sec.gov/Archives
- 离线：``fixtures/submissions_{cik}.json`` + ``fixtures/docs/{accession}/{doc}``

离线模式用于测试与演示，不产生任何网络请求，也不改变解析逻辑。
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from .io import ensure_dir, read_json, write_json

SUBMISSIONS_URL = "https://data.sec.gov/submissions/CIK{cik10}.json"
ARCHIVE_URL = "https://www.sec.gov/Archives/edgar/data/{cik_int}/{acc_nodash}/{doc}"

ANNUAL_FORMS = ("10-K", "10-K/A", "20-F", "20-F/A")
EVENT_FORMS = ("8-K", "8-K/A", "6-K", "6-K/A")
PROXY_FORMS = ("DEF 14A", "DEF 14A/A", "DEFM14A")


class SecError(RuntimeError):
    pass


@dataclass
class SecClient:
    user_agent: str = ""
    offline_dir: Path | None = None
    cache_dir: Path | None = None
    rate_per_sec: float = 5.0
    _last_call: float = field(default=0.0, repr=False)

    def __post_init__(self) -> None:
        if not 0 < self.rate_per_sec <= 10:
            raise SecError("SEC_RATE_LIMIT 必须在 (0, 10] 区间内")

    # ------------------------------------------------------------ 校验
    def validate_ua(self) -> None:
        if self.offline_dir is not None:
            return
        ua = (self.user_agent or "").strip()
        if not ua or "example" in ua.lower() or "@" not in ua:
            raise SecError(
                "SEC 要求声明真实联系人与邮箱。请设置 SEC_USER_AGENT='姓名或项目 真实邮箱'，"
                "例如 'Layoff Research your.name@university.edu'。"
            )

    # ------------------------------------------------------------ 限速
    def _throttle(self) -> None:
        if self.offline_dir is not None:
            return
        interval = 1.0 / self.rate_per_sec
        wait = interval - (time.monotonic() - self._last_call)
        if wait > 0:
            time.sleep(wait)
        self._last_call = time.monotonic()

    def _request(self, url: str, *, missing_ok: bool = False):
        """Bounded transient retries; never silently reuse a stale discovery response."""
        import requests
        self.validate_ua()
        for attempt in range(3):
            self._throttle()
            try:
                response = requests.get(url, headers={"User-Agent": self.user_agent}, timeout=60)
            except requests.RequestException as exc:
                if attempt == 2:
                    raise SecError(f"请求失败: {url}: {exc}") from exc
                time.sleep(2 ** attempt)
                continue
            if response.status_code == 200:
                return response
            if missing_ok and response.status_code == 404:
                return None
            if response.status_code not in {429, 500, 502, 503, 504} or attempt == 2:
                raise SecError(f"请求失败 HTTP {response.status_code}: {url}")
            retry_after = response.headers.get("Retry-After", "")
            delay = float(retry_after) if retry_after.isdigit() else 2 ** attempt
            time.sleep(min(30, delay))
        raise SecError(f"请求重试已耗尽: {url}")

    def submissions(self, cik: str) -> dict:
        cik = str(cik).zfill(10)
        if self.offline_dir is not None:
            p = Path(self.offline_dir) / f"submissions_{cik.lstrip('0') or '0'}.json"
            if not p.exists():
                p = Path(self.offline_dir) / f"submissions_{cik}.json"
            payload = read_json(p)
            if payload is None:
                raise SecError(f"离线模式缺少公司提交清单: {p.name}")
            return payload
        # This index changes throughout the day. Disk is an audit snapshot, not a permanent cache.
        payload = self._request(SUBMISSIONS_URL.format(cik10=cik)).json()
        if self.cache_dir:
            write_json(Path(self.cache_dir) / f"submissions_{cik}.json", payload)
        return payload

    def submission_history(self, payload: dict, start_year: int, end_year: int) -> list[dict]:
        """Load historical columnar pages needed for the requested window.

        Include filings through end_year+1 for annual reports filed after fiscal year end.
        Missing a required page is a failed discovery, never evidence of no filings.
        """
        filings = payload.get("filings") or {}
        if not isinstance(filings, dict):
            return []
        pages = []
        for spec in filings.get("files", []):
            if spec.get("filingTo", "9999")[:4] < str(start_year):
                continue
            if spec.get("filingFrom", "0000")[:4] > str(end_year + 1):
                continue
            name = spec.get("name", "")
            if not name or Path(name).name != name:
                raise SecError("非法历史索引文件名")
            cache = Path(self.cache_dir) / name if self.cache_dir else None
            if self.offline_dir is not None:
                page = read_json(Path(self.offline_dir) / name)
                if page is None:
                    raise SecError(f"缺少所需历史索引: {name}")
            else:
                # Refresh historical indexes too: later amendments/deletions must be visible.
                page = self._request(f"https://data.sec.gov/submissions/{name}").json()
                if cache:
                    write_json(cache, page)
            pages.append({"filings": {"recent": page}})
        return pages

    def companyfacts(self, cik: str) -> dict:
        cik = str(cik).zfill(10)
        if self.offline_dir is not None:
            for name in (f"facts_{cik}.json", f"facts_{int(cik)}.json"):
                path = Path(self.offline_dir) / "facts" / name
                if path.exists():
                    return read_json(path)
            return {}
        response = self._request(
            f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json", missing_ok=True)
        return response.json() if response is not None else {}

    # ------------------------------------------------------------ 原文
    def document(self, cik: str, accession: str, name: str) -> str:
        acc_nodash = accession.replace("-", "")
        if self.offline_dir is not None:
            base = Path(self.offline_dir) / "docs"
            for cand in (base / acc_nodash / name, base / accession / name):
                if cand.exists():
                    return cand.read_text(encoding="utf-8", errors="replace")
            raise SecError(f"离线模式缺少原文: {acc_nodash}/{name}")

        url = ARCHIVE_URL.format(cik_int=int(cik), acc_nodash=acc_nodash, doc=name)
        return self._request(url).text


    def exhibit_texts(self, cik: str, accession: str, pattern: str = r"ex.*99") -> list[str]:
        """取附件（通常是 EX-99.1 新闻稿）。裁员数字常只出现在附件里。"""
        acc_nodash = accession.replace("-", "")
        rx = re.compile(pattern, re.I)
        if self.offline_dir is not None:
            base = Path(self.offline_dir) / "docs"
            folder = base / acc_nodash if (base / acc_nodash).exists() else base / accession
            if not folder.exists():
                return []
            files=[f for f in sorted(folder.iterdir())if f.is_file()and rx.search(f.name)]
            self.last_exhibit_selection={"accession":accession,"text_selected":[f.name for f in files if f.suffix.lower()in {".htm",".html",".txt"}],"nontext_deferred":[f.name for f in files if f.suffix.lower()not in {".htm",".html",".txt"}],"note":"Nontext items were not text-extracted; relevant PDFs/figures require explicit visual review."}
            out = []
            for f in files:
                if f.is_file() and rx.search(f.name) and f.suffix.lower() in {".htm", ".html", ".txt"}:
                    out.append(f.read_text(encoding="utf-8", errors="replace"))
            return out

        url = f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc_nodash}/index.json"
        payload = self._request(url).json()
        names = [it.get("name", "") for it in payload.get("directory", {}).get("item", [])]
        selected=[name for name in names if rx.search(name) and Path(name).suffix.lower() in {".htm", ".html", ".txt"}]
        self.last_exhibit_selection={"accession":accession,"text_selected":selected,"nontext_deferred":[name for name in names if rx.search(name)and name not in selected],"note":"Nontext items were not text-extracted; relevant PDFs/figures require explicit visual review."}
        return [self.document(cik, accession, name) for name in selected]


def parse_submissions(payload: dict, cid: int) -> list[dict]:
    """把提交清单拍平为 [{accession, form, filed, period, primary_doc, fy}]。

    同时兼容 SEC 原始列式结构（filings.recent）与仓库自用的行式结构（filings 列表）。
    """
    raw = payload.get("filings") or {}
    rows: list[dict] = []

    if isinstance(raw, dict) and "recent" in raw:
        recent = raw.get("recent") or {}
        keys = ["accessionNumber", "form", "filingDate", "reportDate", "primaryDocument"]
        columns = [recent.get(k, []) for k in keys]
        for i in range(len(columns[0]) if columns else 0):
            rec = {k: (columns[j][i] if i < len(columns[j]) else "") for j, k in enumerate(keys)}
            rows.append(
                {
                    "accession": rec["accessionNumber"],
                    "form": rec["form"],
                    "filed": rec["filingDate"],
                    "period": rec["reportDate"],
                    "primary_doc": rec["primaryDocument"],
                }
            )
    elif isinstance(raw, list):
        for rec in raw:
            rows.append(
                {
                    "accession": rec.get("accession") or rec.get("accessionNumber", ""),
                    "form": rec.get("form", ""),
                    "filed": rec.get("filed") or rec.get("filingDate", ""),
                    "period": rec.get("period") or rec.get("reportDate", ""),
                    "primary_doc": rec.get("primary_doc") or rec.get("primaryDocument", ""),
                }
            )
    else:
        raise SecError("提交清单结构无法识别：缺少 filings")

    for r in rows:
        r["cid"] = cid
        r["fy"] = fiscal_year_from(r.get("period", ""), r.get("form", ""))
    return [r for r in rows if r["accession"] and r["form"]]


def fiscal_year_from(period: str, form: str = "") -> int:
    """由期间结束日推断财年。

    规则：取期间结束日所在年份；若结束日在 1 月前 10 天（52/53 周财年常见），
    回退到上一年。更精确的财年应由年报 dei:DocumentFiscalYearFocus 校正。
    """
    if not period or len(period) < 10:
        return 0
    try:
        y, m, d = int(period[:4]), int(period[5:7]), int(period[8:10])
    except ValueError:
        return 0
    if m == 1 and d <= 10:
        return y - 1
    return y
