"""Reject demonstrably mistyped measurements even in an inspection export."""
import re
from .io import read_csv

def invalid_headcount(value,quote):
    try:n=float(value)
    except (TypeError,ValueError):return False
    token=re.escape(str(int(n))if n.is_integer()else str(n))
    percent=re.search(r'(?<![\d,])'+token+r'\s*(?:%|percent\b)',quote or'',re.I)
    count=re.search(r'(?<![\d,])'+token+r'\s*(?:full[- ]time\s+)?(?:employees|people|workers|associates|team members)\b',quote or'',re.I)
    return bool(percent and not count)

def validate_research_measures(work):
    rows=read_csv(work/'review/research_long.csv')
    grouped={}
    for r in rows:
        grouped.setdefault((r.get('cik'),r.get('fy')),{})[r.get('var_id')]=r
    for key,record in grouped.items():
        try:
            assets=float(record['total_assets']['value']);liabilities=float(record['total_liabilities']['value']);leverage=float(record['leverage']['value'])
        except (KeyError,TypeError,ValueError):continue
        if assets>0 and abs(leverage-liabilities/assets)>1e-10:raise ValueError('leverage does not equal same-row total liabilities / total assets: '+str(key)+'; re-review and derive')
    for r in rows:
        if r.get('var_id')=='headcount'and invalid_headcount(r.get('value'),r.get('quote')):
            raise ValueError('headcount is a workforce percentage rather than employee stock: '+str((r.get('cik'),r.get('fy')))+'; re-extract before exporting or deriving')
