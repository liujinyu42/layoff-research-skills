"""Versioned primary-annual narrative metrics, bundled with every skill."""
import argparse,math,json,re,hashlib
from pathlib import Path
from collections import Counter,defaultdict
from .io import read_csv,write_csv,write_json,read_json
from .coding_scope import annual_packages,narrative_start
METRIC_VERSION='primary-narrative-v0.7.3'
TOKEN = re.compile(r"[A-Za-z][A-Za-z'\-]+")
STOP = set(
    """the and for that with this from have has had are was were which will would could should
    our its their they them we us you your not but all any each other such than then there these
    those into upon also more most less least may might must can will shall do does did doing
    been being about above after again against because before below between both during each
    few further here how if in is it itself just me my no nor now off on once only or out over
    own same so some such too under until up very what when where while who whom why""".split()
)


def load_dict(path: Path) -> tuple[dict[str, list[tuple[str, float]]], list[tuple[str, str, float]]]:
    single: dict[str, list[tuple[str, float]]] = defaultdict(list)
    phrases: list[tuple[str, str, float]] = []
    for row in read_csv(path):
        term = (row.get("term") or "").strip().lower()
        cat = (row.get("category") or "").strip()
        weight = float(row.get("weight") or 1)
        if not term or not cat:
            continue
        if not math.isfinite(weight) or weight < 0:
            raise ValueError(f"词典权重必须为有限非负数: {term}")
        if " " in term:
            phrases.append((term, cat, weight))
        else:
            single[term].append((cat, weight))
    return dict(single), phrases


def count_categories(text: str, single: dict[str, list[tuple[str, float]]],
                     phrases: list[tuple[str, str, float]]) -> tuple[Counter, int]:
    tokens = [t.lower() for t in TOKEN.findall(text)]
    counts: Counter = Counter()
    for tok in tokens:
        # Literal terms are exact tokens; only an explicit trailing * enables stemming.
        # One token can measure multiple constructs, but synonyms cannot double count it.
        matched: dict[str, float] = {}
        for term, entries in single.items():
            if (tok.startswith(term[:-1]) if term.endswith("*") else tok == term):
                for cat, weight in entries:
                    matched[cat] = max(matched.get(cat, 0), weight)
        counts.update(matched)
    low = text.lower()
    for phrase, cat, weight in phrases:
        counts[cat] += weight * len(re.findall(rf"(?<!\w){re.escape(phrase)}(?!\w)", low))
    return counts, len(tokens)


def _vec(tokens: list[str]) -> Counter:
    return Counter(t for t in tokens if t not in STOP and len(t) > 3)


def _cosine(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    common = set(a) & set(b)
    num = sum(a[t] * b[t] for t in common)
    den = math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values()))
    return num / den if den else 0.0


def _jaccard(a: Counter, b: Counter) -> float:
    sa, sb = set(a), set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="词典法文本测度")
    ap.add_argument("--work", required=True)
    ap.add_argument("--dict", default=str(Path(__file__).parent / "seed_dictionary.csv"))
    args = ap.parse_args(argv)

    work = Path(args.work)
    single, phrases = load_dict(Path(args.dict))
    # v0.3.1 修复：原版按 accession 取"最新"申报，会把 10-K/A 修订件当作年度文本。
    # 10-K/A 常仅含 Part III（约 2 万词，而正本约 20-40 万词），导致 AI/劳动密度
    # 严重失真（Tesla、Shopify 多个年度密度接近 0 的假阴性）。
    # 另注意 base_form 已被归一化（10-K/A → 10-K），必须用原始 form 判断修订件。
    # 现规则：正本优先；仅当该年度没有正本时才使用修订件，并在输出中标注。
    packages=annual_packages(work)
    panel=read_csv(work/'panel/panel_wide.csv')
    if panel:
        scope={(str(r['cik']).zfill(10),int(r['fy']))for r in panel}
        packages={k:p for k,p in packages.items()if k in scope}
    if not packages: raise ValueError('no primary annual anchors; run tracker extract/build first')
    best={key:work/pkg['text_path'] for key,pkg in packages.items()}
    form_by_key={key:pkg['form'] for key,pkg in packages.items()}
    rows: list[dict] = []
    prev_vec: dict[str, tuple[int, Counter]] = {}
    # 统一口径的 AI 提及计数（不随种子词典变化，便于跨公司、跨版本复算）
    # Longest phrase wins: "generative AI" is one mention, not also a second AI hit.
    AI_RX = re.compile(r"(?i:generative\s+AI|artificial\s+intelligence|machine\s+learning)|\bAI\b")


    for (cik, fy), path in sorted(best.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        full_text = path.read_text(encoding="utf-8")
        from .coding_scope import detected_sections
        package=packages[(cik,fy)]
        detected=detected_sections(full_text,package['form'])
        package={**package,'sections':detected}if detected else package
        try: start=narrative_start(full_text,package); scope_basis='primary_annual_narrative'
        except ValueError: start=0; scope_basis='legacy_text_without_sections'
        from .textutil import nontraditional_narrative_scope
        fallback=nontraditional_narrative_scope(full_text,package["form"])
        end=fallback[1]if fallback else len(full_text)
        text=full_text[start:end]
        if not text.strip(): raise ValueError('empty annual narrative')
        counts, n_words = count_categories(text, single, phrases)
        vec = _vec([t.lower() for t in TOKEN.findall(text)])
        drift_cos = drift_jac = None
        if cik in prev_vec:
            previous_year, pv = prev_vec[cik]
            if previous_year == fy - 1 and pv and vec:
                drift_cos = round(1 - _cosine(pv, vec), 4)
                drift_jac = round(1 - _jaccard(pv, vec), 4)
        prev_vec[cik] = (fy, vec)

        per_k = {k: (1000 * counts[k] / n_words if n_words else 0.0) for k in
                 ("risk", "uncertainty", "negative", "positive", "ai", "labor")}
        net = (counts["positive"] - counts["negative"]) / (
            counts["positive"] + counts["negative"] + 1
        )
        rows.append(
            {
                "cik": cik,
                "fy": fy,
                "form": form_by_key[(cik, fy)],
                "is_amendment_text": 1 if form_by_key[(cik, fy)].endswith("/A") else 0,
                "n_chars": len(text),
                "n_words": n_words,
                "risk_density": round(per_k["risk"], 3),
                "uncertainty_density": round(per_k["uncertainty"], 3),
                "negative_density": round(per_k["negative"], 3),
                "positive_density": round(per_k["positive"], 3),
                "ai_density": round(per_k["ai"], 3),
                "ai_mentions": len(AI_RX.findall(text)),
                "ai_measure_version": METRIC_VERSION,
                "accession": packages[(cik,fy)]['accession'],
                "metric_scope_start": start, "metric_scope_end":end,
                "metric_scope_basis":scope_basis,
                "ai_mentions_per_10k": round(
                    10000 * len(AI_RX.findall(text)) / n_words, 3
                ) if n_words else "",
                "labor_density": round(per_k["labor"], 3),
                "net_tone": round(net, 4),
                "cosine_drift": "" if drift_cos is None else drift_cos,
                "jaccard_drift": "" if drift_jac is None else drift_jac,
                "text_path": str(path.relative_to(work)),
                "dictionary_sha256": __import__("hashlib").sha256(Path(args.dict).read_bytes()).hexdigest(),
                "text_sha256": __import__("hashlib").sha256(path.read_bytes()).hexdigest(),
            }
        )

    out = work / "derived" / "metrics" / "lexical.csv"
    write_csv(out, rows)
    write_json(work/'derived/metrics/lexical_meta.json', {'version':METRIC_VERSION,
        'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
        'dictionary_source':'bundled'if Path(args.dict).resolve()==(Path(__file__).parent/'seed_dictionary.csv').resolve()else'custom',
        'dictionary_path':str(Path(args.dict).resolve())if Path(args.dict).resolve()!=(Path(__file__).parent/'seed_dictionary.csv').resolve()else None,
        'dictionary_sha256':hashlib.sha256(Path(args.dict).read_bytes()).hexdigest(),
        'sources':[{'cik':r['cik'],'fy':r['fy'],'accession':r['accession'],'text_path':r['text_path'],'text_sha256':r['text_sha256'],'metric_scope_start':r['metric_scope_start'],'metric_scope_end':r['metric_scope_end']}for r in rows]})
    means = defaultdict(list)
    for r in rows:
        for k in ("risk_density", "ai_density", "labor_density", "net_tone"):
            means[k].append(r[k])
    n_amend = sum(r["is_amendment_text"] for r in rows)
    print(f"文本测度 {len(rows)} 份 -> {out}")
    print(f"  正本 {len(rows) - n_amend} 份，修订件回退 {n_amend} 份"
          + ("（这些年度的密度与正本不可直接比较）" if n_amend else ""))
    for k, v in means.items():
        print(f"  {k}: 均值 {sum(v)/len(v):.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


def ensure_metrics(work):
    work=Path(work);path=work/'derived/metrics/lexical.csv';meta=read_json(work/'derived/metrics/lexical_meta.json',{})
    dictionary=Path(meta['dictionary_path'])if meta.get('dictionary_source')=='custom'else Path(__file__).parent/'seed_dictionary.csv'
    if not dictionary.is_file():raise ValueError('explicit custom dictionary unavailable; restore it instead of silently replacing it')
    packages=annual_packages(work);expected={(c,y,p['accession'])for(c,y),p in packages.items()}
    actual={(str(s['cik']),int(s['fy']),s['accession'])for s in meta.get('sources',[])}
    valid=bool(expected)and expected==actual and meta.get('version')==METRIC_VERSION and path.is_file()
    valid=valid and meta.get('dictionary_sha256')==hashlib.sha256(dictionary.read_bytes()).hexdigest()
    if valid:
        valid=hashlib.sha256(path.read_bytes()).hexdigest()==meta.get('output_sha256')
        valid=valid and all((work/s['text_path']).is_file()and hashlib.sha256((work/s['text_path']).read_bytes()).hexdigest()==s['text_sha256']for s in meta['sources'])
    if valid:
        from .coding_scope import detected_sections
        from .textutil import nontraditional_narrative_scope
        for source in meta['sources']:
            package=packages[(str(source['cik']),int(source['fy']))];text=(work/package['text_path']).read_text();detected=detected_sections(text,package['form'])
            current={**package,'sections':detected}if detected else package
            start=narrative_start(text,current);fallback=nontraditional_narrative_scope(text,package['form']);end=fallback[1]if fallback else len(text)
            if source.get('metric_scope_start')!=start or source.get('metric_scope_end')!=end:valid=False;break
    if not valid: main(['--work',str(work),'--dict',str(dictionary)])
    return read_csv(path)
