"""Executable source/definition/coverage review; never certifies unperformed semantic judgment."""
from pathlib import Path
import argparse,hashlib,json,re,math
from .io import read_csv,read_json,write_json,write_csv
from .source_cache import SourceCache
from .textutil import locate_sections,nontraditional_narrative_scope

def check(work,kind='all',write=True,coder=None):
 documents=SourceCache()
 w=Path(work);issues=[];tasks=[];bindings={};counts={};semantic_tasks=[]
 def finding(check,severity,reason,record=None,action='Read the original source and repair or explicitly retain an unresolved value.'):
  r={'check':check,'severity':severity,'reason':reason,'action':action}
  if record:r.update({k:record.get(k) for k in ['cik','fy','var_id','code_id','event_id','source_url','source_path'] if record.get(k) not in [None,'']})
  issues.append(r);tasks.append({**r,'status':'pending','cannot_be_closed_by_hash_only':True})
 def bind(path):
  p=Path(path)
  if p.is_file():bindings[str(p)]=documents.read(p,text=False)['sha256']
 if kind in {'all','tracker','qualitative','quantitative'}:
  long=read_csv(w/'review/research_long.csv');codes=read_csv(w/'coding/codes.csv')
  coders={r.get('coder_id')for r in codes}
  if coder is None and len(coders)>1:raise ValueError('multiple coders: explicitly select --coder for self_audit')
  coder=coder or next(iter(coders),None)
  if coder is not None:codes=[r for r in codes if r.get('coder_id')==coder]
  counts['source_review_pending']=sum(r.get('status') in {'not_checked','source_missing','numeric_source_unresolved','numeric_period_needs_review','not_disclosed_in_available_sources','text_candidate_needs_review','source_located_pending_semantic_review','scoped_search_only_pending_semantic_review','reference_conflict_needs_review'} for r in long)
  if counts['source_review_pending']:finding('source_judgments_incomplete','completion',str(counts['source_review_pending'])+' source positions need actual definition-based judgment',action='Continue review/review_tasks.jsonl; reject needs complete reading, scope/hash AND substantive criterion application.')
  decisions=read_json(w/'review/self_review_decisions.json',[])
  by_decision={(r.get('code_id'),r.get('record_sha256')):r for r in decisions}
  for code in codes:
   relevant={k:code.get(k)for k in ['code_id','cik','fy','var_id','coder_id','value','quote','text_sha256','codebook_sha256','accession','scope_start','scope_end']}
   digest=hashlib.sha256(json.dumps(relevant,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
   d=by_decision.get((code.get('code_id'),digest),{})
   reviewed=d.get('record_sha256')==digest and d.get('decision')=='keep_verified' and bool(d.get('criterion_application')) and bool(d.get('reviewer_kind'))
   if not reviewed:
    semantic_tasks.append({**relevant,'expected_record_sha256':digest,'text_path':code.get('text_path'),'review_instruction':'Read the current full source/definition again. Check positive evidence support, negative counterevidence, source images and whether abstention is resolvable. Correct through submit_decisions/review tools first, then verify the resulting record. Copying a hash is not review.','status':'second_source_read_required'})
  counts['second_read_expected']=len(codes);counts['second_read_recorded']=len(codes)-len(semantic_tasks)
  if semantic_tasks:finding('second_source_read_incomplete','completion',str(len(semantic_tasks))+' coding records require a documented second source/definition review',action='Read qa/semantic_review_tasks; submit corrections through normal coding tools, then record actual final-record review in review/self_review_decisions.json. Same-model review is not independent human reliability.')
  for row in codes:
   if str(row.get('rationale')or'').count('该年度员工总数')>=2:
    finding('rationale_contains_unresolved_number_placeholders','completion','Rationale replaced several numbers/dates with generic placeholders; it no longer documents the actual source-specific reasoning',row,action='Restore the actual same-year source facts and distinguish dates, percentages and employee counts. Do not replace every number to bypass validation.')
  counts['abstentions']=sum(not r.get('value')for r in codes)
  if counts['abstentions']:finding('coding_abstentions','completion',str(counts['abstentions'])+' undecided codes; audit pass is not full completion',action='Inspect na_reason and original text/images; seek a qualifying source before deciding, never convert null to zero.')
  if kind in {'all','tracker','quantitative'}:
   for r in long:
    if r.get('kind')!='number' or r.get('value') in [None,'']:continue
    if r.get('status') in {'primary_source_verified','reviewed_reference_resolution'}:
     p=Path(r.get('source_path')or'');p=p if p.is_absolute()else w/p;bind(p)
     if not p.is_file()or not r.get('source_sha256')or bindings.get(str(p))!=r['source_sha256']:finding('numeric_source_missing_or_changed','integrity','Numeric provenance does not match actual source',r)
    if r.get('var_id')=='headcount' and re.search(r'(?is)(?:sales\s+and\s+marketing|research\s+and\s+development|engineering)\s+(?:functions?|teams?).{0,100}(?:consist|employ|\d)',r.get('quote','')):
     finding('functional_subset_as_total_headcount','integrity','A functional employee subtotal is not company employee stock',r,action='Locate an explicit Employees total/table and preserve function components separately.')
   keyed={}
   for r in long:keyed.setdefault((r.get('cik'),r.get('fy')),{})[r['var_id']]=r
   for key,vals in keyed.items():
    try:
     l,a,v=[float(vals[k]['value'])for k in ['total_liabilities','total_assets','leverage']]
     if a>0 and not math.isclose(l/a,v,rel_tol=1e-10,abs_tol=1e-10):finding('leverage_definition_mismatch','integrity','leverage must equal total_liabilities/total_assets',vals['leverage'])
    except (KeyError,TypeError,ValueError):pass
  for p in sorted((w/'derived/cells').glob('*.json')):
   d=read_json(p,{})
   if d.get('form')not in {'10-K','20-F'}:continue
   textpath=w/d.get('text_path','');bind(textpath)
   if not textpath.is_file():continue
   t=textpath.read_text();fresh=locate_sections(t,d['form'])
   if nontraditional_narrative_scope(t,d['form']):finding('nontraditional_annual_scope','review','Numbered Items occur only in the cross-reference index; effective scope is explicitly the complete annual narrative, not an Item1/7/8 reconstruction',d,action='Read the expanded source. Retain source_scope_basis and validate section-specific conclusions against the filing cross-reference; do not reuse old index-only decisions.')
   for key,old in d.get('sections',{}).items():
    if key in fresh and list(old)!=[fresh[key].start,fresh[key].end]:finding('stored_section_scope_changed','integrity','Stored section '+key+' differs from current source locator',d,action='Re-extract from preserved raw HTML, build, re-dispatch affected tasks and recalculate metrics/analysis; do not edit hashes.')
  for e in (read_csv(w/'events/layoff_events_independent.csv') if kind in {'all','tracker','quantitative'} else []):
   for field in ['severance_amount']:
    proofs=e.get('measure_sources')or e.get('measurement_evidence')or'{}'
    try:m=json.loads(proofs).get(field,{})
    except (TypeError,ValueError):m={}
    quote=m.get('quote')or m.get('evidence')or''
    raw=m.get('raw')or''
    tail=quote.split(raw,1)[-1]if raw and raw in quote else''
    if tail and re.match(r'(?is)^\s*(?:to\s*\$?[\d.,]+\s*(?:million|billion)\s*)?(?:in\s+)?(?:exit\s+charges|office\s+space|real\s+estate)',tail):finding('office_exit_amount_as_severance','integrity','Amount belongs to office/property exit charges, not severance',e)
    if re.search(r'(?i)severance and (?:related|other) personnel',quote):finding('mixed_personnel_cost_candidate','review','Preserve mixed personnel-cost nature; not a certified annual pure-severance expense',e)
  for m in read_csv(w/'derived/metrics/lexical.csv'):
   package=next((read_json(p,{})for p in (w/'derived/cells').glob('*.json') if (lambda d:d.get('cik')==m.get('cik') and str(d.get('fy'))==m.get('fy') and d.get('accession')==m.get('accession'))(read_json(p,{}))),None)
   if not package:continue
   path=w/package.get('text_path','')
   if path.is_file():
    text=path.read_text();fresh=locate_sections(text,package['form'])
    starts=[s.start for s in fresh.values()]
    if starts and (str(min(starts))!=str(m.get('metric_scope_start'))or(nontraditional_narrative_scope(text,package['form'])and str(nontraditional_narrative_scope(text,package['form'])[1])!=str(m.get('metric_scope_end')))):finding('lexical_scope_stale','integrity','Text metric begins at an obsolete section/index instead of the current annual narrative',package,action='Run ensure_metrics or lexical.py using the current locator; regenerate analysis and all earlier exports.')
  from .source_media import tasks as media_tasks
  media=media_tasks(w) if kind in {'all','tracker','qualitative'} else []
  if media:
   counts['unread_media_candidates']=len(media)
   finding('source_figure_review_queue','completion',str(len(media))+' employee-figure candidates require visual source validation',action='Inspect qa/repair_tasks and the exact source image; no automatic download of unrelated figures.')
   tasks.extend(media)
  for r in codes:
   if not r.get('value'):tasks.append({'check':'resolve_abstention','severity':'completion',**{k:r.get(k)for k in ['cik','fy','var_id','code_id','na_reason','text_path']},'status':'pending','action':'Read relevant text and any referenced image; provide a real source-bound decision or retain a specific unresolved reason.'})
  for task in tasks:
   if task.get('check')!='resolve_abstention' or task.get('var_id') not in {'ai_impact','training_investment'}:continue
   path=w/(task.get('text_path')or'')
   if not path.is_file():continue
   text=path.read_text();pattern=r'artificial intelligence|machine learning'if task['var_id']=='ai_impact'else r'employee development|talent development programs|learning and development resources|self-directed learning'
   candidates=[]
   for match in list(re.finditer(pattern,text,re.I))[:8]:
    start=max(0,text.rfind('\n\n',0,match.start()));start+=2 if text[start:start+2]=='\n\n'else 0
    end=text.find('\n\n',match.end());end=len(text)if end<0 else end
    if end-start<80:
     later=text.find('\n\n',end+2);end=min(len(text),later if later>=0 else end+700)
    candidates.append({'char_start':start,'char_end':end,'quote':text[start:end],'status':'candidate_requires_definition_judgment'})
   task['alternative_source_candidates']=candidates
  bind(w/'review/research_long.csv');bind(w/'coding/codes.csv')
 elif kind=='salary':
  validation=read_json(w/'exports/validation.json',{});manifest=read_json(w/'exports/manifest.json',{});counts['query_states']=manifest.get('query_states',{})
  for issue in validation.get('issues',[]):finding(issue.get('check','salary_validation'),'completion'if issue.get('check')in {'query_unresolved','partial_export','queries_removed_from_active_plan','original_scope_not_verified'}else'integrity',str(issue),action='Continue the original plan; source integrity errors must be repaired before any export.')
  bind(w/'plan.json');bind(w/'exports/salary_records.csv')
 report={'version':'0.8.3','kind':kind,'coder':coder,'integrity_pass':not any(r['severity']=='integrity'for r in issues),'completion_pass':not any(r['severity'] in {'completion','integrity'}for r in issues),'semantic_truth_certified':False,'counts':counts,'issues':issues,'source_bindings':bindings,'repair_task_count':len(tasks),'semantic_review_task_count':len(semantic_tasks),'second_read_required':'Actual source/definition judgment is required; mechanical checks cannot certify semantic truth.'}
 if write:
  write_json(w/'qa'/('self_audit_'+kind+'.json'),report)
  semantic_path=w/'qa'/('semantic_review_tasks_'+kind+'.jsonl');semantic_path.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in semantic_tasks))
  target=w/'qa'/('repair_tasks_'+kind+'.jsonl');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in tasks))
 return report

def main(argv=None):
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work',required=True);p.add_argument('--kind',choices=['all','tracker','qualitative','quantitative','salary'],default='all');p.add_argument('--allow-incomplete',action='store_true');p.add_argument('--coder');p.add_argument('--verbose',action='store_true');a=p.parse_args(argv);r=check(a.work,a.kind,coder=a.coder);summary={k:r[k]for k in ['version','kind','coder','integrity_pass','completion_pass','semantic_truth_certified','counts','repair_task_count','semantic_review_task_count']};summary.update(issue_count=len(r['issues']),first_issues=r['issues'][:5],full_report=str(Path(a.work)/'qa'/('self_audit_'+a.kind+'.json')));print(json.dumps(r if a.verbose else summary,ensure_ascii=False,indent=2));return 0 if r['integrity_pass']and(r['completion_pass']or a.allow_incomplete)else 2
if __name__=='__main__':raise SystemExit(main())
