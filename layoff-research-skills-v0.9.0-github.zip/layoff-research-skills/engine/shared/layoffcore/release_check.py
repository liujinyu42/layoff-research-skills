"""Complete-delivery checks independent of whether a renderer produced an XLSX."""
from pathlib import Path
import argparse,hashlib,json
from .io import read_csv,read_json,write_json
from .schema import TOOL_VERSION

def check_release(work,kind,coder=None):
    w=Path(work);profile=read_json(Path(__file__).parent/'research_profile.json');issues=[]
    panel=read_csv(w/'panel/panel_wide.csv');keys={(str(r['cik']).zfill(10),str(r['fy']))for r in panel}
    from .requested_coverage import requested_periods
    expected_keys={(str(r['cik']).zfill(10),str(r['fy']))for r in requested_periods(w,panel)}
    if not keys:issues.append({'check':'company_year_scope_missing'})
    request=read_json(w/'research_request.json',{})
    if request:
        from .request_scope import check_scope
        scope=check_scope(w,request['years'])
        if not scope['pass']:issues.append({'check':'requested_company_years_missing','missing':scope['missing_company_years'][:10]})
    if kind in {'tracker','quantitative'}:
        records=read_csv(w/'review/research_long.csv');required={r['var_id']for r in profile['company_year_variables']}
        expected={(c,y,v)for c,y in expected_keys for v in required}
        seen=[(str(r['cik']).zfill(10),str(r['fy']),r['var_id'])for r in records]
        if set(seen)!=expected or len(seen)!=len(expected):issues.append({'check':'all_88_variable_positions','expected':len(expected),'actual':len(seen)})
        review=read_json(w/'review/review_summary.json',{})
        if not review.get('strict_release_pass'):issues.append({'check':'source_or_semantic_review_incomplete','pending':review.get('pending_review_cells')})
        if review.get('tool_version')!=TOOL_VERSION:issues.append({'check':'review_engine_not_current','action':'rerun review'})
        if records and review.get('output_hashes',{}).get('research_long.csv')!=hashlib.sha256((w/'review/research_long.csv').read_bytes()).hexdigest():issues.append({'check':'research_review_stale'})
    if kind in {'qualitative','quantitative','tracker'}:
        metric=read_csv(w/'derived/metrics/lexical.csv');m={(str(r['cik']).zfill(10),str(r['fy'])):r for r in metric}
        missing=[]
        for k in keys:
            row=m.get(k,{})
            if any(row.get(v)in ['',None]for v in profile['required_text_metrics']):missing.append(k)
        meta=read_json(w/'derived/metrics/lexical_meta.json',{})
        from .lexical_metrics import METRIC_VERSION
        if meta.get('version')!=METRIC_VERSION:issues.append({'check':'text_metric_engine_not_current'})
        if any(r.get('metric_scope_basis')!='primary_annual_narrative'for r in metric):issues.append({'check':'primary_narrative_scope_not_established'})
        if missing or len(metric)!=len(keys):issues.append({'check':'required_primary_text_metrics_missing','company_years':missing[:10]})
        elif not meta or meta.get('output_sha256')!=hashlib.sha256((w/'derived/metrics/lexical.csv').read_bytes()).hexdigest():issues.append({'check':'text_metrics_version_or_hash_unverified'})
        for s in meta.get('sources',[]):
            p=w/s['text_path']
            if not p.is_file()or hashlib.sha256(p.read_bytes()).hexdigest()!=s['text_sha256']:
                issues.append({'check':'text_metrics_source_changed'});break
    if kind in {'qualitative','quantitative'}:
        codes=read_csv(w/'coding/codes.csv');available={r.get('coder_id')for r in codes};coder=coder or(next(iter(available))if len(available)==1 else None)
        codes=[r for r in codes if r.get('coder_id')==coder];required=set(profile['required_coding_constructs'])
        seen={(str(r['cik']).zfill(10),str(r['fy']),r['var_id'])for r in codes if r.get('value')not in ['',None]}
        expected={(c,y,v)for c,y in expected_keys for v in required}
        if not expected<=seen:issues.append({'check':'all_21_constructs_not_coded','expected':len(expected),'missing_or_abstained':len(expected-seen)})
        audit=read_json(w/'coding/code_audit.json',{})
        if not audit.get('pass')or audit.get('coder')!=coder:issues.append({'check':'coding_audit_missing_or_failed'})
        elif audit.get('audit_version')!=TOOL_VERSION:issues.append({'check':'coding_audit_engine_not_current'})
        elif audit.get('codes_file_sha256')!=hashlib.sha256((w/'coding/codes.csv').read_bytes()).hexdigest():issues.append({'check':'coding_audit_stale'})
        from .coding_dependencies import binding_issues
        if not audit.get('source_bindings'):issues.append({'check':'coding_source_binding_manifest_missing'})
        else:issues.extend(binding_issues(w,audit['source_bindings']))
    if kind=='quantitative':
        data=read_csv(w/'analysis/analysis.csv')
        actual={(str(r['cik']).zfill(10),str(r['fy']))for r in data}
        if not data or actual!=keys or len(actual)!=len(data):issues.append({'check':'analysis_company_years_missing_or_duplicated'})
        derivation=read_json(w/'analysis/derivation_meta.json',{});state=read_json(w/'analysis/last_derivation.json',{})
        if state.get('status')!='complete':issues.append({'check':'analysis_not_completed'})
        if derivation.get('measurement_policy',{}).get('quarantined_cells',1)>0:issues.append({'check':'high_risk_measurements_not_reviewed','action':'prepare measurements, certify accepted or source-reviewed missing values, then derive again'})
        for field in profile['required_text_metrics']:
            if any(r.get(field)in ['',None]for r in data):issues.append({'check':'required_metric_dropped_from_analysis','field':field})
    return {'pass':not issues,'kind':kind,'profile_version':profile['version'],'issues':issues,
            'meaning':'all declared positions reviewed; source-nondisclosure is distinct from an obtained value; independent semantic reliability is a separate assessment'}

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work',required=True);p.add_argument('--kind',choices=['tracker','qualitative','quantitative'],required=True);p.add_argument('--coder');p.add_argument('--out');a=p.parse_args(argv)
    result=check_release(a.work,a.kind,a.coder);write_json(Path(a.out)if a.out else Path(a.work)/'qa'/('full_release_'+a.kind+'.json'),result);print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['pass']else 2
