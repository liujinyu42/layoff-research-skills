"""Source-bound coding scopes; shared by independent installed skills."""
from pathlib import Path
import hashlib,json,re
from functools import lru_cache
from .io import read_csv,read_json
from .source_cache import document

ANNUALS={'10-K','20-F','40-F'}
FULL={'全文','full_text','full text','all'}
TECH=re.compile(r'us-gaap:|(?:https?://)?(?:fasb\.org|xbrl\.org)/|\b(?:iso4217|xbrli|dei):|^\s*[a-z][a-z0-9_-]{1,20}:[A-Z][A-Za-z0-9]+\s*$',re.I)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical_hash(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()
def local(work,path):
 p=(Path(work)/path).resolve()
 if not p.is_relative_to(Path(work).resolve()):raise ValueError('coding source path outside work')
 return p

def annual_packages(work):
 w=Path(work);packages={}
 anchors={(str(r['cik']).zfill(10),int(r['fy'])):r['accession']for r in read_json(w/'panel/panel_meta.json',{}).get('company_periods',[])}
 for p in sorted((w/'derived/cells').glob('*.json')):
  d=read_json(p,{})
  if d.get('form')not in ANNUALS:continue
  key=(str(d['cik']).zfill(10),int(d['fy']))
  if anchors and key not in anchors:continue
  if key in anchors and d['accession']!=anchors[key]:continue
  if key not in packages or d['accession']>packages[key]['accession']:packages[key]=d
 return packages

def narrative_start(text,package):
 spans=[v[0]for k,v in package.get('sections',{}).items()if k in {'1','1A','7','8'} and v and v[1]>v[0]]
 if spans:return min(spans)
 # Legacy sources may not have section metadata. Keep offsets in the original text.
 for m in re.finditer(r'[^\n]+(?:\n(?!\n)[^\n]+)*',text):
  q=m.group()
  if len(re.findall('[A-Za-z]',q))>=80 and len(q.split())>=20 and not TECH.search(q):return m.start()
 raise ValueError('no narrative body found; source scope unavailable')

@lru_cache(maxsize=32)
def detected_sections(text,form):
 from .textutil import locate_sections
 return {k:[v.start,v.end]for k,v in locate_sections(text,form).items()}

def scope_for(text,package,section):
 section=str(section)
 if section in {'8','11'} and str(package.get('form','')).startswith('DEF'):
  return narrative_start(text,package),len(text),'complete_proxy_narrative'
 if section.casefold()in FULL:return narrative_start(text,package),len(text),'full_narrative_original_offsets'
 sections=package.get('sections',{})
 if package.get('form')in {'10-K','20-F'}:
  detected=detected_sections(text,package['form'])
  if detected:sections=detected
 span=sections.get(section)
 if not span or not 0<=int(span[0])<int(span[1])<=len(text):raise ValueError('requested section unavailable: '+section)
 from .textutil import nontraditional_narrative_scope
 if nontraditional_narrative_scope(text,package.get('form')):
  return int(span[0]),int(span[1]),'nontraditional_full_annual_narrative_not_numbered_item'
 return int(span[0]),int(span[1]),'explicit_section'

def anchor_windows(text,patterns,start,end,radius):
 hits=[]
 for pattern in patterns:
  # Short anchors are whole tokens. Long patterns retain documented regex support.
  rx=r'(?<!\w)'+re.escape(pattern)+r'(?!\w)'if re.fullmatch('[A-Za-z]{1,3}',pattern)else pattern
  for m in re.finditer(rx,text[start:end],re.I):
   at=start+m.start();line_start=text.rfind('\n',start,at)+1;line_end=text.find('\n',at,end)
   if line_end<0:line_end=end
   if TECH.search(text[line_start:line_end]):continue
   hits.append((max(start,at-radius),min(end,start+m.end()+radius)))
 hits.sort();merged=[]
 for lo,hi in hits:
  if merged and lo<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],hi))
  else:merged.append((lo,hi))
 return merged

def validate_registered(work,key,entry,definition_hash,expected_role=None,expected_section=None,source_cache=None):
 """A new construct must bind to the CURRENT annual anchor, not any surviving text."""
 w=Path(work);key=(str(key[0]).zfill(10),int(key[1]),str(key[2]))
 if (str(entry.get('cik','')).zfill(10),int(entry.get('fy',0)),entry.get('var_id'))!=key:raise ValueError('registered construct key mismatch')
 if expected_role is not None and entry.get('source_role','annual')!=expected_role:raise ValueError('registered source role differs from definition')
 if expected_section is not None and str(entry.get('section'))!=str(expected_section):raise ValueError('registered section differs from definition')
 source_cache={}if source_cache is None else source_cache
 if 'annual'not in source_cache:source_cache['annual']=annual_packages(w)
 annual=source_cache['annual']
 if entry.get('source_role')=='proxy':
  proxy_key=('proxy',*key[:2])
  if proxy_key not in source_cache:source_cache[proxy_key]=proxy_package(w,*key[:2],annual=annual)
  package=source_cache[proxy_key]
 else:package=annual.get(key[:2])
 if package is None or package['accession']!=entry.get('accession'):raise ValueError('registered construct annual source changed')
 if entry.get('codebook_sha256')!=definition_hash:raise ValueError('registered construct definition changed')
 path=local(w,package['text_path'])
 if package['text_path']!=entry.get('text_path')or not path.is_file()or document(path,source_cache)['sha256']!=entry.get('text_sha256'):raise ValueError('registered construct text changed')
 text=document(path,source_cache)['text']
 lo,hi,_=scope_for(text,package,entry['section'])
 if (lo,hi)!=(entry.get('scope_start'),entry.get('scope_end')):raise ValueError('registered construct scope changed')
 return entry

def proxy_package(work,cik,fy,annual=None):
 """Select the first full proxy after the annual end and before the next annual end."""
 import sqlite3
 w=Path(work);annual=annual if annual is not None else annual_packages(w);p=annual.get((str(cik).zfill(10),int(fy)))
 db_path=w/'state/state.db'
 if not p or not p.get('period') or not db_path.exists():return None
 next_ends=[x.get('period')for(c,y),x in annual.items()if c==str(cik).zfill(10)and y>int(fy)and x.get('period')]
 db=sqlite3.connect(f'file:{db_path}?mode=ro',uri=True);db.row_factory=sqlite3.Row
 filings=[dict(r)for r in db.execute("SELECT * FROM filings WHERE cik=? AND form='DEF 14A' AND status='parsed'",(str(cik).zfill(10),))];db.close()
 filings=[f for f in filings if f.get('filed','')>=p['period']and(not next_ends or f.get('filed','')<min(next_ends))]
 if not filings:return None
 acc=min(filings,key=lambda f:f['filed'])['accession']
 for path in(w/'derived/cells').glob('*.json'):
  candidate=read_json(path,{})
  if candidate.get('accession')==acc:return candidate
 return None

def negative_review(item,text,patterns):
 lo,hi=item['scope_start'],item['scope_end']
 return {'scope_start':lo,'scope_end':hi,'text_sha256':hashlib.sha256(text.encode()).hexdigest(),
         'searches':[{'pattern':p,'count':len(list(re.finditer(p,text[lo:hi],re.I)))}for p in patterns]}

def validate_negative(item,text,proof):
 if not isinstance(proof,dict)or not proof.get('searches'):raise ValueError('negative_scope_review_missing')
 if any(proof.get(k)!=item.get(k)for k in ['scope_start','scope_end','text_sha256']):raise ValueError('negative_scope_review_stale')
 for row in proof['searches']:
  if not isinstance(row.get('pattern'),str)or not row['pattern']:raise ValueError('negative_search_pattern_missing')
  actual=len(list(re.finditer(row['pattern'],text[item['scope_start']:item['scope_end']],re.I)))
  if row.get('count')!=actual:raise ValueError('negative_search_count_mismatch')
 return True
