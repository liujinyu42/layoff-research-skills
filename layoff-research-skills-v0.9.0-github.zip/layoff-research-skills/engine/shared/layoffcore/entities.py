"""Stable-ID joins, explicit historical aliases, and ambiguity rather than fuzzy guesses."""
import re

KNOWN = {
 '0000320193': ['Apple', 'Apple Inc.'],
 '0000789019': ['Microsoft', 'Microsoft Corporation'],
 '0001326801': ['Meta', 'Meta Platforms', 'Meta Platforms Inc.', 'Facebook', 'Facebook Inc.'],
 '0001633917': ['PayPal', 'PayPal Holdings', 'PayPal Holdings Inc.'],
}

def name_key(value):
    words = re.sub(r'[^a-z0-9 ]', '', str(value or '').lower()).split()
    while words and words[-1] in {'inc','incorporated','corp','corporation','ltd','limited','plc'}:
        words.pop()
    return ''.join(words)

class EntityIndex:
    def __init__(self, rows):
        self.entities = {}; self.aliases = {}
        for row in rows:
            cik=str(row['cik']).zfill(10); self.entities[cik]=row
            names=[row.get('company'),row.get('ticker')]+KNOWN.get(cik,[])
            names+=re.split(r'[|;]',str(row.get('aliases') or ''))
            for name in names:
                key=name_key(name)
                if key:self.aliases.setdefault(key,set()).add(cik)

    def resolve(self, cik=None, ticker=None, company=None):
        if cik and str(cik).replace('.0','').isdigit():
            key=str(cik).replace('.0','').zfill(10)
            return self.entities.get(key)
        ids=set()
        for value in [ticker,company]:
            ids.update(self.aliases.get(name_key(value),set()))
        if len(ids)>1:raise ValueError('ambiguous company aliases; provide a CIK: '+str(company))
        return self.entities[next(iter(ids))] if ids else None
