"""Portable typed result preparation for a single-sheet Excel renderer."""
from pathlib import Path
import argparse,csv,json,math,hashlib,sqlite3
from .io import read_csv,read_json,write_json

NUMERIC_IDS={'fy','year','cid','财年','__text_part','__text_parts'}
TEXT_IDS={'cik','ticker','company','var_id','code_id','coder_id','accession','event_id','posting_id','query_id'}
def number(value):
 try:
  v=float(value)
  return int(v)if v.is_integer()else v if math.isfinite(v)else None
 except(TypeError,ValueError):return None
def infer(key,value):
 if value in [None,'']:return None
 if key in TEXT_IDS or key.endswith(('_id','sha256')):return str(value)
 if any(t in key for t in ['quote','narrative','rationale','definition','negative_review','unit','status']):return str(value)
 if value in ['True','False']:return value=='True'
 v=number(value)
 return v if v is not None else str(value)
def split_text(value,limit=850):
 return [value[i:i+limit]for i in range(0,len(value),limit)]or['']

def prepare(kind,work,coder=None,allow_partial=False,layout=None):
 w=Path(work).resolve();sources=[];meta={'skill':kind,'worksheet_count':1,'table_count':1,'empty_values_are_not_zero':True}
 def source(path):
  path=w/path
  if not path.is_file():raise ValueError('missing result input: '+str(path))
  sources.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
  return read_csv(path)
 if kind in {'tracker','qualitative','quantitative'}:
  from .measure_guards import validate_research_measures
  if kind in {'tracker','quantitative'}:validate_research_measures(w)
  from .coding_scope import annual_packages
  if annual_packages(w):
   from .lexical_metrics import ensure_metrics
   ensure_metrics(w)
   source(Path('derived/metrics/lexical.csv'))
  from .requested_coverage import source_coverage
  coverage_rows=source_coverage(w)
  meta['source_coverage']={'requested_company_years':len(coverage_rows),'unavailable_annual_positions':sum(r['status']!='annual_anchor_available'for r in coverage_rows),'records':coverage_rows}
 from .self_audit import check as self_check
 inspection=self_check(w,kind,coder=coder)
 if not inspection['integrity_pass']:raise ValueError('self_audit integrity errors: '+str([r["check"] for r in inspection["issues"] if r["severity"]=="integrity"])+ '; repair qa/repair_tasks_'+kind+'.jsonl before export')
 meta['self_audit']={k:inspection[k]for k in ['version','integrity_pass','completion_pass','semantic_truth_certified','counts','repair_task_count']}
 if kind=='tracker':
  rows=source(Path('review/research_long.csv'));review=read_json(w/'review/review_summary.json',{})
  if not review:raise ValueError('run review.py before exporting the research result')
  coding=read_csv(w/'coding/codes.csv');by_key={(r['cik'],str(r['fy']),r['var_id']):r for r in rows};coders={r.get('coder_id')for r in coding}
  if len(coders)==1:
   gaps=[r.get('code_id')for r in coding if r.get('value')=='1'and(r['cik'],str(r['fy']),r['var_id'])in by_key and by_key[(r['cik'],str(r['fy']),r['var_id'])].get('kind')=='text'and not by_key[(r['cik'],str(r['fy']),r['var_id'])].get('value')]
   if gaps:raise ValueError('positive coding evidence exists but research text is empty; rerun tracker review.py after coding audit: '+str(gaps[:5]))
  status='reviewed_research'if review.get('strict_release_pass')else'research_candidates_pending_review'
  meta.update(strict_release_pass=review.get('strict_release_pass'),pending_review_cells=review.get('pending_review_cells'))
  for r in rows:
   r['numeric_value']=number(r.get('value'))if r.get('kind')in {'number','flag'}else None
   r['narrative_value']=r.get('value','')if r.get('kind')not in {'number','flag'}else''
   r.pop('value',None)
   if r.get('source_path'):r['source_file']=Path(r.pop('source_path')).name
 elif kind=='qualitative':
  rows=source(Path('coding/codes.csv'));coders={r.get('coder_id')for r in rows}
  if coder is None and len(coders)>1:raise ValueError('multiple coders: explicitly choose --coder')
  coder=coder or next(iter(coders),None);rows=[r for r in rows if r.get('coder_id')==coder]
  audit=read_json(w/'coding/code_audit.json',{})
  if not(audit.get('pass')or(allow_partial and audit.get('integrity_pass')))or audit.get('coder')!=coder:raise ValueError('run audit_codes.py (partial: --allow-incomplete) for the selected coder before export')
  if audit.get('codebook_file_sha256') and audit['codebook_file_sha256']!=hashlib.sha256((w/'coding/codebook.yaml').read_bytes()).hexdigest():raise ValueError('codebook changed after audit')
  from .coding_dependencies import bindings
  if audit.get('source_bindings') is not None and audit['source_bindings']!=bindings(w):raise ValueError('coding sources changed after audit')
  if audit.get('codes_file_sha256')!=hashlib.sha256((w/'coding/codes.csv').read_bytes()).hexdigest():raise ValueError('codes changed after audit')
  coverage_path=w/'coding/coverage.csv'
  if coverage_path.exists():
   if audit.get('coverage_file_sha256')!=hashlib.sha256(coverage_path.read_bytes()).hexdigest():raise ValueError('coding coverage changed; rerun audit_codes.py')
   coverage=source(Path('coding/coverage.csv'));existing={(r['cik'],str(r['fy']),r['var_id']):r for r in rows}
   for c in coverage:
    if(c['cik'],str(c['fy']),c['var_id'])not in existing:
     rows.append({**c,'value':None,'coding_status':c['coverage_status'],'rationale':c.get('reason')or'construct not yet prepared; no judgment made'})
    else:
     record=existing[(c['cik'],str(c['fy']),c['var_id'])]
     for key in ['company','coverage_status','codebook_status','time_basis']:record[key]=c.get(key)
   meta.update(coding_coverage=audit.get('coding_coverage'))
  metric={(r['cik'],str(r['fy'])):r for r in read_csv(w/'derived/metrics/lexical.csv')}
  roles=read_json(w/'coding/coders.json',{});role=roles.get(coder,{})
  registry={(str(r['cik']),str(r['fy']),r['var_id']):r for r in read_json(w/'coding/source_registry.json',{}).get('records',[])}
  for r in rows:
   r['source_scope_basis']=registry.get((str(r['cik']),str(r['fy']),r['var_id']),{}).get('scope_basis','unregistered')
   r['coder_kind']=role.get('kind','unspecified');r['independence_status']='declared independent; verify actual procedure'if role.get('independent')else'not established as independent human coding'
   for k in ['n_words','ai_mentions','ai_mentions_per_10k','ai_measure_version']:r[k]=metric.get((r['cik'],str(r['fy'])),{}).get(k)
   if not r.get('coding_status'):r['coding_status']='abstained'if r.get('value')in ['',None]else'coded; provenance checked, semantic judgment still subject to review'
  meta.update(coder=coder,abstentions=sum(r.get('coding_status')=='abstained'for r in rows),reliability=read_json(w/'coding/reliability.json',{}).get('per_variable',{}))
  status='coding_results; distinguish human/model/dictionary coders and pre-adjudication reliability'
 elif kind=='quantitative':
  rows=source(Path('analysis/analysis.csv'));derived=read_json(w/'analysis/derivation_meta.json',{})
  state=read_json(w/'analysis/last_derivation.json',{})
  if state.get('status')!='complete' or derived.get('analysis_sha256')!=hashlib.sha256((w/'analysis/analysis.csv').read_bytes()).hexdigest():raise ValueError('analysis generation failed, is incomplete, or predates output binding; rerun derive_variables.py')
  for entry in derived.get('input_files',[]):
   path=Path(entry['path'])
   if not path.is_file()or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:raise ValueError('analysis input changed after derivation; regenerate analysis')
  meta.update(coding_provenance=derived.get('coding_provenance'),measurement_policy=derived.get('measurement_policy'))
  for r in rows:
   r['analysis_scope']=derived.get('analysis_scope','legacy_unspecified')
   nr=derived.get('numeric_review',{});r['research_review_status']='strict passed'if nr.get('strict_release_pass')else str(nr.get('pending_research_cells','unknown'))+' research cells still require review'
  meta.update(numeric_review=derived.get('numeric_review'))
  status='derived_analysis; causal identification and model-specific inference are separate'
 elif kind=='salary':
  rows=source(Path('exports/salary_records.csv'));manifest=read_json(w/'exports/manifest.json',{});validation=read_json(w/'exports/validation.json',{})
  if not validation.get('pass'):
   coverage_only=all(i.get('check')in {'query_unresolved','partial_export','queries_removed_from_active_plan','original_scope_not_verified'}for i in validation.get('issues',[]))
   if not allow_partial or not coverage_only:raise ValueError('salary verify must pass; use --allow-partial only for inspectable coverage gaps, never stale or altered sources')
  meta.update(scope_coverage=validation.get('scope_coverage'),validation_pass=validation.get('pass'))
  for r in rows:r['query_scope_basis']=validation.get('scope_coverage',{}).get('scope_assurance','legacy_unverified')
  if hashlib.sha256((w/'exports/salary_records.csv').read_bytes()).hexdigest()!=manifest.get('hashes',{}).get('salary_records.csv'):raise ValueError('salary rows changed since verified export')
  db=sqlite3.connect(w/'state.sqlite')
  current=dict(db.execute('select id,snapshot from queries'));db.close()
  if any(current.get(q)!=s for q,s in manifest.get('query_snapshots',{}).items()):raise ValueError('salary active snapshots changed; export and verify again')
  prov=[json.loads(line)for line in(w/'exports/provenance.jsonl').read_text().splitlines()if line.strip()]
  if len(prov)!=len(rows):raise ValueError('posting/provenance row count differs')
  for r,p in zip(rows,prov):
   r.update(posting_id=p['posting_id'],query_id=p['query_id'],source_url=p['source_url'],retrieved_at=p['retrieved_at'],processed_at=p.get('processed_at'),collection_mode=p.get('collection_mode'),as_of=p.get('as_of'),html_sha256=p['html_sha256'],field_status=json.dumps(p['field_status'],ensure_ascii=False))
  meta.update(queries=manifest['queries'],field_coverage=read_json(w/'exports/field_coverage.json',{}))
  status=('complete for selected plan only'if validation.get('pass')else'PARTIAL; unresolved query scope remains')+'; company sample_size repeats across posting rows'
 else:raise ValueError('unknown skill result')
 if kind in {'tracker','qualitative','quantitative'}:
  from .release_check import check_release
  release=check_release(w,kind,coder)
  meta['full_research_release']=release
  if not release['pass'] and not allow_partial:
   raise ValueError('full research is incomplete; finish listed tasks or explicitly --allow-partial for inspection: '+str(release['issues'][:5]))
  if not allow_partial and not inspection['completion_pass']:raise ValueError('self_audit completion is pending; complete repair tasks or explicitly export a partial inspection')
  if not release['pass']or not inspection['completion_pass']:status='PARTIAL inspection; '+status
 if kind in {'tracker','quantitative'}:
  gaps=[r for r in coverage_rows if r['status']!='annual_anchor_available']
  if kind=='tracker':
   profile=read_json(Path(__file__).parent/'research_profile.json')
   for gap in gaps:
    for definition in profile['company_year_variables']:
     rows.append({**{k:gap.get(k)for k in ['cid','cik','company','ticker','fy']},'var_id':definition['var_id'],'kind':definition.get('kind'),'numeric_value':None,'narrative_value':None,'status':gap['status'],'note':gap['reason'],'source_coverage_status':gap['status']})
  else:
   for gap in gaps:rows.append({**{k:gap.get(k)for k in ['cid','cik','company','ticker','fy']},'source_coverage_status':gap['status'],'research_review_status':gap['reason'],'analysis_scope':'unavailable_source_placeholder'})
 if not rows:raise ValueError('no result records; do not manufacture rows to claim completion')
 layout=layout or('wide'if kind in {'tracker','qualitative'}else'native')
 if kind in {'tracker','qualitative'}and layout=='wide':
  from .company_year import widen
  typed=[{k:infer(k,v)for k,v in r.items()}for r in rows]
  rows,shape=widen(kind,typed,company_years=coverage_rows,metrics=[{k:infer(k,v)for k,v in m.items()}for m in read_csv(w/'derived/metrics/lexical.csv')])
  meta.update(shape)
  for r in rows:r['result_stage']=status
  columns=list(dict.fromkeys(k for r in rows for k in r))
  meta.update(logical_records=len(rows),physical_rows=len(rows),numeric_values_on_first_text_part_only=False)
  from .output_templates import bind
  return bind({'columns':columns,'rows':[[r.get(k)for k in columns]for r in rows],'metadata':meta,'source_files':sources},kind)
 if layout not in {'long','native'}:raise ValueError('unsupported result layout for '+kind)
 meta['result_layout']='variable_long'if kind in {'tracker','qualitative'}else'native'
 prepared=[]
 for record_index,r in enumerate(rows,1):
  r={k:infer(k,v)for k,v in r.items()};r['result_stage']=status
  textcols=[k for k,v in r.items()if isinstance(v,str)and len(v)>1000]
  pieces={k:split_text(r[k])for k in textcols};count=max([len(p)for p in pieces.values()]or[1])
  for i in range(count):
   row={**r,'__record_id':record_index,'__text_part':i+1,'__text_parts':count}
   for k,part in pieces.items():row[k]=part[i]if i<len(part)else None
   if i:
    for k,v in list(row.items()):
     if isinstance(v,(int,float))and k not in NUMERIC_IDS and not k.startswith('__'):row[k]=None
   prepared.append(row)
 columns=list(dict.fromkeys(k for r in prepared for k in r))
 if kind=='tracker':
  leading=['cik','company','fy','var_id','numeric_value','narrative_value','unit','status']
  columns=[k for k in leading if k in columns]+[k for k in columns if k not in leading]
 meta.update(logical_records=len(rows),physical_rows=len(prepared),numeric_values_on_first_text_part_only=True)
 from .output_templates import bind
 return bind({'columns':columns,'rows':[[r.get(k)for k in columns]for r in prepared],'metadata':meta,'source_files':sources},kind)

def main(kind,argv=None):
 p=argparse.ArgumentParser(description='Prepare one typed result table; no workbook or data source is overwritten')
 p.add_argument('--verbose',action='store_true');p.add_argument('--work',required=True);p.add_argument('--payload',required=True);p.add_argument('--coder');p.add_argument('--allow-partial',action='store_true');p.add_argument('--layout',choices=['wide','long'],help='tracker/qualitative default wide; explicit long is for evidence interoperability');a=p.parse_args(argv)
 payload=prepare(kind,a.work,a.coder,a.allow_partial,a.layout);write_json(a.payload,payload)
 summary={k:payload['metadata'].get(k)for k in ['skill','result_layout','logical_records','physical_rows','company_years','variable_slots_expected','variable_records_preserved']};summary.update(columns=len(payload['columns']),payload=a.payload,self_audit=payload['metadata'].get('self_audit'),full_release_pass=payload['metadata'].get('full_research_release',{}).get('pass'))
 print(json.dumps(payload['metadata']if a.verbose else summary,ensure_ascii=False,indent=2));return 0
