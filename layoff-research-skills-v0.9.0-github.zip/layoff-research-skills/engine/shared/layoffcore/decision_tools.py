"""Bind supplied judgments and diagnose format errors; never generate semantic decisions."""
from pathlib import Path
import argparse,json,hashlib
from .io import read_csv,write_json
from .source_cache import SourceCache
from .measurement_review import certify,CONTRACT_PATH
from .numbers import parse_amount


def load_rows(path):
    text=Path(path).read_text(encoding='utf-8-sig')
    rows=json.loads(text)if text.lstrip().startswith('[')else[json.loads(l)for l in text.splitlines()if l.strip()]
    if not isinstance(rows,list)or any(not isinstance(r,dict)for r in rows):raise ValueError('Expected a JSON array or JSONL of objects')
    return rows


def key(row):
    cik=str(row['cik'])
    if not cik.isdigit()or not 1<=len(cik)<=10:raise ValueError('cik must contain1:10 digits')
    return cik.zfill(10),int(row['fy']),row['var_id']


def guide():
    return {'source_review':{'command':'decision_tools.py bind-source --work W --judgments judgments.jsonl --tasks W/review/review_tasks.jsonl --output decisions.json; then review.py --work W --decisions decisions.json','minimal_judgment':{'cik':'0000000001','fy':2025,'var_id':'training_investment','decision':'accept','reason':'Actual source-based reason','criterion_application':'How the supplied source meets this variable definition','support_quote':'Exact qualifying quotation of at least30 characters'},'reject_requires':'scope_reviewed:true only after actual complete source reading; helper fills exact scope/hash, never the substantive reason','resolve_requires':'explicit value, unit, period and support_quote; do not change a number merely to pass'},'coding':{'command':'submit_decisions.py --work W --decisions coding.jsonl --coder A --coder-kind model --apply','required':'code_id,value,rationale; positive quote/absolute offset; negative reviewed_scope and challenge_resolutions; null with na_reason','note':'review_bundle only delivers source material; it does not apply decisions'},'measurement':{'command':'review_measurements.py --work W --panel analysis/measurement_input.csv --decisions measurements.json --check-only','required':'cik,fy,var_id,decision,value,reason,source_path,source_sha256,quote','severance_accept_additional':'source_year,scope=company_total,period_basis,amount_raw; value uses original measurement contract, never change the number to satisfy the parser','note':'All-row preflight reports every error before the normal unchanged certifier runs.'},'second_review':{'command':'decision_tools.py bind-second --work W --judgments second.jsonl --output second-bound.json; combine reviewed group outputs into review/self_review_decisions.json','required':'code_id,decision=keep_verified,reviewed_again=true,reviewer_kind,criterion_application; actual second source reading required','note':'Current record hash and source hash are checked; the helper does not invent a review'},'semantic_judgments_generated':False}


def bind_source(work,judgments,tasks):
    w=Path(work).resolve();catalog={};errors=[];output=[];seen=set();cache=SourceCache();texts={}
    for raw in tasks:
        if raw.get('category')and raw['category']!='source_review':continue
        r=raw.get('record',raw);k=key(r)
        if k in catalog:raise ValueError('Duplicate source task identity: '+str(k))
        catalog[k]=r
    for n,d in enumerate(judgments,1):
        try:
            k=key(d)
            if k in seen:raise ValueError('duplicate judgment')
            seen.add(k);task=catalog[k];decision=d.get('decision')
            if decision not in {'accept','reject','resolve'}or not d.get('reason'):raise ValueError('decision and specific reason required')
            criterion=d.get('criterion_application')or(d.get('semantic_review')or{}).get('criterion_application')
            if not str(criterion or'').strip():raise ValueError('Actual criterion_application required; metadata is not judgment')
            source=Path(task.get('source_path')or'');source=source if source.is_absolute()else w/source
            if not source.resolve().is_relative_to(w)or not source.is_file():raise ValueError('source unavailable or outside work')
            doc=cache.read(source)
            if doc['sha256']!=task.get('source_sha256'):raise ValueError('source hash changed; regenerate source tasks')
            if str(source)not in texts:
                from .textutil import html_to_text
                texts[str(source)]=html_to_text(doc['text'])
            text=texts[str(source)];definition=task.get('definition')
            dh=hashlib.sha256(json.dumps(definition,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
            if dh!=task.get('expected_definition_sha256'):raise ValueError('task definition binding missing or changed')
            row={name:d[name]for name in ['decision','reason','value','unit','period','support_quote']if name in d}
            row.update(cik=k[0],fy=k[1],var_id=k[2],source_sha256=doc['sha256'],semantic_review={'definition_sha256':dh,'basis':'source_context_and_definition','criterion_application':criterion})
            quote=d.get('support_quote')
            if quote and(len(quote)<30 or quote not in text):raise ValueError('support_quote must match at least30 exact source characters')
            if decision=='reject':
                bounds=task.get('expected_reviewed_scope')
                if not bounds:raise ValueError('review scope unavailable')
                if d.get('scope_reviewed')is not True and d.get('reviewed_scope')!=bounds:raise ValueError('Actual full-scope reading must be explicitly attested')
                lo,hi=bounds;digest=hashlib.sha256(text[lo:hi].encode()).hexdigest()
                if digest!=task.get('expected_scope_sha256'):raise ValueError('scope changed; regenerate tasks')
                row.update(reviewed_scope=bounds,scope_sha256=digest)
            if decision=='resolve':
                if d.get('value')in [None,'']or not d.get('unit')or not d.get('period')or not quote:raise ValueError('resolve requires explicit value,unit,period,support_quote')
            if decision=='accept'and task.get('value')in [None,'']and not quote:raise ValueError('Empty candidate needs an actual support_quote')
            if decision=='accept'and task.get('status')in {'reference_conflict_needs_review','numeric_source_unresolved','numeric_period_needs_review'}:raise ValueError('Numeric conflict requires resolve or scoped reject')
            output.append(row)
        except (KeyError,ValueError,TypeError,OSError)as exc:errors.append({'row':n,'identity':{k:d.get(k)for k in ['cik','fy','var_id']},'reason':str(exc)})
    return output,{'pass':not errors,'judgments':len(judgments),'bound':len(output),'errors':errors,'semantic_judgments_generated':False,'validation_scope':'source/format binding only; the existing review engine still applies construct and candidate checks'}


def bind_second(work,judgments,coder='A'):
    from .review_bundle import record_hash
    w=Path(work).resolve();task_file=w/'qa/semantic_review_tasks_qualitative.jsonl'
    if not task_file.is_file():task_file=w/'qa/semantic_review_tasks_tracker.jsonl'
    tasks={r['code_id']:r for r in load_rows(task_file)}
    codes={r['code_id']:r for r in read_csv(w/'coding/codes.csv')if r.get('coder_id')==coder};out=[];errors=[];seen=set();cache=SourceCache()
    for n,d in enumerate(judgments,1):
        try:
            cid=d['code_id']
            if cid in seen:raise ValueError('duplicate second review')
            seen.add(cid);task=tasks[cid];row=codes[cid]
            if d.get('decision')!='keep_verified'or d.get('reviewed_again')is not True:raise ValueError('Explicit actual second-reading attestation required')
            if not d.get('criterion_application')or not d.get('reviewer_kind'):raise ValueError('Specific criterion_application and reviewer_kind required')
            digest=record_hash(row)
            if digest!=task.get('expected_record_sha256'):raise ValueError('Coding record changed; regenerate this second-review task')
            path=(w/row['text_path']).resolve()
            if not path.is_relative_to(w)or cache.read(path)['sha256']!=row['text_sha256']:raise ValueError('Source changed or unavailable')
            out.append({'code_id':cid,'record_sha256':digest,'decision':'keep_verified','criterion_application':d['criterion_application'],'reviewer_kind':d['reviewer_kind']})
        except(KeyError,ValueError,TypeError,OSError)as exc:errors.append({'row':n,'code_id':d.get('code_id'),'reason':str(exc)})
    return out,{'pass':not errors,'judgments':len(judgments),'bound':len(out),'errors':errors,'semantic_judgments_generated':False}


def measurement_preflight(work,panel,decisions,contract=CONTRACT_PATH):
    warnings=[]
    result=certify(work,panel,decisions,contract,collect_errors=True)
    errors=result.get('errors',[])
    for error in errors:
        d=decisions[error['row']-1];error['identity']={k:d.get(k)for k in ['cik','fy','var_id']}
        if d.get('var_id')=='severance'and d.get('decision')=='accept':
            raw=d.get('amount_raw','');parsed,ccy,_=parse_amount(raw)if isinstance(raw,str)else(None,'UNKNOWN','')
            error.update(amount_raw=d.get('amount_raw'),parsed_amount_by_current_contract=parsed,submitted_value=d.get('value'),parsed_currency=ccy)
    for n,d in enumerate(decisions,1):
        raw=d.get('amount_raw','')
        if d.get('var_id')=='severance'and d.get('decision')=='accept'and isinstance(raw,str)and raw and not any(word in raw.lower()for word in ['thousand','million','billion','mn','bn']):
            warnings.append({'row':n,'check':'bare_amount_scale_not_in_raw','note':'Confirm table-header units; parser output alone does not establish base currency. No value is changed.'})
    return {'pass':not errors,'decisions':len(decisions),'errors':errors,'warnings':warnings,'values_changed':False,'semantic_judgments_generated':False,'measurement_contract_unchanged':True}


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('guide')
    a=sub.add_parser('bind-source');a.add_argument('--work',required=True);a.add_argument('--judgments',required=True);a.add_argument('--tasks');a.add_argument('--output',required=True)
    a=sub.add_parser('bind-second');a.add_argument('--work',required=True);a.add_argument('--judgments',required=True);a.add_argument('--output',required=True);a.add_argument('--coder',default='A')
    a=sub.add_parser('combine');a.add_argument('--kind',choices=['source','coding','second','measurement'],required=True);a.add_argument('--files',nargs='+',required=True);a.add_argument('--output',required=True)
    a=sub.add_parser('check-measurements');a.add_argument('--work',required=True);a.add_argument('--panel',default='analysis/measurement_input.csv');a.add_argument('--decisions',required=True);a.add_argument('--out')
    a=p.parse_args(argv)
    if a.command=='guide':print(json.dumps(guide(),ensure_ascii=False,indent=2));return 0
    if a.command=='combine':
        rows=[r for path in a.files for r in load_rows(path)];seen=set()
        for r in rows:
            identity=key(r)if a.kind in {'source','measurement'}else r['code_id']
            if identity in seen:raise ValueError('Duplicate decision while combining: '+str(identity))
            seen.add(identity)
        write_json(a.output,rows);print(json.dumps({'combined':len(rows),'output':a.output,'judgments_changed':False}));return 0
    if a.command in {'bind-source','bind-second'}:
        if a.command=='bind-source':records,report=bind_source(a.work,load_rows(a.judgments),load_rows(a.tasks or Path(a.work)/'review/review_tasks.jsonl'))
        else:records,report=bind_second(a.work,load_rows(a.judgments),a.coder)
        report_path=Path(a.output).with_suffix('.preflight.json')
        if report['pass']:
            write_json(a.output,records);report['output_sha256']=hashlib.sha256(Path(a.output).read_bytes()).hexdigest()
        report['existing_output_kept']=not report['pass']and Path(a.output).is_file()
        write_json(report_path,report)
        print(json.dumps({'pass':report['pass'],'bound':report['bound'],'errors':report['errors'][:10],'full_report':str(report_path),'output_written':report['pass'],'semantic_judgments_generated':False},ensure_ascii=False));return 0 if report['pass']else 2
    w=Path(a.work);panel=Path(a.panel);panel=panel if panel.is_absolute()else w/panel
    report=measurement_preflight(w,panel,load_rows(a.decisions));target=Path(a.out)if a.out else w/'qa/measurement_preflight.json';write_json(target,report)
    print(json.dumps(report,ensure_ascii=False,indent=2));return 0 if report['pass']else 2
