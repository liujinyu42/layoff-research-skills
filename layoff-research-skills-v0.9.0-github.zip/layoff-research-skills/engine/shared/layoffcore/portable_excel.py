"""Render the typed payload with the host artifact runtime, falling back only if absent."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys

def fallback(payload,target):
    import openpyxl
    from openpyxl.styles import Font,Alignment,PatternFill
    from openpyxl.worksheet.table import Table,TableStyleInfo
    from openpyxl.utils import get_column_letter
    book=openpyxl.Workbook();sheet=book.active;sheet.title='结果';sheet.sheet_view.showGridLines=False
    columns=payload['columns'];sheet.append(columns);wide=payload.get('metadata',{}).get('result_layout')=='company_year_wide';mainvars=set(payload.get('metadata',{}).get('variables',[]))
    dates={'retrieved_at','processed_at','created_at','filed','period','event_date','plan_date'}
    for values in payload['rows']:
        row=[]
        for name,value in zip(columns,values):
            if name in dates and isinstance(value,str):
                try:
                    d=datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
                    value=d.astimezone(datetime.timezone.utc).replace(tzinfo=None)if d.tzinfo else d
                except ValueError:pass
            if isinstance(value,str)and value.startswith('='):value="'"+value
            row.append(value)
        sheet.append(row)
    for cell in sheet[1]:
        cell.font=Font(name='Arial',size=10,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='253D5B');cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    sheet.row_dimensions[1].height=48
    for i,name in enumerate(columns,1):
        width=16 if name=='cik'else 10 if name in {'fy','year','cid'}else 75 if any(x in name for x in ['quote','narrative','rationale','note','status','stage','definition'])else 35 if name.endswith('_id')else 24
        if wide:width=30 if name=='company'else 10 if name=='fy'else 16 if name=='cik'else 12 if name=='ticker'else 56 if name in mainvars else 72 if'evidence_json'in name else 70 if any(k in name for k in ['quote','rationale'])else 40 if any(k in name for k in ['status','reason'])else 24
        sheet.column_dimensions[get_column_letter(i)].width=width
        for cell in sheet.iter_cols(min_col=i,max_col=i,min_row=2):
            for c in cell:
                c.font=Font(name='Arial',size=10);c.alignment=Alignment(vertical='top',wrap_text=width>=35)
                if isinstance(c.value,datetime.datetime):c.number_format='yyyy-mm-dd hh:mm:ss'
                elif name in {'fy','year','cid','__record_id','__text_part','__text_parts'}:c.number_format='0'
                elif name in {'cik','accession'}or name.endswith(('_id','sha256')):c.number_format='@'
                elif isinstance(c.value,(int,float)):c.number_format='#,##0.00'if isinstance(c.value,float)and not c.value.is_integer()else'#,##0'
    table=Table(displayName='SkillResult',ref=f'A1:{get_column_letter(len(columns))}{sheet.max_row}');table.tableStyleInfo=TableStyleInfo(name='TableStyleLight9',showRowStripes=True);sheet.add_table(table);sheet.freeze_panes='E2'if wide else'A2'
    if wide:
        for i in range(2,sheet.max_row+1):sheet.row_dimensions[i].height=90
    target.parent.mkdir(parents=True,exist_ok=True);book.save(target)

def main(argv=None,script=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--verbose',action='store_true');a=p.parse_args(argv);payload=json.loads(Path(a.input).read_text())
    if not payload.get('columns')or not payload.get('rows'):raise ValueError('no result records; do not manufacture success rows')
    for source in payload.get('source_files',[]):
        if hashlib.sha256(Path(source['path']).read_bytes()).hexdigest()!=source['sha256']:raise ValueError('payload source changed; regenerate it')
    target=Path(a.output);node=shutil.which('node');entry=Path(script).with_name('export_excel.mjs')if script else None
    available=False
    if node and entry and entry.is_file():
        if os.environ.get('ARTIFACT_NODE_MODULES'):available=True
        else:available=subprocess.run([node,'--input-type=module','-e',"await import('@oai/artifact-tool')"],capture_output=True).returncode==0
    if available:
        subprocess.run([node,str(entry),'--input',a.input,'--output',a.output]+(['--verbose']if a.verbose else[]),check=True);engine='host_artifact_tool'
    else:
        fallback(payload,target);engine='openpyxl_fallback_host_artifact_runtime_absent'
    from .delivery_audit import audit
    checked=audit(payload,target)
    if not checked['pass']:raise ValueError('saved workbook differs from typed payload: '+str(checked['issues']))
    print(json.dumps({'engine':engine,'file':str(target),'saved_value_audit':checked},ensure_ascii=False));return 0
