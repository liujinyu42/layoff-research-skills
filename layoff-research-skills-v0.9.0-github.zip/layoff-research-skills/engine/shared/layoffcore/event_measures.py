"""Preserve bounds and subgroup denominators before constructing exact annual measures."""
from __future__ import annotations
import json,re

def measurement_context(quote, raw):
    pos = str(quote).find(str(raw)); prefix = str(quote)[max(0,pos-50):pos] if pos >= 0 else ''
    near = prefix + str(raw)
    qualifier = 'exact'
    if re.search(r'more\s+than|over\s+\d', near, re.I): qualifier='lower_bound_exclusive'
    elif re.search(r'at\s+least',near,re.I): qualifier='lower_bound_inclusive'
    elif re.search(r'up\s+to|at\s+most|less\s+than',near,re.I): qualifier='upper_bound'
    elif re.search(r'\d[\d,]*\s*(?:-|to|and)\s*\d',str(raw)): qualifier='range'
    elif re.search(r'approximately|about|around|nearly|estimated',near,re.I): qualifier='approximate'
    subgroup = bool(re.search(r'recruiting\s+staff|(?:recruiting|customer\s+support|sales|engineering)\s+teams?|segment\s+of|division|department',str(quote),re.I))
    scope='subgroup' if subgroup else 'company_workforce' if re.search(r'(?:global\s+)?workforce|reduction\s+in\s+force|our\s+(?:team|employees)|company.s\s+(?:team|employees)',str(quote),re.I) else 'unspecified'
    return {'qualifier':qualifier,'denominator_scope':scope}

def analysis_measure(row, field):
    proof=row.get('measurement_evidence') or {}
    if isinstance(proof,str): proof=json.loads(proof)
    if not isinstance(proof,dict): proof={}
    sources=row.get('measure_sources') or {}
    if isinstance(sources,str): sources=json.loads(sources)
    if not isinstance(sources,dict): sources={}
    m=proof.get(field) or sources.get(field) or {}
    context=measurement_context(m.get('quote') or m.get('evidence') or row.get('evidence',''),m.get('raw',''))
    context.update({k:m[k] for k in ['qualifier','denominator_scope'] if m.get(k)})
    if context['qualifier'] not in {'exact','approximate'}:
        return None, 'bound_or_range_not_an_exact_point'
    if field=='layoff_pct_num' and context['denominator_scope']!='company_workforce':
        return None, 'subgroup_or_unspecified_denominator'
    return row.get(field), ''
