"""Short-lived file reads shared within one audit; edits invalidate the entry."""
from pathlib import Path
import hashlib

def decode_text(data):
    # Match Path.read_text universal-newline behavior without changing byte hashes.
    return data.decode('utf-8').replace('\r\n','\n').replace('\r','\n')

class SourceCache:
    def __init__(self):self.entries={};self.reads=0;self.hits=0
    def read(self,path,text=True):
        path=Path(path);s=path.stat();signature=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        key=str(path.resolve());entry=self.entries.get(key)
        if entry and entry['signature']==signature:
            self.hits+=1
            if text and 'text'not in entry:entry['text']=decode_text(entry['data'])
            return entry
        data=path.read_bytes();self.reads+=1
        entry={'signature':signature,'sha256':hashlib.sha256(data).hexdigest(),'data':data,'bytes':len(data)}
        if text:entry['text']=decode_text(data)
        self.entries[key]=entry;return entry

def document(path,context):
    if '_documents'not in context:context['_documents']=SourceCache()
    return context['_documents'].read(path)
