"""共享契约层：状态枚举、缺失码、字段定义。

三个 skill 都从此处取枚举，禁止各自定义同义状态。这是整个仓库唯一的"口径源头"。
"""

from __future__ import annotations

from enum import Enum

TOOL_VERSION = "0.8.3"

# ---------------------------------------------------------------- 采集状态

class TaskStatus(str, Enum):
    """单个 (cik, fy, form) 采集单元的状态。

    只有 PARSED 会进入正式面板；其余状态必须在导出时显式解释，绝不静默丢弃。
    """

    PENDING = "pending"            # 已登记，未请求
    FETCHED = "fetched"            # 已取得索引/提交清单
    DOWNLOADED = "downloaded"      # 原文已落盘并校验哈希
    PARSED = "parsed"              # 已解析并写入证据
    QA_FAILED = "qa_failed"        # 硬质量门槛失败，禁止导出
    FAILED = "failed"              # 网络/解析异常，可重试
    INCOMPLETE = "incomplete"      # 缓存不全或任务未完成，不可解释为"无披露"
    SKIPPED = "skipped"            # 明确排除（如窗口外、非目标表单）


TERMINAL_OK = {TaskStatus.PARSED}
TERMINAL_BAD = {TaskStatus.FAILED, TaskStatus.QA_FAILED, TaskStatus.INCOMPLETE}


# ---------------------------------------------------------------- 缺失码

class NA(str, Enum):
    """单元格缺失的语义码。区分它们是本仓库与普通爬虫的主要差别。"""

    NOT_DISCLOSED = "not_disclosed"
    """已取得可解析来源，规则未发现对应披露。仍有漏检可能。"""

    NOT_SEPARATE = "not_separately_reported"
    """原表未设对应小计/字段，不能用其他口径替代。"""

    EXTRACTION_ERROR = "extraction_error"
    """章节定位失败或单变量抽取异常，需人工检查。"""

    NOT_CHECKED = "not_checked"
    """未查询（窗口外、公司未入样本、任务未启动）。"""

    INCOMPLETE = "incomplete_cache"
    """缓存不全、索引缺失，无法判定是否披露。"""

    PERIOD_MISMATCH = "period_mismatch"
    """候选数值所属期间与当前财年不一致（如把上年比较数记入本年）。"""

    COMPONENT_ONLY = "component_only"
    """仅命中费用分项（如销售费用中的遣散费），未找到公司级总额。"""

    AMBIGUOUS_PERIOD = "ambiguous_period"
    """存在多个期间，金额尚未与年度列或明确期间绑定。"""

    REQUIRES_CODING = "requires_coding"
    """确定性规则不适用，交由质性编码 skill 填写。"""


NA_EXPLAIN_ZH = {
    NA.NOT_DISCLOSED: "未披露（已核验来源，规则未命中）",
    NA.NOT_SEPARATE: "未单列/不适用",
    NA.EXTRACTION_ERROR: "提取异常",
    NA.NOT_CHECKED: "未查询",
    NA.INCOMPLETE: "缓存不全，结果未知",
    NA.REQUIRES_CODING: "需质性编码",
    NA.PERIOD_MISMATCH: "期间错配（候选值属于其他财年）",
    NA.COMPONENT_ONLY: "仅分项金额，非公司级总额",
    NA.AMBIGUOUS_PERIOD: "期间不明确，需按年度列或原文复核",
}


# ---------------------------------------------------------------- 变量来源类型

class VarSource(str, Enum):
    XBRL = "xbrl"      # 由 XBRL 事实直接取数
    RULE = "rule"      # 由文本正则/规则抽取
    CODE = "code"      # 需质性编码（含判断成分）


# ---------------------------------------------------------------- 证据模型

EVIDENCE_COLUMNS = [
    "evidence_id",
    "cid",
    "cik",
    "fy",
    "var_id",
    "value_raw",
    "value_num",
    "unit",
    "currency",
    "source_type",     # text | xbrl | table | notice
    "form",
    "accession",
    "section",
    "char_start",
    "char_end",
    "quote",
    "confidence",      # high | medium | low
    "extractor",
    "extractor_version",
    "created_at",
]

# ---------------------------------------------------------------- 面板契约

PANEL_KEY = ["cid", "cik", "fy"]

PANEL_LONG_COLUMNS = [
    "cid",
    "cik",
    "company",
    "ticker",
    "fy",
    "var_id",
    "value",
    "value_type",      # num | flag | text
    "unit",
    "na_code",
    "source_type",
    "evidence_id",
    "form",
    "accession",
    "period",
]

# ---------------------------------------------------------------- 裁员事件契约

EVENT_COLUMNS = [
    "event_id",
    "source",          # sec_8k | sec_6k | warn
    "cid",
    "cik",
    "company",
    "ticker",
    "accession",
    "form",
    "filed",
    "event_date",
    "item_codes",
    "layoff_count_num",
    "layoff_pct_num",
    "severance_amount",
    "severance_currency",
    "severance_usd",
    "severance_raw",
    "evidence_id",
    "evidence",
    "confidence",
    "extractor_version",
]

# ---------------------------------------------------------------- 编码契约

CODE_COLUMNS = [
    "code_id",
    "cik",
    "fy",
    "var_id",
    "coder_id",
    "value",
    "value_label",
    "char_start",
    "char_end",
    "quote",
    "rationale",
    "confidence",
    "pass_id",
    "created_at",
]

# ---------------------------------------------------------------- 目录契约

WORK_DIRS = [
    "config",
    "raw/docs",
    "cache",
    "state/runs",
    "derived/texts",
    "derived/metrics",
    "panel",
    "events",
    "revisions",
    "coding/batches",
    "coding/out",
    "analysis",
    "logs",
]
