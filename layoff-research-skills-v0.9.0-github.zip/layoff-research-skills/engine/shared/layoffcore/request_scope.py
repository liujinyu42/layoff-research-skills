"""Bind expected company-years to the supplied roster rather than extracted successes."""
from pathlib import Path
import hashlib,json,re
from .io import read_csv,read_json,write_json

def check_scope(work,years):
    w=Path(work)
    if not re.fullmatch(r'\d{4}:\d{4}',years):raise ValueError('years must be YYYY:YYYY')
    first,last=map(int,years.split(':'))
    if first>last:raise ValueError('reversed fiscal-year range')
    roster=read_csv(w/'config/companies.csv');eligible=[];excluded=[]
    for r in roster:
        cik=str(r.get('cik')or'').strip()
        if cik.isdigit() and 0<int(cik)<10**10:eligible.append(cik.zfill(10))
        else:excluded.append({'company':r.get('company'),'reason':'no_valid_SEC_CIK; unsupported rather than a fabricated issuer'})
    expected={(c,str(y))for c in eligible for y in range(first,last+1)}
    panel=read_csv(w/'panel/panel_wide.csv');actual={(str(r['cik']).zfill(10),str(r['fy']))for r in panel}
    result={'pass':bool(expected)and expected==actual and len(actual)==len(panel),'years':years,'expected_company_years':len(expected),'actual_company_years':len(actual),'missing_company_years':sorted(expected-actual),'outside_scope':sorted(actual-expected),'non_SEC_rows':excluded,'companies_sha256':hashlib.sha256((w/'config/companies.csv').read_bytes()).hexdigest()}
    request=read_json(w/'research_request.json',{})
    result['roster_matches_request']=not request.get('companies_sha256')or request['companies_sha256']==result['companies_sha256']
    result['pass']=result['pass']and result['roster_matches_request']
    write_json(w/'qa/request_scope.json',result);return result
