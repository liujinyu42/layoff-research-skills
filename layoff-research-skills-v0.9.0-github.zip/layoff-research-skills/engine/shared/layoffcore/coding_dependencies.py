"""Files that determine the selected coding source and its current scope."""
from pathlib import Path
import hashlib
from .io import read_csv

def dependencies(work):
    w=Path(work);paths={w/p for p in ['coding/codebook.yaml','coding/source_registry.json','panel/panel_long.csv','panel/panel_meta.json']}
    for row in read_csv(w/'coding/codes.csv'):
        if row.get('accession'):paths.add(w/'derived/cells'/f"{row['accession']}.json")
        if row.get('text_path'):paths.add(w/row['text_path'])
    return sorted((p for p in paths if p.is_file()),key=str)

def bindings(work):
    w=Path(work).resolve()
    return [{'path':str(p.resolve().relative_to(w)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in dependencies(w)]

def binding_issues(work,rows):
    w=Path(work).resolve();issues=[]
    for row in rows:
        p=(w/row['path']).resolve()
        if not p.is_relative_to(w)or not p.is_file()or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
            issues.append({'check':'coding_source_selection_or_scope_changed','path':row['path']})
    return issues
