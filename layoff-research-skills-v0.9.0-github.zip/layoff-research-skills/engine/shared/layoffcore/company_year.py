"""Lossless, one-row-per-company-fiscal-year delivery for tracker and coding results."""
from __future__ import annotations
import json,math
from pathlib import Path
from .io import read_json

IDENTITY=['company','fy','ticker','cik']
METRICS=['n_words','ai_mentions','ai_mentions_per_10k','ai_measure_version']
LIMIT=30000  # below Excel's 32767 UTF-16 code-unit limit, including astral characters

def split_cell(text,limit=LIMIT):
 if limit<2:raise ValueError('text limit must accommodate a Unicode code point')
 result=[];part=[];units=0
 for char in text:
  size=2 if ord(char)>0xFFFF else 1
  if units+size>limit:
   result.append(''.join(part));part=[];units=0
  part.append(char);units+=size
 result.append(''.join(part));return result

def excel_columns(rows):
 """Split strings across columns; never introduce a second row for a firm-year."""
 maxima={}
 for row in rows:
  for name,value in list(row.items()):
   if not isinstance(value,str):continue
   parts=split_cell(value)
   if len(parts)==1:continue
   row[name]=parts[0];maxima[name]=max(maxima.get(name,1),len(parts))
   for n,part in enumerate(parts[1:],2):
    key=f'{name}__part_{n:03}'
    if key in row:raise ValueError('continuation column collision: '+key)
    row[key]=part
 return {name:[name]+[f'{name}__part_{n:03}'for n in range(2,nparts+1)]for name,nparts in maxima.items()}

def joined(row,name,continuations):
 return ''.join('' if row.get(k) is None else str(row[k])for k in continuations.get(name,[name]))

def widen(kind,records,*,company_years=(),metrics=(),profile=None):
 if kind not in {'tracker','qualitative'}:raise ValueError('company-year reshape supports tracker and qualitative')
 profile=profile or read_json(Path(__file__).parent/'research_profile.json')
 variables=([r['var_id']for r in profile['company_year_variables']]if kind=='tracker'else list(profile['required_coding_constructs']))
 variables+=sorted({r['var_id']for r in records}-set(variables))
 reserved=set(IDENTITY+METRICS+['result_stage'])|{v+'__'+suffix for v in variables for suffix in ['status','unit','quote','source_url','evidence_json','rationale','na_reason']}
 if set(variables)&reserved:raise ValueError('variable name conflicts with company-year provenance columns')
 groups={};identities={}
 def key(row):
  if row.get('cik') in [None,'']or row.get('fy') in [None,'']:raise ValueError('company-year identity missing')
  return str(row['cik']),int(row['fy'])
 for row in company_years:
  k=key(row);groups.setdefault(k,{})
  identities[k]={name:row.get(name)for name in IDENTITY}
 for row in records:
  k=key(row);var=row['var_id'];g=groups.setdefault(k,{})
  if var in g:raise ValueError('duplicate company-year variable; choose a coder/source before pivoting: '+str((k,var)))
  g[var]=dict(row);identities.setdefault(k,{name:row.get(name)for name in IDENTITY})
  for name in IDENTITY:
   value=row.get(name)
   if value in [None,'']:continue
   previous=identities[k].get(name)
   if previous not in [None,'']and str(previous)!=str(value):raise ValueError('conflicting company-year identity: '+str((k,name)))
   identities[k][name]=value
 metric_map={key(r):r for r in metrics};coverage_map={key(r):r for r in company_years};out=[];definitions={}
 for k,g in sorted(groups.items(),key=lambda item:(str(identities[item[0]].get('company')or item[0][0]),item[0][1])):
  row={**identities[k],'cik':k[0],'fy':k[1]};row['source_coverage_status']=coverage_map.get(k,{}).get('status');row['source_coverage_reason']=coverage_map.get(k,{}).get('reason')
  for var in variables:
   original=g.get(var)
   if original is None:
    row[var]=None;row[var+'__status']='not_prepared';row[var+'__unit']=None
    row[var+'__quote']=None;row[var+'__source_url']=None
    if kind=='qualitative':row[var+'__rationale']=None;row[var+'__na_reason']='not_prepared'
    row[var+'__evidence_json']=json.dumps({'var_id':var,'status':'not_prepared','value':None,'reason':'No judgment or extraction record for this requested position.'},ensure_ascii=False,sort_keys=True)
    continue
   if kind=='tracker':value=original.get('numeric_value')if original.get('kind')in {'number','flag'}else original.get('narrative_value')
   else:value=original.get('value')
   row[var]=value;row[var+'__status']=original.get('status')or original.get('coding_status')or original.get('coverage_status')or'not_prepared'
   row[var+'__unit']=original.get('unit')
   row[var+'__quote']=original.get('quote');row[var+'__source_url']=original.get('source_url')or original.get('text_path')
   # The complete original typed record is retained, including null/empty distinction,
   # period, units, scope, source hash, evidence and negative-search proof.
   row[var+'__evidence_json']=json.dumps(original,ensure_ascii=False,sort_keys=True,separators=(',',':'))
   if kind=='qualitative':row[var+'__rationale']=original.get('rationale');row[var+'__na_reason']=original.get('na_reason')
  observed=len(g);row['variable_positions_expected']=len(variables);row['variable_positions_present']=observed
  row['variable_positions_missing']=len(variables)-observed
  if kind=='qualitative':
   row['coder_id']=next((r.get('coder_id')for r in g.values()if r.get('coder_id')),None)
   row['coded_nonmissing']=sum(r.get('value')not in [None,'']for r in g.values())
   row['abstained_or_unjudged']=len(variables)-row['coded_nonmissing']
  for name in METRICS:
   values={str(r[name])for r in g.values()if r.get(name)not in [None,'']}
   if len(values)>1:raise ValueError('inconsistent company-year metric: '+str((k,name)))
   row[name]=metric_map.get(k,{}).get(name,next((r[name]for r in g.values()if r.get(name)not in [None,'']),None))
  out.append(row)
 # Main values first, then compact status/provenance columns. JSON details preserve all fields.
 leading=IDENTITY+variables+METRICS
 columns=leading+[name for row in out for name in row if name not in leading]
 columns=list(dict.fromkeys(columns));continuations=excel_columns(out)
 for names in continuations.values():columns.extend(n for n in names[1:]if n not in columns)
 if len(columns)>16384:raise ValueError('wide result exceeds Excel column limit; no data was silently truncated')
 for var in variables:definitions[var]={'status':var+'__status','unit':var+'__unit','quote':var+'__quote','source_url':var+'__source_url','full_record':var+'__evidence_json'}
 meta={'result_layout':'company_year_wide','record_grain':'company_fiscal_year','key_columns':['cik','fy'],'variables':variables,'company_years':len(out),'variable_slots_expected':len(out)*len(variables),'variable_records_preserved':len(records),'continuation_direction':'columns','cell_text_limit_utf16':LIMIT,'text_continuations':continuations,'field_map':definitions,'one_row_per_company_year':True}
 return [{name:row.get(name)for name in columns}for row in out],meta

def restore(rows,metadata):
 """Restore every original typed variable record from the delivered proof columns."""
 out=[];continuations=metadata.get('text_continuations',{})
 for row in rows:
  for var in metadata['variables']:
   raw=joined(row,var+'__evidence_json',continuations)
   if not raw:raise ValueError('missing full evidence record: '+var)
   record=json.loads(raw)
   if record.get('status')=='not_prepared'and record.get('reason')=='No judgment or extraction record for this requested position.':continue
   # A main value edited without its bound record is not an accepted source correction.
   value=record.get('numeric_value')if record.get('kind')in {'number','flag'}else record.get('narrative_value')if 'narrative_value'in record else record.get('value')
   actual=joined(row,var,continuations)if isinstance(value,str)else row.get(var)
   rounded_float=isinstance(value,float)and isinstance(actual,(float,int))and not isinstance(actual,bool)and math.isfinite(value)and math.isfinite(actual)and abs(actual-value)<=16*math.ulp(value)
   if actual!=value and not rounded_float and not(actual in [None,'']and value in [None,''])and not(isinstance(value,str)and value.startswith('=')and actual=="'"+value):raise ValueError('wide value differs from preserved evidence: '+var)
   out.append(record)
 return out
